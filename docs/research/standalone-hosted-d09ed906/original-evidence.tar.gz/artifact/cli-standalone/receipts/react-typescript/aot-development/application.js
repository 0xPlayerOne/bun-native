// @bun
var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  if (mod && typeof mod === "object" || typeof mod === "function") {
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
  }
  if (canCache)
    cache.set(mod, to);
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __esm = (fn, res, err) => () => {
  if (fn)
    try {
      res = fn(fn = 0);
    } catch (e) {
      err = [e];
    }
  if (err)
    throw err[0];
  return res;
};
var __exportCjs = (target, getters, setters) => {
  for (var name in getters)
    __defProp(target, name, {
      get: getters[name],
      set: setters[name],
      enumerable: true,
      configurable: true
    });
};

// ../projects/react-typescript/node_modules/react-reconciler/cjs/react-reconciler-constants.production.js
var require_react_reconciler_constants_production = __commonJS(function(exports) {
  exports.ConcurrentRoot = 1;
  exports.ContinuousEventPriority = 8;
  exports.DefaultEventPriority = 32;
  exports.DiscreteEventPriority = 2;
  exports.IdleEventPriority = 268435456;
  exports.LegacyRoot = 0;
  exports.NoEventPriority = 0;
});

// ../projects/react-typescript/node_modules/react-reconciler/constants.js
var require_constants = __commonJS(function(exports, module) {
  if (true) {
    module.exports = require_react_reconciler_constants_production();
  }
});

// ../projects/react-typescript/node_modules/react/cjs/react.production.js
var exports_react_production = {};
__exportCjs(exports_react_production, {
  Activity: () => $Activity,
  Children: () => $Children,
  Component: () => $Component,
  Fragment: () => $Fragment,
  Profiler: () => $Profiler,
  PureComponent: () => $PureComponent,
  StrictMode: () => $StrictMode,
  Suspense: () => $Suspense,
  ViewTransition: () => $ViewTransition,
  __CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE: () => $__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
  __COMPILER_RUNTIME: () => $__COMPILER_RUNTIME,
  addTransitionType: () => $addTransitionType,
  cache: () => $cache,
  cacheSignal: () => $cacheSignal,
  cloneElement: () => $cloneElement,
  createContext: () => $createContext,
  createElement: () => $createElement,
  createRef: () => $createRef,
  forwardRef: () => $forwardRef,
  isValidElement: () => $isValidElement,
  lazy: () => $lazy,
  memo: () => $memo,
  startTransition: () => $startTransition,
  unstable_useCacheRefresh: () => $unstable_useCacheRefresh,
  use: () => $use,
  useActionState: () => $useActionState,
  useCallback: () => $useCallback,
  useContext: () => $useContext,
  useDebugValue: () => $useDebugValue,
  useDeferredValue: () => $useDeferredValue,
  useEffect: () => $useEffect,
  useEffectEvent: () => $useEffectEvent,
  useId: () => $useId,
  useImperativeHandle: () => $useImperativeHandle,
  useInsertionEffect: () => $useInsertionEffect,
  useLayoutEffect: () => $useLayoutEffect,
  useMemo: () => $useMemo,
  useOptimistic: () => $useOptimistic,
  useReducer: () => $useReducer,
  useRef: () => $useRef,
  useState: () => $useState,
  useSyncExternalStore: () => $useSyncExternalStore,
  useTransition: () => $useTransition,
  version: () => $version
}, {
  Activity: (value) => $Activity = value,
  Children: (value) => $Children = value,
  Component: (value) => $Component = value,
  Fragment: (value) => $Fragment = value,
  Profiler: (value) => $Profiler = value,
  PureComponent: (value) => $PureComponent = value,
  StrictMode: (value) => $StrictMode = value,
  Suspense: (value) => $Suspense = value,
  ViewTransition: (value) => $ViewTransition = value,
  __CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE: (value) => $__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = value,
  __COMPILER_RUNTIME: (value) => $__COMPILER_RUNTIME = value,
  addTransitionType: (value) => $addTransitionType = value,
  cache: (value) => $cache = value,
  cacheSignal: (value) => $cacheSignal = value,
  cloneElement: (value) => $cloneElement = value,
  createContext: (value) => $createContext = value,
  createElement: (value) => $createElement = value,
  createRef: (value) => $createRef = value,
  forwardRef: (value) => $forwardRef = value,
  isValidElement: (value) => $isValidElement = value,
  lazy: (value) => $lazy = value,
  memo: (value) => $memo = value,
  startTransition: (value) => $startTransition = value,
  unstable_useCacheRefresh: (value) => $unstable_useCacheRefresh = value,
  use: (value) => $use = value,
  useActionState: (value) => $useActionState = value,
  useCallback: (value) => $useCallback = value,
  useContext: (value) => $useContext = value,
  useDebugValue: (value) => $useDebugValue = value,
  useDeferredValue: (value) => $useDeferredValue = value,
  useEffect: (value) => $useEffect = value,
  useEffectEvent: (value) => $useEffectEvent = value,
  useId: (value) => $useId = value,
  useImperativeHandle: (value) => $useImperativeHandle = value,
  useInsertionEffect: (value) => $useInsertionEffect = value,
  useLayoutEffect: (value) => $useLayoutEffect = value,
  useMemo: (value) => $useMemo = value,
  useOptimistic: (value) => $useOptimistic = value,
  useReducer: (value) => $useReducer = value,
  useRef: (value) => $useRef = value,
  useState: (value) => $useState = value,
  useSyncExternalStore: (value) => $useSyncExternalStore = value,
  useTransition: (value) => $useTransition = value,
  version: (value) => $version = value
});
function getIteratorFn(maybeIterable) {
  if (maybeIterable === null || typeof maybeIterable !== "object")
    return null;
  maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
  return typeof maybeIterable === "function" ? maybeIterable : null;
}
function Component(props, context, updater) {
  this.props = props;
  this.context = context;
  this.refs = emptyObject;
  this.updater = updater || ReactNoopUpdateQueue;
}
function ComponentDummy() {}
function PureComponent(props, context, updater) {
  this.props = props;
  this.context = context;
  this.refs = emptyObject;
  this.updater = updater || ReactNoopUpdateQueue;
}
function noop() {}
function ReactElement(type, key, props) {
  var refProp = props.ref;
  return {
    $$typeof: REACT_ELEMENT_TYPE,
    type,
    key,
    ref: refProp !== undefined ? refProp : null,
    props
  };
}
function cloneAndReplaceKey(oldElement, newKey) {
  return ReactElement(oldElement.type, newKey, oldElement.props);
}
function isValidElement(object) {
  return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function escape(key) {
  var escaperLookup = { "=": "=0", ":": "=2" };
  return "$" + key.replace(/[=:]/g, function(match) {
    return escaperLookup[match];
  });
}
function getElementKey(element, index) {
  return typeof element === "object" && element !== null && element.key != null ? escape("" + element.key) : index.toString(36);
}
function resolveThenable(thenable) {
  switch (thenable.status) {
    case "fulfilled":
      return thenable.value;
    case "rejected":
      throw thenable.reason;
    default:
      switch (typeof thenable.status === "string" ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function(fulfilledValue) {
        thenable.status === "pending" && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
      }, function(error) {
        thenable.status === "pending" && (thenable.status = "rejected", thenable.reason = error);
      })), thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          throw thenable.reason;
      }
  }
  throw thenable;
}
function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
  var type = typeof children;
  if (type === "undefined" || type === "boolean")
    children = null;
  var invokeCallback = false;
  if (children === null)
    invokeCallback = true;
  else
    switch (type) {
      case "bigint":
      case "string":
      case "number":
        invokeCallback = true;
        break;
      case "object":
        switch (children.$$typeof) {
          case REACT_ELEMENT_TYPE:
          case REACT_PORTAL_TYPE:
            invokeCallback = true;
            break;
          case REACT_LAZY_TYPE:
            return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
        }
    }
  if (invokeCallback)
    return callback = callback(children), invokeCallback = nameSoFar === "" ? "." + getElementKey(children, 0) : nameSoFar, isArrayImpl(callback) ? (escapedPrefix = "", invokeCallback != null && (escapedPrefix = invokeCallback.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
      return c;
    })) : callback != null && (isValidElement(callback) && (callback = cloneAndReplaceKey(callback, escapedPrefix + (callback.key == null || children && children.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + invokeCallback)), array.push(callback)), 1;
  invokeCallback = 0;
  var nextNamePrefix = nameSoFar === "" ? "." : nameSoFar + ":";
  if (isArrayImpl(children))
    for (var i = 0;i < children.length; i++)
      nameSoFar = children[i], type = nextNamePrefix + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
  else if (i = getIteratorFn(children), typeof i === "function")
    for (children = i.call(children), i = 0;!(nameSoFar = children.next()).done; )
      nameSoFar = nameSoFar.value, type = nextNamePrefix + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
  else if (type === "object") {
    if (typeof children.then === "function")
      return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
    array = String(children);
    throw Error("Objects are not valid as a React child (found: " + (array === "[object Object]" ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
  }
  return invokeCallback;
}
function mapChildren(children, func, context) {
  if (children == null)
    return children;
  var result = [], count = 0;
  mapIntoArray(children, result, "", "", function(child) {
    return func.call(context, child, count++);
  });
  return result;
}
function lazyInitializer(payload) {
  if (payload._status === -1) {
    var ctor = payload._result, thenable = ctor();
    thenable.then(function(moduleObject) {
      if (payload._status === 0 || payload._status === -1)
        payload._status = 1, payload._result = moduleObject, thenable.status === undefined && (thenable.status = "fulfilled", thenable.value = moduleObject);
    }, function(error) {
      if (payload._status === 0 || payload._status === -1)
        payload._status = 2, payload._result = error, thenable.status === undefined && (thenable.status = "rejected", thenable.reason = error);
    });
    payload._status === -1 && (payload._status = 0, payload._result = thenable);
  }
  if (payload._status === 1)
    return payload._result.default;
  throw payload._result;
}
function startTransition(scope) {
  var prevTransition = ReactSharedInternals.T, currentTransition = {};
  currentTransition.types = prevTransition !== null ? prevTransition.types : null;
  ReactSharedInternals.T = currentTransition;
  try {
    var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
    onStartTransitionFinish !== null && onStartTransitionFinish(currentTransition, returnValue);
    typeof returnValue === "object" && returnValue !== null && typeof returnValue.then === "function" && returnValue.then(noop, reportGlobalError);
  } catch (error) {
    reportGlobalError(error);
  } finally {
    prevTransition !== null && currentTransition.types !== null && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
  }
}
function addTransitionType(type) {
  var transition = ReactSharedInternals.T;
  if (transition !== null) {
    var transitionTypes = transition.types;
    transitionTypes === null ? transition.types = [type] : transitionTypes.indexOf(type) === -1 && transitionTypes.push(type);
  } else
    startTransition(addTransitionType.bind(null, type));
}
var REACT_ELEMENT_TYPE, REACT_PORTAL_TYPE, REACT_FRAGMENT_TYPE, REACT_STRICT_MODE_TYPE, REACT_PROFILER_TYPE, REACT_CONSUMER_TYPE, REACT_CONTEXT_TYPE, REACT_FORWARD_REF_TYPE, REACT_SUSPENSE_TYPE, REACT_MEMO_TYPE, REACT_LAZY_TYPE, REACT_ACTIVITY_TYPE, REACT_VIEW_TRANSITION_TYPE, MAYBE_ITERATOR_SYMBOL, ReactNoopUpdateQueue, assign, emptyObject, pureComponentPrototype, isArrayImpl, ReactSharedInternals, hasOwnProperty, userProvidedKeyEscapeRegex, reportGlobalError, Children, $Activity, $Children, $Component, $Fragment, $Profiler, $PureComponent, $StrictMode, $Suspense, $ViewTransition, $__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, $__COMPILER_RUNTIME, $addTransitionType, $cache = function(fn) {
  return function() {
    return fn.apply(null, arguments);
  };
}, $cacheSignal = function() {
  return null;
}, $cloneElement = function(element, config, children) {
  if (element === null || element === undefined)
    throw Error("The argument must be a React element, but you passed " + element + ".");
  var props = assign({}, element.props), key = element.key;
  if (config != null)
    for (propName in config.key !== undefined && (key = "" + config.key), config)
      !hasOwnProperty.call(config, propName) || propName === "key" || propName === "__self" || propName === "__source" || propName === "ref" && config.ref === undefined || (props[propName] = config[propName]);
  var propName = arguments.length - 2;
  if (propName === 1)
    props.children = children;
  else if (1 < propName) {
    for (var childArray = Array(propName), i = 0;i < propName; i++)
      childArray[i] = arguments[i + 2];
    props.children = childArray;
  }
  return ReactElement(element.type, key, props);
}, $createContext = function(defaultValue) {
  defaultValue = {
    $$typeof: REACT_CONTEXT_TYPE,
    _currentValue: defaultValue,
    _currentValue2: defaultValue,
    _threadCount: 0,
    Provider: null,
    Consumer: null
  };
  defaultValue.Provider = defaultValue;
  defaultValue.Consumer = {
    $$typeof: REACT_CONSUMER_TYPE,
    _context: defaultValue
  };
  return defaultValue;
}, $createElement = function(type, config, children) {
  var propName, props = {}, key = null;
  if (config != null)
    for (propName in config.key !== undefined && (key = "" + config.key), config)
      hasOwnProperty.call(config, propName) && propName !== "key" && propName !== "__self" && propName !== "__source" && (props[propName] = config[propName]);
  var childrenLength = arguments.length - 2;
  if (childrenLength === 1)
    props.children = children;
  else if (1 < childrenLength) {
    for (var childArray = Array(childrenLength), i = 0;i < childrenLength; i++)
      childArray[i] = arguments[i + 2];
    props.children = childArray;
  }
  if (type && type.defaultProps)
    for (propName in childrenLength = type.defaultProps, childrenLength)
      props[propName] === undefined && (props[propName] = childrenLength[propName]);
  return ReactElement(type, key, props);
}, $createRef = function() {
  return { current: null };
}, $forwardRef = function(render) {
  return { $$typeof: REACT_FORWARD_REF_TYPE, render };
}, $isValidElement, $lazy = function(ctor) {
  return {
    $$typeof: REACT_LAZY_TYPE,
    _payload: { _status: -1, _result: ctor },
    _init: lazyInitializer
  };
}, $memo = function(type, compare) {
  return {
    $$typeof: REACT_MEMO_TYPE,
    type,
    compare: compare === undefined ? null : compare
  };
}, $startTransition, $unstable_useCacheRefresh = function() {
  return ReactSharedInternals.H.useCacheRefresh();
}, $use = function(usable) {
  return ReactSharedInternals.H.use(usable);
}, $useActionState = function(action, initialState, permalink) {
  return ReactSharedInternals.H.useActionState(action, initialState, permalink);
}, $useCallback = function(callback, deps) {
  return ReactSharedInternals.H.useCallback(callback, deps);
}, $useContext = function(Context) {
  return ReactSharedInternals.H.useContext(Context);
}, $useDebugValue = function() {}, $useDeferredValue = function(value, initialValue) {
  return ReactSharedInternals.H.useDeferredValue(value, initialValue);
}, $useEffect = function(create, deps) {
  return ReactSharedInternals.H.useEffect(create, deps);
}, $useEffectEvent = function(callback) {
  return ReactSharedInternals.H.useEffectEvent(callback);
}, $useId = function() {
  return ReactSharedInternals.H.useId();
}, $useImperativeHandle = function(ref, create, deps) {
  return ReactSharedInternals.H.useImperativeHandle(ref, create, deps);
}, $useInsertionEffect = function(create, deps) {
  return ReactSharedInternals.H.useInsertionEffect(create, deps);
}, $useLayoutEffect = function(create, deps) {
  return ReactSharedInternals.H.useLayoutEffect(create, deps);
}, $useMemo = function(create, deps) {
  return ReactSharedInternals.H.useMemo(create, deps);
}, $useOptimistic = function(passthrough, reducer) {
  return ReactSharedInternals.H.useOptimistic(passthrough, reducer);
}, $useReducer = function(reducer, initialArg, init) {
  return ReactSharedInternals.H.useReducer(reducer, initialArg, init);
}, $useRef = function(initialValue) {
  return ReactSharedInternals.H.useRef(initialValue);
}, $useState = function(initialState) {
  return ReactSharedInternals.H.useState(initialState);
}, $useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
  return ReactSharedInternals.H.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}, $useTransition = function() {
  return ReactSharedInternals.H.useTransition();
}, $version = "19.3.1";
var init_react_production = __esm(() => {
  REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
  REACT_PORTAL_TYPE = Symbol.for("react.portal");
  REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
  REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
  REACT_PROFILER_TYPE = Symbol.for("react.profiler");
  REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
  REACT_CONTEXT_TYPE = Symbol.for("react.context");
  REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
  REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
  REACT_MEMO_TYPE = Symbol.for("react.memo");
  REACT_LAZY_TYPE = Symbol.for("react.lazy");
  REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
  REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition");
  MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
  ReactNoopUpdateQueue = {
    isMounted: function() {
      return false;
    },
    enqueueForceUpdate: function() {},
    enqueueReplaceState: function() {},
    enqueueSetState: function() {}
  };
  assign = Object.assign;
  emptyObject = {};
  Component.prototype.isReactComponent = {};
  Component.prototype.setState = function(partialState, callback) {
    if (typeof partialState !== "object" && typeof partialState !== "function" && partialState != null)
      throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, partialState, callback, "setState");
  };
  Component.prototype.forceUpdate = function(callback) {
    this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
  };
  ComponentDummy.prototype = Component.prototype;
  pureComponentPrototype = PureComponent.prototype = new ComponentDummy;
  pureComponentPrototype.constructor = PureComponent;
  assign(pureComponentPrototype, Component.prototype);
  pureComponentPrototype.isPureReactComponent = true;
  isArrayImpl = Array.isArray;
  ReactSharedInternals = { H: null, A: null, T: null, S: null };
  hasOwnProperty = Object.prototype.hasOwnProperty;
  userProvidedKeyEscapeRegex = /\/+/g;
  reportGlobalError = typeof reportError === "function" ? reportError : function(error) {
    if (typeof window === "object" && typeof window.ErrorEvent === "function") {
      var event = new window.ErrorEvent("error", {
        bubbles: true,
        cancelable: true,
        message: typeof error === "object" && error !== null && typeof error.message === "string" ? String(error.message) : String(error),
        error
      });
      if (!window.dispatchEvent(event))
        return;
    } else if (typeof process === "object" && typeof process.emit === "function") {
      process.emit("uncaughtException", error);
      return;
    }
    console.error(error);
  };
  Children = {
    map: mapChildren,
    forEach: function(children, forEachFunc, forEachContext) {
      mapChildren(children, function() {
        forEachFunc.apply(this, arguments);
      }, forEachContext);
    },
    count: function(children) {
      var n = 0;
      mapChildren(children, function() {
        n++;
      });
      return n;
    },
    toArray: function(children) {
      return mapChildren(children, function(child) {
        return child;
      }) || [];
    },
    only: function(children) {
      if (!isValidElement(children))
        throw Error("React.Children.only expected to receive a single React element child.");
      return children;
    }
  };
  $Activity = REACT_ACTIVITY_TYPE;
  $Children = Children;
  $Component = Component;
  $Fragment = REACT_FRAGMENT_TYPE;
  $Profiler = REACT_PROFILER_TYPE;
  $PureComponent = PureComponent;
  $StrictMode = REACT_STRICT_MODE_TYPE;
  $Suspense = REACT_SUSPENSE_TYPE;
  $ViewTransition = REACT_VIEW_TRANSITION_TYPE;
  $__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
  $__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(size) {
      return ReactSharedInternals.H.useMemoCache(size);
    }
  };
  $addTransitionType = addTransitionType;
  $isValidElement = isValidElement;
  $startTransition = startTransition;
});

// ../projects/react-typescript/node_modules/react/index.js
var require_react = __commonJS(function(exports, module) {
  init_react_production();
  if (true) {
    module.exports = exports_react_production;
  }
});

// ../projects/react-typescript/node_modules/scheduler/cjs/scheduler.production.js
var exports_scheduler_production = {};
__exportCjs(exports_scheduler_production, {
  unstable_now: () => $unstable_now,
  unstable_IdlePriority: () => $unstable_IdlePriority,
  unstable_ImmediatePriority: () => $unstable_ImmediatePriority,
  unstable_LowPriority: () => $unstable_LowPriority,
  unstable_NormalPriority: () => $unstable_NormalPriority,
  unstable_Profiling: () => $unstable_Profiling,
  unstable_UserBlockingPriority: () => $unstable_UserBlockingPriority,
  unstable_cancelCallback: () => $unstable_cancelCallback,
  unstable_forceFrameRate: () => $unstable_forceFrameRate,
  unstable_getCurrentPriorityLevel: () => $unstable_getCurrentPriorityLevel,
  unstable_next: () => $unstable_next,
  unstable_requestPaint: () => $unstable_requestPaint,
  unstable_runWithPriority: () => $unstable_runWithPriority,
  unstable_scheduleCallback: () => $unstable_scheduleCallback,
  unstable_shouldYield: () => $unstable_shouldYield,
  unstable_wrapCallback: () => $unstable_wrapCallback
}, {
  unstable_now: (value2) => $unstable_now = value2,
  unstable_IdlePriority: (value2) => $unstable_IdlePriority = value2,
  unstable_ImmediatePriority: (value2) => $unstable_ImmediatePriority = value2,
  unstable_LowPriority: (value2) => $unstable_LowPriority = value2,
  unstable_NormalPriority: (value2) => $unstable_NormalPriority = value2,
  unstable_Profiling: (value2) => $unstable_Profiling = value2,
  unstable_UserBlockingPriority: (value2) => $unstable_UserBlockingPriority = value2,
  unstable_cancelCallback: (value2) => $unstable_cancelCallback = value2,
  unstable_forceFrameRate: (value2) => $unstable_forceFrameRate = value2,
  unstable_getCurrentPriorityLevel: (value2) => $unstable_getCurrentPriorityLevel = value2,
  unstable_next: (value2) => $unstable_next = value2,
  unstable_requestPaint: (value2) => $unstable_requestPaint = value2,
  unstable_runWithPriority: (value2) => $unstable_runWithPriority = value2,
  unstable_scheduleCallback: (value2) => $unstable_scheduleCallback = value2,
  unstable_shouldYield: (value2) => $unstable_shouldYield = value2,
  unstable_wrapCallback: (value2) => $unstable_wrapCallback = value2
});
function push(heap, node) {
  var index = heap.length;
  heap.push(node);
  a:
    for (;0 < index; ) {
      var parentIndex = index - 1 >>> 1, parent = heap[parentIndex];
      if (0 < compare(parent, node))
        heap[parentIndex] = node, heap[index] = parent, index = parentIndex;
      else
        break a;
    }
}
function peek(heap) {
  return heap.length === 0 ? null : heap[0];
}
function pop(heap) {
  if (heap.length === 0)
    return null;
  var first = heap[0], last = heap.pop();
  if (last !== first) {
    heap[0] = last;
    a:
      for (var index = 0, length = heap.length, halfLength = length >>> 1;index < halfLength; ) {
        var leftIndex = 2 * (index + 1) - 1, left = heap[leftIndex], rightIndex = leftIndex + 1, right = heap[rightIndex];
        if (0 > compare(left, last))
          rightIndex < length && 0 > compare(right, left) ? (heap[index] = right, heap[rightIndex] = last, index = rightIndex) : (heap[index] = left, heap[leftIndex] = last, index = leftIndex);
        else if (rightIndex < length && 0 > compare(right, last))
          heap[index] = right, heap[rightIndex] = last, index = rightIndex;
        else
          break a;
      }
  }
  return first;
}
function compare(a, b) {
  var diff = a.sortIndex - b.sortIndex;
  return diff !== 0 ? diff : a.id - b.id;
}
function advanceTimers(currentTime) {
  for (var timer = peek(timerQueue);timer !== null; ) {
    if (timer.callback === null)
      pop(timerQueue);
    else if (timer.startTime <= currentTime)
      pop(timerQueue), timer.sortIndex = timer.expirationTime, push(taskQueue, timer);
    else
      break;
    timer = peek(timerQueue);
  }
}
function handleTimeout(currentTime) {
  isHostTimeoutScheduled = false;
  advanceTimers(currentTime);
  if (!isHostCallbackScheduled)
    if (peek(taskQueue) !== null)
      isHostCallbackScheduled = true, isMessageLoopRunning || (isMessageLoopRunning = true, schedulePerformWorkUntilDeadline());
    else {
      var firstTimer = peek(timerQueue);
      firstTimer !== null && requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
    }
}
function shouldYieldToHost() {
  return needsPaint ? true : exports_scheduler_production.unstable_now() - startTime < frameInterval ? false : true;
}
function performWorkUntilDeadline() {
  needsPaint = false;
  if (isMessageLoopRunning) {
    var currentTime = exports_scheduler_production.unstable_now();
    startTime = currentTime;
    var hasMoreWork = true;
    try {
      a: {
        isHostCallbackScheduled = false;
        isHostTimeoutScheduled && (isHostTimeoutScheduled = false, localClearTimeout(taskTimeoutID), taskTimeoutID = -1);
        isPerformingWork = true;
        var previousPriorityLevel = currentPriorityLevel;
        try {
          b: {
            advanceTimers(currentTime);
            for (currentTask = peek(taskQueue);currentTask !== null && !(currentTask.expirationTime > currentTime && shouldYieldToHost()); ) {
              var callback = currentTask.callback;
              if (typeof callback === "function") {
                currentTask.callback = null;
                currentPriorityLevel = currentTask.priorityLevel;
                var continuationCallback = callback(currentTask.expirationTime <= currentTime);
                currentTime = exports_scheduler_production.unstable_now();
                if (typeof continuationCallback === "function") {
                  currentTask.callback = continuationCallback;
                  advanceTimers(currentTime);
                  hasMoreWork = true;
                  break b;
                }
                currentTask === peek(taskQueue) && pop(taskQueue);
                advanceTimers(currentTime);
              } else
                pop(taskQueue);
              currentTask = peek(taskQueue);
            }
            if (currentTask !== null)
              hasMoreWork = true;
            else {
              var firstTimer = peek(timerQueue);
              firstTimer !== null && requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
              hasMoreWork = false;
            }
          }
          break a;
        } finally {
          currentTask = null, currentPriorityLevel = previousPriorityLevel, isPerformingWork = false;
        }
        hasMoreWork = undefined;
      }
    } finally {
      hasMoreWork ? schedulePerformWorkUntilDeadline() : isMessageLoopRunning = false;
    }
  }
}
function requestHostTimeout(callback, ms) {
  taskTimeoutID = localSetTimeout(function() {
    callback(exports_scheduler_production.unstable_now());
  }, ms);
}
var $unstable_now = undefined, localPerformance, localDate, initialTime, taskQueue, timerQueue, taskIdCounter = 1, currentTask = null, currentPriorityLevel = 3, isPerformingWork = false, isHostCallbackScheduled = false, isHostTimeoutScheduled = false, needsPaint = false, localSetTimeout, localClearTimeout, localSetImmediate, isMessageLoopRunning = false, taskTimeoutID = -1, frameInterval = 5, startTime = -1, schedulePerformWorkUntilDeadline, channel, port, $unstable_IdlePriority = 5, $unstable_ImmediatePriority = 1, $unstable_LowPriority = 4, $unstable_NormalPriority = 3, $unstable_Profiling = null, $unstable_UserBlockingPriority = 2, $unstable_cancelCallback = function(task) {
  task.callback = null;
}, $unstable_forceFrameRate = function(fps) {
  0 > fps || 125 < fps ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : frameInterval = 0 < fps ? Math.floor(1000 / fps) : 5;
}, $unstable_getCurrentPriorityLevel = function() {
  return currentPriorityLevel;
}, $unstable_next = function(eventHandler) {
  switch (currentPriorityLevel) {
    case 1:
    case 2:
    case 3:
      var priorityLevel = 3;
      break;
    default:
      priorityLevel = currentPriorityLevel;
  }
  var previousPriorityLevel = currentPriorityLevel;
  currentPriorityLevel = priorityLevel;
  try {
    return eventHandler();
  } finally {
    currentPriorityLevel = previousPriorityLevel;
  }
}, $unstable_requestPaint = function() {
  needsPaint = true;
}, $unstable_runWithPriority = function(priorityLevel, eventHandler) {
  switch (priorityLevel) {
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
      break;
    default:
      priorityLevel = 3;
  }
  var previousPriorityLevel = currentPriorityLevel;
  currentPriorityLevel = priorityLevel;
  try {
    return eventHandler();
  } finally {
    currentPriorityLevel = previousPriorityLevel;
  }
}, $unstable_scheduleCallback = function(priorityLevel, callback, options) {
  var currentTime = exports_scheduler_production.unstable_now();
  typeof options === "object" && options !== null ? (options = options.delay, options = typeof options === "number" && 0 < options ? currentTime + options : currentTime) : options = currentTime;
  switch (priorityLevel) {
    case 1:
      var timeout = -1;
      break;
    case 2:
      timeout = 250;
      break;
    case 5:
      timeout = 1073741823;
      break;
    case 4:
      timeout = 1e4;
      break;
    default:
      timeout = 5000;
  }
  timeout = options + timeout;
  priorityLevel = {
    id: taskIdCounter++,
    callback,
    priorityLevel,
    startTime: options,
    expirationTime: timeout,
    sortIndex: -1
  };
  options > currentTime ? (priorityLevel.sortIndex = options, push(timerQueue, priorityLevel), peek(taskQueue) === null && priorityLevel === peek(timerQueue) && (isHostTimeoutScheduled ? (localClearTimeout(taskTimeoutID), taskTimeoutID = -1) : isHostTimeoutScheduled = true, requestHostTimeout(handleTimeout, options - currentTime))) : (priorityLevel.sortIndex = timeout, push(taskQueue, priorityLevel), isHostCallbackScheduled || isPerformingWork || (isHostCallbackScheduled = true, isMessageLoopRunning || (isMessageLoopRunning = true, schedulePerformWorkUntilDeadline())));
  return priorityLevel;
}, $unstable_shouldYield, $unstable_wrapCallback = function(callback) {
  var parentPriorityLevel = currentPriorityLevel;
  return function() {
    var previousPriorityLevel = currentPriorityLevel;
    currentPriorityLevel = parentPriorityLevel;
    try {
      return callback.apply(this, arguments);
    } finally {
      currentPriorityLevel = previousPriorityLevel;
    }
  };
};
var init_scheduler_production = __esm(() => {
  if (typeof performance === "object" && typeof performance.now === "function") {
    localPerformance = performance;
    $unstable_now = function() {
      return localPerformance.now();
    };
  } else {
    localDate = Date, initialTime = localDate.now();
    $unstable_now = function() {
      return localDate.now() - initialTime;
    };
  }
  taskQueue = [];
  timerQueue = [];
  localSetTimeout = typeof setTimeout === "function" ? setTimeout : null;
  localClearTimeout = typeof clearTimeout === "function" ? clearTimeout : null;
  localSetImmediate = typeof setImmediate !== "undefined" ? setImmediate : null;
  if (typeof localSetImmediate === "function")
    schedulePerformWorkUntilDeadline = function() {
      localSetImmediate(performWorkUntilDeadline);
    };
  else if (typeof MessageChannel !== "undefined") {
    channel = new MessageChannel, port = channel.port2;
    channel.port1.onmessage = performWorkUntilDeadline;
    schedulePerformWorkUntilDeadline = function() {
      port.postMessage(null);
    };
  } else
    schedulePerformWorkUntilDeadline = function() {
      localSetTimeout(performWorkUntilDeadline, 0);
    };
  $unstable_shouldYield = shouldYieldToHost;
});

// ../projects/react-typescript/node_modules/scheduler/index.js
var require_scheduler = __commonJS(function(exports, module) {
  init_scheduler_production();
  if (true) {
    module.exports = exports_scheduler_production;
  }
});

// ../projects/react-typescript/node_modules/react-reconciler/cjs/react-reconciler.production.js
var require_react_reconciler_production = __commonJS(function(exports, module) {
  var React = __toESM(require_react());
  var Scheduler = __toESM(require_scheduler());
  module.exports = function($$$config) {
    function createFiber(tag, pendingProps, key, mode) {
      return new FiberNode(tag, pendingProps, key, mode);
    }
    function noop() {}
    function formatProdErrorMessage(code) {
      var url = "https://react.dev/errors/" + code;
      if (1 < arguments.length) {
        url += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var i = 2;i < arguments.length; i++)
          url += "&args[]=" + encodeURIComponent(arguments[i]);
      }
      return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function getNearestMountedFiber(fiber) {
      for (var node = fiber, nextNode = node;nextNode && !nextNode.alternate; )
        node = nextNode, (node.flags & 4098) !== 0 && (fiber = node.return), nextNode = node.return;
      for (;node.return; )
        node = node.return;
      return node.tag === 3 ? fiber : null;
    }
    function assertIsMounted(fiber) {
      if (getNearestMountedFiber(fiber) !== fiber)
        throw Error(formatProdErrorMessage(188));
    }
    function findCurrentFiberUsingSlowPath(fiber) {
      var alternate = fiber.alternate;
      if (!alternate) {
        alternate = getNearestMountedFiber(fiber);
        if (alternate === null)
          throw Error(formatProdErrorMessage(188));
        return alternate !== fiber ? null : fiber;
      }
      for (var a = fiber, b = alternate;; ) {
        var parentA = a.return;
        if (parentA === null)
          break;
        var parentB = parentA.alternate;
        if (parentB === null) {
          b = parentA.return;
          if (b !== null) {
            a = b;
            continue;
          }
          break;
        }
        if (parentA.child === parentB.child) {
          for (parentB = parentA.child;parentB; ) {
            if (parentB === a)
              return assertIsMounted(parentA), fiber;
            if (parentB === b)
              return assertIsMounted(parentA), alternate;
            parentB = parentB.sibling;
          }
          throw Error(formatProdErrorMessage(188));
        }
        if (a.return !== b.return)
          a = parentA, b = parentB;
        else {
          for (var didFindChild = false, child$0 = parentA.child;child$0; ) {
            if (child$0 === a) {
              didFindChild = true;
              a = parentA;
              b = parentB;
              break;
            }
            if (child$0 === b) {
              didFindChild = true;
              b = parentA;
              a = parentB;
              break;
            }
            child$0 = child$0.sibling;
          }
          if (!didFindChild) {
            for (child$0 = parentB.child;child$0; ) {
              if (child$0 === a) {
                didFindChild = true;
                a = parentB;
                b = parentA;
                break;
              }
              if (child$0 === b) {
                didFindChild = true;
                b = parentB;
                a = parentA;
                break;
              }
              child$0 = child$0.sibling;
            }
            if (!didFindChild)
              throw Error(formatProdErrorMessage(189));
          }
        }
        if (a.alternate !== b)
          throw Error(formatProdErrorMessage(190));
      }
      if (a.tag !== 3)
        throw Error(formatProdErrorMessage(188));
      return a.stateNode.current === a ? fiber : alternate;
    }
    function findCurrentHostFiberImpl(node) {
      var tag = node.tag;
      if (tag === 5 || tag === 26 || tag === 27 || tag === 6)
        return node;
      for (node = node.child;node !== null; ) {
        tag = findCurrentHostFiberImpl(node);
        if (tag !== null)
          return tag;
        node = node.sibling;
      }
      return null;
    }
    function findCurrentHostFiberWithNoPortalsImpl(node) {
      var tag = node.tag;
      if (tag === 5 || tag === 26 || tag === 27 || tag === 6)
        return node;
      for (node = node.child;node !== null; ) {
        if (node.tag !== 4 && (tag = findCurrentHostFiberWithNoPortalsImpl(node), tag !== null))
          return tag;
        node = node.sibling;
      }
      return null;
    }
    function getIteratorFn(maybeIterable) {
      if (maybeIterable === null || typeof maybeIterable !== "object")
        return null;
      maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
      return typeof maybeIterable === "function" ? maybeIterable : null;
    }
    function getComponentNameFromType(type) {
      if (type == null)
        return null;
      if (typeof type === "function")
        return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if (typeof type === "string")
        return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
        case REACT_VIEW_TRANSITION_TYPE:
          return "ViewTransition";
      }
      if (typeof type === "object")
        switch (type.$$typeof) {
          case REACT_PORTAL_TYPE:
            return "Portal";
          case REACT_CONTEXT_TYPE:
            return type.displayName || "Context";
          case REACT_CONSUMER_TYPE:
            return (type._context.displayName || "Context") + ".Consumer";
          case REACT_FORWARD_REF_TYPE:
            var innerType = type.render;
            type = type.displayName;
            type || (type = innerType.displayName || innerType.name || "", type = type !== "" ? "ForwardRef(" + type + ")" : "ForwardRef");
            return type;
          case REACT_MEMO_TYPE:
            return innerType = type.displayName || null, innerType !== null ? innerType : getComponentNameFromType(type.type) || "Memo";
          case REACT_LAZY_TYPE:
            innerType = type._payload;
            type = type._init;
            try {
              return getComponentNameFromType(type(innerType));
            } catch (x) {}
        }
      return null;
    }
    function createCursor(defaultValue) {
      return { current: defaultValue };
    }
    function pop(cursor) {
      0 > index$jscomp$0 || (cursor.current = valueStack[index$jscomp$0], valueStack[index$jscomp$0] = null, index$jscomp$0--);
    }
    function push(cursor, value) {
      index$jscomp$0++;
      valueStack[index$jscomp$0] = cursor.current;
      cursor.current = value;
    }
    function clz32Fallback(x) {
      x >>>= 0;
      return x === 0 ? 32 : 31 - (log$1(x) / LN2 | 0) | 0;
    }
    function getHighestPriorityLanes(lanes) {
      var pendingSyncLanes = lanes & 42;
      if (pendingSyncLanes !== 0)
        return pendingSyncLanes;
      switch (lanes & -lanes) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return lanes & -lanes;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return lanes & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return lanes & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return lanes;
      }
    }
    function getNextLanes(root, wipLanes, rootHasPendingCommit) {
      var pendingLanes = root.pendingLanes;
      if (pendingLanes === 0)
        return 0;
      var nextLanes = 0, suspendedLanes = root.suspendedLanes, pingedLanes = root.pingedLanes;
      root = root.warmLanes;
      var nonIdlePendingLanes = pendingLanes & 134217727;
      nonIdlePendingLanes !== 0 ? (pendingLanes = nonIdlePendingLanes & ~suspendedLanes, pendingLanes !== 0 ? nextLanes = getHighestPriorityLanes(pendingLanes) : (pingedLanes &= nonIdlePendingLanes, pingedLanes !== 0 ? nextLanes = getHighestPriorityLanes(pingedLanes) : rootHasPendingCommit || (rootHasPendingCommit = nonIdlePendingLanes & ~root, rootHasPendingCommit !== 0 && (nextLanes = getHighestPriorityLanes(rootHasPendingCommit))))) : (nonIdlePendingLanes = pendingLanes & ~suspendedLanes, nonIdlePendingLanes !== 0 ? nextLanes = getHighestPriorityLanes(nonIdlePendingLanes) : pingedLanes !== 0 ? nextLanes = getHighestPriorityLanes(pingedLanes) : rootHasPendingCommit || (rootHasPendingCommit = pendingLanes & ~root, rootHasPendingCommit !== 0 && (nextLanes = getHighestPriorityLanes(rootHasPendingCommit))));
      return nextLanes === 0 ? 0 : wipLanes !== 0 && wipLanes !== nextLanes && (wipLanes & suspendedLanes) === 0 && (suspendedLanes = nextLanes & -nextLanes, rootHasPendingCommit = wipLanes & -wipLanes, suspendedLanes >= rootHasPendingCommit || suspendedLanes === 32 && (rootHasPendingCommit & 4194048) !== 0) ? wipLanes : nextLanes;
    }
    function checkIfRootIsPrerendering(root, renderLanes) {
      return (root.pendingLanes & ~(root.suspendedLanes & ~root.pingedLanes) & renderLanes) === 0;
    }
    function getEntangledLanes(root, renderLanes) {
      (renderLanes & 8) !== 0 && (renderLanes |= renderLanes & 32);
      var allEntangledLanes = root.entangledLanes;
      if (allEntangledLanes !== 0)
        for (root = root.entanglements, allEntangledLanes &= renderLanes;0 < allEntangledLanes; ) {
          var index$2 = 31 - clz32(allEntangledLanes), lane = 1 << index$2;
          renderLanes |= root[index$2];
          allEntangledLanes &= ~lane;
        }
      return renderLanes;
    }
    function computeExpirationTime(lane, currentTime) {
      switch (lane) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return currentTime + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return currentTime + 5000;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function claimNextRetryLane() {
      var lane = nextRetryLane;
      nextRetryLane <<= 1;
      (nextRetryLane & 62914560) === 0 && (nextRetryLane = 4194304);
      return lane;
    }
    function createLaneMap(initial) {
      for (var laneMap = [], i = 0;31 > i; i++)
        laneMap.push(initial);
      return laneMap;
    }
    function markRootUpdated$1(root, updateLane) {
      root.pendingLanes |= updateLane;
      updateLane !== 268435456 && (root.suspendedLanes = 0, root.pingedLanes = 0, root.warmLanes = 0);
    }
    function markRootFinished(root, finishedLanes, remainingLanes, spawnedLane, updatedLanes, suspendedRetryLanes) {
      var previouslyPendingLanes = root.pendingLanes;
      root.pendingLanes = remainingLanes;
      root.suspendedLanes = 0;
      root.pingedLanes = 0;
      root.warmLanes = 0;
      root.expiredLanes &= remainingLanes;
      root.entangledLanes &= remainingLanes;
      root.errorRecoveryDisabledLanes &= remainingLanes;
      root.shellSuspendCounter = 0;
      var { entanglements, expirationTimes, hiddenUpdates } = root;
      for (remainingLanes = previouslyPendingLanes & ~remainingLanes;0 < remainingLanes; ) {
        var index$5 = 31 - clz32(remainingLanes), lane = 1 << index$5;
        entanglements[index$5] = 0;
        expirationTimes[index$5] = -1;
        var hiddenUpdatesForLane = hiddenUpdates[index$5];
        if (hiddenUpdatesForLane !== null)
          for (hiddenUpdates[index$5] = null, index$5 = 0;index$5 < hiddenUpdatesForLane.length; index$5++) {
            var update = hiddenUpdatesForLane[index$5];
            update !== null && (update.lane &= -536870913);
          }
        remainingLanes &= ~lane;
      }
      spawnedLane !== 0 && markSpawnedDeferredLane(root, spawnedLane, 0);
      suspendedRetryLanes !== 0 && updatedLanes === 0 && root.tag !== 0 && (root.suspendedLanes |= suspendedRetryLanes & ~(previouslyPendingLanes & ~finishedLanes));
    }
    function markSpawnedDeferredLane(root, spawnedLane, entangledLanes) {
      root.pendingLanes |= spawnedLane;
      root.suspendedLanes &= ~spawnedLane;
      var spawnedLaneIndex = 31 - clz32(spawnedLane);
      root.entangledLanes |= spawnedLane;
      root.entanglements[spawnedLaneIndex] = root.entanglements[spawnedLaneIndex] | 1073741824 | entangledLanes & 261930;
    }
    function markRootEntangled(root, entangledLanes) {
      var rootEntangledLanes = root.entangledLanes |= entangledLanes;
      for (root = root.entanglements;rootEntangledLanes; ) {
        var index$6 = 31 - clz32(rootEntangledLanes), lane = 1 << index$6;
        lane & entangledLanes | root[index$6] & entangledLanes && (root[index$6] |= entangledLanes);
        rootEntangledLanes &= ~lane;
      }
    }
    function getBumpedLaneForHydration(root, renderLanes) {
      var renderLane = renderLanes & -renderLanes;
      renderLane = (renderLane & 42) !== 0 ? 1 : getBumpedLaneForHydrationByLane(renderLane);
      return (renderLane & (root.suspendedLanes | renderLanes)) !== 0 ? 0 : renderLane;
    }
    function getBumpedLaneForHydrationByLane(lane) {
      switch (lane) {
        case 2:
          lane = 1;
          break;
        case 8:
          lane = 4;
          break;
        case 32:
          lane = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          lane = 128;
          break;
        case 268435456:
          lane = 134217728;
          break;
        default:
          lane = 0;
      }
      return lane;
    }
    function lanesToEventPriority(lanes) {
      lanes &= -lanes;
      return 2 < lanes ? 8 < lanes ? (lanes & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
    }
    function setIsStrictModeForDevtools(newIsStrictMode) {
      typeof log2 === "function" && unstable_setDisableYieldValue2(newIsStrictMode);
      if (injectedHook && typeof injectedHook.setStrictMode === "function")
        try {
          injectedHook.setStrictMode(rendererID, newIsStrictMode);
        } catch (err) {}
    }
    function getViewTransitionName(props, instance) {
      if (props.name != null && props.name !== "auto")
        return props.name;
      if (instance.autoName !== null)
        return instance.autoName;
      props = pendingEffectsRoot.identifierPrefix;
      var globalClientId = globalClientIdCounter$1++;
      props = "_" + props + "t_" + globalClientId.toString(32) + "_";
      return instance.autoName = props;
    }
    function getClassNameByType(classByType) {
      if (classByType == null || typeof classByType === "string")
        return classByType;
      var className = null, activeTypes = pendingTransitionTypes;
      if (activeTypes !== null)
        for (var i = 0;i < activeTypes.length; i++) {
          var match = classByType[activeTypes[i]];
          if (match != null) {
            if (match === "none")
              return "none";
            className = className == null ? match : className + (" " + match);
          }
        }
      return className == null ? classByType.default : className;
    }
    function getViewTransitionClassName(defaultClass, eventClass) {
      defaultClass = getClassNameByType(defaultClass);
      eventClass = getClassNameByType(eventClass);
      return eventClass == null ? defaultClass === "auto" ? null : defaultClass : eventClass === "auto" ? null : eventClass;
    }
    function is(x, y) {
      return x === y && (x !== 0 || 1 / x === 1 / y) || x !== x && y !== y;
    }
    function describeBuiltInComponentFrame(name) {
      if (prefix === undefined)
        try {
          throw Error();
        } catch (x) {
          var match = x.stack.trim().match(/\n( *(at )?)/);
          prefix = match && match[1] || "";
          suffix = -1 < x.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < x.stack.indexOf("@") ? "@unknown:0:0" : "";
        }
      return `
` + prefix + name + suffix;
    }
    function describeNativeComponentFrame(fn, construct) {
      if (!fn || reentry)
        return "";
      reentry = true;
      var previousPrepareStackTrace = Error.prepareStackTrace;
      Error.prepareStackTrace = undefined;
      try {
        var RunInRootFrame = {
          DetermineComponentFrameRoot: function() {
            try {
              if (construct) {
                var Fake = function() {
                  throw Error();
                };
                Object.defineProperty(Fake.prototype, "props", {
                  set: function() {
                    throw Error();
                  }
                });
                if (typeof Reflect === "object" && Reflect.construct) {
                  try {
                    Reflect.construct(Fake, []);
                  } catch (x) {
                    var control = x;
                  }
                  Reflect.construct(fn, [], Fake);
                } else {
                  try {
                    Fake.call();
                  } catch (x$8) {
                    control = x$8;
                  }
                  Fake = false;
                  try {
                    var prevProps = Object.getOwnPropertyDescriptor(fn.prototype, "props");
                    Object.defineProperty(fn.prototype, "props", {
                      configurable: true,
                      set: function() {
                        throw Error();
                      }
                    });
                    Fake = true;
                    new fn;
                  } finally {
                    Fake && (prevProps !== undefined ? Object.defineProperty(fn.prototype, "props", prevProps) : delete fn.prototype.props);
                  }
                }
              } else {
                try {
                  throw Error();
                } catch (x$9) {
                  control = x$9;
                }
                (Fake = fn()) && typeof Fake.catch === "function" && Fake.catch(function() {});
              }
            } catch (sample) {
              if (sample && control && typeof sample.stack === "string")
                return [sample.stack, control.stack];
            }
            return [null, null];
          }
        };
        RunInRootFrame.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
        var namePropDescriptor = Object.getOwnPropertyDescriptor(RunInRootFrame.DetermineComponentFrameRoot, "name");
        namePropDescriptor && namePropDescriptor.configurable && Object.defineProperty(RunInRootFrame.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
        var _RunInRootFrame$Deter = RunInRootFrame.DetermineComponentFrameRoot(), sampleStack = _RunInRootFrame$Deter[0], controlStack = _RunInRootFrame$Deter[1];
        if (sampleStack && controlStack) {
          var sampleLines = sampleStack.split(`
`), controlLines = controlStack.split(`
`);
          for (namePropDescriptor = RunInRootFrame = 0;RunInRootFrame < sampleLines.length && !sampleLines[RunInRootFrame].includes("DetermineComponentFrameRoot"); )
            RunInRootFrame++;
          for (;namePropDescriptor < controlLines.length && !controlLines[namePropDescriptor].includes("DetermineComponentFrameRoot"); )
            namePropDescriptor++;
          if (RunInRootFrame === sampleLines.length || namePropDescriptor === controlLines.length)
            for (RunInRootFrame = sampleLines.length - 1, namePropDescriptor = controlLines.length - 1;1 <= RunInRootFrame && 0 <= namePropDescriptor && sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]; )
              namePropDescriptor--;
          for (;1 <= RunInRootFrame && 0 <= namePropDescriptor; RunInRootFrame--, namePropDescriptor--)
            if (sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
              if (RunInRootFrame !== 1 || namePropDescriptor !== 1) {
                do
                  if (RunInRootFrame--, namePropDescriptor--, 0 > namePropDescriptor || sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
                    var frame = `
` + sampleLines[RunInRootFrame].replace(" at new ", " at ");
                    fn.displayName && frame.includes("<anonymous>") && (frame = frame.replace("<anonymous>", fn.displayName));
                    return frame;
                  }
                while (1 <= RunInRootFrame && 0 <= namePropDescriptor);
              }
              break;
            }
        }
      } finally {
        reentry = false, Error.prepareStackTrace = previousPrepareStackTrace;
      }
      return (previousPrepareStackTrace = fn ? fn.displayName || fn.name : "") ? describeBuiltInComponentFrame(previousPrepareStackTrace) : "";
    }
    function describeFiber(fiber, childFiber) {
      switch (fiber.tag) {
        case 26:
        case 27:
        case 5:
          return describeBuiltInComponentFrame(fiber.type);
        case 16:
          return describeBuiltInComponentFrame("Lazy");
        case 13:
          return fiber.child !== childFiber && childFiber !== null ? describeBuiltInComponentFrame("Suspense Fallback") : describeBuiltInComponentFrame("Suspense");
        case 19:
          return describeBuiltInComponentFrame("SuspenseList");
        case 0:
        case 15:
          return describeNativeComponentFrame(fiber.type, false);
        case 11:
          return describeNativeComponentFrame(fiber.type.render, false);
        case 1:
          return describeNativeComponentFrame(fiber.type, true);
        case 31:
          return describeBuiltInComponentFrame("Activity");
        case 30:
          return describeBuiltInComponentFrame("ViewTransition");
        default:
          return "";
      }
    }
    function getStackByFiberInDevAndProd(workInProgress) {
      try {
        var info = "", previous = null;
        do
          info += describeFiber(workInProgress, previous), previous = workInProgress, workInProgress = workInProgress.return;
        while (workInProgress);
        return info;
      } catch (x) {
        return `
Error generating stack: ` + x.message + `
` + x.stack;
      }
    }
    function createCapturedValueAtFiber(value, source) {
      if (typeof value === "object" && value !== null) {
        var existing = CapturedStacks.get(value);
        if (existing !== undefined)
          return existing;
        source = {
          value,
          source,
          stack: getStackByFiberInDevAndProd(source)
        };
        CapturedStacks.set(value, source);
        return source;
      }
      return {
        value,
        source,
        stack: getStackByFiberInDevAndProd(source)
      };
    }
    function pushTreeFork(workInProgress, totalChildren) {
      forkStack[forkStackIndex++] = treeForkCount;
      forkStack[forkStackIndex++] = treeForkProvider;
      treeForkProvider = workInProgress;
      treeForkCount = totalChildren;
    }
    function pushTreeId(workInProgress, totalChildren, index) {
      idStack[idStackIndex++] = treeContextId;
      idStack[idStackIndex++] = treeContextOverflow;
      idStack[idStackIndex++] = treeContextProvider;
      treeContextProvider = workInProgress;
      var baseIdWithLeadingBit = treeContextId;
      workInProgress = treeContextOverflow;
      var baseLength = 32 - clz32(baseIdWithLeadingBit) - 1;
      baseIdWithLeadingBit &= ~(1 << baseLength);
      index += 1;
      var length = 32 - clz32(totalChildren) + baseLength;
      if (30 < length) {
        var numberOfOverflowBits = baseLength - baseLength % 5;
        length = (baseIdWithLeadingBit & (1 << numberOfOverflowBits) - 1).toString(32);
        baseIdWithLeadingBit >>= numberOfOverflowBits;
        baseLength -= numberOfOverflowBits;
        treeContextId = 1 << 32 - clz32(totalChildren) + baseLength | index << baseLength | baseIdWithLeadingBit;
        treeContextOverflow = length + workInProgress;
      } else
        treeContextId = 1 << length | index << baseLength | baseIdWithLeadingBit, treeContextOverflow = workInProgress;
    }
    function pushMaterializedTreeId(workInProgress) {
      workInProgress.return !== null && (pushTreeFork(workInProgress, 1), pushTreeId(workInProgress, 1, 0));
    }
    function popTreeContext(workInProgress) {
      for (;workInProgress === treeForkProvider; )
        treeForkProvider = forkStack[--forkStackIndex], forkStack[forkStackIndex] = null, treeForkCount = forkStack[--forkStackIndex], forkStack[forkStackIndex] = null;
      for (;workInProgress === treeContextProvider; )
        treeContextProvider = idStack[--idStackIndex], idStack[idStackIndex] = null, treeContextOverflow = idStack[--idStackIndex], idStack[idStackIndex] = null, treeContextId = idStack[--idStackIndex], idStack[idStackIndex] = null;
    }
    function restoreSuspendedTreeContext(workInProgress, suspendedContext) {
      idStack[idStackIndex++] = treeContextId;
      idStack[idStackIndex++] = treeContextOverflow;
      idStack[idStackIndex++] = treeContextProvider;
      treeContextId = suspendedContext.id;
      treeContextOverflow = suspendedContext.overflow;
      treeContextProvider = workInProgress;
    }
    function pushHostContainer(fiber, nextRootInstance) {
      push(rootInstanceStackCursor, nextRootInstance);
      push(contextFiberStackCursor, fiber);
      push(contextStackCursor, null);
      fiber = getRootHostContext(nextRootInstance);
      pop(contextStackCursor);
      push(contextStackCursor, fiber);
    }
    function popHostContainer() {
      pop(contextStackCursor);
      pop(contextFiberStackCursor);
      pop(rootInstanceStackCursor);
    }
    function pushHostContext(fiber) {
      var stateHook = fiber.memoizedState;
      stateHook !== null && (stateHook = stateHook.memoizedState, isPrimaryRenderer ? HostTransitionContext._currentValue = stateHook : HostTransitionContext._currentValue2 = stateHook, push(hostTransitionProviderCursor, fiber));
      stateHook = contextStackCursor.current;
      var nextContext = getChildHostContext(stateHook, fiber.type);
      stateHook !== nextContext && (push(contextFiberStackCursor, fiber), push(contextStackCursor, nextContext));
    }
    function popHostContext(fiber) {
      contextFiberStackCursor.current === fiber && (pop(contextStackCursor), pop(contextFiberStackCursor));
      hostTransitionProviderCursor.current === fiber && (pop(hostTransitionProviderCursor), isPrimaryRenderer ? HostTransitionContext._currentValue = NotPendingTransition : HostTransitionContext._currentValue2 = NotPendingTransition);
    }
    function throwOnHydrationMismatch(fiber) {
      var error = Error(formatProdErrorMessage(418, 1 < arguments.length && arguments[1] !== undefined && arguments[1] ? "text" : "HTML", ""));
      queueHydrationError(createCapturedValueAtFiber(error, fiber));
      throw HydrationMismatchException;
    }
    function prepareToHydrateHostInstance(fiber, hostContext) {
      if (!supportsHydration)
        throw Error(formatProdErrorMessage(175));
      hydrateInstance(fiber.stateNode, fiber.type, fiber.memoizedProps, hostContext, fiber) || throwOnHydrationMismatch(fiber, true);
    }
    function popToNextHostParent(fiber) {
      for (hydrationParentFiber = fiber.return;hydrationParentFiber; )
        switch (hydrationParentFiber.tag) {
          case 5:
          case 31:
          case 13:
            rootOrSingletonContext = false;
            return;
          case 27:
          case 3:
            rootOrSingletonContext = true;
            return;
          default:
            hydrationParentFiber = hydrationParentFiber.return;
        }
    }
    function popHydrationState(fiber) {
      if (!supportsHydration || fiber !== hydrationParentFiber)
        return false;
      if (!isHydrating)
        return popToNextHostParent(fiber), isHydrating = true, false;
      var tag = fiber.tag;
      supportsSingletons ? tag !== 3 && tag !== 27 && (tag !== 5 || shouldDeleteUnhydratedTailInstances(fiber.type) && !shouldSetTextContent(fiber.type, fiber.memoizedProps)) && nextHydratableInstance && throwOnHydrationMismatch(fiber) : tag !== 3 && (tag !== 5 || shouldDeleteUnhydratedTailInstances(fiber.type) && !shouldSetTextContent(fiber.type, fiber.memoizedProps)) && nextHydratableInstance && throwOnHydrationMismatch(fiber);
      popToNextHostParent(fiber);
      if (tag === 13) {
        if (!supportsHydration)
          throw Error(formatProdErrorMessage(316));
        fiber = fiber.memoizedState;
        fiber = fiber !== null ? fiber.dehydrated : null;
        if (!fiber)
          throw Error(formatProdErrorMessage(317));
        nextHydratableInstance = getNextHydratableInstanceAfterSuspenseInstance(fiber);
      } else if (tag === 31) {
        fiber = fiber.memoizedState;
        fiber = fiber !== null ? fiber.dehydrated : null;
        if (!fiber)
          throw Error(formatProdErrorMessage(317));
        nextHydratableInstance = getNextHydratableInstanceAfterActivityInstance(fiber);
      } else
        nextHydratableInstance = supportsSingletons && tag === 27 ? getNextHydratableSiblingAfterSingleton(fiber.type, nextHydratableInstance) : hydrationParentFiber ? getNextHydratableSibling(fiber.stateNode) : null;
      return true;
    }
    function resetHydrationState() {
      supportsHydration && (nextHydratableInstance = hydrationParentFiber = null, isHydrating = false);
    }
    function upgradeHydrationErrorsToRecoverable() {
      var queuedErrors = hydrationErrors;
      queuedErrors !== null && (workInProgressRootRecoverableErrors === null ? workInProgressRootRecoverableErrors = queuedErrors : workInProgressRootRecoverableErrors.push.apply(workInProgressRootRecoverableErrors, queuedErrors), hydrationErrors = null);
      return queuedErrors;
    }
    function queueHydrationError(error) {
      hydrationErrors === null ? hydrationErrors = [error] : hydrationErrors.push(error);
    }
    function pushProvider(providerFiber, context, nextValue) {
      isPrimaryRenderer ? (push(valueCursor, context._currentValue), context._currentValue = nextValue) : (push(valueCursor, context._currentValue2), context._currentValue2 = nextValue);
    }
    function popProvider(context) {
      var currentValue = valueCursor.current;
      isPrimaryRenderer ? context._currentValue = currentValue : context._currentValue2 = currentValue;
      pop(valueCursor);
    }
    function scheduleContextWorkOnParentPath(parent, renderLanes, propagationRoot) {
      for (;parent !== null; ) {
        var alternate = parent.alternate;
        (parent.childLanes & renderLanes) !== renderLanes ? (parent.childLanes |= renderLanes, alternate !== null && (alternate.childLanes |= renderLanes)) : alternate !== null && (alternate.childLanes & renderLanes) !== renderLanes && (alternate.childLanes |= renderLanes);
        if (parent === propagationRoot)
          break;
        parent = parent.return;
      }
    }
    function propagateContextChanges(workInProgress, contexts, renderLanes, forcePropagateEntireTree) {
      var fiber = workInProgress.child;
      fiber !== null && (fiber.return = workInProgress);
      for (;fiber !== null; ) {
        var list = fiber.dependencies;
        if (list !== null) {
          var nextFiber = fiber.child;
          list = list.firstContext;
          a:
            for (;list !== null; ) {
              var dependency = list;
              list = fiber;
              for (var i = 0;i < contexts.length; i++)
                if (dependency.context === contexts[i]) {
                  list.lanes |= renderLanes;
                  dependency = list.alternate;
                  dependency !== null && (dependency.lanes |= renderLanes);
                  scheduleContextWorkOnParentPath(list.return, renderLanes, workInProgress);
                  forcePropagateEntireTree || (nextFiber = null);
                  break a;
                }
              list = dependency.next;
            }
        } else if (fiber.tag === 18) {
          nextFiber = fiber.return;
          if (nextFiber === null)
            throw Error(formatProdErrorMessage(341));
          nextFiber.lanes |= renderLanes;
          list = nextFiber.alternate;
          list !== null && (list.lanes |= renderLanes);
          scheduleContextWorkOnParentPath(nextFiber, renderLanes, workInProgress);
          nextFiber = null;
        } else
          fiber.tag === 13 && fiber.memoizedState !== null && fiber.memoizedState.dehydrated === null ? (fiber.lanes |= renderLanes, nextFiber = fiber.alternate, nextFiber !== null && (nextFiber.lanes |= renderLanes), scheduleContextWorkOnParentPath(fiber.return, renderLanes, workInProgress), nextFiber = fiber.child, nextFiber = nextFiber !== null ? nextFiber.sibling : null) : nextFiber = fiber.child;
        if (nextFiber !== null)
          nextFiber.return = fiber;
        else
          for (nextFiber = fiber;nextFiber !== null; ) {
            if (nextFiber === workInProgress) {
              nextFiber = null;
              break;
            }
            fiber = nextFiber.sibling;
            if (fiber !== null) {
              fiber.return = nextFiber.return;
              nextFiber = fiber;
              break;
            }
            nextFiber = nextFiber.return;
          }
        fiber = nextFiber;
      }
    }
    function propagateParentContextChanges(current, workInProgress, renderLanes, forcePropagateEntireTree) {
      current = null;
      for (var parent = workInProgress, isInsidePropagationBailout = false;parent !== null; ) {
        if (!isInsidePropagationBailout) {
          if ((parent.flags & 524288) !== 0)
            isInsidePropagationBailout = true;
          else if ((parent.flags & 262144) !== 0)
            break;
        }
        if (parent.tag === 10) {
          var currentParent = parent.alternate;
          if (currentParent === null)
            throw Error(formatProdErrorMessage(387));
          currentParent = currentParent.memoizedProps;
          if (currentParent !== null) {
            var context = parent.type;
            objectIs(parent.pendingProps.value, currentParent.value) || (current !== null ? current.push(context) : current = [context]);
          }
        } else if (parent === hostTransitionProviderCursor.current) {
          currentParent = parent.alternate;
          if (currentParent === null)
            throw Error(formatProdErrorMessage(387));
          currentParent.memoizedState.memoizedState !== parent.memoizedState.memoizedState && (current !== null ? current.push(HostTransitionContext) : current = [HostTransitionContext]);
        }
        parent = parent.return;
      }
      current !== null && propagateContextChanges(workInProgress, current, renderLanes, forcePropagateEntireTree);
      workInProgress.flags |= 262144;
      return current !== null;
    }
    function checkIfContextChanged(currentDependencies) {
      for (currentDependencies = currentDependencies.firstContext;currentDependencies !== null; ) {
        var context = currentDependencies.context;
        if (!objectIs(isPrimaryRenderer ? context._currentValue : context._currentValue2, currentDependencies.memoizedValue))
          return true;
        currentDependencies = currentDependencies.next;
      }
      return false;
    }
    function prepareToReadContext(workInProgress) {
      currentlyRenderingFiber$1 = workInProgress;
      lastContextDependency = null;
      workInProgress = workInProgress.dependencies;
      workInProgress !== null && (workInProgress.firstContext = null);
    }
    function readContext(context) {
      return readContextForConsumer(currentlyRenderingFiber$1, context);
    }
    function readContextDuringReconciliation(consumer, context) {
      currentlyRenderingFiber$1 === null && prepareToReadContext(consumer);
      return readContextForConsumer(consumer, context);
    }
    function readContextForConsumer(consumer, context) {
      var value = isPrimaryRenderer ? context._currentValue : context._currentValue2;
      context = { context, memoizedValue: value, next: null };
      if (lastContextDependency === null) {
        if (consumer === null)
          throw Error(formatProdErrorMessage(308));
        lastContextDependency = context;
        consumer.dependencies = { lanes: 0, firstContext: context };
        consumer.flags |= 524288;
      } else
        lastContextDependency = lastContextDependency.next = context;
      return value;
    }
    function createCache() {
      return {
        controller: new AbortControllerLocal,
        data: new Map,
        refCount: 0
      };
    }
    function releaseCache(cache) {
      cache.refCount--;
      cache.refCount === 0 && scheduleCallback$2(NormalPriority, function() {
        cache.controller.abort();
      });
    }
    function queueTransitionTypes(root, transitionTypes) {
      if ((root.pendingLanes & 4194048) !== 0) {
        var queued = root.transitionTypes;
        queued === null && (queued = root.transitionTypes = []);
        for (root = 0;root < transitionTypes.length; root++) {
          var transitionType = transitionTypes[root];
          queued.indexOf(transitionType) === -1 && queued.push(transitionType);
        }
      }
    }
    function claimQueuedTransitionTypes(root) {
      var claimed = root.transitionTypes;
      root.transitionTypes = null;
      return claimed;
    }
    function noop$1() {}
    function ensureRootIsScheduled(root) {
      root !== lastScheduledRoot && root.next === null && (lastScheduledRoot === null ? firstScheduledRoot = lastScheduledRoot = root : lastScheduledRoot = lastScheduledRoot.next = root);
      mightHavePendingSyncWork = true;
      didScheduleMicrotask || (didScheduleMicrotask = true, scheduleImmediateRootScheduleTask());
    }
    function flushSyncWorkAcrossRoots_impl(syncTransitionLanes, onlyLegacy) {
      if (!isFlushingWork && mightHavePendingSyncWork) {
        isFlushingWork = true;
        do {
          var didPerformSomeWork = false;
          for (var root = firstScheduledRoot;root !== null; ) {
            if (!onlyLegacy)
              if (syncTransitionLanes !== 0) {
                var pendingLanes = root.pendingLanes;
                if (pendingLanes === 0)
                  var JSCompiler_inline_result = 0;
                else {
                  var suspendedLanes = root.suspendedLanes, pingedLanes = root.pingedLanes;
                  JSCompiler_inline_result = (1 << 31 - clz32(42 | syncTransitionLanes) + 1) - 1;
                  JSCompiler_inline_result &= pendingLanes & ~(suspendedLanes & ~pingedLanes);
                  JSCompiler_inline_result = JSCompiler_inline_result & 201326741 ? JSCompiler_inline_result & 201326741 | 1 : JSCompiler_inline_result ? JSCompiler_inline_result | 2 : 0;
                }
                JSCompiler_inline_result !== 0 && (didPerformSomeWork = true, performSyncWorkOnRoot(root, JSCompiler_inline_result));
              } else
                JSCompiler_inline_result = workInProgressRootRenderLanes, JSCompiler_inline_result = getNextLanes(root, root === workInProgressRoot ? JSCompiler_inline_result : 0, root.cancelPendingCommit !== null || root.timeoutHandle !== noTimeout), (JSCompiler_inline_result & 3) === 0 || checkIfRootIsPrerendering(root, JSCompiler_inline_result) || (didPerformSomeWork = true, performSyncWorkOnRoot(root, JSCompiler_inline_result));
            root = root.next;
          }
        } while (didPerformSomeWork);
        isFlushingWork = false;
      }
    }
    function processRootScheduleInImmediateTask() {
      processRootScheduleInMicrotask();
    }
    function processRootScheduleInMicrotask() {
      mightHavePendingSyncWork = didScheduleMicrotask = false;
      var syncTransitionLanes = 0;
      currentEventTransitionLane !== 0 && shouldAttemptEagerTransition() && (syncTransitionLanes = currentEventTransitionLane);
      for (var currentTime = now(), prev = null, root = firstScheduledRoot;root !== null; ) {
        var next = root.next, nextLanes = scheduleTaskForRootDuringMicrotask(root, currentTime);
        if (nextLanes === 0)
          root.next = null, prev === null ? firstScheduledRoot = next : prev.next = next, next === null && (lastScheduledRoot = prev);
        else if (prev = root, syncTransitionLanes !== 0 || (nextLanes & 3) !== 0)
          mightHavePendingSyncWork = true;
        root = next;
      }
      pendingEffectsStatus !== 0 && pendingEffectsStatus !== 5 || flushSyncWorkAcrossRoots_impl(syncTransitionLanes, false);
      currentEventTransitionLane !== 0 && (currentEventTransitionLane = 0);
    }
    function scheduleTaskForRootDuringMicrotask(root, currentTime) {
      for (var { suspendedLanes, pingedLanes, expirationTimes } = root, lanes = root.pendingLanes & -62914561;0 < lanes; ) {
        var index$3 = 31 - clz32(lanes), lane = 1 << index$3, expirationTime = expirationTimes[index$3];
        if (expirationTime === -1) {
          if ((lane & suspendedLanes) === 0 || (lane & pingedLanes) !== 0)
            expirationTimes[index$3] = computeExpirationTime(lane, currentTime);
        } else
          expirationTime <= currentTime && (root.expiredLanes |= lane);
        lanes &= ~lane;
      }
      currentTime = workInProgressRoot;
      suspendedLanes = workInProgressRootRenderLanes;
      suspendedLanes = getNextLanes(root, root === currentTime ? suspendedLanes : 0, root.cancelPendingCommit !== null || root.timeoutHandle !== noTimeout);
      pingedLanes = root.callbackNode;
      if (suspendedLanes === 0 || root === currentTime && (workInProgressSuspendedReason === 2 || workInProgressSuspendedReason === 9) || root.cancelPendingCommit !== null)
        return pingedLanes !== null && pingedLanes !== null && cancelCallback$1(pingedLanes), root.callbackNode = null, root.callbackPriority = 0;
      if ((suspendedLanes & 3) === 0 || checkIfRootIsPrerendering(root, suspendedLanes)) {
        currentTime = suspendedLanes & -suspendedLanes;
        if (currentTime === root.callbackPriority)
          return currentTime;
        pingedLanes !== null && cancelCallback$1(pingedLanes);
        switch (lanesToEventPriority(suspendedLanes)) {
          case 2:
          case 8:
            suspendedLanes = UserBlockingPriority;
            break;
          case 32:
            suspendedLanes = NormalPriority$1;
            break;
          case 268435456:
            suspendedLanes = IdlePriority;
            break;
          default:
            suspendedLanes = NormalPriority$1;
        }
        pingedLanes = performWorkOnRootViaSchedulerTask.bind(null, root);
        suspendedLanes = scheduleCallback$3(suspendedLanes, pingedLanes);
        root.callbackPriority = currentTime;
        root.callbackNode = suspendedLanes;
        return currentTime;
      }
      pingedLanes !== null && pingedLanes !== null && cancelCallback$1(pingedLanes);
      root.callbackPriority = 2;
      root.callbackNode = null;
      return 2;
    }
    function performWorkOnRootViaSchedulerTask(root, didTimeout) {
      if (pendingEffectsStatus !== 0 && pendingEffectsStatus !== 5)
        return root.callbackNode = null, root.callbackPriority = 0, null;
      var originalCallbackNode = root.callbackNode;
      if (flushPendingEffects() && root.callbackNode !== originalCallbackNode)
        return null;
      var workInProgressRootRenderLanes$jscomp$0 = workInProgressRootRenderLanes;
      workInProgressRootRenderLanes$jscomp$0 = getNextLanes(root, root === workInProgressRoot ? workInProgressRootRenderLanes$jscomp$0 : 0, root.cancelPendingCommit !== null || root.timeoutHandle !== noTimeout);
      if (workInProgressRootRenderLanes$jscomp$0 === 0)
        return null;
      performWorkOnRoot(root, workInProgressRootRenderLanes$jscomp$0, didTimeout);
      scheduleTaskForRootDuringMicrotask(root, now());
      return root.callbackNode != null && root.callbackNode === originalCallbackNode ? performWorkOnRootViaSchedulerTask.bind(null, root) : null;
    }
    function performSyncWorkOnRoot(root, lanes) {
      if (flushPendingEffects())
        return null;
      performWorkOnRoot(root, lanes, true);
    }
    function scheduleImmediateRootScheduleTask() {
      supportsMicrotasks ? scheduleMicrotask(function() {
        (executionContext & 6) !== 0 ? scheduleCallback$3(ImmediatePriority, processRootScheduleInImmediateTask) : processRootScheduleInMicrotask();
      }) : scheduleCallback$3(ImmediatePriority, processRootScheduleInImmediateTask);
    }
    function requestTransitionLane() {
      if (currentEventTransitionLane === 0) {
        var actionScopeLane = currentEntangledLane;
        actionScopeLane === 0 && (actionScopeLane = nextTransitionUpdateLane, nextTransitionUpdateLane <<= 1, (nextTransitionUpdateLane & 261888) === 0 && (nextTransitionUpdateLane = 256));
        currentEventTransitionLane = actionScopeLane;
      }
      return currentEventTransitionLane;
    }
    function entangleAsyncAction(transition, thenable) {
      if (currentEntangledListeners === null) {
        var entangledListeners = currentEntangledListeners = [];
        currentEntangledPendingCount = 0;
        currentEntangledLane = requestTransitionLane();
        currentEntangledActionThenable = {
          status: "pending",
          value: undefined,
          then: function(resolve) {
            entangledListeners.push(resolve);
          }
        };
      }
      currentEntangledPendingCount++;
      thenable.then(pingEngtangledActionScope, pingEngtangledActionScope);
      return thenable;
    }
    function pingEngtangledActionScope() {
      if (--currentEntangledPendingCount === 0 && (entangledTransitionTypes = null, currentEntangledListeners !== null)) {
        currentEntangledActionThenable !== null && (currentEntangledActionThenable.status = "fulfilled");
        var listeners = currentEntangledListeners;
        currentEntangledListeners = null;
        currentEntangledLane = 0;
        currentEntangledActionThenable = null;
        for (var i = 0;i < listeners.length; i++)
          (0, listeners[i])();
      }
    }
    function chainThenableValue(thenable, result) {
      var listeners = [], thenableWithOverride = {
        status: "pending",
        value: null,
        reason: null,
        then: function(resolve) {
          listeners.push(resolve);
        }
      };
      thenable.then(function() {
        thenableWithOverride.status = "fulfilled";
        thenableWithOverride.value = result;
        for (var i = 0;i < listeners.length; i++)
          (0, listeners[i])(result);
      }, function(error) {
        thenableWithOverride.status = "rejected";
        thenableWithOverride.reason = error;
        for (error = 0;error < listeners.length; error++)
          (0, listeners[error])(undefined);
      });
      return thenableWithOverride;
    }
    function peekCacheFromPool() {
      var cacheResumedFromPreviousRender = resumedCache.current;
      return cacheResumedFromPreviousRender !== null ? cacheResumedFromPreviousRender : workInProgressRoot.pooledCache;
    }
    function pushTransition(offscreenWorkInProgress, prevCachePool) {
      prevCachePool === null ? push(resumedCache, resumedCache.current) : push(resumedCache, prevCachePool.pool);
    }
    function getSuspendedCache() {
      var cacheFromPool = peekCacheFromPool();
      return cacheFromPool === null ? null : {
        parent: isPrimaryRenderer ? CacheContext._currentValue : CacheContext._currentValue2,
        pool: cacheFromPool
      };
    }
    function shallowEqual(objA, objB) {
      if (objectIs(objA, objB))
        return true;
      if (typeof objA !== "object" || objA === null || typeof objB !== "object" || objB === null)
        return false;
      var keysA = Object.keys(objA), keysB = Object.keys(objB);
      if (keysA.length !== keysB.length)
        return false;
      for (keysB = 0;keysB < keysA.length; keysB++) {
        var currentKey = keysA[keysB];
        if (!hasOwnProperty.call(objB, currentKey) || !objectIs(objA[currentKey], objB[currentKey]))
          return false;
      }
      return true;
    }
    function isThenableResolved(thenable) {
      thenable = thenable.status;
      return thenable === "fulfilled" || thenable === "rejected";
    }
    function trackUsedThenable(thenableState, thenable, index) {
      index = thenableState[index];
      index === undefined ? thenableState.push(thenable) : index !== thenable && (thenable.then(noop$1, noop$1), thenable = index);
      switch (thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          thenableState = thenable.reason;
          checkIfUseWrappedInAsyncCatch(thenableState);
          if (thenableState === undefined && !("reason" in thenable))
            throw Error(formatProdErrorMessage(600));
          throw thenableState;
        default:
          if (typeof thenable.status === "string")
            thenable.then(noop$1, noop$1);
          else {
            thenableState = workInProgressRoot;
            if (thenableState !== null && 100 < thenableState.shellSuspendCounter)
              throw Error(formatProdErrorMessage(482));
            thenableState = thenable;
            thenableState.status = "pending";
            thenableState.then(function(fulfilledValue) {
              if (thenable.status === "pending") {
                var fulfilledThenable = thenable;
                fulfilledThenable.status = "fulfilled";
                fulfilledThenable.value = fulfilledValue;
              }
            }, function(error) {
              if (thenable.status === "pending") {
                var rejectedThenable = thenable;
                rejectedThenable.status = "rejected";
                rejectedThenable.reason = error;
              }
            });
          }
          switch (thenable.status) {
            case "fulfilled":
              return thenable.value;
            case "rejected":
              throw thenableState = thenable.reason, checkIfUseWrappedInAsyncCatch(thenableState), thenableState;
          }
          suspendedThenable = thenable;
          throw SuspenseException;
      }
    }
    function resolveLazy(lazyType) {
      try {
        var init = lazyType._init;
        return init(lazyType._payload);
      } catch (x) {
        if (x !== null && typeof x === "object" && typeof x.then === "function")
          throw suspendedThenable = x, SuspenseException;
        throw x;
      }
    }
    function getSuspendedThenable() {
      if (suspendedThenable === null)
        throw Error(formatProdErrorMessage(459));
      var thenable = suspendedThenable;
      suspendedThenable = null;
      return thenable;
    }
    function checkIfUseWrappedInAsyncCatch(rejectedReason) {
      if (rejectedReason === SuspenseException || rejectedReason === SuspenseActionException)
        throw Error(formatProdErrorMessage(483));
    }
    function unwrapThenable(thenable) {
      var index = thenableIndexCounter$1;
      thenableIndexCounter$1 += 1;
      thenableState$1 === null && (thenableState$1 = []);
      return trackUsedThenable(thenableState$1, thenable, index);
    }
    function coerceRef(workInProgress, element) {
      element = element.props.ref;
      workInProgress.ref = element !== undefined ? element : null;
    }
    function throwOnInvalidObjectTypeImpl(returnFiber, newChild) {
      if (newChild.$$typeof === REACT_LEGACY_ELEMENT_TYPE)
        throw Error(formatProdErrorMessage(525));
      returnFiber = Object.prototype.toString.call(newChild);
      throw Error(formatProdErrorMessage(31, returnFiber === "[object Object]" ? "object with keys {" + Object.keys(newChild).join(", ") + "}" : returnFiber));
    }
    function createChildReconciler(shouldTrackSideEffects) {
      function deleteChild(returnFiber, childToDelete) {
        if (shouldTrackSideEffects) {
          var deletions = returnFiber.deletions;
          deletions === null ? (returnFiber.deletions = [childToDelete], returnFiber.flags |= 16) : deletions.push(childToDelete);
        }
      }
      function deleteRemainingChildren(returnFiber, currentFirstChild) {
        if (!shouldTrackSideEffects)
          return null;
        for (;currentFirstChild !== null; )
          deleteChild(returnFiber, currentFirstChild), currentFirstChild = currentFirstChild.sibling;
        return null;
      }
      function mapRemainingChildren(currentFirstChild) {
        for (var existingChildren = new Map;currentFirstChild !== null; )
          currentFirstChild.key === null ? existingChildren.set(currentFirstChild.index, currentFirstChild) : existingChildren.set(currentFirstChild.key, currentFirstChild), currentFirstChild = currentFirstChild.sibling;
        return existingChildren;
      }
      function useFiber(fiber, pendingProps) {
        fiber = createWorkInProgress(fiber, pendingProps);
        fiber.index = 0;
        fiber.sibling = null;
        return fiber;
      }
      function placeChild(newFiber, lastPlacedIndex, newIndex) {
        newFiber.index = newIndex;
        if (!shouldTrackSideEffects)
          return newFiber.flags |= 1048576, lastPlacedIndex;
        newIndex = newFiber.alternate;
        if (newIndex !== null)
          return newIndex = newIndex.index, newIndex < lastPlacedIndex ? (newFiber.flags |= 2, lastPlacedIndex) : newIndex;
        newFiber.flags |= 134217730;
        return lastPlacedIndex;
      }
      function placeSingleChild(newFiber) {
        shouldTrackSideEffects && newFiber.alternate === null && (newFiber.flags |= 134217730);
        return newFiber;
      }
      function updateTextNode(returnFiber, current, textContent, lanes) {
        if (current === null || current.tag !== 6)
          return current = createFiberFromText(textContent, returnFiber.mode, lanes), current.return = returnFiber, current;
        current = useFiber(current, textContent);
        current.return = returnFiber;
        return current;
      }
      function updateElement(returnFiber, current, element, lanes) {
        var elementType = element.type;
        if (elementType === REACT_FRAGMENT_TYPE)
          return returnFiber = updateFragment(returnFiber, current, element.props.children, lanes, element.key), coerceRef(returnFiber, element), returnFiber;
        if (current !== null && (current.elementType === elementType || typeof elementType === "object" && elementType !== null && elementType.$$typeof === REACT_LAZY_TYPE && resolveLazy(elementType) === current.type))
          return current = useFiber(current, element.props), coerceRef(current, element), current.return = returnFiber, current;
        current = createFiberFromTypeAndProps(element.type, element.key, element.props, null, returnFiber.mode, lanes);
        coerceRef(current, element);
        current.return = returnFiber;
        return current;
      }
      function updatePortal(returnFiber, current, portal, lanes) {
        if (current === null || current.tag !== 4 || current.stateNode.containerInfo !== portal.containerInfo || current.stateNode.implementation !== portal.implementation)
          return current = createFiberFromPortal(portal, returnFiber.mode, lanes), current.return = returnFiber, current;
        current = useFiber(current, portal.children || []);
        current.return = returnFiber;
        return current;
      }
      function updateFragment(returnFiber, current, fragment, lanes, key) {
        if (current === null || current.tag !== 7)
          return current = createFiberFromFragment(fragment, returnFiber.mode, lanes, key), current.return = returnFiber, current;
        current = useFiber(current, fragment);
        current.return = returnFiber;
        return current;
      }
      function createChild(returnFiber, newChild, lanes) {
        if (typeof newChild === "string" && newChild !== "" || typeof newChild === "number" || typeof newChild === "bigint")
          return newChild = createFiberFromText("" + newChild, returnFiber.mode, lanes), newChild.return = returnFiber, newChild;
        if (typeof newChild === "object" && newChild !== null) {
          switch (newChild.$$typeof) {
            case REACT_ELEMENT_TYPE:
              return lanes = createFiberFromTypeAndProps(newChild.type, newChild.key, newChild.props, null, returnFiber.mode, lanes), coerceRef(lanes, newChild), lanes.return = returnFiber, lanes;
            case REACT_PORTAL_TYPE:
              return newChild = createFiberFromPortal(newChild, returnFiber.mode, lanes), newChild.return = returnFiber, newChild;
            case REACT_LAZY_TYPE:
              return newChild = resolveLazy(newChild), createChild(returnFiber, newChild, lanes);
          }
          if (isArrayImpl(newChild) || getIteratorFn(newChild))
            return newChild = createFiberFromFragment(newChild, returnFiber.mode, lanes, null), newChild.return = returnFiber, newChild;
          if (typeof newChild.then === "function")
            return createChild(returnFiber, unwrapThenable(newChild), lanes);
          if (newChild.$$typeof === REACT_CONTEXT_TYPE)
            return createChild(returnFiber, readContextDuringReconciliation(returnFiber, newChild), lanes);
          throwOnInvalidObjectTypeImpl(returnFiber, newChild);
        }
        return null;
      }
      function updateSlot(returnFiber, oldFiber, newChild, lanes) {
        var key = oldFiber !== null ? oldFiber.key : null;
        if (typeof newChild === "string" && newChild !== "" || typeof newChild === "number" || typeof newChild === "bigint")
          return key !== null ? null : updateTextNode(returnFiber, oldFiber, "" + newChild, lanes);
        if (typeof newChild === "object" && newChild !== null) {
          switch (newChild.$$typeof) {
            case REACT_ELEMENT_TYPE:
              return newChild.key === key ? updateElement(returnFiber, oldFiber, newChild, lanes) : null;
            case REACT_PORTAL_TYPE:
              return newChild.key === key ? updatePortal(returnFiber, oldFiber, newChild, lanes) : null;
            case REACT_LAZY_TYPE:
              return newChild = resolveLazy(newChild), updateSlot(returnFiber, oldFiber, newChild, lanes);
          }
          if (isArrayImpl(newChild) || getIteratorFn(newChild))
            return key !== null ? null : updateFragment(returnFiber, oldFiber, newChild, lanes, null);
          if (typeof newChild.then === "function")
            return updateSlot(returnFiber, oldFiber, unwrapThenable(newChild), lanes);
          if (newChild.$$typeof === REACT_CONTEXT_TYPE)
            return updateSlot(returnFiber, oldFiber, readContextDuringReconciliation(returnFiber, newChild), lanes);
          throwOnInvalidObjectTypeImpl(returnFiber, newChild);
        }
        return null;
      }
      function updateFromMap(existingChildren, returnFiber, newIdx, newChild, lanes) {
        if (typeof newChild === "string" && newChild !== "" || typeof newChild === "number" || typeof newChild === "bigint")
          return existingChildren = existingChildren.get(newIdx) || null, updateTextNode(returnFiber, existingChildren, "" + newChild, lanes);
        if (typeof newChild === "object" && newChild !== null) {
          switch (newChild.$$typeof) {
            case REACT_ELEMENT_TYPE:
              return existingChildren = existingChildren.get(newChild.key === null ? newIdx : newChild.key) || null, updateElement(returnFiber, existingChildren, newChild, lanes);
            case REACT_PORTAL_TYPE:
              return existingChildren = existingChildren.get(newChild.key === null ? newIdx : newChild.key) || null, updatePortal(returnFiber, existingChildren, newChild, lanes);
            case REACT_LAZY_TYPE:
              return newChild = resolveLazy(newChild), updateFromMap(existingChildren, returnFiber, newIdx, newChild, lanes);
          }
          if (isArrayImpl(newChild) || getIteratorFn(newChild))
            return existingChildren = existingChildren.get(newIdx) || null, updateFragment(returnFiber, existingChildren, newChild, lanes, null);
          if (typeof newChild.then === "function")
            return updateFromMap(existingChildren, returnFiber, newIdx, unwrapThenable(newChild), lanes);
          if (newChild.$$typeof === REACT_CONTEXT_TYPE)
            return updateFromMap(existingChildren, returnFiber, newIdx, readContextDuringReconciliation(returnFiber, newChild), lanes);
          throwOnInvalidObjectTypeImpl(returnFiber, newChild);
        }
        return null;
      }
      function reconcileChildrenArray(returnFiber, currentFirstChild, newChildren, lanes) {
        for (var resultingFirstChild = null, previousNewFiber = null, oldFiber = currentFirstChild, newIdx = currentFirstChild = 0, nextOldFiber = null;oldFiber !== null && newIdx < newChildren.length; newIdx++) {
          oldFiber.index > newIdx ? (nextOldFiber = oldFiber, oldFiber = null) : nextOldFiber = oldFiber.sibling;
          var newFiber = updateSlot(returnFiber, oldFiber, newChildren[newIdx], lanes);
          if (newFiber === null) {
            oldFiber === null && (oldFiber = nextOldFiber);
            break;
          }
          shouldTrackSideEffects && oldFiber && newFiber.alternate === null && deleteChild(returnFiber, oldFiber);
          currentFirstChild = placeChild(newFiber, currentFirstChild, newIdx);
          previousNewFiber === null ? resultingFirstChild = newFiber : previousNewFiber.sibling = newFiber;
          previousNewFiber = newFiber;
          oldFiber = nextOldFiber;
        }
        if (newIdx === newChildren.length)
          return deleteRemainingChildren(returnFiber, oldFiber), isHydrating && pushTreeFork(returnFiber, newIdx), resultingFirstChild;
        if (oldFiber === null) {
          for (;newIdx < newChildren.length; newIdx++)
            oldFiber = createChild(returnFiber, newChildren[newIdx], lanes), oldFiber !== null && (currentFirstChild = placeChild(oldFiber, currentFirstChild, newIdx), previousNewFiber === null ? resultingFirstChild = oldFiber : previousNewFiber.sibling = oldFiber, previousNewFiber = oldFiber);
          isHydrating && pushTreeFork(returnFiber, newIdx);
          return resultingFirstChild;
        }
        for (oldFiber = mapRemainingChildren(oldFiber);newIdx < newChildren.length; newIdx++)
          nextOldFiber = updateFromMap(oldFiber, returnFiber, newIdx, newChildren[newIdx], lanes), nextOldFiber !== null && (shouldTrackSideEffects && (newFiber = nextOldFiber.alternate, newFiber !== null && oldFiber.delete(newFiber.key === null ? newIdx : newFiber.key)), currentFirstChild = placeChild(nextOldFiber, currentFirstChild, newIdx), previousNewFiber === null ? resultingFirstChild = nextOldFiber : previousNewFiber.sibling = nextOldFiber, previousNewFiber = nextOldFiber);
        shouldTrackSideEffects && oldFiber.forEach(function(child) {
          return deleteChild(returnFiber, child);
        });
        isHydrating && pushTreeFork(returnFiber, newIdx);
        return resultingFirstChild;
      }
      function reconcileChildrenIterator(returnFiber, currentFirstChild, newChildren, lanes) {
        if (newChildren == null)
          throw Error(formatProdErrorMessage(151));
        for (var resultingFirstChild = null, previousNewFiber = null, oldFiber = currentFirstChild, newIdx = currentFirstChild = 0, nextOldFiber = null, step = newChildren.next();oldFiber !== null && !step.done; newIdx++, step = newChildren.next()) {
          oldFiber.index > newIdx ? (nextOldFiber = oldFiber, oldFiber = null) : nextOldFiber = oldFiber.sibling;
          var newFiber = updateSlot(returnFiber, oldFiber, step.value, lanes);
          if (newFiber === null) {
            oldFiber === null && (oldFiber = nextOldFiber);
            break;
          }
          shouldTrackSideEffects && oldFiber && newFiber.alternate === null && deleteChild(returnFiber, oldFiber);
          currentFirstChild = placeChild(newFiber, currentFirstChild, newIdx);
          previousNewFiber === null ? resultingFirstChild = newFiber : previousNewFiber.sibling = newFiber;
          previousNewFiber = newFiber;
          oldFiber = nextOldFiber;
        }
        if (step.done)
          return deleteRemainingChildren(returnFiber, oldFiber), isHydrating && pushTreeFork(returnFiber, newIdx), resultingFirstChild;
        if (oldFiber === null) {
          for (;!step.done; newIdx++, step = newChildren.next())
            step = createChild(returnFiber, step.value, lanes), step !== null && (currentFirstChild = placeChild(step, currentFirstChild, newIdx), previousNewFiber === null ? resultingFirstChild = step : previousNewFiber.sibling = step, previousNewFiber = step);
          isHydrating && pushTreeFork(returnFiber, newIdx);
          return resultingFirstChild;
        }
        for (oldFiber = mapRemainingChildren(oldFiber);!step.done; newIdx++, step = newChildren.next())
          step = updateFromMap(oldFiber, returnFiber, newIdx, step.value, lanes), step !== null && (shouldTrackSideEffects && (nextOldFiber = step.alternate, nextOldFiber !== null && oldFiber.delete(nextOldFiber.key === null ? newIdx : nextOldFiber.key)), currentFirstChild = placeChild(step, currentFirstChild, newIdx), previousNewFiber === null ? resultingFirstChild = step : previousNewFiber.sibling = step, previousNewFiber = step);
        shouldTrackSideEffects && oldFiber.forEach(function(child) {
          return deleteChild(returnFiber, child);
        });
        isHydrating && pushTreeFork(returnFiber, newIdx);
        return resultingFirstChild;
      }
      function reconcileChildFibersImpl(returnFiber, currentFirstChild, newChild, lanes) {
        typeof newChild === "object" && newChild !== null && newChild.type === REACT_FRAGMENT_TYPE && newChild.key === null && newChild.props.ref === undefined && (newChild = newChild.props.children);
        if (typeof newChild === "object" && newChild !== null) {
          switch (newChild.$$typeof) {
            case REACT_ELEMENT_TYPE:
              a: {
                for (var key = newChild.key;currentFirstChild !== null; ) {
                  if (currentFirstChild.key === key) {
                    key = newChild.type;
                    if (key === REACT_FRAGMENT_TYPE) {
                      if (currentFirstChild.tag === 7) {
                        deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
                        lanes = useFiber(currentFirstChild, newChild.props.children);
                        coerceRef(lanes, newChild);
                        lanes.return = returnFiber;
                        returnFiber = lanes;
                        break a;
                      }
                    } else if (currentFirstChild.elementType === key || typeof key === "object" && key !== null && key.$$typeof === REACT_LAZY_TYPE && resolveLazy(key) === currentFirstChild.type) {
                      deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
                      lanes = useFiber(currentFirstChild, newChild.props);
                      coerceRef(lanes, newChild);
                      lanes.return = returnFiber;
                      returnFiber = lanes;
                      break a;
                    }
                    deleteRemainingChildren(returnFiber, currentFirstChild);
                    break;
                  } else
                    deleteChild(returnFiber, currentFirstChild);
                  currentFirstChild = currentFirstChild.sibling;
                }
                newChild.type === REACT_FRAGMENT_TYPE ? (lanes = createFiberFromFragment(newChild.props.children, returnFiber.mode, lanes, newChild.key), coerceRef(lanes, newChild), lanes.return = returnFiber, returnFiber = lanes) : (lanes = createFiberFromTypeAndProps(newChild.type, newChild.key, newChild.props, null, returnFiber.mode, lanes), coerceRef(lanes, newChild), lanes.return = returnFiber, returnFiber = lanes);
              }
              return placeSingleChild(returnFiber);
            case REACT_PORTAL_TYPE:
              a: {
                for (key = newChild.key;currentFirstChild !== null; ) {
                  if (currentFirstChild.key === key)
                    if (currentFirstChild.tag === 4 && currentFirstChild.stateNode.containerInfo === newChild.containerInfo && currentFirstChild.stateNode.implementation === newChild.implementation) {
                      deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
                      lanes = useFiber(currentFirstChild, newChild.children || []);
                      lanes.return = returnFiber;
                      returnFiber = lanes;
                      break a;
                    } else {
                      deleteRemainingChildren(returnFiber, currentFirstChild);
                      break;
                    }
                  else
                    deleteChild(returnFiber, currentFirstChild);
                  currentFirstChild = currentFirstChild.sibling;
                }
                lanes = createFiberFromPortal(newChild, returnFiber.mode, lanes);
                lanes.return = returnFiber;
                returnFiber = lanes;
              }
              return placeSingleChild(returnFiber);
            case REACT_LAZY_TYPE:
              return newChild = resolveLazy(newChild), reconcileChildFibersImpl(returnFiber, currentFirstChild, newChild, lanes);
          }
          if (isArrayImpl(newChild))
            return reconcileChildrenArray(returnFiber, currentFirstChild, newChild, lanes);
          if (getIteratorFn(newChild)) {
            key = getIteratorFn(newChild);
            if (typeof key !== "function")
              throw Error(formatProdErrorMessage(150));
            newChild = key.call(newChild);
            return reconcileChildrenIterator(returnFiber, currentFirstChild, newChild, lanes);
          }
          if (typeof newChild.then === "function")
            return reconcileChildFibersImpl(returnFiber, currentFirstChild, unwrapThenable(newChild), lanes);
          if (newChild.$$typeof === REACT_CONTEXT_TYPE)
            return reconcileChildFibersImpl(returnFiber, currentFirstChild, readContextDuringReconciliation(returnFiber, newChild), lanes);
          throwOnInvalidObjectTypeImpl(returnFiber, newChild);
        }
        return typeof newChild === "string" && newChild !== "" || typeof newChild === "number" || typeof newChild === "bigint" ? (newChild = "" + newChild, currentFirstChild !== null && currentFirstChild.tag === 6 ? (deleteRemainingChildren(returnFiber, currentFirstChild.sibling), lanes = useFiber(currentFirstChild, newChild), lanes.return = returnFiber, returnFiber = lanes) : (deleteRemainingChildren(returnFiber, currentFirstChild), lanes = createFiberFromText(newChild, returnFiber.mode, lanes), lanes.return = returnFiber, returnFiber = lanes), placeSingleChild(returnFiber)) : deleteRemainingChildren(returnFiber, currentFirstChild);
      }
      return function(returnFiber, currentFirstChild, newChild, lanes) {
        try {
          thenableIndexCounter$1 = 0;
          var firstChildFiber = reconcileChildFibersImpl(returnFiber, currentFirstChild, newChild, lanes);
          thenableState$1 = null;
          return firstChildFiber;
        } catch (x) {
          if (x === SuspenseException || x === SuspenseActionException)
            throw x;
          var fiber = createFiber(29, x, null, returnFiber.mode);
          fiber.lanes = lanes;
          fiber.return = returnFiber;
          return fiber;
        } finally {}
      };
    }
    function finishQueueingConcurrentUpdates() {
      for (var endIndex = concurrentQueuesIndex, i = concurrentlyUpdatedLanes = concurrentQueuesIndex = 0;i < endIndex; ) {
        var fiber = concurrentQueues[i];
        concurrentQueues[i++] = null;
        var queue = concurrentQueues[i];
        concurrentQueues[i++] = null;
        var update = concurrentQueues[i];
        concurrentQueues[i++] = null;
        var lane = concurrentQueues[i];
        concurrentQueues[i++] = null;
        if (queue !== null && update !== null) {
          var pending = queue.pending;
          pending === null ? update.next = update : (update.next = pending.next, pending.next = update);
          queue.pending = update;
        }
        lane !== 0 && markUpdateLaneFromFiberToRoot(fiber, update, lane);
      }
    }
    function enqueueUpdate$1(fiber, queue, update, lane) {
      concurrentQueues[concurrentQueuesIndex++] = fiber;
      concurrentQueues[concurrentQueuesIndex++] = queue;
      concurrentQueues[concurrentQueuesIndex++] = update;
      concurrentQueues[concurrentQueuesIndex++] = lane;
      concurrentlyUpdatedLanes |= lane;
      fiber.lanes |= lane;
      fiber = fiber.alternate;
      fiber !== null && (fiber.lanes |= lane);
    }
    function enqueueConcurrentHookUpdate(fiber, queue, update, lane) {
      enqueueUpdate$1(fiber, queue, update, lane);
      return getRootForUpdatedFiber(fiber);
    }
    function enqueueConcurrentRenderForLane(fiber, lane) {
      enqueueUpdate$1(fiber, null, null, lane);
      return getRootForUpdatedFiber(fiber);
    }
    function markUpdateLaneFromFiberToRoot(sourceFiber, update, lane) {
      sourceFiber.lanes |= lane;
      var alternate = sourceFiber.alternate;
      alternate !== null && (alternate.lanes |= lane);
      for (var isHidden = false, parent = sourceFiber.return;parent !== null; )
        parent.childLanes |= lane, alternate = parent.alternate, alternate !== null && (alternate.childLanes |= lane), parent.tag === 22 && (sourceFiber = parent.stateNode, sourceFiber === null || sourceFiber._visibility & 1 || (isHidden = true)), sourceFiber = parent, parent = parent.return;
      return sourceFiber.tag === 3 ? (parent = sourceFiber.stateNode, isHidden && update !== null && (isHidden = 31 - clz32(lane), sourceFiber = parent.hiddenUpdates, alternate = sourceFiber[isHidden], alternate === null ? sourceFiber[isHidden] = [update] : alternate.push(update), update.lane = lane | 536870912), parent) : null;
    }
    function getRootForUpdatedFiber(sourceFiber) {
      if (50 < nestedUpdateCount)
        throw nestedUpdateCount = 0, rootWithNestedUpdates = null, Error(formatProdErrorMessage(185));
      for (var parent = sourceFiber.return;parent !== null; )
        sourceFiber = parent, parent = sourceFiber.return;
      return sourceFiber.tag === 3 ? sourceFiber.stateNode : null;
    }
    function initializeUpdateQueue(fiber) {
      fiber.updateQueue = {
        baseState: fiber.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: { pending: null, lanes: 0, hiddenCallbacks: null },
        callbacks: null
      };
    }
    function cloneUpdateQueue(current, workInProgress) {
      current = current.updateQueue;
      workInProgress.updateQueue === current && (workInProgress.updateQueue = {
        baseState: current.baseState,
        firstBaseUpdate: current.firstBaseUpdate,
        lastBaseUpdate: current.lastBaseUpdate,
        shared: current.shared,
        callbacks: null
      });
    }
    function createUpdate(lane) {
      return { lane, tag: 0, payload: null, callback: null, next: null };
    }
    function enqueueUpdate(fiber, update, lane) {
      var updateQueue = fiber.updateQueue;
      if (updateQueue === null)
        return null;
      updateQueue = updateQueue.shared;
      if ((executionContext & 2) !== 0) {
        var pending = updateQueue.pending;
        pending === null ? update.next = update : (update.next = pending.next, pending.next = update);
        updateQueue.pending = update;
        update = getRootForUpdatedFiber(fiber);
        markUpdateLaneFromFiberToRoot(fiber, null, lane);
        return update;
      }
      enqueueUpdate$1(fiber, updateQueue, update, lane);
      return getRootForUpdatedFiber(fiber);
    }
    function entangleTransitions(root, fiber, lane) {
      fiber = fiber.updateQueue;
      if (fiber !== null && (fiber = fiber.shared, (lane & 4194048) !== 0)) {
        var queueLanes = fiber.lanes;
        queueLanes &= root.pendingLanes;
        lane |= queueLanes;
        fiber.lanes = lane;
        markRootEntangled(root, lane);
      }
    }
    function enqueueCapturedUpdate(workInProgress, capturedUpdate) {
      var queue = workInProgress.updateQueue, current = workInProgress.alternate;
      if (current !== null && (current = current.updateQueue, queue === current)) {
        var newFirst = null, newLast = null;
        queue = queue.firstBaseUpdate;
        if (queue !== null) {
          do {
            var clone = {
              lane: queue.lane,
              tag: queue.tag,
              payload: queue.payload,
              callback: null,
              next: null
            };
            newLast === null ? newFirst = newLast = clone : newLast = newLast.next = clone;
            queue = queue.next;
          } while (queue !== null);
          newLast === null ? newFirst = newLast = capturedUpdate : newLast = newLast.next = capturedUpdate;
        } else
          newFirst = newLast = capturedUpdate;
        queue = {
          baseState: current.baseState,
          firstBaseUpdate: newFirst,
          lastBaseUpdate: newLast,
          shared: current.shared,
          callbacks: current.callbacks
        };
        workInProgress.updateQueue = queue;
        return;
      }
      workInProgress = queue.lastBaseUpdate;
      workInProgress === null ? queue.firstBaseUpdate = capturedUpdate : workInProgress.next = capturedUpdate;
      queue.lastBaseUpdate = capturedUpdate;
    }
    function suspendIfUpdateReadFromEntangledAsyncAction() {
      if (didReadFromEntangledAsyncAction) {
        var entangledActionThenable = currentEntangledActionThenable;
        if (entangledActionThenable !== null)
          throw entangledActionThenable;
      }
    }
    function processUpdateQueue(workInProgress$jscomp$0, props, instance$jscomp$0, renderLanes) {
      didReadFromEntangledAsyncAction = false;
      var queue = workInProgress$jscomp$0.updateQueue;
      hasForceUpdate = false;
      var { firstBaseUpdate, lastBaseUpdate } = queue, pendingQueue = queue.shared.pending;
      if (pendingQueue !== null) {
        queue.shared.pending = null;
        var lastPendingUpdate = pendingQueue, firstPendingUpdate = lastPendingUpdate.next;
        lastPendingUpdate.next = null;
        lastBaseUpdate === null ? firstBaseUpdate = firstPendingUpdate : lastBaseUpdate.next = firstPendingUpdate;
        lastBaseUpdate = lastPendingUpdate;
        var current = workInProgress$jscomp$0.alternate;
        current !== null && (current = current.updateQueue, pendingQueue = current.lastBaseUpdate, pendingQueue !== lastBaseUpdate && (pendingQueue === null ? current.firstBaseUpdate = firstPendingUpdate : pendingQueue.next = firstPendingUpdate, current.lastBaseUpdate = lastPendingUpdate));
      }
      if (firstBaseUpdate !== null) {
        var newState = queue.baseState;
        lastBaseUpdate = 0;
        current = firstPendingUpdate = lastPendingUpdate = null;
        pendingQueue = firstBaseUpdate;
        do {
          var updateLane = pendingQueue.lane & -536870913, isHiddenUpdate = updateLane !== pendingQueue.lane;
          if (isHiddenUpdate ? (workInProgressRootRenderLanes & updateLane) === updateLane : (renderLanes & updateLane) === updateLane) {
            updateLane !== 0 && updateLane === currentEntangledLane && (didReadFromEntangledAsyncAction = true);
            current !== null && (current = current.next = {
              lane: 0,
              tag: pendingQueue.tag,
              payload: pendingQueue.payload,
              callback: null,
              next: null
            });
            a: {
              var workInProgress = workInProgress$jscomp$0, update = pendingQueue;
              updateLane = props;
              var instance = instance$jscomp$0;
              switch (update.tag) {
                case 1:
                  workInProgress = update.payload;
                  if (typeof workInProgress === "function") {
                    newState = workInProgress.call(instance, newState, updateLane);
                    break a;
                  }
                  newState = workInProgress;
                  break a;
                case 3:
                  workInProgress.flags = workInProgress.flags & -65537 | 128;
                case 0:
                  workInProgress = update.payload;
                  updateLane = typeof workInProgress === "function" ? workInProgress.call(instance, newState, updateLane) : workInProgress;
                  if (updateLane === null || updateLane === undefined)
                    break a;
                  newState = assign({}, newState, updateLane);
                  break a;
                case 2:
                  hasForceUpdate = true;
              }
            }
            updateLane = pendingQueue.callback;
            updateLane !== null && (workInProgress$jscomp$0.flags |= 64, isHiddenUpdate && (workInProgress$jscomp$0.flags |= 8192), isHiddenUpdate = queue.callbacks, isHiddenUpdate === null ? queue.callbacks = [updateLane] : isHiddenUpdate.push(updateLane));
          } else
            isHiddenUpdate = {
              lane: updateLane,
              tag: pendingQueue.tag,
              payload: pendingQueue.payload,
              callback: pendingQueue.callback,
              next: null
            }, current === null ? (firstPendingUpdate = current = isHiddenUpdate, lastPendingUpdate = newState) : current = current.next = isHiddenUpdate, lastBaseUpdate |= updateLane;
          pendingQueue = pendingQueue.next;
          if (pendingQueue === null)
            if (pendingQueue = queue.shared.pending, pendingQueue === null)
              break;
            else
              isHiddenUpdate = pendingQueue, pendingQueue = isHiddenUpdate.next, isHiddenUpdate.next = null, queue.lastBaseUpdate = isHiddenUpdate, queue.shared.pending = null;
        } while (1);
        current === null && (lastPendingUpdate = newState);
        queue.baseState = lastPendingUpdate;
        queue.firstBaseUpdate = firstPendingUpdate;
        queue.lastBaseUpdate = current;
        firstBaseUpdate === null && (queue.shared.lanes = 0);
        workInProgressRootSkippedLanes |= lastBaseUpdate;
        workInProgress$jscomp$0.lanes = lastBaseUpdate;
        workInProgress$jscomp$0.memoizedState = newState;
      }
    }
    function callCallback(callback, context) {
      if (typeof callback !== "function")
        throw Error(formatProdErrorMessage(191, callback));
      callback.call(context);
    }
    function commitCallbacks(updateQueue, context) {
      var callbacks = updateQueue.callbacks;
      if (callbacks !== null)
        for (updateQueue.callbacks = null, updateQueue = 0;updateQueue < callbacks.length; updateQueue++)
          callCallback(callbacks[updateQueue], context);
    }
    function pushHiddenContext(fiber, context) {
      fiber = entangledRenderLanes;
      push(prevEntangledRenderLanesCursor, fiber);
      push(currentTreeHiddenStackCursor, context);
      entangledRenderLanes = fiber | context.baseLanes;
    }
    function reuseHiddenContextOnStack() {
      push(prevEntangledRenderLanesCursor, entangledRenderLanes);
      push(currentTreeHiddenStackCursor, currentTreeHiddenStackCursor.current);
    }
    function popHiddenContext() {
      entangledRenderLanes = prevEntangledRenderLanesCursor.current;
      pop(currentTreeHiddenStackCursor);
      pop(prevEntangledRenderLanesCursor);
    }
    function pushPrimaryTreeSuspenseHandler(handler) {
      var current = handler.alternate;
      push(suspenseStackCursor, suspenseStackCursor.current & 1);
      push(suspenseHandlerStackCursor, handler);
      shellBoundary === null && (current === null || currentTreeHiddenStackCursor.current !== null ? shellBoundary = handler : current.memoizedState !== null && (shellBoundary = handler));
    }
    function pushDehydratedActivitySuspenseHandler(fiber) {
      push(suspenseStackCursor, suspenseStackCursor.current);
      push(suspenseHandlerStackCursor, fiber);
      shellBoundary === null && (shellBoundary = fiber);
    }
    function pushOffscreenSuspenseHandler(fiber) {
      fiber.tag === 22 ? (push(suspenseStackCursor, suspenseStackCursor.current), push(suspenseHandlerStackCursor, fiber), shellBoundary === null && (shellBoundary = fiber)) : reuseSuspenseHandlerOnStack();
    }
    function reuseSuspenseHandlerOnStack() {
      push(suspenseStackCursor, suspenseStackCursor.current);
      push(suspenseHandlerStackCursor, suspenseHandlerStackCursor.current);
    }
    function popSuspenseHandler(fiber) {
      pop(suspenseHandlerStackCursor);
      shellBoundary === fiber && (shellBoundary = null);
      pop(suspenseStackCursor);
    }
    function pushSuspenseListContext(fiber, newContext) {
      push(suspenseHandlerStackCursor, suspenseHandlerStackCursor.current);
      push(suspenseStackCursor, newContext);
    }
    function popSuspenseListContext(fiber) {
      pop(suspenseStackCursor);
      pop(suspenseHandlerStackCursor);
      shellBoundary === fiber && (shellBoundary = null);
    }
    function findFirstSuspended(row) {
      for (var node = row;node !== null; ) {
        if (node.tag === 13) {
          var state = node.memoizedState;
          if (state !== null && (state = state.dehydrated, state === null || isSuspenseInstancePending(state) || isSuspenseInstanceFallback(state)))
            return node;
        } else if (node.tag === 19 && node.memoizedProps.revealOrder !== "independent") {
          if ((node.flags & 128) !== 0)
            return node;
        } else if (node.child !== null) {
          node.child.return = node;
          node = node.child;
          continue;
        }
        if (node === row)
          break;
        for (;node.sibling === null; ) {
          if (node.return === null || node.return === row)
            return null;
          node = node.return;
        }
        node.sibling.return = node.return;
        node = node.sibling;
      }
      return null;
    }
    function throwInvalidHookError() {
      throw Error(formatProdErrorMessage(321));
    }
    function areHookInputsEqual(nextDeps, prevDeps) {
      if (prevDeps === null)
        return false;
      for (var i = 0;i < prevDeps.length && i < nextDeps.length; i++)
        if (!objectIs(nextDeps[i], prevDeps[i]))
          return false;
      return true;
    }
    function renderWithHooks(current, workInProgress, Component, props, secondArg, nextRenderLanes) {
      renderLanes = nextRenderLanes;
      currentlyRenderingFiber = workInProgress;
      workInProgress.memoizedState = null;
      workInProgress.updateQueue = null;
      workInProgress.lanes = 0;
      ReactSharedInternals.H = current === null || current.memoizedState === null ? HooksDispatcherOnMount : HooksDispatcherOnUpdate;
      shouldDoubleInvokeUserFnsInHooksDEV = false;
      nextRenderLanes = Component(props, secondArg);
      shouldDoubleInvokeUserFnsInHooksDEV = false;
      didScheduleRenderPhaseUpdateDuringThisPass && (nextRenderLanes = renderWithHooksAgain(workInProgress, Component, props, secondArg));
      finishRenderingHooks(current);
      return nextRenderLanes;
    }
    function finishRenderingHooks(current) {
      ReactSharedInternals.H = ContextOnlyDispatcher;
      var didRenderTooFewHooks = currentHook !== null && currentHook.next !== null;
      renderLanes = 0;
      workInProgressHook = currentHook = currentlyRenderingFiber = null;
      didScheduleRenderPhaseUpdate = false;
      thenableIndexCounter = 0;
      thenableState = null;
      if (didRenderTooFewHooks)
        throw Error(formatProdErrorMessage(300));
      current === null || didReceiveUpdate || (current = current.dependencies, current !== null && checkIfContextChanged(current) && (didReceiveUpdate = true));
    }
    function renderWithHooksAgain(workInProgress, Component, props, secondArg) {
      currentlyRenderingFiber = workInProgress;
      var numberOfReRenders = 0;
      do {
        didScheduleRenderPhaseUpdateDuringThisPass && (thenableState = null);
        thenableIndexCounter = 0;
        didScheduleRenderPhaseUpdateDuringThisPass = false;
        if (25 <= numberOfReRenders)
          throw Error(formatProdErrorMessage(301));
        numberOfReRenders += 1;
        workInProgressHook = currentHook = null;
        if (workInProgress.updateQueue != null) {
          var children = workInProgress.updateQueue;
          children.lastEffect = null;
          children.events = null;
          children.stores = null;
          children.memoCache != null && (children.memoCache.index = 0);
        }
        ReactSharedInternals.H = HooksDispatcherOnRerender;
        children = Component(props, secondArg);
      } while (didScheduleRenderPhaseUpdateDuringThisPass);
      return children;
    }
    function TransitionAwareHostComponent() {
      var dispatcher = ReactSharedInternals.H, maybeThenable = dispatcher.useState()[0];
      maybeThenable = typeof maybeThenable.then === "function" ? useThenable(maybeThenable) : maybeThenable;
      dispatcher = dispatcher.useState()[0];
      (currentHook !== null ? currentHook.memoizedState : null) !== dispatcher && (currentlyRenderingFiber.flags |= 1024);
      return maybeThenable;
    }
    function checkDidRenderIdHook() {
      var didRenderIdHook = localIdCounter !== 0;
      localIdCounter = 0;
      return didRenderIdHook;
    }
    function bailoutHooks(current, workInProgress, lanes) {
      workInProgress.updateQueue = current.updateQueue;
      workInProgress.flags &= -2053;
      current.lanes &= ~lanes;
    }
    function resetHooksOnUnwind(workInProgress) {
      if (didScheduleRenderPhaseUpdate) {
        for (workInProgress = workInProgress.memoizedState;workInProgress !== null; ) {
          var queue = workInProgress.queue;
          queue !== null && (queue.pending = null);
          workInProgress = workInProgress.next;
        }
        didScheduleRenderPhaseUpdate = false;
      }
      renderLanes = 0;
      workInProgressHook = currentHook = currentlyRenderingFiber = null;
      didScheduleRenderPhaseUpdateDuringThisPass = false;
      thenableIndexCounter = localIdCounter = 0;
      thenableState = null;
    }
    function mountWorkInProgressHook() {
      var hook = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
      };
      workInProgressHook === null ? currentlyRenderingFiber.memoizedState = workInProgressHook = hook : workInProgressHook = workInProgressHook.next = hook;
      return workInProgressHook;
    }
    function updateWorkInProgressHook() {
      if (currentHook === null) {
        var nextCurrentHook = currentlyRenderingFiber.alternate;
        nextCurrentHook = nextCurrentHook !== null ? nextCurrentHook.memoizedState : null;
      } else
        nextCurrentHook = currentHook.next;
      var nextWorkInProgressHook = workInProgressHook === null ? currentlyRenderingFiber.memoizedState : workInProgressHook.next;
      if (nextWorkInProgressHook !== null)
        workInProgressHook = nextWorkInProgressHook, currentHook = nextCurrentHook;
      else {
        if (nextCurrentHook === null) {
          if (currentlyRenderingFiber.alternate === null)
            throw Error(formatProdErrorMessage(467));
          throw Error(formatProdErrorMessage(310));
        }
        currentHook = nextCurrentHook;
        nextCurrentHook = {
          memoizedState: currentHook.memoizedState,
          baseState: currentHook.baseState,
          baseQueue: currentHook.baseQueue,
          queue: currentHook.queue,
          next: null
        };
        workInProgressHook === null ? currentlyRenderingFiber.memoizedState = workInProgressHook = nextCurrentHook : workInProgressHook = workInProgressHook.next = nextCurrentHook;
      }
      return workInProgressHook;
    }
    function createFunctionComponentUpdateQueue() {
      return { lastEffect: null, events: null, stores: null, memoCache: null };
    }
    function useThenable(thenable) {
      var index = thenableIndexCounter;
      thenableIndexCounter += 1;
      thenableState === null && (thenableState = []);
      thenable = trackUsedThenable(thenableState, thenable, index);
      index = currentlyRenderingFiber;
      (workInProgressHook === null ? index.memoizedState : workInProgressHook.next) === null && (index = index.alternate, ReactSharedInternals.H = index === null || index.memoizedState === null ? HooksDispatcherOnMount : HooksDispatcherOnUpdate);
      return thenable;
    }
    function use(usable) {
      if (usable !== null && typeof usable === "object") {
        if (typeof usable.then === "function")
          return useThenable(usable);
        if (usable.$$typeof === REACT_RECOVERABLE_TYPE)
          return;
        if (usable.$$typeof === REACT_CONTEXT_TYPE)
          return readContext(usable);
      }
      throw Error(formatProdErrorMessage(438, String(usable)));
    }
    function useMemoCache(size) {
      var memoCache = null, updateQueue = currentlyRenderingFiber.updateQueue;
      updateQueue !== null && (memoCache = updateQueue.memoCache);
      if (memoCache == null) {
        var current = currentlyRenderingFiber.alternate;
        current !== null && (current = current.updateQueue, current !== null && (current = current.memoCache, current != null && (memoCache = {
          data: current.data.map(function(array) {
            return array.slice();
          }),
          index: 0
        })));
      }
      memoCache == null && (memoCache = { data: [], index: 0 });
      updateQueue === null && (updateQueue = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = updateQueue);
      updateQueue.memoCache = memoCache;
      updateQueue = memoCache.data[memoCache.index];
      if (updateQueue === undefined)
        for (updateQueue = memoCache.data[memoCache.index] = Array(size), current = 0;current < size; current++)
          updateQueue[current] = REACT_MEMO_CACHE_SENTINEL;
      memoCache.index++;
      return updateQueue;
    }
    function basicStateReducer(state, action) {
      return typeof action === "function" ? action(state) : action;
    }
    function updateReducer(reducer) {
      var hook = updateWorkInProgressHook();
      return updateReducerImpl(hook, currentHook, reducer);
    }
    function updateReducerImpl(hook, current, reducer) {
      var queue = hook.queue;
      if (queue === null)
        throw Error(formatProdErrorMessage(311));
      queue.lastRenderedReducer = reducer;
      var baseQueue = hook.baseQueue, pendingQueue = queue.pending;
      if (pendingQueue !== null) {
        if (baseQueue !== null) {
          var baseFirst = baseQueue.next;
          baseQueue.next = pendingQueue.next;
          pendingQueue.next = baseFirst;
        }
        current.baseQueue = baseQueue = pendingQueue;
        queue.pending = null;
      }
      pendingQueue = hook.baseState;
      if (baseQueue === null)
        hook.memoizedState = pendingQueue;
      else {
        current = baseQueue.next;
        var newBaseQueueFirst = baseFirst = null, newBaseQueueLast = null, update = current, didReadFromEntangledAsyncAction$53 = false;
        do {
          var updateLane = update.lane & -536870913;
          if (updateLane !== update.lane ? (workInProgressRootRenderLanes & updateLane) === updateLane : (renderLanes & updateLane) === updateLane) {
            var revertLane = update.revertLane;
            if (revertLane === 0)
              newBaseQueueLast !== null && (newBaseQueueLast = newBaseQueueLast.next = {
                lane: 0,
                revertLane: 0,
                gesture: null,
                action: update.action,
                hasEagerState: update.hasEagerState,
                eagerState: update.eagerState,
                next: null
              }), updateLane === currentEntangledLane && (didReadFromEntangledAsyncAction$53 = true);
            else if ((renderLanes & revertLane) === revertLane) {
              update = update.next;
              revertLane === currentEntangledLane && (didReadFromEntangledAsyncAction$53 = true);
              continue;
            } else
              updateLane = {
                lane: 0,
                revertLane: update.revertLane,
                gesture: null,
                action: update.action,
                hasEagerState: update.hasEagerState,
                eagerState: update.eagerState,
                next: null
              }, newBaseQueueLast === null ? (newBaseQueueFirst = newBaseQueueLast = updateLane, baseFirst = pendingQueue) : newBaseQueueLast = newBaseQueueLast.next = updateLane, currentlyRenderingFiber.lanes |= revertLane, workInProgressRootSkippedLanes |= revertLane;
            updateLane = update.action;
            shouldDoubleInvokeUserFnsInHooksDEV && reducer(pendingQueue, updateLane);
            pendingQueue = update.hasEagerState ? update.eagerState : reducer(pendingQueue, updateLane);
          } else
            revertLane = {
              lane: updateLane,
              revertLane: update.revertLane,
              gesture: update.gesture,
              action: update.action,
              hasEagerState: update.hasEagerState,
              eagerState: update.eagerState,
              next: null
            }, newBaseQueueLast === null ? (newBaseQueueFirst = newBaseQueueLast = revertLane, baseFirst = pendingQueue) : newBaseQueueLast = newBaseQueueLast.next = revertLane, currentlyRenderingFiber.lanes |= updateLane, workInProgressRootSkippedLanes |= updateLane;
          update = update.next;
        } while (update !== null && update !== current);
        newBaseQueueLast === null ? baseFirst = pendingQueue : newBaseQueueLast.next = newBaseQueueFirst;
        if (!objectIs(pendingQueue, hook.memoizedState) && (didReceiveUpdate = true, didReadFromEntangledAsyncAction$53 && (reducer = currentEntangledActionThenable, reducer !== null)))
          throw reducer;
        hook.memoizedState = pendingQueue;
        hook.baseState = baseFirst;
        hook.baseQueue = newBaseQueueLast;
        queue.lastRenderedState = pendingQueue;
      }
      baseQueue === null && (queue.lanes = 0);
      return [hook.memoizedState, queue.dispatch];
    }
    function rerenderReducer(reducer) {
      var hook = updateWorkInProgressHook(), queue = hook.queue;
      if (queue === null)
        throw Error(formatProdErrorMessage(311));
      queue.lastRenderedReducer = reducer;
      var { dispatch, pending: lastRenderPhaseUpdate } = queue, newState = hook.memoizedState;
      if (lastRenderPhaseUpdate !== null) {
        queue.pending = null;
        var update = lastRenderPhaseUpdate = lastRenderPhaseUpdate.next;
        do
          newState = reducer(newState, update.action), update = update.next;
        while (update !== lastRenderPhaseUpdate);
        objectIs(newState, hook.memoizedState) || (didReceiveUpdate = true);
        hook.memoizedState = newState;
        hook.baseQueue === null && (hook.baseState = newState);
        queue.lastRenderedState = newState;
      }
      return [newState, dispatch];
    }
    function updateSyncExternalStore(subscribe, getSnapshot, getServerSnapshot) {
      var fiber = currentlyRenderingFiber, hook = updateWorkInProgressHook(), isHydrating$jscomp$0 = isHydrating;
      if (isHydrating$jscomp$0) {
        if (getServerSnapshot === undefined)
          throw Error(formatProdErrorMessage(407));
        getServerSnapshot = getServerSnapshot();
      } else
        getServerSnapshot = getSnapshot();
      var snapshotChanged = !objectIs((currentHook || hook).memoizedState, getServerSnapshot);
      snapshotChanged && (hook.memoizedState = getServerSnapshot, didReceiveUpdate = true);
      hook = hook.queue;
      updateEffect(subscribeToStore.bind(null, fiber, hook, subscribe), [
        subscribe
      ]);
      subscribe = hook.getSnapshot !== getSnapshot || snapshotChanged || workInProgressHook !== null && (workInProgressHook.memoizedState.tag & 1) !== 0;
      pushSimpleEffect(subscribe ? 9 : 8, { destroy: undefined }, updateStoreInstance.bind(null, fiber, hook, getServerSnapshot, getSnapshot), null);
      if (subscribe) {
        fiber.flags |= 2048;
        if (workInProgressRoot === null)
          throw Error(formatProdErrorMessage(349));
        isHydrating$jscomp$0 || (renderLanes & 127) !== 0 || pushStoreConsistencyCheck(fiber, getSnapshot, getServerSnapshot);
      }
      return getServerSnapshot;
    }
    function pushStoreConsistencyCheck(fiber, getSnapshot, renderedSnapshot) {
      fiber.flags |= 16384;
      fiber = { getSnapshot, value: renderedSnapshot };
      getSnapshot = currentlyRenderingFiber.updateQueue;
      getSnapshot === null ? (getSnapshot = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = getSnapshot, getSnapshot.stores = [fiber]) : (renderedSnapshot = getSnapshot.stores, renderedSnapshot === null ? getSnapshot.stores = [fiber] : renderedSnapshot.push(fiber));
    }
    function updateStoreInstance(fiber, inst, nextSnapshot, getSnapshot) {
      inst.value = nextSnapshot;
      inst.getSnapshot = getSnapshot;
      checkIfSnapshotChanged(inst) && forceStoreRerender(fiber);
    }
    function subscribeToStore(fiber, inst, subscribe) {
      return subscribe(function() {
        checkIfSnapshotChanged(inst) && forceStoreRerender(fiber);
      });
    }
    function checkIfSnapshotChanged(inst) {
      var latestGetSnapshot = inst.getSnapshot;
      inst = inst.value;
      try {
        var nextValue = latestGetSnapshot();
        return !objectIs(inst, nextValue);
      } catch (error) {
        return true;
      }
    }
    function forceStoreRerender(fiber) {
      var root = enqueueConcurrentRenderForLane(fiber, 2);
      root !== null && scheduleUpdateOnFiber(root, fiber, 2);
    }
    function mountStateImpl(initialState) {
      var hook = mountWorkInProgressHook();
      if (typeof initialState === "function") {
        var initialStateInitializer = initialState;
        initialState = initialStateInitializer();
        if (shouldDoubleInvokeUserFnsInHooksDEV) {
          setIsStrictModeForDevtools(true);
          try {
            initialStateInitializer();
          } finally {
            setIsStrictModeForDevtools(false);
          }
        }
      }
      hook.memoizedState = hook.baseState = initialState;
      hook.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: basicStateReducer,
        lastRenderedState: initialState
      };
      return hook;
    }
    function updateOptimisticImpl(hook, current, passthrough, reducer) {
      hook.baseState = passthrough;
      return updateReducerImpl(hook, currentHook, typeof reducer === "function" ? reducer : basicStateReducer);
    }
    function dispatchActionState(fiber, actionQueue, setPendingState, setState, payload) {
      if (isRenderPhaseUpdate(fiber))
        throw Error(formatProdErrorMessage(485));
      fiber = actionQueue.action;
      if (fiber !== null) {
        var actionNode = {
          payload,
          action: fiber,
          next: null,
          isTransition: true,
          status: "pending",
          value: null,
          reason: null,
          listeners: [],
          then: function(listener) {
            actionNode.listeners.push(listener);
          }
        };
        ReactSharedInternals.T !== null ? setPendingState(true) : actionNode.isTransition = false;
        setState(actionNode);
        setPendingState = actionQueue.pending;
        setPendingState === null ? (actionNode.next = actionQueue.pending = actionNode, runActionStateAction(actionQueue, actionNode)) : (actionNode.next = setPendingState.next, actionQueue.pending = setPendingState.next = actionNode);
      }
    }
    function runActionStateAction(actionQueue, node) {
      var { action, payload } = node, prevState = actionQueue.state;
      if (node.isTransition) {
        var prevTransition = ReactSharedInternals.T, currentTransition = {};
        currentTransition.types = prevTransition !== null ? prevTransition.types : null;
        ReactSharedInternals.T = currentTransition;
        try {
          var returnValue = action(prevState, payload), onStartTransitionFinish = ReactSharedInternals.S;
          onStartTransitionFinish !== null && onStartTransitionFinish(currentTransition, returnValue);
          handleActionReturnValue(actionQueue, node, returnValue);
        } catch (error) {
          onActionError(actionQueue, node, error);
        } finally {
          prevTransition !== null && currentTransition.types !== null && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
        }
      } else
        try {
          prevTransition = action(prevState, payload), handleActionReturnValue(actionQueue, node, prevTransition);
        } catch (error$57) {
          onActionError(actionQueue, node, error$57);
        }
    }
    function handleActionReturnValue(actionQueue, node, returnValue) {
      returnValue !== null && typeof returnValue === "object" && typeof returnValue.then === "function" ? returnValue.then(function(nextState) {
        onActionSuccess(actionQueue, node, nextState);
      }, function(error) {
        return onActionError(actionQueue, node, error);
      }) : onActionSuccess(actionQueue, node, returnValue);
    }
    function onActionSuccess(actionQueue, actionNode, nextState) {
      actionNode.status = "fulfilled";
      actionNode.value = nextState;
      notifyActionListeners(actionNode);
      actionQueue.state = nextState;
      actionNode = actionQueue.pending;
      actionNode !== null && (nextState = actionNode.next, nextState === actionNode ? actionQueue.pending = null : (nextState = nextState.next, actionNode.next = nextState, runActionStateAction(actionQueue, nextState)));
    }
    function onActionError(actionQueue, actionNode, error) {
      var last = actionQueue.pending;
      actionQueue.pending = null;
      if (last !== null) {
        last = last.next;
        do
          actionNode.status = "rejected", actionNode.reason = error, notifyActionListeners(actionNode), actionNode = actionNode.next;
        while (actionNode !== last);
      }
      actionQueue.action = null;
    }
    function notifyActionListeners(actionNode) {
      actionNode = actionNode.listeners;
      for (var i = 0;i < actionNode.length; i++)
        (0, actionNode[i])();
    }
    function actionStateReducer(oldState, newState) {
      return newState;
    }
    function mountActionState(action, initialStateProp) {
      if (isHydrating) {
        var ssrFormState = workInProgressRoot.formState;
        if (ssrFormState !== null) {
          a: {
            var JSCompiler_inline_result = currentlyRenderingFiber;
            if (isHydrating) {
              if (nextHydratableInstance) {
                var markerInstance = canHydrateFormStateMarker(nextHydratableInstance, rootOrSingletonContext);
                if (markerInstance) {
                  nextHydratableInstance = getNextHydratableSibling(markerInstance);
                  JSCompiler_inline_result = isFormStateMarkerMatching(markerInstance);
                  break a;
                }
              }
              throwOnHydrationMismatch(JSCompiler_inline_result);
            }
            JSCompiler_inline_result = false;
          }
          JSCompiler_inline_result && (initialStateProp = ssrFormState[0]);
        }
      }
      ssrFormState = mountWorkInProgressHook();
      ssrFormState.memoizedState = ssrFormState.baseState = initialStateProp;
      JSCompiler_inline_result = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: actionStateReducer,
        lastRenderedState: initialStateProp
      };
      ssrFormState.queue = JSCompiler_inline_result;
      ssrFormState = dispatchSetState.bind(null, currentlyRenderingFiber, JSCompiler_inline_result);
      JSCompiler_inline_result.dispatch = ssrFormState;
      JSCompiler_inline_result = mountStateImpl(false);
      var setPendingState = dispatchOptimisticSetState.bind(null, currentlyRenderingFiber, false, JSCompiler_inline_result.queue);
      JSCompiler_inline_result = mountWorkInProgressHook();
      markerInstance = {
        state: initialStateProp,
        dispatch: null,
        action,
        pending: null
      };
      JSCompiler_inline_result.queue = markerInstance;
      ssrFormState = dispatchActionState.bind(null, currentlyRenderingFiber, markerInstance, setPendingState, ssrFormState);
      markerInstance.dispatch = ssrFormState;
      JSCompiler_inline_result.memoizedState = action;
      return [initialStateProp, ssrFormState, false];
    }
    function updateActionState(action) {
      var stateHook = updateWorkInProgressHook();
      return updateActionStateImpl(stateHook, currentHook, action);
    }
    function updateActionStateImpl(stateHook, currentStateHook, action) {
      currentStateHook = updateReducerImpl(stateHook, currentStateHook, actionStateReducer)[0];
      stateHook = updateReducer(basicStateReducer)[0];
      if (typeof currentStateHook === "object" && currentStateHook !== null && typeof currentStateHook.then === "function")
        try {
          var state = useThenable(currentStateHook);
        } catch (x) {
          if (x === SuspenseException)
            throw SuspenseActionException;
          throw x;
        }
      else
        state = currentStateHook;
      currentStateHook = updateWorkInProgressHook();
      var actionQueue = currentStateHook.queue, dispatch = actionQueue.dispatch;
      action !== currentStateHook.memoizedState && (currentlyRenderingFiber.flags |= 2048, pushSimpleEffect(9, { destroy: undefined }, actionStateActionEffect.bind(null, actionQueue, action), null));
      return [state, dispatch, stateHook];
    }
    function actionStateActionEffect(actionQueue, action) {
      actionQueue.action = action;
    }
    function rerenderActionState(action) {
      var stateHook = updateWorkInProgressHook(), currentStateHook = currentHook;
      if (currentStateHook !== null)
        return updateActionStateImpl(stateHook, currentStateHook, action);
      updateWorkInProgressHook();
      stateHook = stateHook.memoizedState;
      currentStateHook = updateWorkInProgressHook();
      var dispatch = currentStateHook.queue.dispatch;
      currentStateHook.memoizedState = action;
      return [stateHook, dispatch, false];
    }
    function pushSimpleEffect(tag, inst, create, deps) {
      tag = { tag, create, deps, inst, next: null };
      inst = currentlyRenderingFiber.updateQueue;
      inst === null && (inst = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = inst);
      create = inst.lastEffect;
      create === null ? inst.lastEffect = tag.next = tag : (deps = create.next, create.next = tag, tag.next = deps, inst.lastEffect = tag);
      return tag;
    }
    function updateRef() {
      return updateWorkInProgressHook().memoizedState;
    }
    function mountEffectImpl(fiberFlags, hookFlags, create, deps) {
      var hook = mountWorkInProgressHook();
      currentlyRenderingFiber.flags |= fiberFlags;
      hook.memoizedState = pushSimpleEffect(1 | hookFlags, { destroy: undefined }, create, deps === undefined ? null : deps);
    }
    function updateEffectImpl(fiberFlags, hookFlags, create, deps) {
      var hook = updateWorkInProgressHook();
      deps = deps === undefined ? null : deps;
      var inst = hook.memoizedState.inst;
      currentHook !== null && deps !== null && areHookInputsEqual(deps, currentHook.memoizedState.deps) ? hook.memoizedState = pushSimpleEffect(hookFlags, inst, create, deps) : (currentlyRenderingFiber.flags |= fiberFlags, hook.memoizedState = pushSimpleEffect(1 | hookFlags, inst, create, deps));
    }
    function mountEffect(create, deps) {
      mountEffectImpl(8390656, 8, create, deps);
    }
    function updateEffect(create, deps) {
      updateEffectImpl(2048, 8, create, deps);
    }
    function useEffectEventImpl(payload) {
      currentlyRenderingFiber.flags |= 4;
      var componentUpdateQueue = currentlyRenderingFiber.updateQueue;
      if (componentUpdateQueue === null)
        componentUpdateQueue = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = componentUpdateQueue, componentUpdateQueue.events = [payload];
      else {
        var events = componentUpdateQueue.events;
        events === null ? componentUpdateQueue.events = [payload] : events.push(payload);
      }
    }
    function updateEvent(callback) {
      var ref = updateWorkInProgressHook().memoizedState;
      useEffectEventImpl({ ref, nextImpl: callback });
      return function() {
        if ((executionContext & 2) !== 0)
          throw Error(formatProdErrorMessage(440));
        return ref.impl.apply(undefined, arguments);
      };
    }
    function updateInsertionEffect(create, deps) {
      return updateEffectImpl(4, 2, create, deps);
    }
    function updateLayoutEffect(create, deps) {
      return updateEffectImpl(4, 4, create, deps);
    }
    function imperativeHandleEffect(create, ref) {
      if (typeof ref === "function") {
        create = create();
        var refCleanup = ref(create);
        return function() {
          typeof refCleanup === "function" ? refCleanup() : ref(null);
        };
      }
      if (ref !== null && ref !== undefined)
        return create = create(), ref.current = create, function() {
          ref.current = null;
        };
    }
    function updateImperativeHandle(ref, create, deps) {
      deps = deps !== null && deps !== undefined ? deps.concat([ref]) : null;
      updateEffectImpl(4, 4, imperativeHandleEffect.bind(null, create, ref), deps);
    }
    function mountDebugValue() {}
    function updateCallback(callback, deps) {
      var hook = updateWorkInProgressHook();
      deps = deps === undefined ? null : deps;
      var prevState = hook.memoizedState;
      if (deps !== null && areHookInputsEqual(deps, prevState[1]))
        return prevState[0];
      hook.memoizedState = [callback, deps];
      return callback;
    }
    function updateMemo(nextCreate, deps) {
      var hook = updateWorkInProgressHook();
      deps = deps === undefined ? null : deps;
      var prevState = hook.memoizedState;
      if (deps !== null && areHookInputsEqual(deps, prevState[1]))
        return prevState[0];
      prevState = nextCreate();
      if (shouldDoubleInvokeUserFnsInHooksDEV) {
        setIsStrictModeForDevtools(true);
        try {
          nextCreate();
        } finally {
          setIsStrictModeForDevtools(false);
        }
      }
      hook.memoizedState = [prevState, deps];
      return prevState;
    }
    function mountDeferredValueImpl(hook, value, initialValue) {
      if (initialValue === undefined || (renderLanes & 1073741824) !== 0 && (workInProgressRootRenderLanes & 261930) === 0)
        return hook.memoizedState = value;
      hook.memoizedState = initialValue;
      hook = requestDeferredLane();
      currentlyRenderingFiber.lanes |= hook;
      workInProgressRootSkippedLanes |= hook;
      return initialValue;
    }
    function updateDeferredValueImpl(hook, prevValue, value, initialValue) {
      if (objectIs(value, prevValue))
        return value;
      if (currentTreeHiddenStackCursor.current !== null)
        return hook = mountDeferredValueImpl(hook, value, initialValue), objectIs(hook, prevValue) || (didReceiveUpdate = true), hook;
      if ((renderLanes & 106) === 0 || (renderLanes & 1073741824) !== 0 && (workInProgressRootRenderLanes & 261930) === 0)
        return didReceiveUpdate = true, hook.memoizedState = value;
      hook = requestDeferredLane();
      currentlyRenderingFiber.lanes |= hook;
      workInProgressRootSkippedLanes |= hook;
      return prevValue;
    }
    function startTransition(fiber, queue, pendingState, finishedState, callback) {
      var previousPriority = getCurrentUpdatePriority();
      setCurrentUpdatePriority(previousPriority !== 0 && 8 > previousPriority ? previousPriority : 8);
      var prevTransition = ReactSharedInternals.T, currentTransition = {};
      currentTransition.types = prevTransition !== null ? prevTransition.types : null;
      ReactSharedInternals.T = currentTransition;
      dispatchOptimisticSetState(fiber, false, queue, pendingState);
      try {
        var returnValue = callback(), onStartTransitionFinish = ReactSharedInternals.S;
        onStartTransitionFinish !== null && onStartTransitionFinish(currentTransition, returnValue);
        if (returnValue !== null && typeof returnValue === "object" && typeof returnValue.then === "function") {
          var thenableForFinishedState = chainThenableValue(returnValue, finishedState);
          dispatchSetStateInternal(fiber, queue, thenableForFinishedState, requestUpdateLane(fiber));
        } else
          dispatchSetStateInternal(fiber, queue, finishedState, requestUpdateLane(fiber));
      } catch (error) {
        dispatchSetStateInternal(fiber, queue, { then: function() {}, status: "rejected", reason: error }, requestUpdateLane());
      } finally {
        setCurrentUpdatePriority(previousPriority), prevTransition !== null && currentTransition.types !== null && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
      }
    }
    function ensureFormComponentIsStateful(formFiber) {
      var existingStateHook = formFiber.memoizedState;
      if (existingStateHook !== null)
        return existingStateHook;
      existingStateHook = {
        memoizedState: NotPendingTransition,
        baseState: NotPendingTransition,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: basicStateReducer,
          lastRenderedState: NotPendingTransition
        },
        next: null
      };
      var initialResetState = {};
      existingStateHook.next = {
        memoizedState: initialResetState,
        baseState: initialResetState,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: basicStateReducer,
          lastRenderedState: initialResetState
        },
        next: null
      };
      formFiber.memoizedState = existingStateHook;
      formFiber = formFiber.alternate;
      formFiber !== null && (formFiber.memoizedState = existingStateHook);
      return existingStateHook;
    }
    function useHostTransitionStatus() {
      return readContext(HostTransitionContext);
    }
    function updateId() {
      return updateWorkInProgressHook().memoizedState;
    }
    function updateRefresh() {
      return updateWorkInProgressHook().memoizedState;
    }
    function refreshCache(fiber) {
      for (var provider = fiber.return;provider !== null; ) {
        switch (provider.tag) {
          case 24:
          case 3:
            var lane = requestUpdateLane();
            fiber = createUpdate(lane);
            var root = enqueueUpdate(provider, fiber, lane);
            root !== null && (scheduleUpdateOnFiber(root, provider, lane), entangleTransitions(root, provider, lane));
            provider = { cache: createCache() };
            fiber.payload = provider;
            return;
        }
        provider = provider.return;
      }
    }
    function dispatchReducerAction(fiber, queue, action) {
      var lane = requestUpdateLane();
      action = {
        lane,
        revertLane: 0,
        gesture: null,
        action,
        hasEagerState: false,
        eagerState: null,
        next: null
      };
      isRenderPhaseUpdate(fiber) ? enqueueRenderPhaseUpdate(queue, action) : (action = enqueueConcurrentHookUpdate(fiber, queue, action, lane), action !== null && (scheduleUpdateOnFiber(action, fiber, lane), entangleTransitionUpdate(action, queue, lane)));
    }
    function dispatchSetState(fiber, queue, action) {
      var lane = requestUpdateLane();
      dispatchSetStateInternal(fiber, queue, action, lane);
    }
    function dispatchSetStateInternal(fiber, queue, action, lane) {
      var update = {
        lane,
        revertLane: 0,
        gesture: null,
        action,
        hasEagerState: false,
        eagerState: null,
        next: null
      };
      if (isRenderPhaseUpdate(fiber))
        enqueueRenderPhaseUpdate(queue, update);
      else {
        var alternate = fiber.alternate;
        if (fiber.lanes === 0 && (alternate === null || alternate.lanes === 0) && (alternate = queue.lastRenderedReducer, alternate !== null))
          try {
            var currentState = queue.lastRenderedState, eagerState = alternate(currentState, action);
            update.hasEagerState = true;
            update.eagerState = eagerState;
            if (objectIs(eagerState, currentState))
              return enqueueUpdate$1(fiber, queue, update, 0), workInProgressRoot === null && finishQueueingConcurrentUpdates(), false;
          } catch (error) {} finally {}
        action = enqueueConcurrentHookUpdate(fiber, queue, update, lane);
        if (action !== null)
          return scheduleUpdateOnFiber(action, fiber, lane), entangleTransitionUpdate(action, queue, lane), true;
      }
      return false;
    }
    function dispatchOptimisticSetState(fiber, throwIfDuringRender, queue, action) {
      action = {
        lane: 2,
        revertLane: requestTransitionLane(),
        gesture: null,
        action,
        hasEagerState: false,
        eagerState: null,
        next: null
      };
      if (isRenderPhaseUpdate(fiber)) {
        if (throwIfDuringRender)
          throw Error(formatProdErrorMessage(479));
      } else
        throwIfDuringRender = enqueueConcurrentHookUpdate(fiber, queue, action, 2), throwIfDuringRender !== null && scheduleUpdateOnFiber(throwIfDuringRender, fiber, 2);
    }
    function isRenderPhaseUpdate(fiber) {
      var alternate = fiber.alternate;
      return fiber === currentlyRenderingFiber || alternate !== null && alternate === currentlyRenderingFiber;
    }
    function enqueueRenderPhaseUpdate(queue, update) {
      didScheduleRenderPhaseUpdateDuringThisPass = didScheduleRenderPhaseUpdate = true;
      var pending = queue.pending;
      pending === null ? update.next = update : (update.next = pending.next, pending.next = update);
      queue.pending = update;
    }
    function entangleTransitionUpdate(root, queue, lane) {
      if ((lane & 4194048) !== 0) {
        var queueLanes = queue.lanes;
        queueLanes &= root.pendingLanes;
        lane |= queueLanes;
        queue.lanes = lane;
        markRootEntangled(root, lane);
      }
    }
    function applyDerivedStateFromProps(workInProgress, ctor, getDerivedStateFromProps, nextProps) {
      ctor = workInProgress.memoizedState;
      getDerivedStateFromProps = getDerivedStateFromProps(nextProps, ctor);
      getDerivedStateFromProps = getDerivedStateFromProps === null || getDerivedStateFromProps === undefined ? ctor : assign({}, ctor, getDerivedStateFromProps);
      workInProgress.memoizedState = getDerivedStateFromProps;
      workInProgress.lanes === 0 && (workInProgress.updateQueue.baseState = getDerivedStateFromProps);
    }
    function checkShouldComponentUpdate(workInProgress, ctor, oldProps, newProps, oldState, newState, nextContext) {
      workInProgress = workInProgress.stateNode;
      return typeof workInProgress.shouldComponentUpdate === "function" ? workInProgress.shouldComponentUpdate(newProps, newState, nextContext) : ctor.prototype && ctor.prototype.isPureReactComponent ? !shallowEqual(oldProps, newProps) || !shallowEqual(oldState, newState) : true;
    }
    function callComponentWillReceiveProps(workInProgress, instance, newProps, nextContext) {
      workInProgress = instance.state;
      typeof instance.componentWillReceiveProps === "function" && instance.componentWillReceiveProps(newProps, nextContext);
      typeof instance.UNSAFE_componentWillReceiveProps === "function" && instance.UNSAFE_componentWillReceiveProps(newProps, nextContext);
      instance.state !== workInProgress && classComponentUpdater.enqueueReplaceState(instance, instance.state, null);
    }
    function resolveClassComponentProps(Component, baseProps) {
      var newProps = baseProps;
      if ("ref" in baseProps) {
        newProps = {};
        for (var propName in baseProps)
          propName !== "ref" && (newProps[propName] = baseProps[propName]);
      }
      if (Component = Component.defaultProps) {
        newProps === baseProps && (newProps = assign({}, newProps));
        for (var propName$59 in Component)
          newProps[propName$59] === undefined && (newProps[propName$59] = Component[propName$59]);
      }
      return newProps;
    }
    function logUncaughtError(root, errorInfo) {
      try {
        var onUncaughtError = root.onUncaughtError;
        onUncaughtError(errorInfo.value, { componentStack: errorInfo.stack });
      } catch (e) {
        setTimeout(function() {
          throw e;
        });
      }
    }
    function logCaughtError(root, boundary, errorInfo) {
      try {
        var onCaughtError = root.onCaughtError;
        onCaughtError(errorInfo.value, {
          componentStack: errorInfo.stack,
          errorBoundary: boundary.tag === 1 ? boundary.stateNode : null
        });
      } catch (e) {
        setTimeout(function() {
          throw e;
        });
      }
    }
    function createRootErrorUpdate(root, errorInfo, lane) {
      lane = createUpdate(lane);
      lane.tag = 3;
      lane.payload = { element: null };
      lane.callback = function() {
        logUncaughtError(root, errorInfo);
      };
      return lane;
    }
    function createClassErrorUpdate(lane) {
      lane = createUpdate(lane);
      lane.tag = 3;
      return lane;
    }
    function initializeClassErrorUpdate(update, root, fiber, errorInfo) {
      var getDerivedStateFromError = fiber.type.getDerivedStateFromError;
      if (typeof getDerivedStateFromError === "function") {
        var error = errorInfo.value;
        update.payload = function() {
          return getDerivedStateFromError(error);
        };
        update.callback = function() {
          logCaughtError(root, fiber, errorInfo);
        };
      }
      var inst = fiber.stateNode;
      inst !== null && typeof inst.componentDidCatch === "function" && (update.callback = function() {
        logCaughtError(root, fiber, errorInfo);
        typeof getDerivedStateFromError !== "function" && (legacyErrorBoundariesThatAlreadyFailed === null ? legacyErrorBoundariesThatAlreadyFailed = new Set([this]) : legacyErrorBoundariesThatAlreadyFailed.add(this));
        var stack = errorInfo.stack;
        this.componentDidCatch(errorInfo.value, {
          componentStack: stack !== null ? stack : ""
        });
      });
    }
    function throwException(root, returnFiber, sourceFiber, value, rootRenderLanes) {
      sourceFiber.flags |= 32768;
      if (value !== null && typeof value === "object" && typeof value.then === "function") {
        returnFiber = sourceFiber.alternate;
        returnFiber !== null && propagateParentContextChanges(returnFiber, sourceFiber, rootRenderLanes, true);
        sourceFiber = suspenseHandlerStackCursor.current;
        if (sourceFiber !== null) {
          switch (sourceFiber.tag) {
            case 31:
            case 13:
            case 19:
              return shellBoundary === null ? renderDidSuspendDelayIfPossible() : sourceFiber.alternate === null && workInProgressRootExitStatus === 0 && (workInProgressRootExitStatus = 3), sourceFiber.flags &= -257, sourceFiber.flags |= 65536, sourceFiber.lanes = rootRenderLanes, value === noopSuspenseyCommitThenable ? sourceFiber.flags |= 16384 : (returnFiber = sourceFiber.updateQueue, returnFiber === null ? sourceFiber.updateQueue = new Set([value]) : returnFiber.add(value), attachPingListener(root, value, rootRenderLanes)), false;
            case 22:
              return sourceFiber.flags |= 65536, value === noopSuspenseyCommitThenable ? sourceFiber.flags |= 16384 : (returnFiber = sourceFiber.updateQueue, returnFiber === null ? (returnFiber = {
                transitions: null,
                markerInstances: null,
                retryQueue: new Set([value])
              }, sourceFiber.updateQueue = returnFiber) : (sourceFiber = returnFiber.retryQueue, sourceFiber === null ? returnFiber.retryQueue = new Set([value]) : sourceFiber.add(value)), attachPingListener(root, value, rootRenderLanes)), false;
          }
          throw Error(formatProdErrorMessage(435, sourceFiber.tag));
        }
        attachPingListener(root, value, rootRenderLanes);
        renderDidSuspendDelayIfPossible();
        return false;
      }
      if (isHydrating)
        return returnFiber = suspenseHandlerStackCursor.current, returnFiber !== null ? ((returnFiber.flags & 65536) === 0 && (returnFiber.flags |= 256), returnFiber.flags |= 65536, returnFiber.lanes = rootRenderLanes, value !== HydrationMismatchException && (root = Error(formatProdErrorMessage(422), { cause: value }), queueHydrationError(createCapturedValueAtFiber(root, sourceFiber)))) : (value !== HydrationMismatchException && (returnFiber = Error(formatProdErrorMessage(423), {
          cause: value
        }), queueHydrationError(createCapturedValueAtFiber(returnFiber, sourceFiber))), root = root.current.alternate, root.flags |= 65536, rootRenderLanes &= -rootRenderLanes, root.lanes |= rootRenderLanes, value = createCapturedValueAtFiber(value, sourceFiber), rootRenderLanes = createRootErrorUpdate(root.stateNode, value, rootRenderLanes), enqueueCapturedUpdate(root, rootRenderLanes), workInProgressRootExitStatus !== 4 && (workInProgressRootExitStatus = 2)), false;
      var wrapperError = Error(formatProdErrorMessage(520), { cause: value });
      wrapperError = createCapturedValueAtFiber(wrapperError, sourceFiber);
      workInProgressRootConcurrentErrors === null ? workInProgressRootConcurrentErrors = [wrapperError] : workInProgressRootConcurrentErrors.push(wrapperError);
      workInProgressRootExitStatus !== 4 && (workInProgressRootExitStatus = 2);
      if (returnFiber === null)
        return true;
      value = createCapturedValueAtFiber(value, sourceFiber);
      sourceFiber = returnFiber;
      do {
        switch (sourceFiber.tag) {
          case 3:
            return sourceFiber.flags |= 65536, root = rootRenderLanes & -rootRenderLanes, sourceFiber.lanes |= root, root = createRootErrorUpdate(sourceFiber.stateNode, value, root), enqueueCapturedUpdate(sourceFiber, root), false;
          case 1:
            returnFiber = sourceFiber.type;
            wrapperError = sourceFiber.stateNode;
            if ((sourceFiber.flags & 128) === 0 && (typeof returnFiber.getDerivedStateFromError === "function" || wrapperError !== null && typeof wrapperError.componentDidCatch === "function" && (legacyErrorBoundariesThatAlreadyFailed === null || !legacyErrorBoundariesThatAlreadyFailed.has(wrapperError))))
              return sourceFiber.flags |= 65536, rootRenderLanes &= -rootRenderLanes, sourceFiber.lanes |= rootRenderLanes, rootRenderLanes = createClassErrorUpdate(rootRenderLanes), initializeClassErrorUpdate(rootRenderLanes, root, sourceFiber, value), enqueueCapturedUpdate(sourceFiber, rootRenderLanes), false;
            break;
          case 22:
            if (sourceFiber.memoizedState !== null)
              return sourceFiber.flags |= 65536, false;
        }
        sourceFiber = sourceFiber.return;
      } while (sourceFiber !== null);
      return false;
    }
    function reconcileChildren(current, workInProgress, nextChildren, renderLanes) {
      workInProgress.child = current === null ? mountChildFibers(workInProgress, null, nextChildren, renderLanes) : reconcileChildFibers(workInProgress, current.child, nextChildren, renderLanes);
    }
    function updateForwardRef(current, workInProgress, Component, nextProps, renderLanes) {
      Component = Component.render;
      var ref = workInProgress.ref;
      if ("ref" in nextProps) {
        var propsWithoutRef = {};
        for (var key in nextProps)
          key !== "ref" && (propsWithoutRef[key] = nextProps[key]);
      } else
        propsWithoutRef = nextProps;
      prepareToReadContext(workInProgress);
      nextProps = renderWithHooks(current, workInProgress, Component, propsWithoutRef, ref, renderLanes);
      key = checkDidRenderIdHook();
      if (current !== null && !didReceiveUpdate)
        return bailoutHooks(current, workInProgress, renderLanes), bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
      isHydrating && key && pushMaterializedTreeId(workInProgress);
      workInProgress.flags |= 1;
      reconcileChildren(current, workInProgress, nextProps, renderLanes);
      return workInProgress.child;
    }
    function updateMemoComponent(current, workInProgress, Component, nextProps, renderLanes) {
      if (current === null) {
        var type = Component.type;
        if (typeof type === "function" && !shouldConstruct(type) && type.defaultProps === undefined && Component.compare === null)
          return workInProgress.tag = 15, workInProgress.type = type, updateSimpleMemoComponent(current, workInProgress, type, nextProps, renderLanes);
        current = createFiberFromTypeAndProps(Component.type, null, nextProps, workInProgress, workInProgress.mode, renderLanes);
        current.ref = workInProgress.ref;
        current.return = workInProgress;
        return workInProgress.child = current;
      }
      type = current.child;
      if (!checkScheduledUpdateOrContext(current, renderLanes)) {
        var prevProps = type.memoizedProps;
        Component = Component.compare;
        Component = Component !== null ? Component : shallowEqual;
        if (Component(prevProps, nextProps) && current.ref === workInProgress.ref)
          return bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
      }
      workInProgress.flags |= 1;
      current = createWorkInProgress(type, nextProps);
      current.ref = workInProgress.ref;
      current.return = workInProgress;
      return workInProgress.child = current;
    }
    function updateSimpleMemoComponent(current, workInProgress, Component, nextProps, renderLanes) {
      if (current !== null) {
        var prevProps = current.memoizedProps;
        if (shallowEqual(prevProps, nextProps) && current.ref === workInProgress.ref)
          if (didReceiveUpdate = false, workInProgress.pendingProps = nextProps = prevProps, checkScheduledUpdateOrContext(current, renderLanes))
            (current.flags & 131072) !== 0 && (didReceiveUpdate = true);
          else
            return workInProgress.lanes = current.lanes, bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
      }
      return updateFunctionComponent(current, workInProgress, Component, nextProps, renderLanes);
    }
    function updateOffscreenComponent(current, workInProgress, renderLanes, nextProps) {
      var nextChildren = nextProps.children, prevState = current !== null ? current.memoizedState : null;
      current === null && workInProgress.stateNode === null && (workInProgress.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      });
      if (nextProps.mode === "hidden") {
        if ((workInProgress.flags & 128) !== 0) {
          prevState = prevState !== null ? prevState.baseLanes | renderLanes : renderLanes;
          if (current !== null) {
            nextProps = workInProgress.child = current.child;
            for (nextChildren = 0;nextProps !== null; )
              nextChildren = nextChildren | nextProps.lanes | nextProps.childLanes, nextProps = nextProps.sibling;
            nextProps = nextChildren & ~prevState;
          } else
            nextProps = 0, workInProgress.child = null;
          return deferHiddenOffscreenComponent(current, workInProgress, prevState, renderLanes, nextProps);
        }
        if ((renderLanes & 536870912) !== 0)
          workInProgress.memoizedState = { baseLanes: 0, cachePool: null }, current !== null && pushTransition(workInProgress, prevState !== null ? prevState.cachePool : null), prevState !== null ? pushHiddenContext(workInProgress, prevState) : reuseHiddenContextOnStack(), pushOffscreenSuspenseHandler(workInProgress);
        else
          return nextProps = workInProgress.lanes = 536870912, deferHiddenOffscreenComponent(current, workInProgress, prevState !== null ? prevState.baseLanes | renderLanes : renderLanes, renderLanes, nextProps);
      } else
        prevState !== null ? (pushTransition(workInProgress, prevState.cachePool), pushHiddenContext(workInProgress, prevState), reuseSuspenseHandlerOnStack(), workInProgress.memoizedState = null) : (current !== null && pushTransition(workInProgress, null), reuseHiddenContextOnStack(), reuseSuspenseHandlerOnStack());
      reconcileChildren(current, workInProgress, nextChildren, renderLanes);
      return workInProgress.child;
    }
    function bailoutOffscreenComponent(current, workInProgress) {
      current !== null && current.tag === 22 || workInProgress.stateNode !== null || (workInProgress.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      });
      return workInProgress.sibling;
    }
    function deferHiddenOffscreenComponent(current, workInProgress, nextBaseLanes, renderLanes, remainingChildLanes) {
      var JSCompiler_inline_result = peekCacheFromPool();
      JSCompiler_inline_result = JSCompiler_inline_result === null ? null : {
        parent: isPrimaryRenderer ? CacheContext._currentValue : CacheContext._currentValue2,
        pool: JSCompiler_inline_result
      };
      workInProgress.memoizedState = {
        baseLanes: nextBaseLanes,
        cachePool: JSCompiler_inline_result
      };
      current !== null && pushTransition(workInProgress, null);
      reuseHiddenContextOnStack();
      pushOffscreenSuspenseHandler(workInProgress);
      current !== null && propagateParentContextChanges(current, workInProgress, renderLanes, true);
      workInProgress.childLanes = remainingChildLanes;
      return null;
    }
    function mountActivityChildren(workInProgress, nextProps) {
      nextProps = mountWorkInProgressOffscreenFiber({ mode: nextProps.mode, children: nextProps.children }, workInProgress.mode);
      nextProps.ref = workInProgress.ref;
      workInProgress.child = nextProps;
      nextProps.return = workInProgress;
      return nextProps;
    }
    function retryActivityComponentWithoutHydrating(current, workInProgress, renderLanes) {
      reconcileChildFibers(workInProgress, current.child, null, renderLanes);
      current = mountActivityChildren(workInProgress, workInProgress.pendingProps);
      current.flags |= 2;
      popSuspenseHandler(workInProgress);
      workInProgress.memoizedState = null;
      return current;
    }
    function updateActivityComponent(current, workInProgress, renderLanes) {
      var nextProps = workInProgress.pendingProps, didSuspend = (workInProgress.flags & 128) !== 0;
      workInProgress.flags &= -129;
      if (current === null) {
        if (isHydrating) {
          if (nextProps.mode === "hidden")
            return current = mountActivityChildren(workInProgress, nextProps), workInProgress.lanes = 536870912, current.memoizedState = { baseLanes: 0, cachePool: null }, bailoutOffscreenComponent(null, current);
          pushDehydratedActivitySuspenseHandler(workInProgress);
          (current = nextHydratableInstance) ? (current = canHydrateActivityInstance(current, rootOrSingletonContext), current !== null && (workInProgress.memoizedState = {
            dehydrated: current,
            treeContext: treeContextProvider !== null ? { id: treeContextId, overflow: treeContextOverflow } : null,
            retryLane: 536870912,
            hydrationErrors: null
          }, renderLanes = createFiberFromDehydratedFragment(current), renderLanes.return = workInProgress, workInProgress.child = renderLanes, hydrationParentFiber = workInProgress, nextHydratableInstance = null)) : current = null;
          if (current === null)
            throw throwOnHydrationMismatch(workInProgress);
          workInProgress.lanes = 536870912;
          return null;
        }
        return mountActivityChildren(workInProgress, nextProps);
      }
      var prevState = current.memoizedState;
      if (prevState !== null) {
        var dehydrated = prevState.dehydrated;
        pushDehydratedActivitySuspenseHandler(workInProgress);
        if (didSuspend)
          if (workInProgress.flags & 256)
            workInProgress.flags &= -257, workInProgress = retryActivityComponentWithoutHydrating(current, workInProgress, renderLanes);
          else if (workInProgress.memoizedState !== null)
            workInProgress.child = current.child, workInProgress.flags |= 128, workInProgress = null;
          else
            throw Error(formatProdErrorMessage(558));
        else if (didReceiveUpdate || propagateParentContextChanges(current, workInProgress, renderLanes, false), didSuspend = (renderLanes & current.childLanes) !== 0, didReceiveUpdate || didSuspend) {
          if (currentTreeHiddenStackCursor.current === null) {
            nextProps = workInProgressRoot;
            if (nextProps !== null && (dehydrated = getBumpedLaneForHydration(nextProps, renderLanes), dehydrated !== 0 && dehydrated !== prevState.retryLane))
              throw prevState.retryLane = dehydrated, enqueueConcurrentRenderForLane(current, dehydrated), scheduleUpdateOnFiber(nextProps, current, dehydrated), SelectiveHydrationException;
            renderDidSuspendDelayIfPossible();
          }
          workInProgress = retryActivityComponentWithoutHydrating(current, workInProgress, renderLanes);
        } else
          current = prevState.treeContext, supportsHydration && (nextHydratableInstance = getFirstHydratableChildWithinActivityInstance(dehydrated), hydrationParentFiber = workInProgress, isHydrating = true, hydrationErrors = null, rootOrSingletonContext = false, current !== null && restoreSuspendedTreeContext(workInProgress, current)), workInProgress = mountActivityChildren(workInProgress, nextProps), workInProgress.flags |= 134221824;
        return workInProgress;
      }
      current = createWorkInProgress(current.child, {
        mode: nextProps.mode,
        children: nextProps.children
      });
      current.ref = workInProgress.ref;
      workInProgress.child = current;
      current.return = workInProgress;
      return current;
    }
    function markRef(current, workInProgress) {
      var ref = workInProgress.ref;
      if (ref === null)
        current !== null && current.ref !== null && (workInProgress.flags |= 4194816);
      else {
        if (typeof ref !== "function" && typeof ref !== "object")
          throw Error(formatProdErrorMessage(284));
        if (current === null || current.ref !== ref)
          workInProgress.flags |= 4194816;
      }
    }
    function updateFunctionComponent(current, workInProgress, Component, nextProps, renderLanes) {
      prepareToReadContext(workInProgress);
      Component = renderWithHooks(current, workInProgress, Component, nextProps, undefined, renderLanes);
      nextProps = checkDidRenderIdHook();
      if (current !== null && !didReceiveUpdate)
        return bailoutHooks(current, workInProgress, renderLanes), bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
      isHydrating && nextProps && pushMaterializedTreeId(workInProgress);
      workInProgress.flags |= 1;
      reconcileChildren(current, workInProgress, Component, renderLanes);
      return workInProgress.child;
    }
    function replayFunctionComponent(current, workInProgress, nextProps, Component, secondArg, renderLanes) {
      prepareToReadContext(workInProgress);
      workInProgress.updateQueue = null;
      nextProps = renderWithHooksAgain(workInProgress, Component, nextProps, secondArg);
      finishRenderingHooks(current);
      Component = checkDidRenderIdHook();
      if (current !== null && !didReceiveUpdate)
        return bailoutHooks(current, workInProgress, renderLanes), bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
      isHydrating && Component && pushMaterializedTreeId(workInProgress);
      workInProgress.flags |= 1;
      reconcileChildren(current, workInProgress, nextProps, renderLanes);
      return workInProgress.child;
    }
    function updateClassComponent(current, workInProgress, Component, nextProps, renderLanes) {
      prepareToReadContext(workInProgress);
      if (workInProgress.stateNode === null) {
        var context = emptyContextObject, contextType = Component.contextType;
        typeof contextType === "object" && contextType !== null && (context = readContext(contextType));
        context = new Component(nextProps, context);
        workInProgress.memoizedState = context.state !== null && context.state !== undefined ? context.state : null;
        context.updater = classComponentUpdater;
        workInProgress.stateNode = context;
        context._reactInternals = workInProgress;
        context = workInProgress.stateNode;
        context.props = nextProps;
        context.state = workInProgress.memoizedState;
        context.refs = {};
        initializeUpdateQueue(workInProgress);
        contextType = Component.contextType;
        context.context = typeof contextType === "object" && contextType !== null ? readContext(contextType) : emptyContextObject;
        context.state = workInProgress.memoizedState;
        contextType = Component.getDerivedStateFromProps;
        typeof contextType === "function" && (applyDerivedStateFromProps(workInProgress, Component, contextType, nextProps), context.state = workInProgress.memoizedState);
        typeof Component.getDerivedStateFromProps === "function" || typeof context.getSnapshotBeforeUpdate === "function" || typeof context.UNSAFE_componentWillMount !== "function" && typeof context.componentWillMount !== "function" || (contextType = context.state, typeof context.componentWillMount === "function" && context.componentWillMount(), typeof context.UNSAFE_componentWillMount === "function" && context.UNSAFE_componentWillMount(), contextType !== context.state && classComponentUpdater.enqueueReplaceState(context, context.state, null), processUpdateQueue(workInProgress, nextProps, context, renderLanes), suspendIfUpdateReadFromEntangledAsyncAction(), context.state = workInProgress.memoizedState);
        typeof context.componentDidMount === "function" && (workInProgress.flags |= 4194308);
        nextProps = true;
      } else if (current === null) {
        context = workInProgress.stateNode;
        var unresolvedOldProps = workInProgress.memoizedProps, oldProps = resolveClassComponentProps(Component, unresolvedOldProps);
        context.props = oldProps;
        var oldContext = context.context, contextType$jscomp$0 = Component.contextType;
        contextType = emptyContextObject;
        typeof contextType$jscomp$0 === "object" && contextType$jscomp$0 !== null && (contextType = readContext(contextType$jscomp$0));
        var getDerivedStateFromProps = Component.getDerivedStateFromProps;
        contextType$jscomp$0 = typeof getDerivedStateFromProps === "function" || typeof context.getSnapshotBeforeUpdate === "function";
        unresolvedOldProps = workInProgress.pendingProps !== unresolvedOldProps;
        contextType$jscomp$0 || typeof context.UNSAFE_componentWillReceiveProps !== "function" && typeof context.componentWillReceiveProps !== "function" || (unresolvedOldProps || oldContext !== contextType) && callComponentWillReceiveProps(workInProgress, context, nextProps, contextType);
        hasForceUpdate = false;
        var oldState = workInProgress.memoizedState;
        context.state = oldState;
        processUpdateQueue(workInProgress, nextProps, context, renderLanes);
        suspendIfUpdateReadFromEntangledAsyncAction();
        oldContext = workInProgress.memoizedState;
        unresolvedOldProps || oldState !== oldContext || hasForceUpdate ? (typeof getDerivedStateFromProps === "function" && (applyDerivedStateFromProps(workInProgress, Component, getDerivedStateFromProps, nextProps), oldContext = workInProgress.memoizedState), (oldProps = hasForceUpdate || checkShouldComponentUpdate(workInProgress, Component, oldProps, nextProps, oldState, oldContext, contextType)) ? (contextType$jscomp$0 || typeof context.UNSAFE_componentWillMount !== "function" && typeof context.componentWillMount !== "function" || (typeof context.componentWillMount === "function" && context.componentWillMount(), typeof context.UNSAFE_componentWillMount === "function" && context.UNSAFE_componentWillMount()), typeof context.componentDidMount === "function" && (workInProgress.flags |= 4194308)) : (typeof context.componentDidMount === "function" && (workInProgress.flags |= 4194308), workInProgress.memoizedProps = nextProps, workInProgress.memoizedState = oldContext), context.props = nextProps, context.state = oldContext, context.context = contextType, nextProps = oldProps) : (typeof context.componentDidMount === "function" && (workInProgress.flags |= 4194308), nextProps = false);
      } else {
        context = workInProgress.stateNode;
        cloneUpdateQueue(current, workInProgress);
        contextType = workInProgress.memoizedProps;
        contextType$jscomp$0 = resolveClassComponentProps(Component, contextType);
        context.props = contextType$jscomp$0;
        getDerivedStateFromProps = workInProgress.pendingProps;
        oldState = context.context;
        oldContext = Component.contextType;
        oldProps = emptyContextObject;
        typeof oldContext === "object" && oldContext !== null && (oldProps = readContext(oldContext));
        unresolvedOldProps = Component.getDerivedStateFromProps;
        (oldContext = typeof unresolvedOldProps === "function" || typeof context.getSnapshotBeforeUpdate === "function") || typeof context.UNSAFE_componentWillReceiveProps !== "function" && typeof context.componentWillReceiveProps !== "function" || (contextType !== getDerivedStateFromProps || oldState !== oldProps) && callComponentWillReceiveProps(workInProgress, context, nextProps, oldProps);
        hasForceUpdate = false;
        oldState = workInProgress.memoizedState;
        context.state = oldState;
        processUpdateQueue(workInProgress, nextProps, context, renderLanes);
        suspendIfUpdateReadFromEntangledAsyncAction();
        var newState = workInProgress.memoizedState;
        contextType !== getDerivedStateFromProps || oldState !== newState || hasForceUpdate || current !== null && current.dependencies !== null && checkIfContextChanged(current.dependencies) ? (typeof unresolvedOldProps === "function" && (applyDerivedStateFromProps(workInProgress, Component, unresolvedOldProps, nextProps), newState = workInProgress.memoizedState), (contextType$jscomp$0 = hasForceUpdate || checkShouldComponentUpdate(workInProgress, Component, contextType$jscomp$0, nextProps, oldState, newState, oldProps) || current !== null && current.dependencies !== null && checkIfContextChanged(current.dependencies)) ? (oldContext || typeof context.UNSAFE_componentWillUpdate !== "function" && typeof context.componentWillUpdate !== "function" || (typeof context.componentWillUpdate === "function" && context.componentWillUpdate(nextProps, newState, oldProps), typeof context.UNSAFE_componentWillUpdate === "function" && context.UNSAFE_componentWillUpdate(nextProps, newState, oldProps)), typeof context.componentDidUpdate === "function" && (workInProgress.flags |= 4), typeof context.getSnapshotBeforeUpdate === "function" && (workInProgress.flags |= 1024)) : (typeof context.componentDidUpdate !== "function" || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 4), typeof context.getSnapshotBeforeUpdate !== "function" || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 1024), workInProgress.memoizedProps = nextProps, workInProgress.memoizedState = newState), context.props = nextProps, context.state = newState, context.context = oldProps, nextProps = contextType$jscomp$0) : (typeof context.componentDidUpdate !== "function" || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 4), typeof context.getSnapshotBeforeUpdate !== "function" || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 1024), nextProps = false);
      }
      context = nextProps;
      markRef(current, workInProgress);
      nextProps = (workInProgress.flags & 128) !== 0;
      context || nextProps ? (context = workInProgress.stateNode, Component = nextProps && typeof Component.getDerivedStateFromError !== "function" ? null : context.render(), workInProgress.flags |= 1, current !== null && nextProps ? (workInProgress.child = reconcileChildFibers(workInProgress, current.child, null, renderLanes), workInProgress.child = reconcileChildFibers(workInProgress, null, Component, renderLanes)) : reconcileChildren(current, workInProgress, Component, renderLanes), workInProgress.memoizedState = context.state, current = workInProgress.child) : current = bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
      return current;
    }
    function mountHostRootWithoutHydrating(current, workInProgress, nextChildren, renderLanes) {
      resetHydrationState();
      workInProgress.flags |= 256;
      reconcileChildren(current, workInProgress, nextChildren, renderLanes);
      return workInProgress.child;
    }
    function mountSuspenseOffscreenState(renderLanes) {
      return { baseLanes: renderLanes, cachePool: getSuspendedCache() };
    }
    function getRemainingWorkInPrimaryTree(current, primaryTreeDidDefer, renderLanes) {
      current = current !== null ? current.childLanes & ~renderLanes : 0;
      primaryTreeDidDefer && (current |= workInProgressDeferredLane);
      return current;
    }
    function updateSuspenseComponent(current, workInProgress, renderLanes) {
      var nextProps = workInProgress.pendingProps, showFallback = false, didSuspend = (workInProgress.flags & 128) !== 0, JSCompiler_temp;
      (JSCompiler_temp = didSuspend) || (JSCompiler_temp = current !== null && current.memoizedState === null ? false : (suspenseStackCursor.current & 2) !== 0);
      JSCompiler_temp && (showFallback = true, workInProgress.flags &= -129);
      JSCompiler_temp = (workInProgress.flags & 32) !== 0;
      workInProgress.flags &= -33;
      if (current === null) {
        if (isHydrating) {
          showFallback ? pushPrimaryTreeSuspenseHandler(workInProgress) : reuseSuspenseHandlerOnStack();
          (current = nextHydratableInstance) ? (current = canHydrateSuspenseInstance(current, rootOrSingletonContext), current !== null && (workInProgress.memoizedState = {
            dehydrated: current,
            treeContext: treeContextProvider !== null ? { id: treeContextId, overflow: treeContextOverflow } : null,
            retryLane: 536870912,
            hydrationErrors: null
          }, renderLanes = createFiberFromDehydratedFragment(current), renderLanes.return = workInProgress, workInProgress.child = renderLanes, hydrationParentFiber = workInProgress, nextHydratableInstance = null)) : current = null;
          if (current === null)
            throw throwOnHydrationMismatch(workInProgress);
          isSuspenseInstanceFallback(current) ? workInProgress.lanes = 32 : workInProgress.lanes = 536870912;
          return null;
        }
        didSuspend = nextProps.children;
        nextProps = nextProps.fallback;
        if (showFallback)
          return reuseSuspenseHandlerOnStack(), showFallback = workInProgress.mode, didSuspend = mountWorkInProgressOffscreenFiber({ mode: "hidden", children: didSuspend }, showFallback), nextProps = createFiberFromFragment(nextProps, showFallback, renderLanes, null), didSuspend.return = workInProgress, nextProps.return = workInProgress, didSuspend.sibling = nextProps, workInProgress.child = didSuspend, nextProps = workInProgress.child, nextProps.memoizedState = mountSuspenseOffscreenState(renderLanes), nextProps.childLanes = getRemainingWorkInPrimaryTree(current, JSCompiler_temp, renderLanes), workInProgress.memoizedState = SUSPENDED_MARKER, bailoutOffscreenComponent(null, nextProps);
        pushPrimaryTreeSuspenseHandler(workInProgress);
        return mountSuspensePrimaryChildren(workInProgress, didSuspend);
      }
      var prevState = current.memoizedState;
      if (prevState !== null) {
        var dehydrated$75 = prevState.dehydrated;
        if (dehydrated$75 !== null)
          return updateDehydratedSuspenseComponent(current, workInProgress, didSuspend, JSCompiler_temp, nextProps, dehydrated$75, prevState, renderLanes);
      }
      if (showFallback)
        return reuseSuspenseHandlerOnStack(), showFallback = nextProps.fallback, didSuspend = workInProgress.mode, prevState = current.child, dehydrated$75 = prevState.sibling, nextProps = createWorkInProgress(prevState, {
          mode: "hidden",
          children: nextProps.children
        }), nextProps.subtreeFlags = prevState.subtreeFlags & 1206910976, dehydrated$75 !== null ? showFallback = createWorkInProgress(dehydrated$75, showFallback) : (showFallback = createFiberFromFragment(showFallback, didSuspend, renderLanes, null), showFallback.flags |= 2), showFallback.return = workInProgress, nextProps.return = workInProgress, nextProps.sibling = showFallback, workInProgress.child = nextProps, bailoutOffscreenComponent(null, nextProps), nextProps = workInProgress.child, showFallback = current.child.memoizedState, showFallback === null ? showFallback = mountSuspenseOffscreenState(renderLanes) : (didSuspend = showFallback.cachePool, didSuspend !== null ? (prevState = isPrimaryRenderer ? CacheContext._currentValue : CacheContext._currentValue2, didSuspend = didSuspend.parent !== prevState ? { parent: prevState, pool: prevState } : didSuspend) : didSuspend = getSuspendedCache(), showFallback = {
          baseLanes: showFallback.baseLanes | renderLanes,
          cachePool: didSuspend
        }), nextProps.memoizedState = showFallback, nextProps.childLanes = getRemainingWorkInPrimaryTree(current, JSCompiler_temp, renderLanes), workInProgress.memoizedState = SUSPENDED_MARKER, bailoutOffscreenComponent(current.child, nextProps);
      pushPrimaryTreeSuspenseHandler(workInProgress);
      renderLanes = current.child;
      current = renderLanes.sibling;
      renderLanes = createWorkInProgress(renderLanes, {
        mode: "visible",
        children: nextProps.children
      });
      renderLanes.return = workInProgress;
      renderLanes.sibling = null;
      current !== null && (JSCompiler_temp = workInProgress.deletions, JSCompiler_temp === null ? (workInProgress.deletions = [current], workInProgress.flags |= 16) : JSCompiler_temp.push(current));
      workInProgress.child = renderLanes;
      workInProgress.memoizedState = null;
      return renderLanes;
    }
    function mountSuspensePrimaryChildren(workInProgress, primaryChildren) {
      primaryChildren = mountWorkInProgressOffscreenFiber({ mode: "visible", children: primaryChildren }, workInProgress.mode);
      primaryChildren.return = workInProgress;
      return workInProgress.child = primaryChildren;
    }
    function mountWorkInProgressOffscreenFiber(offscreenProps, mode) {
      offscreenProps = createFiber(22, offscreenProps, null, mode);
      offscreenProps.lanes = 0;
      return offscreenProps;
    }
    function retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes) {
      reconcileChildFibers(workInProgress, current.child, null, renderLanes);
      current = mountSuspensePrimaryChildren(workInProgress, workInProgress.pendingProps.children);
      current.flags |= 2;
      workInProgress.memoizedState = null;
      return current;
    }
    function updateDehydratedSuspenseComponent(current, workInProgress, didSuspend, didPrimaryChildrenDefer, nextProps, suspenseInstance, suspenseState, renderLanes) {
      if (didSuspend) {
        if (workInProgress.flags & 256)
          return pushPrimaryTreeSuspenseHandler(workInProgress), workInProgress.flags &= -257, retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
        if (workInProgress.memoizedState !== null)
          return reuseSuspenseHandlerOnStack(), workInProgress.child = current.child, workInProgress.flags |= 128, null;
        reuseSuspenseHandlerOnStack();
        suspenseInstance = nextProps.fallback;
        suspenseState = workInProgress.mode;
        nextProps = mountWorkInProgressOffscreenFiber({ mode: "visible", children: nextProps.children }, suspenseState);
        suspenseInstance = createFiberFromFragment(suspenseInstance, suspenseState, renderLanes, null);
        suspenseInstance.flags |= 2;
        nextProps.return = workInProgress;
        suspenseInstance.return = workInProgress;
        nextProps.sibling = suspenseInstance;
        workInProgress.child = nextProps;
        reconcileChildFibers(workInProgress, current.child, null, renderLanes);
        nextProps = workInProgress.child;
        nextProps.memoizedState = mountSuspenseOffscreenState(renderLanes);
        nextProps.childLanes = getRemainingWorkInPrimaryTree(current, didPrimaryChildrenDefer, renderLanes);
        workInProgress.memoizedState = SUSPENDED_MARKER;
        return bailoutOffscreenComponent(null, nextProps);
      }
      pushPrimaryTreeSuspenseHandler(workInProgress);
      if (isSuspenseInstanceFallback(suspenseInstance))
        return didPrimaryChildrenDefer = getSuspenseInstanceFallbackErrorDetails(suspenseInstance).digest, didPrimaryChildrenDefer !== "" && (nextProps = Error(formatProdErrorMessage(419)), nextProps.stack = "", nextProps.digest = didPrimaryChildrenDefer, queueHydrationError({ value: nextProps, source: null, stack: null })), retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
      didReceiveUpdate || propagateParentContextChanges(current, workInProgress, renderLanes, false);
      didPrimaryChildrenDefer = (renderLanes & current.childLanes) !== 0;
      if (didReceiveUpdate || didPrimaryChildrenDefer) {
        if (currentTreeHiddenStackCursor.current !== null)
          return retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
        didPrimaryChildrenDefer = workInProgressRoot;
        if (didPrimaryChildrenDefer !== null && (nextProps = getBumpedLaneForHydration(didPrimaryChildrenDefer, renderLanes), nextProps !== 0 && nextProps !== suspenseState.retryLane))
          throw suspenseState.retryLane = nextProps, enqueueConcurrentRenderForLane(current, nextProps), scheduleUpdateOnFiber(didPrimaryChildrenDefer, current, nextProps), SelectiveHydrationException;
        isSuspenseInstancePending(suspenseInstance) || renderDidSuspendDelayIfPossible();
        return retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
      }
      if (isSuspenseInstancePending(suspenseInstance))
        return workInProgress.flags |= 192, workInProgress.child = current.child, null;
      current = suspenseState.treeContext;
      supportsHydration && (nextHydratableInstance = getFirstHydratableChildWithinSuspenseInstance(suspenseInstance), hydrationParentFiber = workInProgress, isHydrating = true, hydrationErrors = null, rootOrSingletonContext = false, current !== null && restoreSuspendedTreeContext(workInProgress, current));
      workInProgress = mountSuspensePrimaryChildren(workInProgress, nextProps.children);
      workInProgress.flags |= 134221824;
      return workInProgress;
    }
    function scheduleSuspenseWorkOnFiber(fiber, renderLanes, propagationRoot) {
      fiber.lanes |= renderLanes;
      var alternate = fiber.alternate;
      alternate !== null && (alternate.lanes |= renderLanes);
      scheduleContextWorkOnParentPath(fiber.return, renderLanes, propagationRoot);
    }
    function findLastContentRow(firstChild) {
      for (var lastContentRow = null;firstChild !== null; ) {
        var currentRow = firstChild.alternate;
        currentRow !== null && findFirstSuspended(currentRow) === null && (lastContentRow = firstChild);
        firstChild = firstChild.sibling;
      }
      return lastContentRow;
    }
    function initSuspenseListRenderState(workInProgress, isBackwards, tail, lastContentRow, tailMode, treeForkCount) {
      var renderState = workInProgress.memoizedState;
      renderState === null ? workInProgress.memoizedState = {
        isBackwards,
        rendering: null,
        renderingStartTime: 0,
        last: lastContentRow,
        tail,
        tailMode,
        treeForkCount
      } : (renderState.isBackwards = isBackwards, renderState.rendering = null, renderState.renderingStartTime = 0, renderState.last = lastContentRow, renderState.tail = tail, renderState.tailMode = tailMode, renderState.treeForkCount = treeForkCount);
    }
    function reverseChildren(fiber) {
      var row = fiber.child;
      for (fiber.child = null;row !== null; ) {
        var nextRow = row.sibling;
        row.sibling = fiber.child;
        fiber.child = row;
        row = nextRow;
      }
    }
    function updateSuspenseListComponent(current, workInProgress, renderLanes) {
      var nextProps = workInProgress.pendingProps, revealOrder = nextProps.revealOrder, tailMode = nextProps.tail;
      nextProps = nextProps.children;
      var suspenseContext = suspenseStackCursor.current;
      if (workInProgress.flags & 128)
        return pushSuspenseListContext(workInProgress, suspenseContext), null;
      var shouldForceFallback = (suspenseContext & 2) !== 0;
      shouldForceFallback ? (suspenseContext = suspenseContext & 1 | 2, workInProgress.flags |= 128) : suspenseContext &= 1;
      pushSuspenseListContext(workInProgress, suspenseContext);
      revealOrder === "backwards" && current !== null ? (reverseChildren(current), reconcileChildren(current, workInProgress, nextProps, renderLanes), reverseChildren(current)) : reconcileChildren(current, workInProgress, nextProps, renderLanes);
      nextProps = isHydrating ? treeForkCount : 0;
      if (!shouldForceFallback && current !== null && (current.flags & 128) !== 0)
        a:
          for (current = workInProgress.child;current !== null; ) {
            if (current.tag === 13)
              current.memoizedState !== null && scheduleSuspenseWorkOnFiber(current, renderLanes, workInProgress);
            else if (current.tag === 19)
              scheduleSuspenseWorkOnFiber(current, renderLanes, workInProgress);
            else if (current.child !== null) {
              current.child.return = current;
              current = current.child;
              continue;
            }
            if (current === workInProgress)
              break a;
            for (;current.sibling === null; ) {
              if (current.return === null || current.return === workInProgress)
                break a;
              current = current.return;
            }
            current.sibling.return = current.return;
            current = current.sibling;
          }
      switch (revealOrder) {
        case "backwards":
          renderLanes = findLastContentRow(workInProgress.child);
          renderLanes === null ? (revealOrder = workInProgress.child, workInProgress.child = null) : (revealOrder = renderLanes.sibling, renderLanes.sibling = null, reverseChildren(workInProgress));
          initSuspenseListRenderState(workInProgress, true, revealOrder, null, tailMode, nextProps);
          break;
        case "unstable_legacy-backwards":
          renderLanes = null;
          revealOrder = workInProgress.child;
          for (workInProgress.child = null;revealOrder !== null; ) {
            current = revealOrder.alternate;
            if (current !== null && findFirstSuspended(current) === null) {
              workInProgress.child = revealOrder;
              break;
            }
            current = revealOrder.sibling;
            revealOrder.sibling = renderLanes;
            renderLanes = revealOrder;
            revealOrder = current;
          }
          initSuspenseListRenderState(workInProgress, true, renderLanes, null, tailMode, nextProps);
          break;
        case "together":
          initSuspenseListRenderState(workInProgress, false, null, null, undefined, nextProps);
          break;
        case "independent":
          workInProgress.memoizedState = null;
          break;
        default:
          renderLanes = findLastContentRow(workInProgress.child), renderLanes === null ? (revealOrder = workInProgress.child, workInProgress.child = null) : (revealOrder = renderLanes.sibling, renderLanes.sibling = null), initSuspenseListRenderState(workInProgress, false, revealOrder, renderLanes, tailMode, nextProps);
      }
      return workInProgress.child;
    }
    function updateContextProvider(current, workInProgress, renderLanes) {
      var newProps = workInProgress.pendingProps;
      pushProvider(workInProgress, workInProgress.type, newProps.value);
      reconcileChildren(current, workInProgress, newProps.children, renderLanes);
      return workInProgress.child;
    }
    function bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes) {
      current !== null && (workInProgress.dependencies = current.dependencies);
      workInProgressRootSkippedLanes |= workInProgress.lanes;
      if ((renderLanes & workInProgress.childLanes) === 0)
        if (current !== null) {
          if (propagateParentContextChanges(current, workInProgress, renderLanes, false), (renderLanes & workInProgress.childLanes) === 0)
            return null;
        } else
          return null;
      if (current !== null && workInProgress.child !== current.child)
        throw Error(formatProdErrorMessage(153));
      if (workInProgress.child !== null) {
        current = workInProgress.child;
        renderLanes = createWorkInProgress(current, current.pendingProps);
        workInProgress.child = renderLanes;
        for (renderLanes.return = workInProgress;current.sibling !== null; )
          current = current.sibling, renderLanes = renderLanes.sibling = createWorkInProgress(current, current.pendingProps), renderLanes.return = workInProgress;
        renderLanes.sibling = null;
      }
      return workInProgress.child;
    }
    function checkScheduledUpdateOrContext(current, renderLanes) {
      if ((current.lanes & renderLanes) !== 0)
        return true;
      current = current.dependencies;
      return current !== null && checkIfContextChanged(current) ? true : false;
    }
    function attemptEarlyBailoutIfNoScheduledUpdate(current, workInProgress, renderLanes) {
      switch (workInProgress.tag) {
        case 3:
          pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo);
          pushProvider(workInProgress, CacheContext, current.memoizedState.cache);
          resetHydrationState();
          break;
        case 27:
        case 5:
          pushHostContext(workInProgress);
          break;
        case 4:
          pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo);
          break;
        case 10:
          pushProvider(workInProgress, workInProgress.type, workInProgress.memoizedProps.value);
          break;
        case 31:
          if (workInProgress.memoizedState !== null)
            return workInProgress.flags |= 128, pushDehydratedActivitySuspenseHandler(workInProgress), null;
          break;
        case 13:
          var state$86 = workInProgress.memoizedState;
          if (state$86 !== null) {
            if (state$86.dehydrated !== null)
              return pushPrimaryTreeSuspenseHandler(workInProgress), workInProgress.flags |= 128, null;
            state$86 = propagateParentContextChanges(current, workInProgress, renderLanes, false);
            var primaryChildLanes = workInProgress.child.childLanes;
            if (state$86 || (renderLanes & primaryChildLanes) !== 0)
              return updateSuspenseComponent(current, workInProgress, renderLanes);
            pushPrimaryTreeSuspenseHandler(workInProgress);
            current = bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
            return current !== null ? current.sibling : null;
          }
          pushPrimaryTreeSuspenseHandler(workInProgress);
          break;
        case 19:
          if (workInProgress.flags & 128)
            return updateSuspenseListComponent(current, workInProgress, renderLanes);
          primaryChildLanes = (current.flags & 128) !== 0;
          state$86 = (renderLanes & workInProgress.childLanes) !== 0;
          state$86 || (propagateParentContextChanges(current, workInProgress, renderLanes, false), state$86 = (renderLanes & workInProgress.childLanes) !== 0);
          if (primaryChildLanes) {
            if (state$86)
              return updateSuspenseListComponent(current, workInProgress, renderLanes);
            workInProgress.flags |= 128;
          }
          primaryChildLanes = workInProgress.memoizedState;
          primaryChildLanes !== null && (primaryChildLanes.rendering = null, primaryChildLanes.tail = null, primaryChildLanes.lastEffect = null);
          pushSuspenseListContext(workInProgress, suspenseStackCursor.current);
          if (state$86)
            break;
          else
            return null;
        case 22:
          return workInProgress.lanes = 0, updateOffscreenComponent(current, workInProgress, renderLanes, workInProgress.pendingProps);
        case 24:
          pushProvider(workInProgress, CacheContext, current.memoizedState.cache);
      }
      return bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
    }
    function beginWork(current, workInProgress, renderLanes) {
      if (current !== null)
        if (current.memoizedProps !== workInProgress.pendingProps)
          didReceiveUpdate = true;
        else {
          if (!checkScheduledUpdateOrContext(current, renderLanes) && (workInProgress.flags & 128) === 0)
            return didReceiveUpdate = false, attemptEarlyBailoutIfNoScheduledUpdate(current, workInProgress, renderLanes);
          didReceiveUpdate = (current.flags & 131072) !== 0 ? true : false;
        }
      else
        didReceiveUpdate = false, isHydrating && (workInProgress.flags & 1048576) !== 0 && pushTreeId(workInProgress, treeForkCount, workInProgress.index);
      workInProgress.lanes = 0;
      switch (workInProgress.tag) {
        case 16:
          a: {
            var props = workInProgress.pendingProps;
            current = resolveLazy(workInProgress.elementType);
            workInProgress.type = current;
            if (typeof current === "function")
              shouldConstruct(current) ? (props = resolveClassComponentProps(current, props), workInProgress.tag = 1, workInProgress = updateClassComponent(null, workInProgress, current, props, renderLanes)) : (workInProgress.tag = 0, workInProgress = updateFunctionComponent(null, workInProgress, current, props, renderLanes));
            else {
              if (current !== undefined && current !== null) {
                var $$typeof = current.$$typeof;
                if ($$typeof === REACT_FORWARD_REF_TYPE) {
                  workInProgress.tag = 11;
                  workInProgress = updateForwardRef(null, workInProgress, current, props, renderLanes);
                  break a;
                } else if ($$typeof === REACT_MEMO_TYPE) {
                  workInProgress.tag = 14;
                  workInProgress = updateMemoComponent(null, workInProgress, current, props, renderLanes);
                  break a;
                } else if ($$typeof === REACT_CONTEXT_TYPE) {
                  workInProgress.tag = 10;
                  workInProgress.type = current;
                  workInProgress = updateContextProvider(null, workInProgress, renderLanes);
                  break a;
                }
              }
              workInProgress = getComponentNameFromType(current) || current;
              throw Error(formatProdErrorMessage(306, workInProgress, ""));
            }
          }
          return workInProgress;
        case 0:
          return updateFunctionComponent(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
        case 1:
          return props = workInProgress.type, $$typeof = resolveClassComponentProps(props, workInProgress.pendingProps), updateClassComponent(current, workInProgress, props, $$typeof, renderLanes);
        case 3:
          a: {
            pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo);
            if (current === null)
              throw Error(formatProdErrorMessage(387));
            var nextProps = workInProgress.pendingProps;
            $$typeof = workInProgress.memoizedState;
            props = $$typeof.element;
            cloneUpdateQueue(current, workInProgress);
            processUpdateQueue(workInProgress, nextProps, null, renderLanes);
            var nextState = workInProgress.memoizedState;
            nextProps = nextState.cache;
            pushProvider(workInProgress, CacheContext, nextProps);
            nextProps !== $$typeof.cache && propagateContextChanges(workInProgress, [CacheContext], renderLanes, true);
            suspendIfUpdateReadFromEntangledAsyncAction();
            nextProps = nextState.element;
            if (supportsHydration && $$typeof.isDehydrated)
              if ($$typeof = {
                element: nextProps,
                isDehydrated: false,
                cache: nextState.cache
              }, workInProgress.updateQueue.baseState = $$typeof, workInProgress.memoizedState = $$typeof, workInProgress.flags & 256) {
                workInProgress = mountHostRootWithoutHydrating(current, workInProgress, nextProps, renderLanes);
                break a;
              } else if (nextProps !== props) {
                props = createCapturedValueAtFiber(Error(formatProdErrorMessage(424)), workInProgress);
                queueHydrationError(props);
                workInProgress = mountHostRootWithoutHydrating(current, workInProgress, nextProps, renderLanes);
                break a;
              } else
                for (supportsHydration && (nextHydratableInstance = getFirstHydratableChildWithinContainer(workInProgress.stateNode.containerInfo), hydrationParentFiber = workInProgress, isHydrating = true, hydrationErrors = null, rootOrSingletonContext = true), renderLanes = mountChildFibers(workInProgress, null, nextProps, renderLanes), workInProgress.child = renderLanes;renderLanes; )
                  renderLanes.flags = renderLanes.flags & -3 | 134221824, renderLanes = renderLanes.sibling;
            else {
              resetHydrationState();
              if (nextProps === props) {
                workInProgress = bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
                break a;
              }
              reconcileChildren(current, workInProgress, nextProps, renderLanes);
            }
            workInProgress = workInProgress.child;
          }
          return workInProgress;
        case 26:
          if (supportsResources)
            return markRef(current, workInProgress), current === null ? (renderLanes = getResource(workInProgress.type, null, workInProgress.pendingProps, null)) ? workInProgress.memoizedState = renderLanes : isHydrating || (workInProgress.stateNode = createHoistableInstance(workInProgress.type, workInProgress.pendingProps, rootInstanceStackCursor.current, workInProgress)) : workInProgress.memoizedState = getResource(workInProgress.type, current.memoizedProps, workInProgress.pendingProps, current.memoizedState), null;
        case 27:
          if (supportsSingletons)
            return pushHostContext(workInProgress), current === null && supportsSingletons && isHydrating && (props = workInProgress.stateNode = resolveSingletonInstance(workInProgress.type, workInProgress.pendingProps, rootInstanceStackCursor.current, contextStackCursor.current, false), hydrationParentFiber = workInProgress, rootOrSingletonContext = true, nextHydratableInstance = getFirstHydratableChildWithinSingleton(workInProgress.type, props, nextHydratableInstance)), reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), markRef(current, workInProgress), current === null && (workInProgress.flags |= 4194304), workInProgress.child;
        case 5:
          if (current === null && isHydrating) {
            validateHydratableInstance(workInProgress.type, workInProgress.pendingProps, contextStackCursor.current);
            if ($$typeof = props = nextHydratableInstance)
              props = canHydrateInstance(props, workInProgress.type, workInProgress.pendingProps, rootOrSingletonContext), props !== null ? (workInProgress.stateNode = props, hydrationParentFiber = workInProgress, nextHydratableInstance = getFirstHydratableChild(props), rootOrSingletonContext = false, $$typeof = true) : $$typeof = false;
            $$typeof || throwOnHydrationMismatch(workInProgress);
          }
          pushHostContext(workInProgress);
          $$typeof = workInProgress.type;
          nextProps = workInProgress.pendingProps;
          nextState = current !== null ? current.memoizedProps : null;
          props = nextProps.children;
          shouldSetTextContent($$typeof, nextProps) ? props = null : nextState !== null && shouldSetTextContent($$typeof, nextState) && (workInProgress.flags |= 32);
          workInProgress.memoizedState !== null && ($$typeof = renderWithHooks(current, workInProgress, TransitionAwareHostComponent, null, null, renderLanes), isPrimaryRenderer ? HostTransitionContext._currentValue = $$typeof : HostTransitionContext._currentValue2 = $$typeof);
          markRef(current, workInProgress);
          reconcileChildren(current, workInProgress, props, renderLanes);
          return workInProgress.child;
        case 6:
          if (current === null && isHydrating) {
            validateHydratableTextInstance(workInProgress.pendingProps, contextStackCursor.current);
            if (current = renderLanes = nextHydratableInstance)
              renderLanes = canHydrateTextInstance(renderLanes, workInProgress.pendingProps, rootOrSingletonContext), renderLanes !== null ? (workInProgress.stateNode = renderLanes, hydrationParentFiber = workInProgress, nextHydratableInstance = null, current = true) : current = false;
            current || throwOnHydrationMismatch(workInProgress);
          }
          return null;
        case 13:
          return updateSuspenseComponent(current, workInProgress, renderLanes);
        case 4:
          return pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo), props = workInProgress.pendingProps, current === null ? workInProgress.child = reconcileChildFibers(workInProgress, null, props, renderLanes) : reconcileChildren(current, workInProgress, props, renderLanes), workInProgress.child;
        case 11:
          return updateForwardRef(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
        case 7:
          return props = workInProgress.pendingProps, markRef(current, workInProgress), reconcileChildren(current, workInProgress, props, renderLanes), workInProgress.child;
        case 8:
          return reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), workInProgress.child;
        case 12:
          return reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), workInProgress.child;
        case 10:
          return updateContextProvider(current, workInProgress, renderLanes);
        case 9:
          return $$typeof = workInProgress.type._context, props = workInProgress.pendingProps.children, prepareToReadContext(workInProgress), $$typeof = readContext($$typeof), props = props($$typeof), workInProgress.flags |= 1, reconcileChildren(current, workInProgress, props, renderLanes), workInProgress.child;
        case 14:
          return updateMemoComponent(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
        case 15:
          return updateSimpleMemoComponent(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
        case 19:
          return updateSuspenseListComponent(current, workInProgress, renderLanes);
        case 31:
          return updateActivityComponent(current, workInProgress, renderLanes);
        case 22:
          return updateOffscreenComponent(current, workInProgress, renderLanes, workInProgress.pendingProps);
        case 24:
          return prepareToReadContext(workInProgress), props = readContext(CacheContext), current === null ? ($$typeof = peekCacheFromPool(), $$typeof === null && ($$typeof = workInProgressRoot, nextProps = createCache(), $$typeof.pooledCache = nextProps, nextProps.refCount++, nextProps !== null && ($$typeof.pooledCacheLanes |= renderLanes), $$typeof = nextProps), workInProgress.memoizedState = {
            parent: props,
            cache: $$typeof
          }, initializeUpdateQueue(workInProgress), pushProvider(workInProgress, CacheContext, $$typeof)) : ((current.lanes & renderLanes) !== 0 && (cloneUpdateQueue(current, workInProgress), processUpdateQueue(workInProgress, null, null, renderLanes), suspendIfUpdateReadFromEntangledAsyncAction()), $$typeof = current.memoizedState, nextProps = workInProgress.memoizedState, $$typeof.parent !== props ? ($$typeof = { parent: props, cache: props }, workInProgress.memoizedState = $$typeof, workInProgress.lanes === 0 && (workInProgress.memoizedState = workInProgress.updateQueue.baseState = $$typeof), pushProvider(workInProgress, CacheContext, props)) : (props = nextProps.cache, pushProvider(workInProgress, CacheContext, props), props !== $$typeof.cache && propagateContextChanges(workInProgress, [CacheContext], renderLanes, true))), reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), workInProgress.child;
        case 30:
          return workInProgress.stateNode === null && (workInProgress.stateNode = {
            autoName: null,
            paired: null,
            clones: null,
            ref: null
          }), props = workInProgress.pendingProps, props.name != null && props.name !== "auto" ? workInProgress.flags |= current === null ? 18882560 : 18874368 : isHydrating && pushMaterializedTreeId(workInProgress), current !== null && current.memoizedProps.name !== props.name ? workInProgress.flags |= 4194816 : markRef(current, workInProgress), reconcileChildren(current, workInProgress, props.children, renderLanes), workInProgress.child;
        case 29:
          throw workInProgress.pendingProps;
      }
      throw Error(formatProdErrorMessage(156, workInProgress.tag));
    }
    function markUpdate(workInProgress) {
      workInProgress.flags |= 4;
    }
    function markCloned(workInProgress) {
      supportsPersistence && (workInProgress.flags |= 8);
    }
    function doesRequireClone(current, completedWork) {
      if (current !== null && current.child === completedWork.child)
        return false;
      if ((completedWork.flags & 16) !== 0)
        return true;
      for (current = completedWork.child;current !== null; ) {
        if ((current.flags & 8218) !== 0 || (current.subtreeFlags & 8218) !== 0)
          return true;
        current = current.sibling;
      }
      return false;
    }
    function appendAllChildren(parent, workInProgress, needsVisibilityToggle, isHidden) {
      if (supportsMutation)
        for (needsVisibilityToggle = workInProgress.child;needsVisibilityToggle !== null; ) {
          if (needsVisibilityToggle.tag === 5 || needsVisibilityToggle.tag === 6)
            appendInitialChild(parent, needsVisibilityToggle.stateNode);
          else if (!(needsVisibilityToggle.tag === 4 || supportsSingletons && needsVisibilityToggle.tag === 27) && needsVisibilityToggle.child !== null) {
            needsVisibilityToggle.child.return = needsVisibilityToggle;
            needsVisibilityToggle = needsVisibilityToggle.child;
            continue;
          }
          if (needsVisibilityToggle === workInProgress)
            break;
          for (;needsVisibilityToggle.sibling === null; ) {
            if (needsVisibilityToggle.return === null || needsVisibilityToggle.return === workInProgress)
              return;
            needsVisibilityToggle = needsVisibilityToggle.return;
          }
          needsVisibilityToggle.sibling.return = needsVisibilityToggle.return;
          needsVisibilityToggle = needsVisibilityToggle.sibling;
        }
      else if (supportsPersistence)
        for (var node$89 = workInProgress.child;node$89 !== null; ) {
          if (node$89.tag === 5) {
            var instance = node$89.stateNode;
            needsVisibilityToggle && isHidden && (instance = cloneHiddenInstance(instance, node$89.type, node$89.memoizedProps));
            appendInitialChild(parent, instance);
          } else if (node$89.tag === 6)
            instance = node$89.stateNode, needsVisibilityToggle && isHidden && (instance = cloneHiddenTextInstance(instance, node$89.memoizedProps)), appendInitialChild(parent, instance);
          else if (node$89.tag !== 4) {
            if (node$89.tag === 22 && node$89.memoizedState !== null)
              instance = node$89.child, instance !== null && (instance.return = node$89), appendAllChildren(parent, node$89, true, true);
            else if (node$89.child !== null) {
              node$89.child.return = node$89;
              node$89 = node$89.child;
              continue;
            }
          }
          if (node$89 === workInProgress)
            break;
          for (;node$89.sibling === null; ) {
            if (node$89.return === null || node$89.return === workInProgress)
              return;
            node$89 = node$89.return;
          }
          node$89.sibling.return = node$89.return;
          node$89 = node$89.sibling;
        }
    }
    function appendAllChildrenToContainer(containerChildSet, workInProgress, needsVisibilityToggle, isHidden) {
      var hasOffscreenComponentChild = false;
      if (supportsPersistence)
        for (var node = workInProgress.child;node !== null; ) {
          if (node.tag === 5) {
            var instance = node.stateNode;
            needsVisibilityToggle && isHidden && (instance = cloneHiddenInstance(instance, node.type, node.memoizedProps));
            appendChildToContainerChildSet(containerChildSet, instance);
          } else if (node.tag === 6)
            instance = node.stateNode, needsVisibilityToggle && isHidden && (instance = cloneHiddenTextInstance(instance, node.memoizedProps)), appendChildToContainerChildSet(containerChildSet, instance);
          else if (node.tag !== 4) {
            if (node.tag === 22 && node.memoizedState !== null)
              hasOffscreenComponentChild = node.child, hasOffscreenComponentChild !== null && (hasOffscreenComponentChild.return = node), appendAllChildrenToContainer(containerChildSet, node, true, true), hasOffscreenComponentChild = true;
            else if (node.child !== null) {
              node.child.return = node;
              node = node.child;
              continue;
            }
          }
          if (node === workInProgress)
            break;
          for (;node.sibling === null; ) {
            if (node.return === null || node.return === workInProgress)
              return hasOffscreenComponentChild;
            node = node.return;
          }
          node.sibling.return = node.return;
          node = node.sibling;
        }
      return hasOffscreenComponentChild;
    }
    function updateHostContainer(current, workInProgress) {
      if (supportsPersistence && doesRequireClone(current, workInProgress)) {
        current = workInProgress.stateNode;
        var container = current.containerInfo, newChildSet = createContainerChildSet();
        appendAllChildrenToContainer(newChildSet, workInProgress, false, false);
        current.pendingChildren = newChildSet;
        markUpdate(workInProgress);
        finalizeContainerChildren(container, newChildSet);
      }
    }
    function updateHostComponent(current, workInProgress, type, newProps) {
      if (supportsMutation)
        current.memoizedProps !== newProps && markUpdate(workInProgress);
      else if (supportsPersistence) {
        var currentInstance = current.stateNode, oldProps$92 = current.memoizedProps;
        if ((current = doesRequireClone(current, workInProgress)) || oldProps$92 !== newProps) {
          var currentHostContext = contextStackCursor.current;
          oldProps$92 = cloneInstance(currentInstance, type, oldProps$92, newProps, !current, null);
          oldProps$92 === currentInstance ? workInProgress.stateNode = currentInstance : (markCloned(workInProgress), finalizeInitialChildren(oldProps$92, type, newProps, currentHostContext) && markUpdate(workInProgress), workInProgress.stateNode = oldProps$92, current && appendAllChildren(oldProps$92, workInProgress, false, false));
        } else
          workInProgress.stateNode = currentInstance;
      }
    }
    function preloadInstanceAndSuspendIfNeeded(workInProgress, type, oldProps, newProps, renderLanes) {
      if ((workInProgress.mode & 32) !== 0 && (oldProps === null ? maySuspendCommit(type, newProps) : maySuspendCommitOnUpdate(type, oldProps, newProps))) {
        if (workInProgress.flags |= 16777216, (renderLanes & 335544128) === renderLanes || maySuspendCommitInSyncRender(type, newProps))
          if (preloadInstance(workInProgress.stateNode, type, newProps))
            workInProgress.flags |= 8192;
          else if (shouldRemainOnPreviousScreen())
            workInProgress.flags |= 8192;
          else
            throw suspendedThenable = noopSuspenseyCommitThenable, SuspenseyCommitException;
      } else
        workInProgress.flags &= -16777217;
    }
    function preloadResourceAndSuspendIfNeeded(workInProgress, resource) {
      if (mayResourceSuspendCommit(resource)) {
        if (workInProgress.flags |= 16777216, !preloadResource(resource))
          if (shouldRemainOnPreviousScreen())
            workInProgress.flags |= 8192;
          else
            throw suspendedThenable = noopSuspenseyCommitThenable, SuspenseyCommitException;
      } else
        workInProgress.flags &= -16777217;
    }
    function scheduleRetryEffect(workInProgress, retryQueue) {
      retryQueue !== null && (workInProgress.flags |= 4);
      workInProgress.flags & 16384 && (retryQueue = workInProgress.tag !== 22 ? claimNextRetryLane() : 536870912, workInProgress.lanes |= retryQueue, workInProgressSuspendedRetryLanes |= retryQueue);
    }
    function cutOffTailIfNeeded(renderState, hasRenderedATailFallback) {
      if (!isHydrating)
        switch (renderState.tailMode) {
          case "visible":
            break;
          case "collapsed":
            for (var tailNode = renderState.tail, lastTailNode = null;tailNode !== null; )
              tailNode.alternate !== null && (lastTailNode = tailNode), tailNode = tailNode.sibling;
            lastTailNode === null ? hasRenderedATailFallback || renderState.tail === null ? renderState.tail = null : renderState.tail.sibling = null : lastTailNode.sibling = null;
            break;
          default:
            hasRenderedATailFallback = renderState.tail;
            for (tailNode = null;hasRenderedATailFallback !== null; )
              hasRenderedATailFallback.alternate !== null && (tailNode = hasRenderedATailFallback), hasRenderedATailFallback = hasRenderedATailFallback.sibling;
            tailNode === null ? renderState.tail = null : tailNode.sibling = null;
        }
    }
    function bubbleProperties(completedWork) {
      var didBailout = completedWork.alternate !== null && completedWork.alternate.child === completedWork.child, newChildLanes = 0, subtreeFlags = 0;
      if (didBailout)
        for (var child$95 = completedWork.child;child$95 !== null; )
          newChildLanes |= child$95.lanes | child$95.childLanes, subtreeFlags |= child$95.subtreeFlags & 1206910976, subtreeFlags |= child$95.flags & 1206910976, child$95.return = completedWork, child$95 = child$95.sibling;
      else
        for (child$95 = completedWork.child;child$95 !== null; )
          newChildLanes |= child$95.lanes | child$95.childLanes, subtreeFlags |= child$95.subtreeFlags, subtreeFlags |= child$95.flags, child$95.return = completedWork, child$95 = child$95.sibling;
      completedWork.subtreeFlags |= subtreeFlags;
      completedWork.childLanes = newChildLanes;
      return didBailout;
    }
    function completeWork(current, workInProgress, renderLanes) {
      var newProps = workInProgress.pendingProps;
      popTreeContext(workInProgress);
      switch (workInProgress.tag) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return bubbleProperties(workInProgress), null;
        case 1:
          return bubbleProperties(workInProgress), null;
        case 3:
          renderLanes = workInProgress.stateNode;
          newProps = null;
          current !== null && (newProps = current.memoizedState.cache);
          workInProgress.memoizedState.cache !== newProps && (workInProgress.flags |= 2048);
          popProvider(CacheContext);
          popHostContainer();
          renderLanes.pendingContext && (renderLanes.context = renderLanes.pendingContext, renderLanes.pendingContext = null);
          if (current === null || current.child === null)
            popHydrationState(workInProgress) ? markUpdate(workInProgress) : current === null || current.memoizedState.isDehydrated && (workInProgress.flags & 256) === 0 || (workInProgress.flags |= 1024, upgradeHydrationErrorsToRecoverable());
          updateHostContainer(current, workInProgress);
          bubbleProperties(workInProgress);
          return null;
        case 26:
          if (supportsResources) {
            var { type, memoizedState: nextResource } = workInProgress;
            current === null ? (markUpdate(workInProgress), nextResource !== null ? (bubbleProperties(workInProgress), preloadResourceAndSuspendIfNeeded(workInProgress, nextResource)) : (bubbleProperties(workInProgress), preloadInstanceAndSuspendIfNeeded(workInProgress, type, null, newProps, renderLanes))) : nextResource ? nextResource !== current.memoizedState ? (markUpdate(workInProgress), bubbleProperties(workInProgress), preloadResourceAndSuspendIfNeeded(workInProgress, nextResource)) : (bubbleProperties(workInProgress), workInProgress.flags &= -16777217) : (nextResource = current.memoizedProps, supportsMutation ? nextResource !== newProps && markUpdate(workInProgress) : updateHostComponent(current, workInProgress, type, newProps), bubbleProperties(workInProgress), preloadInstanceAndSuspendIfNeeded(workInProgress, type, nextResource, newProps, renderLanes));
            return null;
          }
        case 27:
          if (supportsSingletons) {
            popHostContext(workInProgress);
            renderLanes = rootInstanceStackCursor.current;
            type = workInProgress.type;
            if (current !== null && workInProgress.stateNode != null)
              supportsMutation ? current.memoizedProps !== newProps && markUpdate(workInProgress) : updateHostComponent(current, workInProgress, type, newProps);
            else {
              if (!newProps) {
                if (workInProgress.stateNode === null)
                  throw Error(formatProdErrorMessage(166));
                bubbleProperties(workInProgress);
                workInProgress.subtreeFlags &= -33554433;
                return null;
              }
              current = contextStackCursor.current;
              popHydrationState(workInProgress) ? prepareToHydrateHostInstance(workInProgress, current) : (current = resolveSingletonInstance(type, newProps, renderLanes, current, true), workInProgress.stateNode = current, markUpdate(workInProgress));
            }
            bubbleProperties(workInProgress);
            workInProgress.subtreeFlags &= -33554433;
            return null;
          }
        case 5:
          popHostContext(workInProgress);
          type = workInProgress.type;
          if (current !== null && workInProgress.stateNode != null)
            updateHostComponent(current, workInProgress, type, newProps);
          else {
            if (!newProps) {
              if (workInProgress.stateNode === null)
                throw Error(formatProdErrorMessage(166));
              bubbleProperties(workInProgress);
              workInProgress.subtreeFlags &= -33554433;
              return null;
            }
            nextResource = contextStackCursor.current;
            if (popHydrationState(workInProgress))
              prepareToHydrateHostInstance(workInProgress, nextResource), finalizeHydratedChildren(workInProgress.stateNode, type, newProps, nextResource) && (workInProgress.flags |= 64);
            else {
              var instance$105 = createInstance(type, newProps, rootInstanceStackCursor.current, nextResource, workInProgress);
              markCloned(workInProgress);
              appendAllChildren(instance$105, workInProgress, false, false);
              workInProgress.stateNode = instance$105;
              finalizeInitialChildren(instance$105, type, newProps, nextResource) && markUpdate(workInProgress);
            }
          }
          bubbleProperties(workInProgress);
          workInProgress.subtreeFlags &= -33554433;
          preloadInstanceAndSuspendIfNeeded(workInProgress, workInProgress.type, current === null ? null : current.memoizedProps, workInProgress.pendingProps, renderLanes);
          return null;
        case 6:
          if (current && workInProgress.stateNode != null)
            renderLanes = current.memoizedProps, supportsMutation ? renderLanes !== newProps && markUpdate(workInProgress) : supportsPersistence && (renderLanes !== newProps ? (current = rootInstanceStackCursor.current, renderLanes = contextStackCursor.current, markCloned(workInProgress), workInProgress.stateNode = createTextInstance(newProps, current, renderLanes, workInProgress)) : workInProgress.stateNode = current.stateNode);
          else {
            if (typeof newProps !== "string" && workInProgress.stateNode === null)
              throw Error(formatProdErrorMessage(166));
            current = rootInstanceStackCursor.current;
            renderLanes = contextStackCursor.current;
            if (popHydrationState(workInProgress)) {
              if (!supportsHydration)
                throw Error(formatProdErrorMessage(176));
              current = workInProgress.stateNode;
              renderLanes = workInProgress.memoizedProps;
              newProps = null;
              type = hydrationParentFiber;
              if (type !== null)
                switch (type.tag) {
                  case 27:
                  case 5:
                    newProps = type.memoizedProps;
                }
              hydrateTextInstance(current, renderLanes, workInProgress, newProps) || throwOnHydrationMismatch(workInProgress, true);
            } else
              markCloned(workInProgress), workInProgress.stateNode = createTextInstance(newProps, current, renderLanes, workInProgress);
          }
          bubbleProperties(workInProgress);
          return null;
        case 31:
          renderLanes = workInProgress.memoizedState;
          if (current === null || current.memoizedState !== null) {
            newProps = popHydrationState(workInProgress);
            if (renderLanes !== null) {
              if (current === null) {
                if (!newProps)
                  throw Error(formatProdErrorMessage(318));
                if (!supportsHydration)
                  throw Error(formatProdErrorMessage(556));
                current = workInProgress.memoizedState;
                current = current !== null ? current.dehydrated : null;
                if (!current)
                  throw Error(formatProdErrorMessage(557));
                hydrateActivityInstance(current, workInProgress);
              } else
                resetHydrationState(), (workInProgress.flags & 128) === 0 && (workInProgress.memoizedState = null), workInProgress.flags |= 4;
              bubbleProperties(workInProgress);
              current = false;
            } else
              renderLanes = upgradeHydrationErrorsToRecoverable(), current !== null && current.memoizedState !== null && (current.memoizedState.hydrationErrors = renderLanes), current = true;
            if (!current) {
              if (workInProgress.flags & 256)
                return popSuspenseHandler(workInProgress), workInProgress;
              popSuspenseHandler(workInProgress);
              return null;
            }
            if ((workInProgress.flags & 128) !== 0)
              throw Error(formatProdErrorMessage(558));
          }
          bubbleProperties(workInProgress);
          return null;
        case 13:
          newProps = workInProgress.memoizedState;
          if (current === null || current.memoizedState !== null && current.memoizedState.dehydrated !== null) {
            type = popHydrationState(workInProgress);
            if (newProps !== null && newProps.dehydrated !== null) {
              if (current === null) {
                if (!type)
                  throw Error(formatProdErrorMessage(318));
                if (!supportsHydration)
                  throw Error(formatProdErrorMessage(344));
                type = workInProgress.memoizedState;
                type = type !== null ? type.dehydrated : null;
                if (!type)
                  throw Error(formatProdErrorMessage(317));
                hydrateSuspenseInstance(type, workInProgress);
              } else
                resetHydrationState(), (workInProgress.flags & 128) === 0 && (workInProgress.memoizedState = null), workInProgress.flags |= 4;
              bubbleProperties(workInProgress);
              type = false;
            } else
              type = upgradeHydrationErrorsToRecoverable(), current !== null && current.memoizedState !== null && (current.memoizedState.hydrationErrors = type), type = true;
            if (!type) {
              if (workInProgress.flags & 256)
                return popSuspenseHandler(workInProgress), workInProgress;
              popSuspenseHandler(workInProgress);
              return null;
            }
          }
          popSuspenseHandler(workInProgress);
          if ((workInProgress.flags & 128) !== 0)
            return workInProgress.lanes = renderLanes, workInProgress;
          renderLanes = newProps !== null;
          current = current !== null && current.memoizedState !== null;
          renderLanes && (newProps = workInProgress.child, type = null, newProps.alternate !== null && newProps.alternate.memoizedState !== null && newProps.alternate.memoizedState.cachePool !== null && (type = newProps.alternate.memoizedState.cachePool.pool), nextResource = null, newProps.memoizedState !== null && newProps.memoizedState.cachePool !== null && (nextResource = newProps.memoizedState.cachePool.pool), nextResource !== type && (newProps.flags |= 2048));
          renderLanes !== current && renderLanes && (workInProgress.child.flags |= 8192);
          scheduleRetryEffect(workInProgress, workInProgress.updateQueue);
          bubbleProperties(workInProgress);
          return null;
        case 4:
          return popHostContainer(), updateHostContainer(current, workInProgress), current === null && preparePortalMount(workInProgress.stateNode.containerInfo), workInProgress.flags |= 67108864, bubbleProperties(workInProgress), null;
        case 10:
          return popProvider(workInProgress.type), bubbleProperties(workInProgress), null;
        case 19:
          popSuspenseListContext(workInProgress);
          newProps = workInProgress.memoizedState;
          if (newProps === null)
            return bubbleProperties(workInProgress), null;
          type = (workInProgress.flags & 128) !== 0;
          nextResource = newProps.rendering;
          if (nextResource === null)
            if (type)
              cutOffTailIfNeeded(newProps, false);
            else {
              if (workInProgressRootExitStatus !== 0 || current !== null && (current.flags & 128) !== 0)
                for (current = workInProgress.child;current !== null; ) {
                  nextResource = findFirstSuspended(current);
                  if (nextResource !== null) {
                    workInProgress.flags |= 128;
                    cutOffTailIfNeeded(newProps, false);
                    current = nextResource.updateQueue;
                    workInProgress.updateQueue = current;
                    scheduleRetryEffect(workInProgress, current);
                    workInProgress.subtreeFlags = 0;
                    current = renderLanes;
                    for (renderLanes = workInProgress.child;renderLanes !== null; )
                      resetWorkInProgress(renderLanes, current), renderLanes = renderLanes.sibling;
                    pushSuspenseListContext(workInProgress, suspenseStackCursor.current & 1 | 2);
                    isHydrating && pushTreeFork(workInProgress, newProps.treeForkCount);
                    return workInProgress.child;
                  }
                  current = current.sibling;
                }
              newProps.tail !== null && now() > workInProgressRootRenderTargetTime && (workInProgress.flags |= 128, type = true, cutOffTailIfNeeded(newProps, false), workInProgress.lanes = 4194304);
            }
          else {
            if (!type)
              if (current = findFirstSuspended(nextResource), current !== null) {
                if (workInProgress.flags |= 128, type = true, current = current.updateQueue, workInProgress.updateQueue = current, scheduleRetryEffect(workInProgress, current), cutOffTailIfNeeded(newProps, true), newProps.tail === null && newProps.tailMode !== "collapsed" && newProps.tailMode !== "visible" && !nextResource.alternate && !isHydrating)
                  return bubbleProperties(workInProgress), null;
              } else
                2 * now() - newProps.renderingStartTime > workInProgressRootRenderTargetTime && renderLanes !== 536870912 && (workInProgress.flags |= 128, type = true, cutOffTailIfNeeded(newProps, false), workInProgress.lanes = 4194304);
            newProps.isBackwards ? (nextResource.sibling = workInProgress.child, workInProgress.child = nextResource) : (current = newProps.last, current !== null ? current.sibling = nextResource : workInProgress.child = nextResource, newProps.last = nextResource);
          }
          if (newProps.tail !== null) {
            current = newProps.tail;
            a: {
              for (renderLanes = current;renderLanes !== null; ) {
                if (renderLanes.alternate !== null) {
                  renderLanes = false;
                  break a;
                }
                renderLanes = renderLanes.sibling;
              }
              renderLanes = true;
            }
            newProps.rendering = current;
            newProps.tail = current.sibling;
            newProps.renderingStartTime = now();
            current.sibling = null;
            nextResource = suspenseStackCursor.current;
            nextResource = type ? nextResource & 1 | 2 : nextResource & 1;
            newProps.tailMode === "visible" || newProps.tailMode === "collapsed" || !renderLanes || isHydrating ? pushSuspenseListContext(workInProgress, nextResource) : (renderLanes = nextResource, push(suspenseHandlerStackCursor, workInProgress), push(suspenseStackCursor, renderLanes), shellBoundary === null && (shellBoundary = workInProgress));
            isHydrating && pushTreeFork(workInProgress, newProps.treeForkCount);
            return current;
          }
          bubbleProperties(workInProgress);
          return null;
        case 22:
        case 23:
          return popSuspenseHandler(workInProgress), popHiddenContext(), newProps = workInProgress.memoizedState !== null, current !== null ? current.memoizedState !== null !== newProps && (workInProgress.flags |= 8192) : newProps && (workInProgress.flags |= 8192), newProps ? (renderLanes & 536870912) !== 0 && (workInProgress.flags & 128) === 0 && (bubbleProperties(workInProgress), workInProgress.subtreeFlags & 6 && (workInProgress.flags |= 8192)) : bubbleProperties(workInProgress), renderLanes = workInProgress.updateQueue, renderLanes !== null && scheduleRetryEffect(workInProgress, renderLanes.retryQueue), renderLanes = null, current !== null && current.memoizedState !== null && current.memoizedState.cachePool !== null && (renderLanes = current.memoizedState.cachePool.pool), newProps = null, workInProgress.memoizedState !== null && workInProgress.memoizedState.cachePool !== null && (newProps = workInProgress.memoizedState.cachePool.pool), newProps !== renderLanes && (workInProgress.flags |= 2048), current !== null && pop(resumedCache), null;
        case 24:
          return renderLanes = null, current !== null && (renderLanes = current.memoizedState.cache), workInProgress.memoizedState.cache !== renderLanes && (workInProgress.flags |= 2048), popProvider(CacheContext), bubbleProperties(workInProgress), null;
        case 25:
          return null;
        case 30:
          return workInProgress.flags |= 33554432, bubbleProperties(workInProgress), null;
      }
      throw Error(formatProdErrorMessage(156, workInProgress.tag));
    }
    function unwindWork(current, workInProgress) {
      popTreeContext(workInProgress);
      switch (workInProgress.tag) {
        case 1:
          return current = workInProgress.flags, current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
        case 3:
          return popProvider(CacheContext), popHostContainer(), current = workInProgress.flags, (current & 65536) !== 0 && (current & 128) === 0 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
        case 26:
        case 27:
        case 5:
          return popHostContext(workInProgress), null;
        case 31:
          if (workInProgress.memoizedState !== null) {
            popSuspenseHandler(workInProgress);
            if (workInProgress.alternate === null)
              throw Error(formatProdErrorMessage(340));
            resetHydrationState();
          }
          current = workInProgress.flags;
          return current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
        case 13:
          popSuspenseHandler(workInProgress);
          current = workInProgress.memoizedState;
          if (current !== null && current.dehydrated !== null) {
            if (workInProgress.alternate === null)
              throw Error(formatProdErrorMessage(340));
            resetHydrationState();
          }
          current = workInProgress.flags;
          return current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
        case 19:
          return popSuspenseListContext(workInProgress), current = workInProgress.flags, current & 65536 ? (workInProgress.flags = current & -65537 | 128, current = workInProgress.memoizedState, current !== null && (current.rendering = null, current.tail = null), workInProgress.flags |= 4, workInProgress) : null;
        case 4:
          return popHostContainer(), null;
        case 10:
          return popProvider(workInProgress.type), null;
        case 22:
        case 23:
          return popSuspenseHandler(workInProgress), popHiddenContext(), current !== null && pop(resumedCache), current = workInProgress.flags, current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
        case 24:
          return popProvider(CacheContext), null;
        case 25:
          return null;
        default:
          return null;
      }
    }
    function unwindInterruptedWork(current, interruptedWork) {
      popTreeContext(interruptedWork);
      switch (interruptedWork.tag) {
        case 3:
          popProvider(CacheContext);
          popHostContainer();
          break;
        case 26:
        case 27:
        case 5:
          popHostContext(interruptedWork);
          break;
        case 4:
          popHostContainer();
          break;
        case 31:
          interruptedWork.memoizedState !== null && popSuspenseHandler(interruptedWork);
          break;
        case 13:
          popSuspenseHandler(interruptedWork);
          break;
        case 19:
          popSuspenseListContext(interruptedWork);
          break;
        case 10:
          popProvider(interruptedWork.type);
          break;
        case 22:
        case 23:
          popSuspenseHandler(interruptedWork);
          popHiddenContext();
          current !== null && pop(resumedCache);
          break;
        case 24:
          popProvider(CacheContext);
      }
    }
    function commitHookEffectListMount(flags, finishedWork) {
      try {
        var updateQueue = finishedWork.updateQueue, lastEffect = updateQueue !== null ? updateQueue.lastEffect : null;
        if (lastEffect !== null) {
          var firstEffect = lastEffect.next;
          updateQueue = firstEffect;
          do {
            if ((updateQueue.tag & flags) === flags) {
              lastEffect = undefined;
              var create = updateQueue.create, inst = updateQueue.inst;
              lastEffect = create();
              inst.destroy = lastEffect;
            }
            updateQueue = updateQueue.next;
          } while (updateQueue !== firstEffect);
        }
      } catch (error) {
        captureCommitPhaseError(finishedWork, finishedWork.return, error);
      }
    }
    function commitHookEffectListUnmount(flags, finishedWork, nearestMountedAncestor$jscomp$0) {
      try {
        var updateQueue = finishedWork.updateQueue, lastEffect = updateQueue !== null ? updateQueue.lastEffect : null;
        if (lastEffect !== null) {
          var firstEffect = lastEffect.next;
          updateQueue = firstEffect;
          do {
            if ((updateQueue.tag & flags) === flags) {
              var inst = updateQueue.inst, destroy = inst.destroy;
              if (destroy !== undefined) {
                inst.destroy = undefined;
                lastEffect = finishedWork;
                var nearestMountedAncestor = nearestMountedAncestor$jscomp$0, destroy_ = destroy;
                try {
                  destroy_();
                } catch (error) {
                  captureCommitPhaseError(lastEffect, nearestMountedAncestor, error);
                }
              }
            }
            updateQueue = updateQueue.next;
          } while (updateQueue !== firstEffect);
        }
      } catch (error) {
        captureCommitPhaseError(finishedWork, finishedWork.return, error);
      }
    }
    function commitClassCallbacks(finishedWork) {
      var updateQueue = finishedWork.updateQueue;
      if (updateQueue !== null) {
        var instance = finishedWork.stateNode;
        try {
          commitCallbacks(updateQueue, instance);
        } catch (error) {
          captureCommitPhaseError(finishedWork, finishedWork.return, error);
        }
      }
    }
    function safelyCallComponentWillUnmount(current, nearestMountedAncestor, instance) {
      instance.props = resolveClassComponentProps(current.type, current.memoizedProps);
      instance.state = current.memoizedState;
      try {
        instance.componentWillUnmount();
      } catch (error) {
        captureCommitPhaseError(current, nearestMountedAncestor, error);
      }
    }
    function safelyAttachRef(current, nearestMountedAncestor) {
      try {
        var ref = current.ref;
        if (ref !== null) {
          switch (current.tag) {
            case 26:
            case 27:
            case 5:
              var instanceToUse = getPublicInstance(current.stateNode);
              break;
            case 30:
              var instance = current.stateNode, name = getViewTransitionName(current.memoizedProps, instance);
              if (instance.ref === null || instance.ref.name !== name)
                instance.ref = createViewTransitionInstance(name);
              instanceToUse = instance.ref;
              break;
            case 7:
              current.stateNode === null && (current.stateNode = createFragmentInstance(current));
              instanceToUse = current.stateNode;
              break;
            default:
              instanceToUse = current.stateNode;
          }
          typeof ref === "function" ? current.refCleanup = ref(instanceToUse) : ref.current = instanceToUse;
        }
      } catch (error) {
        captureCommitPhaseError(current, nearestMountedAncestor, error);
      }
    }
    function safelyDetachRef(current, nearestMountedAncestor) {
      var ref = current.ref, refCleanup = current.refCleanup;
      if (ref !== null)
        if (typeof refCleanup === "function")
          try {
            refCleanup();
          } catch (error) {
            captureCommitPhaseError(current, nearestMountedAncestor, error);
          } finally {
            current.refCleanup = null, current = current.alternate, current != null && (current.refCleanup = null);
          }
        else if (typeof ref === "function")
          try {
            ref(null);
          } catch (error$130) {
            captureCommitPhaseError(current, nearestMountedAncestor, error$130);
          }
        else
          ref.current = null;
    }
    function pushMutationContext() {
      var prev = viewTransitionMutationContext;
      viewTransitionMutationContext = false;
      return prev;
    }
    function commitNewChildToFragmentInstances(fiber, parentFragmentInstances) {
      if ((fiber.tag === 5 || fiber.tag === 27 || fiber.tag === 6) && fiber.alternate === null && parentFragmentInstances !== null)
        for (var i = 0;i < parentFragmentInstances.length; i++)
          commitNewChildToFragmentInstance(fiber.stateNode, parentFragmentInstances[i]);
    }
    function commitFragmentInstanceInsertionEffects(fiber) {
      for (var parent = fiber.return;parent !== null; ) {
        isFragmentInstanceParent(parent) && commitNewChildToFragmentInstance(fiber.stateNode, parent.stateNode);
        if (isFragmentInstanceHostBoundary(parent))
          break;
        parent = parent.return;
      }
    }
    function commitFragmentInstanceDeletionEffects(fiber) {
      for (var parent = fiber.return;parent !== null; ) {
        isFragmentInstanceParent(parent) && deleteChildFromFragmentInstance(fiber.stateNode, parent.stateNode);
        if (isFragmentInstanceHostBoundary(parent))
          break;
        parent = parent.return;
      }
    }
    function isFragmentInstanceHostBoundary(fiber) {
      return fiber.tag === 5 || fiber.tag === 3 || (supportsSingletons ? fiber.tag === 27 : false);
    }
    function isFragmentInstanceParent(fiber) {
      return fiber && fiber.tag === 7 && fiber.stateNode !== null;
    }
    function commitHostMount(finishedWork) {
      var { type, memoizedProps: props, stateNode: instance } = finishedWork;
      try {
        commitMount(instance, type, props, finishedWork);
      } catch (error) {
        captureCommitPhaseError(finishedWork, finishedWork.return, error);
      }
    }
    function commitHostUpdate(finishedWork, newProps, oldProps) {
      try {
        commitUpdate(finishedWork.stateNode, finishedWork.type, oldProps, newProps, finishedWork);
      } catch (error) {
        captureCommitPhaseError(finishedWork, finishedWork.return, error);
      }
    }
    function isHostParent(fiber) {
      return fiber.tag === 5 || fiber.tag === 3 || (supportsResources ? fiber.tag === 26 : false) || (supportsSingletons ? fiber.tag === 27 && isSingletonScope(fiber.type) : false) || fiber.tag === 4;
    }
    function getHostSibling(fiber) {
      a:
        for (;; ) {
          for (;fiber.sibling === null; ) {
            if (fiber.return === null || isHostParent(fiber.return))
              return null;
            fiber = fiber.return;
          }
          fiber.sibling.return = fiber.return;
          for (fiber = fiber.sibling;fiber.tag !== 5 && fiber.tag !== 6 && fiber.tag !== 18; ) {
            if (supportsSingletons && fiber.tag === 27 && isSingletonScope(fiber.type))
              continue a;
            if (fiber.flags & 2)
              continue a;
            if (fiber.child === null || fiber.tag === 4)
              continue a;
            else
              fiber.child.return = fiber, fiber = fiber.child;
          }
          if (!(fiber.flags & 2))
            return fiber.stateNode;
        }
    }
    function insertOrAppendPlacementNodeIntoContainer(node, before, parent, parentFragmentInstances) {
      var tag = node.tag;
      if (tag === 5 || tag === 6)
        tag = node.stateNode, before ? insertInContainerBefore(parent, tag, before) : appendChildToContainer(parent, tag), commitNewChildToFragmentInstances(node, parentFragmentInstances), viewTransitionMutationContext = true;
      else if (tag !== 4 && (supportsSingletons && tag === 27 && (commitNewChildToFragmentInstances(node, parentFragmentInstances), parentFragmentInstances = null, isSingletonScope(node.type) && (parent = node.stateNode, before = null)), node = node.child, node !== null))
        for (insertOrAppendPlacementNodeIntoContainer(node, before, parent, parentFragmentInstances), node = node.sibling;node !== null; )
          insertOrAppendPlacementNodeIntoContainer(node, before, parent, parentFragmentInstances), node = node.sibling;
    }
    function insertOrAppendPlacementNode(node, before, parent, parentFragmentInstances) {
      var tag = node.tag;
      if (tag === 5 || tag === 6)
        tag = node.stateNode, before ? insertBefore(parent, tag, before) : appendChild(parent, tag), commitNewChildToFragmentInstances(node, parentFragmentInstances), viewTransitionMutationContext = true;
      else if (tag !== 4 && (supportsSingletons && tag === 27 && (commitNewChildToFragmentInstances(node, parentFragmentInstances), parentFragmentInstances = null, isSingletonScope(node.type) && (parent = node.stateNode)), node = node.child, node !== null))
        for (insertOrAppendPlacementNode(node, before, parent, parentFragmentInstances), node = node.sibling;node !== null; )
          insertOrAppendPlacementNode(node, before, parent, parentFragmentInstances), node = node.sibling;
    }
    function commitImmutablePlacementNodeToFragmentInstances(finishedWork, parentFragmentInstances) {
      if (finishedWork.tag === 5 || supportsSingletons && finishedWork.tag === 27)
        commitNewChildToFragmentInstances(finishedWork, parentFragmentInstances);
      else if (finishedWork.tag !== 4 && (finishedWork = finishedWork.child, finishedWork !== null))
        for (commitImmutablePlacementNodeToFragmentInstances(finishedWork, parentFragmentInstances), finishedWork = finishedWork.sibling;finishedWork !== null; )
          commitImmutablePlacementNodeToFragmentInstances(finishedWork, parentFragmentInstances), finishedWork = finishedWork.sibling;
    }
    function commitHostPortalContainerChildren(portal, finishedWork, pendingChildren) {
      portal = portal.containerInfo;
      try {
        replaceContainerChildren(portal, pendingChildren);
      } catch (error) {
        captureCommitPhaseError(finishedWork, finishedWork.return, error);
      }
    }
    function commitHostSingletonAcquisition(finishedWork) {
      var { stateNode: singleton, memoizedProps: props } = finishedWork;
      try {
        acquireSingletonInstance(finishedWork.type, props, singleton, finishedWork);
      } catch (error) {
        captureCommitPhaseError(finishedWork, finishedWork.return, error);
      }
    }
    function trackEnterViewTransitions(placement) {
      if (placement.tag === 30 || (placement.subtreeFlags & 33554432) !== 0)
        shouldStartViewTransition = true;
    }
    function pushViewTransitionCancelableScope() {
      var prevChildren = viewTransitionCancelableChildren;
      viewTransitionCancelableChildren = null;
      return prevChildren;
    }
    function applyViewTransitionToHostInstances(fiber, name, className, collectMeasurements, stopAtNestedViewTransitions) {
      viewTransitionHostInstanceIdx = 0;
      return applyViewTransitionToHostInstancesRecursive(fiber.child, name, className, collectMeasurements, stopAtNestedViewTransitions);
    }
    function applyViewTransitionToHostInstancesRecursive(child, name, className, collectMeasurements, stopAtNestedViewTransitions) {
      if (!supportsMutation)
        return false;
      for (var inViewport = false;child !== null; ) {
        if (child.tag === 5) {
          var instance = child.stateNode;
          if (collectMeasurements !== null) {
            var measurement = measureInstance(instance);
            collectMeasurements.push(measurement);
            wasInstanceInViewport(measurement) && (inViewport = true);
          } else
            inViewport || wasInstanceInViewport(measureInstance(instance)) && (inViewport = true);
          shouldStartViewTransition = true;
          applyViewTransitionName(instance, viewTransitionHostInstanceIdx === 0 ? name : name + "_" + viewTransitionHostInstanceIdx, className);
          viewTransitionHostInstanceIdx++;
        } else if (child.tag !== 22 || child.memoizedState === null)
          child.tag === 30 && stopAtNestedViewTransitions || applyViewTransitionToHostInstancesRecursive(child.child, name, className, collectMeasurements, stopAtNestedViewTransitions) && (inViewport = true);
        child = child.sibling;
      }
      return inViewport;
    }
    function restoreViewTransitionOnHostInstances(child, stopAtNestedViewTransitions) {
      if (supportsMutation)
        for (;child !== null; ) {
          if (child.tag === 5)
            restoreViewTransitionName(child.stateNode, child.memoizedProps);
          else if (child.tag !== 22 || child.memoizedState === null)
            child.tag === 30 && stopAtNestedViewTransitions || restoreViewTransitionOnHostInstances(child.child, stopAtNestedViewTransitions);
          child = child.sibling;
        }
    }
    function commitAppearingPairViewTransitions(placement) {
      if ((placement.subtreeFlags & 18874368) !== 0)
        for (placement = placement.child;placement !== null; ) {
          if (placement.tag !== 22 || placement.memoizedState === null) {
            if (commitAppearingPairViewTransitions(placement), placement.tag === 30 && (placement.flags & 18874368) !== 0 && placement.stateNode.paired) {
              var props = placement.memoizedProps;
              if (props.name == null || props.name === "auto")
                throw Error(formatProdErrorMessage(544));
              var name = props.name;
              props = getViewTransitionClassName(props.default, props.share);
              props !== "none" && (applyViewTransitionToHostInstances(placement, name, props, null, false) || restoreViewTransitionOnHostInstances(placement.child, false));
            }
          }
          placement = placement.sibling;
        }
    }
    function commitEnterViewTransitions(placement, gesture) {
      if (placement.tag === 30) {
        var state = placement.stateNode, props = placement.memoizedProps, name = getViewTransitionName(props, state), className = getViewTransitionClassName(props.default, state.paired ? props.share : props.enter);
        className !== "none" ? applyViewTransitionToHostInstances(placement, name, className, null, false) ? (commitAppearingPairViewTransitions(placement), state.paired || gesture || scheduleViewTransitionEvent(placement, props.onEnter)) : restoreViewTransitionOnHostInstances(placement.child, false) : commitAppearingPairViewTransitions(placement);
      } else if ((placement.subtreeFlags & 33554432) !== 0)
        for (placement = placement.child;placement !== null; )
          commitEnterViewTransitions(placement, gesture), placement = placement.sibling;
      else
        commitAppearingPairViewTransitions(placement);
    }
    function commitDeletedPairViewTransitions(deletion) {
      if (appearingViewTransitions !== null && appearingViewTransitions.size !== 0) {
        var pairs = appearingViewTransitions;
        if ((deletion.subtreeFlags & 18874368) !== 0)
          for (deletion = deletion.child;deletion !== null; ) {
            if (deletion.tag !== 22 || deletion.memoizedState === null) {
              if (deletion.tag === 30 && (deletion.flags & 18874368) !== 0) {
                var props = deletion.memoizedProps, name = props.name;
                if (name != null && name !== "auto") {
                  var pair = pairs.get(name);
                  if (pair !== undefined) {
                    var className = getViewTransitionClassName(props.default, props.share);
                    className !== "none" && (applyViewTransitionToHostInstances(deletion, name, className, null, false) ? (className = deletion.stateNode, pair.paired = className, className.paired = pair, scheduleViewTransitionEvent(deletion, props.onShare)) : restoreViewTransitionOnHostInstances(deletion.child, false));
                    pairs.delete(name);
                    if (pairs.size === 0)
                      break;
                  }
                }
              }
              commitDeletedPairViewTransitions(deletion);
            }
            deletion = deletion.sibling;
          }
      }
    }
    function commitExitViewTransitions(deletion) {
      if (deletion.tag === 30) {
        var props = deletion.memoizedProps, name = getViewTransitionName(props, deletion.stateNode), pair = appearingViewTransitions !== null ? appearingViewTransitions.get(name) : undefined, className = getViewTransitionClassName(props.default, pair !== undefined ? props.share : props.exit);
        className !== "none" && (applyViewTransitionToHostInstances(deletion, name, className, null, false) ? pair !== undefined ? (className = deletion.stateNode, pair.paired = className, className.paired = pair, appearingViewTransitions.delete(name), scheduleViewTransitionEvent(deletion, props.onShare)) : scheduleViewTransitionEvent(deletion, props.onExit) : restoreViewTransitionOnHostInstances(deletion.child, false));
        appearingViewTransitions !== null && commitDeletedPairViewTransitions(deletion);
      } else if ((deletion.subtreeFlags & 33554432) !== 0)
        for (deletion = deletion.child;deletion !== null; )
          commitExitViewTransitions(deletion), deletion = deletion.sibling;
      else
        appearingViewTransitions !== null && commitDeletedPairViewTransitions(deletion);
    }
    function commitNestedViewTransitions(changedParent) {
      for (changedParent = changedParent.child;changedParent !== null; ) {
        if (changedParent.tag === 30) {
          var props = changedParent.memoizedProps, name = getViewTransitionName(props, changedParent.stateNode);
          props = getViewTransitionClassName(props.default, props.update);
          changedParent.flags &= -5;
          props !== "none" && applyViewTransitionToHostInstances(changedParent, name, props, changedParent.memoizedState = [], false);
        } else
          (changedParent.subtreeFlags & 33554432) !== 0 && commitNestedViewTransitions(changedParent);
        changedParent = changedParent.sibling;
      }
    }
    function restorePairedViewTransitions(parent) {
      if ((parent.subtreeFlags & 18874368) !== 0)
        for (parent = parent.child;parent !== null; ) {
          if (parent.tag !== 22 || parent.memoizedState === null) {
            if (parent.tag === 30 && (parent.flags & 18874368) !== 0) {
              var instance = parent.stateNode;
              instance.paired !== null && (instance.paired = null, restoreViewTransitionOnHostInstances(parent.child, false));
            }
            restorePairedViewTransitions(parent);
          }
          parent = parent.sibling;
        }
    }
    function restoreEnterOrExitViewTransitions(fiber) {
      if (fiber.tag === 30)
        fiber.stateNode.paired = null, restoreViewTransitionOnHostInstances(fiber.child, false), restorePairedViewTransitions(fiber);
      else if ((fiber.subtreeFlags & 33554432) !== 0)
        for (fiber = fiber.child;fiber !== null; )
          restoreEnterOrExitViewTransitions(fiber), fiber = fiber.sibling;
      else
        restorePairedViewTransitions(fiber);
    }
    function restoreNestedViewTransitions(changedParent) {
      for (changedParent = changedParent.child;changedParent !== null; )
        changedParent.tag === 30 ? restoreViewTransitionOnHostInstances(changedParent.child, false) : (changedParent.subtreeFlags & 33554432) !== 0 && restoreNestedViewTransitions(changedParent), changedParent = changedParent.sibling;
    }
    function measureViewTransitionHostInstancesRecursive(parentViewTransition, child, newName, oldName, className, previousMeasurements, stopAtNestedViewTransitions) {
      if (!supportsMutation)
        return false;
      for (var inViewport = false;child !== null; ) {
        if (child.tag === 5) {
          var instance = child.stateNode;
          if (previousMeasurements !== null && viewTransitionHostInstanceIdx < previousMeasurements.length) {
            var previousMeasurement = previousMeasurements[viewTransitionHostInstanceIdx], nextMeasurement = measureInstance(instance);
            if (wasInstanceInViewport(previousMeasurement) || wasInstanceInViewport(nextMeasurement))
              inViewport = true;
            (parentViewTransition.flags & 4) === 0 && hasInstanceChanged(previousMeasurement, nextMeasurement) && (parentViewTransition.flags |= 4);
            hasInstanceAffectedParent(previousMeasurement, nextMeasurement) && (parentViewTransition.flags |= 32);
          } else
            parentViewTransition.flags |= 32;
          (parentViewTransition.flags & 4) !== 0 && applyViewTransitionName(instance, viewTransitionHostInstanceIdx === 0 ? newName : newName + "_" + viewTransitionHostInstanceIdx, className);
          inViewport && (parentViewTransition.flags & 4) !== 0 || (viewTransitionCancelableChildren === null && (viewTransitionCancelableChildren = []), viewTransitionCancelableChildren.push(instance, viewTransitionHostInstanceIdx === 0 ? oldName : oldName + "_" + viewTransitionHostInstanceIdx, child.memoizedProps));
          viewTransitionHostInstanceIdx++;
        } else if (child.tag !== 22 || child.memoizedState === null)
          child.tag === 30 && stopAtNestedViewTransitions ? parentViewTransition.flags |= child.flags & 32 : measureViewTransitionHostInstancesRecursive(parentViewTransition, child.child, newName, oldName, className, previousMeasurements, stopAtNestedViewTransitions) && (inViewport = true);
        child = child.sibling;
      }
      return inViewport;
    }
    function measureNestedViewTransitions(changedParent, gesture) {
      for (changedParent = changedParent.child;changedParent !== null; ) {
        if (changedParent.tag === 30) {
          var props = changedParent.memoizedProps, state = changedParent.stateNode, name = getViewTransitionName(props, state), className = getViewTransitionClassName(props.default, props.update);
          if (gesture) {
            state = state.clones;
            var previousMeasurements = state === null ? null : state.map(measureClonedInstance);
          } else
            previousMeasurements = changedParent.memoizedState, changedParent.memoizedState = null;
          state = changedParent;
          var child = changedParent.child;
          viewTransitionHostInstanceIdx = 0;
          name = measureViewTransitionHostInstancesRecursive(state, child, name, name, className, previousMeasurements, false);
          (changedParent.flags & 4) !== 0 && name && (gesture || scheduleViewTransitionEvent(changedParent, props.onUpdate));
        } else
          (changedParent.subtreeFlags & 33554432) !== 0 && measureNestedViewTransitions(changedParent, gesture);
        changedParent = changedParent.sibling;
      }
    }
    function commitBeforeMutationEffects(root, firstChild, committedLanes) {
      prepareForCommit(root.containerInfo);
      root = (committedLanes & 335544064) === committedLanes;
      nextEffect = firstChild;
      for (firstChild = root ? 9270 : 1024;nextEffect !== null; ) {
        committedLanes = nextEffect;
        if (root) {
          var deletions = committedLanes.deletions;
          if (deletions !== null)
            for (var i = 0;i < deletions.length; i++)
              root && commitExitViewTransitions(deletions[i]);
        }
        if (committedLanes.alternate === null && (committedLanes.flags & 2) !== 0)
          root && trackEnterViewTransitions(committedLanes), commitBeforeMutationEffects_complete(root);
        else {
          if (committedLanes.tag === 22) {
            if (deletions = committedLanes.alternate, committedLanes.memoizedState !== null) {
              deletions !== null && deletions.memoizedState === null && root && commitExitViewTransitions(deletions);
              commitBeforeMutationEffects_complete(root);
              continue;
            } else if (deletions !== null && deletions.memoizedState !== null) {
              root && trackEnterViewTransitions(committedLanes);
              commitBeforeMutationEffects_complete(root);
              continue;
            }
          }
          deletions = committedLanes.child;
          (committedLanes.subtreeFlags & firstChild) !== 0 && deletions !== null ? (deletions.return = committedLanes, nextEffect = deletions) : (root && commitNestedViewTransitions(committedLanes), commitBeforeMutationEffects_complete(root));
        }
      }
      appearingViewTransitions = null;
    }
    function commitBeforeMutationEffects_complete(isViewTransitionEligible$jscomp$0) {
      for (;nextEffect !== null; ) {
        var fiber = nextEffect, isViewTransitionEligible = isViewTransitionEligible$jscomp$0, { alternate: current, flags } = fiber;
        switch (fiber.tag) {
          case 0:
          case 11:
          case 15:
            break;
          case 1:
            if ((flags & 1024) !== 0 && current !== null) {
              isViewTransitionEligible = undefined;
              flags = current.memoizedProps;
              current = current.memoizedState;
              var instance = fiber.stateNode;
              try {
                var resolvedPrevProps = resolveClassComponentProps(fiber.type, flags);
                isViewTransitionEligible = instance.getSnapshotBeforeUpdate(resolvedPrevProps, current);
                instance.__reactInternalSnapshotBeforeUpdate = isViewTransitionEligible;
              } catch (error) {
                captureCommitPhaseError(fiber, fiber.return, error);
              }
            }
            break;
          case 3:
            (flags & 1024) !== 0 && supportsMutation && clearContainer(fiber.stateNode.containerInfo);
            break;
          case 5:
          case 26:
          case 27:
          case 6:
          case 4:
          case 17:
            break;
          case 30:
            isViewTransitionEligible && current !== null && (isViewTransitionEligible = getViewTransitionName(current.memoizedProps, current.stateNode), flags = fiber.memoizedProps, flags = getViewTransitionClassName(flags.default, flags.update), flags !== "none" && applyViewTransitionToHostInstances(current, isViewTransitionEligible, flags, current.memoizedState = [], true));
            break;
          default:
            if ((flags & 1024) !== 0)
              throw Error(formatProdErrorMessage(163));
        }
        current = fiber.sibling;
        if (current !== null) {
          current.return = fiber.return;
          nextEffect = current;
          break;
        }
        nextEffect = fiber.return;
      }
    }
    function commitLayoutEffectOnFiber(finishedRoot, current, finishedWork) {
      var flags = finishedWork.flags;
      switch (finishedWork.tag) {
        case 0:
        case 11:
        case 15:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          flags & 4 && commitHookEffectListMount(5, finishedWork);
          break;
        case 1:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          if (flags & 4)
            if (finishedRoot = finishedWork.stateNode, current === null)
              try {
                finishedRoot.componentDidMount();
              } catch (error) {
                captureCommitPhaseError(finishedWork, finishedWork.return, error);
              }
            else {
              var prevProps = resolveClassComponentProps(finishedWork.type, current.memoizedProps);
              current = current.memoizedState;
              try {
                finishedRoot.componentDidUpdate(prevProps, current, finishedRoot.__reactInternalSnapshotBeforeUpdate);
              } catch (error$128) {
                captureCommitPhaseError(finishedWork, finishedWork.return, error$128);
              }
            }
          flags & 64 && commitClassCallbacks(finishedWork);
          flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
          break;
        case 3:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          if (flags & 64 && (flags = finishedWork.updateQueue, flags !== null)) {
            finishedRoot = null;
            if (finishedWork.child !== null)
              switch (finishedWork.child.tag) {
                case 27:
                case 5:
                  finishedRoot = getPublicInstance(finishedWork.child.stateNode);
                  break;
                case 1:
                  finishedRoot = finishedWork.child.stateNode;
              }
            try {
              commitCallbacks(flags, finishedRoot);
            } catch (error) {
              captureCommitPhaseError(finishedWork, finishedWork.return, error);
            }
          }
          break;
        case 27:
          supportsSingletons && current === null && flags & 4 && commitHostSingletonAcquisition(finishedWork);
        case 26:
        case 5:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          if (current === null) {
            if (flags & 4)
              commitHostMount(finishedWork);
            else if (flags & 64) {
              finishedRoot = finishedWork.type;
              current = finishedWork.memoizedProps;
              prevProps = finishedWork.stateNode;
              try {
                commitHydratedInstance(prevProps, finishedRoot, current, finishedWork);
              } catch (error) {
                captureCommitPhaseError(finishedWork, finishedWork.return, error);
              }
            }
          }
          flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
          break;
        case 12:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          break;
        case 31:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          flags & 4 && commitActivityHydrationCallbacks(finishedRoot, finishedWork);
          break;
        case 13:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          flags & 4 && commitSuspenseHydrationCallbacks(finishedRoot, finishedWork);
          flags & 64 && (flags = finishedWork.memoizedState, flags !== null && (flags = flags.dehydrated, flags !== null && (finishedWork = retryDehydratedSuspenseBoundary.bind(null, finishedWork), registerSuspenseInstanceRetry(flags, finishedWork))));
          break;
        case 22:
          flags = finishedWork.memoizedState !== null || offscreenSubtreeIsHidden;
          if (!flags) {
            var newOffscreenSubtreeWasHidden = current !== null && current.memoizedState !== null || offscreenSubtreeWasHidden;
            current = offscreenSubtreeIsHidden;
            prevProps = offscreenSubtreeWasHidden;
            offscreenSubtreeIsHidden = flags;
            (offscreenSubtreeWasHidden = newOffscreenSubtreeWasHidden) && !prevProps ? (flags = supportsSingletons ? 2 : 0, (finishedWork.subtreeFlags & 8772) !== 0 && (flags |= 1), recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, flags)) : recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
            offscreenSubtreeIsHidden = current;
            offscreenSubtreeWasHidden = prevProps;
          }
          break;
        case 30:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
          flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
          break;
        case 7:
          flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
        default:
          recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
      }
    }
    function hideOrUnhideAllChildren(parentFiber, isHidden) {
      if (supportsMutation)
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          hideOrUnhideAllChildrenOnFiber(parentFiber, isHidden), parentFiber = parentFiber.sibling;
    }
    function hideOrUnhideAllChildrenOnFiber(fiber, isHidden) {
      if (supportsMutation)
        switch (fiber.tag) {
          case 5:
          case 26:
            try {
              var instance = fiber.stateNode;
              isHidden ? hideInstance(instance) : unhideInstance(fiber.stateNode, fiber.memoizedProps);
            } catch (error) {
              captureCommitPhaseError(fiber, fiber.return, error);
            }
            hideOrUnhideNearestPortals(fiber, isHidden);
            break;
          case 6:
            try {
              var instance$jscomp$0 = fiber.stateNode;
              isHidden ? hideTextInstance(instance$jscomp$0) : unhideTextInstance(instance$jscomp$0, fiber.memoizedProps);
              viewTransitionMutationContext = true;
            } catch (error) {
              captureCommitPhaseError(fiber, fiber.return, error);
            }
            break;
          case 18:
            try {
              var instance$jscomp$1 = fiber.stateNode;
              isHidden ? hideDehydratedBoundary(instance$jscomp$1) : unhideDehydratedBoundary(fiber.stateNode);
            } catch (error) {
              captureCommitPhaseError(fiber, fiber.return, error);
            }
            break;
          case 22:
          case 23:
            fiber.memoizedState === null && hideOrUnhideAllChildren(fiber, isHidden);
            break;
          default:
            hideOrUnhideAllChildren(fiber, isHidden);
        }
    }
    function hideOrUnhideNearestPortals(parentFiber, isHidden$jscomp$0) {
      if (supportsMutation && parentFiber.subtreeFlags & 67108864)
        for (parentFiber = parentFiber.child;parentFiber !== null; ) {
          var fiber = parentFiber, isHidden = isHidden$jscomp$0;
          if (supportsMutation)
            switch (fiber.tag) {
              case 4:
                hideOrUnhideAllChildrenOnFiber(fiber, isHidden);
                break;
              case 22:
                fiber.memoizedState === null && hideOrUnhideNearestPortals(fiber, isHidden);
                break;
              default:
                hideOrUnhideNearestPortals(fiber, isHidden);
            }
          parentFiber = parentFiber.sibling;
        }
    }
    function detachFiberAfterEffects(fiber) {
      var alternate = fiber.alternate;
      alternate !== null && (fiber.alternate = null, detachFiberAfterEffects(alternate));
      fiber.child = null;
      fiber.deletions = null;
      fiber.sibling = null;
      fiber.tag === 5 && (alternate = fiber.stateNode, alternate !== null && detachDeletedInstance(alternate));
      fiber.stateNode = null;
      fiber.return = null;
      fiber.dependencies = null;
      fiber.memoizedProps = null;
      fiber.memoizedState = null;
      fiber.pendingProps = null;
      fiber.stateNode = null;
      fiber.updateQueue = null;
    }
    function recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, parent) {
      for (parent = parent.child;parent !== null; )
        commitDeletionEffectsOnFiber(finishedRoot, nearestMountedAncestor, parent), parent = parent.sibling;
    }
    function commitDeletionEffectsOnFiber(finishedRoot, nearestMountedAncestor, deletedFiber) {
      if (injectedHook && typeof injectedHook.onCommitFiberUnmount === "function")
        try {
          injectedHook.onCommitFiberUnmount(rendererID, deletedFiber);
        } catch (err) {}
      switch (deletedFiber.tag) {
        case 26:
          if (supportsResources) {
            offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor);
            recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
            deletedFiber.memoizedState ? releaseResource(deletedFiber.memoizedState) : deletedFiber.stateNode && (offscreenSubtreeWasHidden || unmountHoistable(deletedFiber.stateNode));
            break;
          }
        case 27:
          if (supportsSingletons) {
            offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor);
            commitFragmentInstanceDeletionEffects(deletedFiber);
            var prevHostParent = hostParent, prevHostParentIsContainer = hostParentIsContainer;
            isSingletonScope(deletedFiber.type) && (hostParent = deletedFiber.stateNode, hostParentIsContainer = false);
            recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
            releaseSingletonInstance(deletedFiber.stateNode, deletedFiber.type, deletedFiber.memoizedProps);
            hostParent = prevHostParent;
            hostParentIsContainer = prevHostParentIsContainer;
            break;
          }
        case 5:
          offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor), commitFragmentInstanceDeletionEffects(deletedFiber);
        case 6:
          deletedFiber.tag === 6 && commitFragmentInstanceDeletionEffects(deletedFiber);
          if (supportsMutation) {
            if (prevHostParent = hostParent, prevHostParentIsContainer = hostParentIsContainer, hostParent = null, recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber), hostParent = prevHostParent, hostParentIsContainer = prevHostParentIsContainer, hostParent !== null)
              if (hostParentIsContainer)
                try {
                  removeChildFromContainer(hostParent, deletedFiber.stateNode), viewTransitionMutationContext = true;
                } catch (error) {
                  captureCommitPhaseError(deletedFiber, nearestMountedAncestor, error);
                }
              else
                try {
                  removeChild(hostParent, deletedFiber.stateNode), viewTransitionMutationContext = true;
                } catch (error) {
                  captureCommitPhaseError(deletedFiber, nearestMountedAncestor, error);
                }
          } else
            recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          break;
        case 18:
          supportsMutation && hostParent !== null && (hostParentIsContainer ? clearSuspenseBoundaryFromContainer(hostParent, deletedFiber.stateNode) : clearSuspenseBoundary(hostParent, deletedFiber.stateNode));
          break;
        case 4:
          supportsMutation ? (prevHostParent = hostParent, prevHostParentIsContainer = hostParentIsContainer, hostParent = deletedFiber.stateNode.containerInfo, hostParentIsContainer = true, recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber), hostParent = prevHostParent, hostParentIsContainer = prevHostParentIsContainer) : (supportsPersistence && commitHostPortalContainerChildren(deletedFiber.stateNode, deletedFiber, createContainerChildSet()), recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber));
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          commitHookEffectListUnmount(2, deletedFiber, nearestMountedAncestor);
          offscreenSubtreeWasHidden || commitHookEffectListUnmount(4, deletedFiber, nearestMountedAncestor);
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          break;
        case 1:
          offscreenSubtreeWasHidden || (safelyDetachRef(deletedFiber, nearestMountedAncestor), prevHostParent = deletedFiber.stateNode, typeof prevHostParent.componentWillUnmount === "function" && safelyCallComponentWillUnmount(deletedFiber, nearestMountedAncestor, prevHostParent));
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          break;
        case 21:
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          break;
        case 22:
          offscreenSubtreeWasHidden = (prevHostParent = offscreenSubtreeWasHidden) || deletedFiber.memoizedState !== null;
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          offscreenSubtreeWasHidden = prevHostParent;
          break;
        case 30:
          safelyDetachRef(deletedFiber, nearestMountedAncestor);
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          break;
        case 7:
          offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor);
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
          break;
        default:
          recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
      }
    }
    function commitActivityHydrationCallbacks(finishedRoot, finishedWork) {
      if (supportsHydration && finishedWork.memoizedState === null && (finishedRoot = finishedWork.alternate, finishedRoot !== null && (finishedRoot = finishedRoot.memoizedState, finishedRoot !== null))) {
        finishedRoot = finishedRoot.dehydrated;
        try {
          commitHydratedActivityInstance(finishedRoot);
        } catch (error) {
          captureCommitPhaseError(finishedWork, finishedWork.return, error);
        }
      }
    }
    function commitSuspenseHydrationCallbacks(finishedRoot, finishedWork) {
      if (supportsHydration && finishedWork.memoizedState === null && (finishedRoot = finishedWork.alternate, finishedRoot !== null && (finishedRoot = finishedRoot.memoizedState, finishedRoot !== null && (finishedRoot = finishedRoot.dehydrated, finishedRoot !== null))))
        try {
          commitHydratedSuspenseInstance(finishedRoot);
        } catch (error) {
          captureCommitPhaseError(finishedWork, finishedWork.return, error);
        }
    }
    function getRetryCache(finishedWork) {
      switch (finishedWork.tag) {
        case 31:
        case 13:
        case 19:
          var retryCache = finishedWork.stateNode;
          retryCache === null && (retryCache = finishedWork.stateNode = new PossiblyWeakSet);
          return retryCache;
        case 22:
          return finishedWork = finishedWork.stateNode, retryCache = finishedWork._retryCache, retryCache === null && (retryCache = finishedWork._retryCache = new PossiblyWeakSet), retryCache;
        default:
          throw Error(formatProdErrorMessage(435, finishedWork.tag));
      }
    }
    function attachSuspenseRetryListeners(finishedWork, wakeables) {
      var retryCache = getRetryCache(finishedWork);
      wakeables.forEach(function(wakeable) {
        if (!retryCache.has(wakeable)) {
          retryCache.add(wakeable);
          var retry = resolveRetryWakeable.bind(null, finishedWork, wakeable);
          wakeable.then(retry, retry);
        }
      });
    }
    function recursivelyTraverseMutationEffects(root$jscomp$0, parentFiber, lanes) {
      var deletions = parentFiber.deletions;
      if (deletions !== null)
        for (var i = 0;i < deletions.length; i++) {
          var childToDelete = deletions[i], root = root$jscomp$0, returnFiber = parentFiber;
          if (supportsMutation) {
            var parent = returnFiber;
            a:
              for (;parent !== null; ) {
                switch (parent.tag) {
                  case 27:
                    if (supportsSingletons) {
                      if (isSingletonScope(parent.type)) {
                        hostParent = parent.stateNode;
                        hostParentIsContainer = false;
                        break a;
                      }
                      break;
                    }
                  case 5:
                    hostParent = parent.stateNode;
                    hostParentIsContainer = false;
                    break a;
                  case 3:
                  case 4:
                    hostParent = parent.stateNode.containerInfo;
                    hostParentIsContainer = true;
                    break a;
                }
                parent = parent.return;
              }
            if (hostParent === null)
              throw Error(formatProdErrorMessage(160));
            commitDeletionEffectsOnFiber(root, returnFiber, childToDelete);
            hostParent = null;
            hostParentIsContainer = false;
          } else
            commitDeletionEffectsOnFiber(root, returnFiber, childToDelete);
          root = childToDelete.alternate;
          root !== null && (root.return = null);
          childToDelete.return = null;
        }
      if (parentFiber.subtreeFlags & 13886)
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          commitMutationEffectsOnFiber(parentFiber, root$jscomp$0, lanes), parentFiber = parentFiber.sibling;
    }
    function commitMutationEffectsOnFiber(finishedWork, root, lanes) {
      var current = finishedWork.alternate, flags = finishedWork.flags;
      switch (finishedWork.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          if (flags & 4 && (current = finishedWork.updateQueue, current = current !== null ? current.events : null, current !== null))
            for (var ii = 0;ii < current.length; ii++) {
              var _eventPayloads$ii2 = current[ii];
              _eventPayloads$ii2.ref.impl = _eventPayloads$ii2.nextImpl;
            }
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          flags & 4 && (commitHookEffectListUnmount(3, finishedWork, finishedWork.return), commitHookEffectListMount(3, finishedWork), commitHookEffectListUnmount(5, finishedWork, finishedWork.return));
          break;
        case 1:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          flags & 512 && (offscreenSubtreeWasHidden || current === null || safelyDetachRef(current, current.return));
          flags & 64 && offscreenSubtreeIsHidden && (finishedWork = finishedWork.updateQueue, finishedWork !== null && (root = finishedWork.callbacks, root !== null && (flags = finishedWork.shared.hiddenCallbacks, finishedWork.shared.hiddenCallbacks = flags === null ? root : flags.concat(root))));
          break;
        case 26:
          if (supportsResources) {
            ii = currentHoistableRoot;
            recursivelyTraverseMutationEffects(root, finishedWork, lanes);
            commitReconciliationEffects(finishedWork);
            flags & 512 && (offscreenSubtreeWasHidden || current === null || safelyDetachRef(current, current.return));
            flags & 4 && (lanes = current !== null ? current.memoizedState : null, flags = finishedWork.memoizedState, current === null ? flags === null ? finishedWork.stateNode === null ? finishedWork.stateNode = offscreenSubtreeIsHidden ? createHoistableInstance(finishedWork.type, finishedWork.memoizedProps, root.containerInfo, finishedWork) : hydrateHoistable(ii, finishedWork.type, finishedWork.memoizedProps, finishedWork) : offscreenSubtreeIsHidden || mountHoistable(ii, finishedWork.type, finishedWork.stateNode) : finishedWork.stateNode = acquireResource(ii, flags, finishedWork.memoizedProps) : lanes !== flags ? (lanes === null ? (root = current.stateNode, root === null || offscreenSubtreeWasHidden || unmountHoistable(root)) : releaseResource(lanes), flags === null ? offscreenSubtreeIsHidden || mountHoistable(ii, finishedWork.type, finishedWork.stateNode) : acquireResource(ii, flags, finishedWork.memoizedProps)) : flags === null && finishedWork.stateNode !== null && commitHostUpdate(finishedWork, finishedWork.memoizedProps, current.memoizedProps));
            break;
          }
        case 27:
          if (supportsSingletons) {
            recursivelyTraverseMutationEffects(root, finishedWork, lanes);
            commitReconciliationEffects(finishedWork);
            flags & 512 && (offscreenSubtreeWasHidden || current === null || safelyDetachRef(current, current.return));
            current !== null && flags & 4 && commitHostUpdate(finishedWork, finishedWork.memoizedProps, current.memoizedProps);
            break;
          }
        case 5:
          ii = offscreenDirectParentIsHidden;
          offscreenDirectParentIsHidden = false;
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          offscreenDirectParentIsHidden = ii;
          commitReconciliationEffects(finishedWork);
          flags & 512 && (offscreenSubtreeWasHidden || current === null || safelyDetachRef(current, current.return));
          if (supportsMutation) {
            if (finishedWork.flags & 32) {
              root = finishedWork.stateNode;
              try {
                resetTextContent(root), viewTransitionMutationContext = true;
              } catch (error) {
                captureCommitPhaseError(finishedWork, finishedWork.return, error);
              }
            }
            flags & 4 && finishedWork.stateNode != null && (root = finishedWork.memoizedProps, commitHostUpdate(finishedWork, root, current !== null ? current.memoizedProps : root));
            flags & 1024 && (needsFormReset = true);
          } else
            supportsPersistence && finishedWork.alternate !== null && (finishedWork.alternate.stateNode = finishedWork.stateNode);
          break;
        case 6:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          if (flags & 4 && supportsMutation) {
            if (finishedWork.stateNode === null)
              throw Error(formatProdErrorMessage(162));
            root = finishedWork.memoizedProps;
            flags = current !== null ? current.memoizedProps : root;
            lanes = finishedWork.stateNode;
            try {
              commitTextUpdate(lanes, flags, root), viewTransitionMutationContext = true;
            } catch (error) {
              captureCommitPhaseError(finishedWork, finishedWork.return, error);
            }
          }
          break;
        case 3:
          viewTransitionMutationContext = false;
          supportsResources ? (prepareToCommitHoistables(), ii = currentHoistableRoot, currentHoistableRoot = getHoistableRoot(root.containerInfo), recursivelyTraverseMutationEffects(root, finishedWork, lanes), currentHoistableRoot = ii) : recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          if (flags & 4) {
            if (supportsMutation && supportsHydration && current !== null && current.memoizedState.isDehydrated)
              try {
                commitHydratedContainer(root.containerInfo);
              } catch (error) {
                captureCommitPhaseError(finishedWork, finishedWork.return, error);
              }
            if (supportsPersistence) {
              flags = root.containerInfo;
              root = root.pendingChildren;
              try {
                replaceContainerChildren(flags, root), viewTransitionMutationContext = true;
              } catch (error) {
                captureCommitPhaseError(finishedWork, finishedWork.return, error);
              }
            }
          }
          needsFormReset && (needsFormReset = false, recursivelyResetForms(finishedWork));
          viewTransitionMutationContext = false;
          break;
        case 4:
          current = offscreenDirectParentIsHidden;
          offscreenDirectParentIsHidden = offscreenSubtreeIsHidden;
          ii = pushMutationContext();
          supportsResources ? (_eventPayloads$ii2 = currentHoistableRoot, currentHoistableRoot = getHoistableRoot(finishedWork.stateNode.containerInfo), recursivelyTraverseMutationEffects(root, finishedWork, lanes), commitReconciliationEffects(finishedWork), currentHoistableRoot = _eventPayloads$ii2) : (recursivelyTraverseMutationEffects(root, finishedWork, lanes), commitReconciliationEffects(finishedWork));
          viewTransitionMutationContext && inUpdateViewTransition && (rootViewTransitionAffected = true);
          viewTransitionMutationContext = ii;
          offscreenDirectParentIsHidden = current;
          flags & 4 && supportsPersistence && commitHostPortalContainerChildren(finishedWork.stateNode, finishedWork, finishedWork.stateNode.pendingChildren);
          break;
        case 12:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          break;
        case 31:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          flags & 4 && (root = finishedWork.updateQueue, root !== null && (finishedWork.updateQueue = null, attachSuspenseRetryListeners(finishedWork, root)));
          break;
        case 13:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          finishedWork.child.flags & 8192 && finishedWork.memoizedState !== null !== (current !== null && current.memoizedState !== null) && (globalMostRecentFallbackTime = now());
          flags & 4 && (root = finishedWork.updateQueue, root !== null && (finishedWork.updateQueue = null, attachSuspenseRetryListeners(finishedWork, root)));
          break;
        case 22:
          ii = finishedWork.memoizedState !== null;
          _eventPayloads$ii2 = current !== null && current.memoizedState !== null;
          var prevOffscreenSubtreeIsHidden = offscreenSubtreeIsHidden, prevOffscreenSubtreeWasHidden = offscreenSubtreeWasHidden, prevOffscreenDirectParentIsHidden$147 = offscreenDirectParentIsHidden;
          offscreenSubtreeIsHidden = prevOffscreenSubtreeIsHidden || ii;
          offscreenDirectParentIsHidden = prevOffscreenDirectParentIsHidden$147 || ii;
          offscreenSubtreeWasHidden = prevOffscreenSubtreeWasHidden || _eventPayloads$ii2;
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          offscreenSubtreeWasHidden = prevOffscreenSubtreeWasHidden;
          offscreenDirectParentIsHidden = prevOffscreenDirectParentIsHidden$147;
          offscreenSubtreeIsHidden = prevOffscreenSubtreeIsHidden;
          commitReconciliationEffects(finishedWork);
          flags & 8192 && (root = finishedWork.stateNode, root._visibility = ii ? root._visibility & -2 : root._visibility | 1, !ii || current === null || _eventPayloads$ii2 || offscreenSubtreeIsHidden || offscreenSubtreeWasHidden || (root = supportsSingletons ? 2 : 0, lanes = _eventPayloads$ii2 || offscreenSubtreeWasHidden, current = offscreenSubtreeIsHidden, _eventPayloads$ii2 = offscreenSubtreeWasHidden, offscreenSubtreeIsHidden = ii || offscreenSubtreeIsHidden, offscreenSubtreeWasHidden = lanes, recursivelyTraverseDisappearLayoutEffects(finishedWork, root), offscreenSubtreeIsHidden = current, offscreenSubtreeWasHidden = _eventPayloads$ii2), supportsMutation && (ii || !offscreenDirectParentIsHidden) && hideOrUnhideAllChildren(finishedWork, ii));
          flags & 4 && (root = finishedWork.updateQueue, root !== null && (flags = root.retryQueue, flags !== null && (root.retryQueue = null, attachSuspenseRetryListeners(finishedWork, flags))));
          break;
        case 19:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          flags & 4 && (root = finishedWork.updateQueue, root !== null && (finishedWork.updateQueue = null, attachSuspenseRetryListeners(finishedWork, root)));
          break;
        case 30:
          flags & 512 && (offscreenSubtreeWasHidden || current === null || safelyDetachRef(current, current.return));
          flags = pushMutationContext();
          ii = inUpdateViewTransition;
          _eventPayloads$ii2 = (lanes & 335544064) === lanes;
          prevOffscreenSubtreeIsHidden = finishedWork.memoizedProps;
          inUpdateViewTransition = _eventPayloads$ii2 && getViewTransitionClassName(prevOffscreenSubtreeIsHidden.default, prevOffscreenSubtreeIsHidden.update) !== "none";
          recursivelyTraverseMutationEffects(root, finishedWork, lanes);
          commitReconciliationEffects(finishedWork);
          _eventPayloads$ii2 && current !== null && viewTransitionMutationContext && (finishedWork.flags |= 4);
          inUpdateViewTransition = ii;
          viewTransitionMutationContext = flags;
          break;
        case 21:
          break;
        case 7:
          flags & 512 && (offscreenSubtreeWasHidden || current === null || safelyDetachRef(current, current.return)), current && current.stateNode !== null && updateFragmentInstanceFiber(finishedWork, current.stateNode);
        default:
          recursivelyTraverseMutationEffects(root, finishedWork, lanes), commitReconciliationEffects(finishedWork);
      }
    }
    function commitReconciliationEffects(finishedWork) {
      var flags = finishedWork.flags;
      if (flags & 2) {
        try {
          for (var hostParentFiber, parentFiber = finishedWork.return;parentFiber !== null; ) {
            if (isHostParent(parentFiber)) {
              hostParentFiber = parentFiber;
              break;
            }
            parentFiber = parentFiber.return;
          }
          parentFiber = null;
          for (var parent = finishedWork.return;parent !== null; ) {
            if (isFragmentInstanceParent(parent)) {
              var fragmentInstance = parent.stateNode;
              parentFiber === null ? parentFiber = [fragmentInstance] : parentFiber.push(fragmentInstance);
            }
            if (isFragmentInstanceHostBoundary(parent))
              break;
            parent = parent.return;
          }
          var JSCompiler_inline_result = parentFiber;
          if (supportsMutation) {
            if (hostParentFiber == null)
              throw Error(formatProdErrorMessage(160));
            switch (hostParentFiber.tag) {
              case 27:
                if (supportsSingletons) {
                  var parent$jscomp$0 = hostParentFiber.stateNode, before = getHostSibling(finishedWork);
                  insertOrAppendPlacementNode(finishedWork, before, parent$jscomp$0, JSCompiler_inline_result);
                  break;
                }
              case 5:
                var parent$131 = hostParentFiber.stateNode;
                hostParentFiber.flags & 32 && (resetTextContent(parent$131), hostParentFiber.flags &= -33);
                var before$132 = getHostSibling(finishedWork);
                insertOrAppendPlacementNode(finishedWork, before$132, parent$131, JSCompiler_inline_result);
                break;
              case 3:
              case 4:
                var parent$133 = hostParentFiber.stateNode.containerInfo, before$134 = getHostSibling(finishedWork);
                insertOrAppendPlacementNodeIntoContainer(finishedWork, before$134, parent$133, JSCompiler_inline_result);
                break;
              default:
                throw Error(formatProdErrorMessage(161));
            }
          } else
            commitImmutablePlacementNodeToFragmentInstances(finishedWork, JSCompiler_inline_result);
        } catch (error) {
          captureCommitPhaseError(finishedWork, finishedWork.return, error);
        }
        finishedWork.flags &= -3;
      }
      flags & 4096 && (finishedWork.flags &= -4097);
    }
    function recursivelyResetForms(parentFiber) {
      if (parentFiber.subtreeFlags & 1024)
        for (parentFiber = parentFiber.child;parentFiber !== null; ) {
          var fiber = parentFiber;
          recursivelyResetForms(fiber);
          fiber.tag === 5 && fiber.flags & 1024 && resetFormInstance(fiber.stateNode);
          parentFiber = parentFiber.sibling;
        }
    }
    function recursivelyTraverseAfterMutationEffects(root, parentFiber) {
      if (parentFiber.subtreeFlags & 9270)
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          commitAfterMutationEffectsOnFiber(parentFiber, root), parentFiber = parentFiber.sibling;
      else
        measureNestedViewTransitions(parentFiber, false);
    }
    function commitAfterMutationEffectsOnFiber(finishedWork, root) {
      var current = finishedWork.alternate;
      if (current === null)
        commitEnterViewTransitions(finishedWork, false);
      else
        switch (finishedWork.tag) {
          case 3:
            rootViewTransitionNameCanceled = viewTransitionContextChanged = false;
            pushViewTransitionCancelableScope();
            recursivelyTraverseAfterMutationEffects(root, finishedWork);
            if (!viewTransitionContextChanged && !rootViewTransitionAffected) {
              finishedWork = viewTransitionCancelableChildren;
              if (finishedWork !== null)
                for (var i = 0;i < finishedWork.length; i += 3)
                  cancelViewTransitionName(finishedWork[i], finishedWork[i + 1], finishedWork[i + 2]);
              cancelRootViewTransitionName(root.containerInfo);
              rootViewTransitionNameCanceled = true;
            }
            viewTransitionCancelableChildren = null;
            break;
          case 5:
            recursivelyTraverseAfterMutationEffects(root, finishedWork);
            break;
          case 4:
            i = viewTransitionContextChanged;
            viewTransitionContextChanged = false;
            recursivelyTraverseAfterMutationEffects(root, finishedWork);
            viewTransitionContextChanged && (rootViewTransitionAffected = true);
            viewTransitionContextChanged = i;
            break;
          case 22:
            finishedWork.memoizedState === null && (current.memoizedState !== null ? commitEnterViewTransitions(finishedWork, false) : recursivelyTraverseAfterMutationEffects(root, finishedWork));
            break;
          case 30:
            i = viewTransitionContextChanged;
            var prevCancelableChildren = pushViewTransitionCancelableScope();
            viewTransitionContextChanged = false;
            recursivelyTraverseAfterMutationEffects(root, finishedWork);
            viewTransitionContextChanged && (finishedWork.flags |= 4);
            var props = finishedWork.memoizedProps, state = finishedWork.stateNode;
            root = getViewTransitionName(props, state);
            state = getViewTransitionName(current.memoizedProps, state);
            var className = getViewTransitionClassName(props.default, props.update);
            className === "none" ? current = false : (props = current.memoizedState, current.memoizedState = null, current = finishedWork.child, viewTransitionHostInstanceIdx = 0, current = measureViewTransitionHostInstancesRecursive(finishedWork, current, root, state, className, props, true), viewTransitionHostInstanceIdx !== (props === null ? 0 : props.length) && (finishedWork.flags |= 32));
            (finishedWork.flags & 4) !== 0 && current ? (scheduleViewTransitionEvent(finishedWork, finishedWork.memoizedProps.onUpdate), viewTransitionCancelableChildren = prevCancelableChildren) : prevCancelableChildren !== null && (prevCancelableChildren.push.apply(prevCancelableChildren, viewTransitionCancelableChildren), viewTransitionCancelableChildren = prevCancelableChildren);
            viewTransitionContextChanged = (finishedWork.flags & 32) !== 0 ? true : i;
            break;
          default:
            recursivelyTraverseAfterMutationEffects(root, finishedWork);
        }
    }
    function recursivelyTraverseLayoutEffects(root, parentFiber) {
      if (parentFiber.subtreeFlags & 8772)
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          commitLayoutEffectOnFiber(root, parentFiber.alternate, parentFiber), parentFiber = parentFiber.sibling;
    }
    function recursivelyTraverseDisappearLayoutEffects(parentFiber, layoutEffectTraversalFlags$jscomp$0) {
      for (parentFiber = parentFiber.child;parentFiber !== null; ) {
        var finishedWork = parentFiber, layoutEffectTraversalFlags = layoutEffectTraversalFlags$jscomp$0;
        switch (finishedWork.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            commitHookEffectListUnmount(4, finishedWork, finishedWork.return);
            recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
            break;
          case 1:
            safelyDetachRef(finishedWork, finishedWork.return);
            var instance = finishedWork.stateNode;
            typeof instance.componentWillUnmount === "function" && safelyCallComponentWillUnmount(finishedWork, finishedWork.return, instance);
            recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
            break;
          case 27:
            supportsSingletons && (layoutEffectTraversalFlags & 2) !== 0 && releaseSingletonInstance(finishedWork.stateNode, finishedWork.type, finishedWork.memoizedProps);
          case 5:
            safelyDetachRef(finishedWork, finishedWork.return);
            finishedWork.tag !== 5 && finishedWork.tag !== 27 || commitFragmentInstanceDeletionEffects(finishedWork);
            recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
            break;
          case 6:
            commitFragmentInstanceDeletionEffects(finishedWork);
            break;
          case 26:
            safelyDetachRef(finishedWork, finishedWork.return);
            supportsResources && (instance = finishedWork.stateNode, finishedWork.memoizedState !== null || instance === null || offscreenSubtreeWasHidden || unmountHoistable(instance));
            recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
            break;
          case 22:
            finishedWork.memoizedState === null && recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
            break;
          case 30:
            safelyDetachRef(finishedWork, finishedWork.return);
            recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
            break;
          case 7:
            safelyDetachRef(finishedWork, finishedWork.return);
          default:
            recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
        }
        parentFiber = parentFiber.sibling;
      }
    }
    function recursivelyTraverseReappearLayoutEffects(finishedRoot$jscomp$0, parentFiber, layoutEffectTraversalFlags) {
      layoutEffectTraversalFlags = (parentFiber.subtreeFlags & 8772) !== 0 ? layoutEffectTraversalFlags : layoutEffectTraversalFlags & -2;
      for (parentFiber = parentFiber.child;parentFiber !== null; ) {
        var current = parentFiber.alternate, finishedRoot = finishedRoot$jscomp$0, finishedWork = parentFiber, flags = finishedWork.flags, includeWorkInProgressEffects = (layoutEffectTraversalFlags & 1) !== 0;
        switch (finishedWork.tag) {
          case 0:
          case 11:
          case 15:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            commitHookEffectListMount(4, finishedWork);
            break;
          case 1:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            current = finishedWork;
            finishedRoot = current.stateNode;
            if (typeof finishedRoot.componentDidMount === "function")
              try {
                finishedRoot.componentDidMount();
              } catch (error) {
                captureCommitPhaseError(current, current.return, error);
              }
            current = finishedWork;
            finishedRoot = current.updateQueue;
            if (finishedRoot !== null) {
              var instance = current.stateNode;
              try {
                var hiddenCallbacks = finishedRoot.shared.hiddenCallbacks;
                if (hiddenCallbacks !== null)
                  for (finishedRoot.shared.hiddenCallbacks = null, finishedRoot = 0;finishedRoot < hiddenCallbacks.length; finishedRoot++)
                    callCallback(hiddenCallbacks[finishedRoot], instance);
              } catch (error) {
                captureCommitPhaseError(current, current.return, error);
              }
            }
            includeWorkInProgressEffects && flags & 64 && commitClassCallbacks(finishedWork);
            safelyAttachRef(finishedWork, finishedWork.return);
            break;
          case 27:
            supportsSingletons && (layoutEffectTraversalFlags & 2) !== 0 && commitHostSingletonAcquisition(finishedWork);
          case 5:
            finishedWork.tag !== 5 && finishedWork.tag !== 27 || commitFragmentInstanceInsertionEffects(finishedWork);
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            includeWorkInProgressEffects && current === null && flags & 4 && commitHostMount(finishedWork);
            safelyAttachRef(finishedWork, finishedWork.return);
            break;
          case 6:
            commitFragmentInstanceInsertionEffects(finishedWork);
            break;
          case 26:
            supportsResources && (instance = finishedWork.stateNode, finishedWork.memoizedState !== null || instance === null || offscreenSubtreeIsHidden || mountHoistable(getHoistableRoot(instance.ownerDocument), finishedWork.type, instance));
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            includeWorkInProgressEffects && current === null && flags & 4 && commitHostMount(finishedWork);
            safelyAttachRef(finishedWork, finishedWork.return);
            break;
          case 12:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            break;
          case 31:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            includeWorkInProgressEffects && flags & 4 && commitActivityHydrationCallbacks(finishedRoot, finishedWork);
            break;
          case 13:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            includeWorkInProgressEffects && flags & 4 && commitSuspenseHydrationCallbacks(finishedRoot, finishedWork);
            break;
          case 22:
            finishedWork.memoizedState === null && recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            safelyAttachRef(finishedWork, finishedWork.return);
            break;
          case 30:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
            safelyAttachRef(finishedWork, finishedWork.return);
            break;
          case 7:
            safelyAttachRef(finishedWork, finishedWork.return);
          default:
            recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
        }
        parentFiber = parentFiber.sibling;
      }
    }
    function commitOffscreenPassiveMountEffects(current, finishedWork) {
      var previousCache = null;
      current !== null && current.memoizedState !== null && current.memoizedState.cachePool !== null && (previousCache = current.memoizedState.cachePool.pool);
      current = null;
      finishedWork.memoizedState !== null && finishedWork.memoizedState.cachePool !== null && (current = finishedWork.memoizedState.cachePool.pool);
      current !== previousCache && (current != null && current.refCount++, previousCache != null && releaseCache(previousCache));
    }
    function commitCachePassiveMountEffect(current, finishedWork) {
      current = null;
      finishedWork.alternate !== null && (current = finishedWork.alternate.memoizedState.cache);
      finishedWork = finishedWork.memoizedState.cache;
      finishedWork !== current && (finishedWork.refCount++, current != null && releaseCache(current));
    }
    function recursivelyTraversePassiveMountEffects(root, parentFiber, committedLanes, committedTransitions) {
      var isViewTransitionEligible = (committedLanes & 335544064) === committedLanes;
      if (parentFiber.subtreeFlags & (isViewTransitionEligible ? 10262 : 10256))
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          commitPassiveMountOnFiber(root, parentFiber, committedLanes, committedTransitions), parentFiber = parentFiber.sibling;
      else
        isViewTransitionEligible && restoreNestedViewTransitions(parentFiber);
    }
    function commitPassiveMountOnFiber(finishedRoot, finishedWork, committedLanes, committedTransitions) {
      var isViewTransitionEligible = (committedLanes & 335544064) === committedLanes;
      isViewTransitionEligible && finishedWork.alternate === null && finishedWork.return !== null && finishedWork.return.alternate !== null && restoreEnterOrExitViewTransitions(finishedWork);
      var flags = finishedWork.flags;
      switch (finishedWork.tag) {
        case 0:
        case 11:
        case 15:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          flags & 2048 && commitHookEffectListMount(9, finishedWork);
          break;
        case 1:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          break;
        case 3:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          isViewTransitionEligible && supportsMutation && rootViewTransitionNameCanceled && restoreRootViewTransitionName(finishedRoot.containerInfo);
          flags & 2048 && (finishedRoot = null, finishedWork.alternate !== null && (finishedRoot = finishedWork.alternate.memoizedState.cache), finishedWork = finishedWork.memoizedState.cache, finishedWork !== finishedRoot && (finishedWork.refCount++, finishedRoot != null && releaseCache(finishedRoot)));
          break;
        case 12:
          if (flags & 2048) {
            recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
            finishedRoot = finishedWork.stateNode;
            try {
              var _finishedWork$memoize2 = finishedWork.memoizedProps, id = _finishedWork$memoize2.id, onPostCommit = _finishedWork$memoize2.onPostCommit;
              typeof onPostCommit === "function" && onPostCommit(id, finishedWork.alternate === null ? "mount" : "update", finishedRoot.passiveEffectDuration, -0);
            } catch (error) {
              captureCommitPhaseError(finishedWork, finishedWork.return, error);
            }
          } else
            recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          break;
        case 31:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          break;
        case 13:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          break;
        case 23:
          break;
        case 22:
          _finishedWork$memoize2 = finishedWork.stateNode;
          id = finishedWork.alternate;
          finishedWork.memoizedState !== null ? (isViewTransitionEligible && id !== null && id.memoizedState === null && restoreEnterOrExitViewTransitions(id), _finishedWork$memoize2._visibility & 2 ? recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions) : recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork)) : (isViewTransitionEligible && id !== null && id.memoizedState !== null && restoreEnterOrExitViewTransitions(finishedWork), _finishedWork$memoize2._visibility & 2 ? recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions) : (_finishedWork$memoize2._visibility |= 2, recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, (finishedWork.subtreeFlags & 10256) !== 0 || false)));
          flags & 2048 && commitOffscreenPassiveMountEffects(id, finishedWork);
          break;
        case 24:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          flags & 2048 && commitCachePassiveMountEffect(finishedWork.alternate, finishedWork);
          break;
        case 30:
          isViewTransitionEligible && (isViewTransitionEligible = finishedWork.alternate, isViewTransitionEligible !== null && (restoreViewTransitionOnHostInstances(isViewTransitionEligible.child, true), restoreViewTransitionOnHostInstances(finishedWork.child, true)));
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
          break;
        default:
          recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
      }
    }
    function recursivelyTraverseReconnectPassiveEffects(finishedRoot$jscomp$0, parentFiber, committedLanes$jscomp$0, committedTransitions$jscomp$0, includeWorkInProgressEffects) {
      includeWorkInProgressEffects = includeWorkInProgressEffects && ((parentFiber.subtreeFlags & 10256) !== 0 || false);
      for (parentFiber = parentFiber.child;parentFiber !== null; ) {
        var finishedRoot = finishedRoot$jscomp$0, finishedWork = parentFiber, committedLanes = committedLanes$jscomp$0, committedTransitions = committedTransitions$jscomp$0, flags = finishedWork.flags;
        switch (finishedWork.tag) {
          case 0:
          case 11:
          case 15:
            recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects);
            commitHookEffectListMount(8, finishedWork);
            break;
          case 23:
            break;
          case 22:
            var instance = finishedWork.stateNode;
            finishedWork.memoizedState !== null ? instance._visibility & 2 ? recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects) : recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork) : (instance._visibility |= 2, recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects));
            includeWorkInProgressEffects && flags & 2048 && commitOffscreenPassiveMountEffects(finishedWork.alternate, finishedWork);
            break;
          case 24:
            recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects);
            includeWorkInProgressEffects && flags & 2048 && commitCachePassiveMountEffect(finishedWork.alternate, finishedWork);
            break;
          default:
            recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects);
        }
        parentFiber = parentFiber.sibling;
      }
    }
    function recursivelyTraverseAtomicPassiveEffects(finishedRoot$jscomp$0, parentFiber) {
      if (parentFiber.subtreeFlags & 10256)
        for (parentFiber = parentFiber.child;parentFiber !== null; ) {
          var finishedRoot = finishedRoot$jscomp$0, finishedWork = parentFiber, flags = finishedWork.flags;
          switch (finishedWork.tag) {
            case 22:
              recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork);
              flags & 2048 && commitOffscreenPassiveMountEffects(finishedWork.alternate, finishedWork);
              break;
            case 24:
              recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork);
              flags & 2048 && commitCachePassiveMountEffect(finishedWork.alternate, finishedWork);
              break;
            default:
              recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork);
          }
          parentFiber = parentFiber.sibling;
        }
    }
    function recursivelyAccumulateSuspenseyCommit(parentFiber, committedLanes, suspendedState) {
      if (parentFiber.subtreeFlags & suspenseyCommitFlag)
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          accumulateSuspenseyCommitOnFiber(parentFiber, committedLanes, suspendedState), parentFiber = parentFiber.sibling;
    }
    function accumulateSuspenseyCommitOnFiber(fiber, committedLanes, suspendedState) {
      switch (fiber.tag) {
        case 26:
          recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
          if (fiber.flags & suspenseyCommitFlag)
            if (fiber.memoizedState !== null)
              suspendResource(suspendedState, currentHoistableRoot, fiber.memoizedState, fiber.memoizedProps);
            else {
              var instance = fiber.stateNode, type = fiber.type;
              fiber = fiber.memoizedProps;
              ((committedLanes & 335544128) === committedLanes || maySuspendCommitInSyncRender(type, fiber)) && suspendInstance(suspendedState, instance, type, fiber);
            }
          break;
        case 5:
          recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
          fiber.flags & suspenseyCommitFlag && (instance = fiber.stateNode, type = fiber.type, fiber = fiber.memoizedProps, ((committedLanes & 335544128) === committedLanes || maySuspendCommitInSyncRender(type, fiber)) && suspendInstance(suspendedState, instance, type, fiber));
          break;
        case 3:
        case 4:
          supportsResources ? (instance = currentHoistableRoot, currentHoistableRoot = getHoistableRoot(fiber.stateNode.containerInfo), recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState), currentHoistableRoot = instance) : recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
          break;
        case 22:
          fiber.memoizedState === null && (instance = fiber.alternate, instance !== null && instance.memoizedState !== null ? (instance = suspenseyCommitFlag, suspenseyCommitFlag = 16777216, recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState), suspenseyCommitFlag = instance) : recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState));
          break;
        case 30:
          (fiber.flags & suspenseyCommitFlag) !== 0 && (instance = fiber.memoizedProps.name, instance != null && instance !== "auto" && (type = fiber.stateNode, type.paired = null, appearingViewTransitions === null && (appearingViewTransitions = new Map), appearingViewTransitions.set(instance, type)));
          recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
          break;
        default:
          recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
      }
    }
    function detachAlternateSiblings(parentFiber) {
      var previousFiber = parentFiber.alternate;
      if (previousFiber !== null && (parentFiber = previousFiber.child, parentFiber !== null)) {
        previousFiber.child = null;
        do
          previousFiber = parentFiber.sibling, parentFiber.sibling = null, parentFiber = previousFiber;
        while (parentFiber !== null);
      }
    }
    function recursivelyTraversePassiveUnmountEffects(parentFiber) {
      var deletions = parentFiber.deletions;
      if ((parentFiber.flags & 16) !== 0) {
        if (deletions !== null)
          for (var i = 0;i < deletions.length; i++) {
            var childToDelete = deletions[i];
            nextEffect = childToDelete;
            commitPassiveUnmountEffectsInsideOfDeletedTree_begin(childToDelete, parentFiber);
          }
        detachAlternateSiblings(parentFiber);
      }
      if (parentFiber.subtreeFlags & 10256)
        for (parentFiber = parentFiber.child;parentFiber !== null; )
          commitPassiveUnmountOnFiber(parentFiber), parentFiber = parentFiber.sibling;
    }
    function commitPassiveUnmountOnFiber(finishedWork) {
      switch (finishedWork.tag) {
        case 0:
        case 11:
        case 15:
          recursivelyTraversePassiveUnmountEffects(finishedWork);
          finishedWork.flags & 2048 && commitHookEffectListUnmount(9, finishedWork, finishedWork.return);
          break;
        case 3:
          recursivelyTraversePassiveUnmountEffects(finishedWork);
          break;
        case 12:
          recursivelyTraversePassiveUnmountEffects(finishedWork);
          break;
        case 22:
          var instance = finishedWork.stateNode;
          finishedWork.memoizedState !== null && instance._visibility & 2 && (finishedWork.return === null || finishedWork.return.tag !== 13) ? (instance._visibility &= -3, recursivelyTraverseDisconnectPassiveEffects(finishedWork)) : recursivelyTraversePassiveUnmountEffects(finishedWork);
          break;
        default:
          recursivelyTraversePassiveUnmountEffects(finishedWork);
      }
    }
    function recursivelyTraverseDisconnectPassiveEffects(parentFiber) {
      var deletions = parentFiber.deletions;
      if ((parentFiber.flags & 16) !== 0) {
        if (deletions !== null)
          for (var i = 0;i < deletions.length; i++) {
            var childToDelete = deletions[i];
            nextEffect = childToDelete;
            commitPassiveUnmountEffectsInsideOfDeletedTree_begin(childToDelete, parentFiber);
          }
        detachAlternateSiblings(parentFiber);
      }
      for (parentFiber = parentFiber.child;parentFiber !== null; ) {
        deletions = parentFiber;
        switch (deletions.tag) {
          case 0:
          case 11:
          case 15:
            commitHookEffectListUnmount(8, deletions, deletions.return);
            recursivelyTraverseDisconnectPassiveEffects(deletions);
            break;
          case 22:
            i = deletions.stateNode;
            i._visibility & 2 && (i._visibility &= -3, recursivelyTraverseDisconnectPassiveEffects(deletions));
            break;
          default:
            recursivelyTraverseDisconnectPassiveEffects(deletions);
        }
        parentFiber = parentFiber.sibling;
      }
    }
    function commitPassiveUnmountEffectsInsideOfDeletedTree_begin(deletedSubtreeRoot, nearestMountedAncestor) {
      for (;nextEffect !== null; ) {
        var fiber = nextEffect;
        switch (fiber.tag) {
          case 0:
          case 11:
          case 15:
            commitHookEffectListUnmount(8, fiber, nearestMountedAncestor);
            break;
          case 23:
          case 22:
            if (fiber.memoizedState !== null && fiber.memoizedState.cachePool !== null) {
              var cache = fiber.memoizedState.cachePool.pool;
              cache != null && cache.refCount++;
            }
            break;
          case 24:
            releaseCache(fiber.memoizedState.cache);
        }
        cache = fiber.child;
        if (cache !== null)
          cache.return = fiber, nextEffect = cache;
        else
          a:
            for (fiber = deletedSubtreeRoot;nextEffect !== null; ) {
              cache = nextEffect;
              var sibling = cache.sibling, returnFiber = cache.return;
              detachFiberAfterEffects(cache);
              if (cache === fiber) {
                nextEffect = null;
                break a;
              }
              if (sibling !== null) {
                sibling.return = returnFiber;
                nextEffect = sibling;
                break a;
              }
              nextEffect = returnFiber;
            }
      }
    }
    function findFiberRootForHostRoot(hostRoot) {
      var maybeFiber = getInstanceFromNode(hostRoot);
      if (maybeFiber != null) {
        if (typeof maybeFiber.memoizedProps["data-testname"] !== "string")
          throw Error(formatProdErrorMessage(364));
        return maybeFiber;
      }
      hostRoot = findFiberRoot(hostRoot);
      if (hostRoot === null)
        throw Error(formatProdErrorMessage(362));
      return hostRoot.stateNode.current;
    }
    function matchSelector(fiber$jscomp$0, selector) {
      var tag = fiber$jscomp$0.tag;
      switch (selector.$$typeof) {
        case COMPONENT_TYPE:
          if (fiber$jscomp$0.type === selector.value)
            return true;
          break;
        case HAS_PSEUDO_CLASS_TYPE:
          a: {
            selector = selector.value;
            fiber$jscomp$0 = [fiber$jscomp$0, 0];
            for (tag = 0;tag < fiber$jscomp$0.length; ) {
              var fiber = fiber$jscomp$0[tag++], tag$jscomp$0 = fiber.tag, selectorIndex = fiber$jscomp$0[tag++], selector$jscomp$0 = selector[selectorIndex];
              if (tag$jscomp$0 !== 5 && tag$jscomp$0 !== 26 && tag$jscomp$0 !== 27 || !isHiddenSubtree(fiber)) {
                for (;selector$jscomp$0 != null && matchSelector(fiber, selector$jscomp$0); )
                  selectorIndex++, selector$jscomp$0 = selector[selectorIndex];
                if (selectorIndex === selector.length) {
                  selector = true;
                  break a;
                } else
                  for (fiber = fiber.child;fiber !== null; )
                    fiber$jscomp$0.push(fiber, selectorIndex), fiber = fiber.sibling;
              }
            }
            selector = false;
          }
          return selector;
        case ROLE_TYPE:
          if ((tag === 5 || tag === 26 || tag === 27) && matchAccessibilityRole(fiber$jscomp$0.stateNode, selector.value))
            return true;
          break;
        case TEXT_TYPE:
          if (tag === 5 || tag === 6 || tag === 26 || tag === 27) {
            if (fiber$jscomp$0 = getTextContent(fiber$jscomp$0), fiber$jscomp$0 !== null && 0 <= fiber$jscomp$0.indexOf(selector.value))
              return true;
          }
          break;
        case TEST_NAME_TYPE:
          if (tag === 5 || tag === 26 || tag === 27) {
            if (fiber$jscomp$0 = fiber$jscomp$0.memoizedProps["data-testname"], typeof fiber$jscomp$0 === "string" && fiber$jscomp$0.toLowerCase() === selector.value.toLowerCase())
              return true;
          }
          break;
        default:
          throw Error(formatProdErrorMessage(365));
      }
      return false;
    }
    function selectorToString(selector) {
      switch (selector.$$typeof) {
        case COMPONENT_TYPE:
          return "<" + (getComponentNameFromType(selector.value) || "Unknown") + ">";
        case HAS_PSEUDO_CLASS_TYPE:
          return ":has(" + (selectorToString(selector) || "") + ")";
        case ROLE_TYPE:
          return '[role="' + selector.value + '"]';
        case TEXT_TYPE:
          return '"' + selector.value + '"';
        case TEST_NAME_TYPE:
          return '[data-testname="' + selector.value + '"]';
        default:
          throw Error(formatProdErrorMessage(365));
      }
    }
    function findPaths(root, selectors) {
      var matchingFibers = [];
      root = [root, 0];
      for (var index = 0;index < root.length; ) {
        var fiber = root[index++], tag = fiber.tag, selectorIndex = root[index++], selector = selectors[selectorIndex];
        if (tag !== 5 && tag !== 26 && tag !== 27 || !isHiddenSubtree(fiber)) {
          for (;selector != null && matchSelector(fiber, selector); )
            selectorIndex++, selector = selectors[selectorIndex];
          if (selectorIndex === selectors.length)
            matchingFibers.push(fiber);
          else
            for (fiber = fiber.child;fiber !== null; )
              root.push(fiber, selectorIndex), fiber = fiber.sibling;
        }
      }
      return matchingFibers;
    }
    function findAllNodes(hostRoot, selectors) {
      if (!supportsTestSelectors)
        throw Error(formatProdErrorMessage(363));
      hostRoot = findFiberRootForHostRoot(hostRoot);
      hostRoot = findPaths(hostRoot, selectors);
      selectors = [];
      hostRoot = Array.from(hostRoot);
      for (var index = 0;index < hostRoot.length; ) {
        var node = hostRoot[index++], tag = node.tag;
        if (tag === 5 || tag === 26 || tag === 27)
          isHiddenSubtree(node) || selectors.push(node.stateNode);
        else
          for (node = node.child;node !== null; )
            hostRoot.push(node), node = node.sibling;
      }
      return selectors;
    }
    function requestUpdateLane() {
      return (executionContext & 2) !== 0 && workInProgressRootRenderLanes !== 0 ? workInProgressRootRenderLanes & -workInProgressRootRenderLanes : ReactSharedInternals.T !== null ? requestTransitionLane() : resolveUpdatePriority();
    }
    function requestDeferredLane() {
      if (workInProgressDeferredLane === 0)
        if ((workInProgressRootRenderLanes & 536870912) === 0 || isHydrating) {
          var lane = nextTransitionDeferredLane;
          nextTransitionDeferredLane <<= 1;
          (nextTransitionDeferredLane & 3932160) === 0 && (nextTransitionDeferredLane = 262144);
          workInProgressDeferredLane = lane;
        } else
          workInProgressDeferredLane = 536870912;
      lane = suspenseHandlerStackCursor.current;
      lane !== null && (lane.flags |= 32);
      return workInProgressDeferredLane;
    }
    function scheduleViewTransitionEvent(fiber, callback) {
      if (callback != null) {
        var state = fiber.stateNode, instance = state.ref;
        instance === null && (instance = state.ref = createViewTransitionInstance(getViewTransitionName(fiber.memoizedProps, state)));
        pendingViewTransitionEvents === null && (pendingViewTransitionEvents = []);
        pendingViewTransitionEvents.push(callback.bind(null, instance));
      }
    }
    function scheduleUpdateOnFiber(root, fiber, lane) {
      if (root === workInProgressRoot && (workInProgressSuspendedReason === 2 || workInProgressSuspendedReason === 9) || root.cancelPendingCommit !== null)
        prepareFreshStack(root, 0), markRootSuspended(root, workInProgressRootRenderLanes, workInProgressDeferredLane, false);
      markRootUpdated$1(root, lane);
      if ((executionContext & 2) === 0 || root !== workInProgressRoot)
        root === workInProgressRoot && ((executionContext & 2) === 0 && (workInProgressRootInterleavedUpdatedLanes |= lane), workInProgressRootExitStatus === 4 && markRootSuspended(root, workInProgressRootRenderLanes, workInProgressDeferredLane, false)), ensureRootIsScheduled(root);
    }
    function performWorkOnRoot(root$jscomp$0, lanes, forceSync) {
      if ((executionContext & 6) !== 0)
        throw Error(formatProdErrorMessage(327));
      var shouldTimeSlice = !forceSync && (lanes & 127) === 0 && (lanes & root$jscomp$0.expiredLanes) === 0 || checkIfRootIsPrerendering(root$jscomp$0, lanes), exitStatus = shouldTimeSlice ? renderRootConcurrent(root$jscomp$0, lanes) : renderRootSync(root$jscomp$0, lanes, true), renderWasConcurrent = shouldTimeSlice;
      do {
        if (exitStatus === 0) {
          workInProgressRootIsPrerendering && !shouldTimeSlice && markRootSuspended(root$jscomp$0, lanes, 0, false);
          break;
        } else {
          forceSync = root$jscomp$0.current.alternate;
          if (renderWasConcurrent && !isRenderConsistentWithExternalStores(forceSync)) {
            exitStatus = renderRootSync(root$jscomp$0, lanes, false);
            renderWasConcurrent = false;
            continue;
          }
          if (exitStatus === 2) {
            renderWasConcurrent = lanes;
            if (root$jscomp$0.errorRecoveryDisabledLanes & renderWasConcurrent)
              var JSCompiler_inline_result = 0;
            else
              JSCompiler_inline_result = root$jscomp$0.pendingLanes & -536870913, JSCompiler_inline_result = JSCompiler_inline_result !== 0 ? JSCompiler_inline_result : JSCompiler_inline_result & 536870912 ? 536870912 : 0;
            if (JSCompiler_inline_result !== 0) {
              lanes = JSCompiler_inline_result;
              a: {
                var root = root$jscomp$0;
                exitStatus = workInProgressRootConcurrentErrors;
                var wasRootDehydrated = supportsHydration && root.current.memoizedState.isDehydrated;
                wasRootDehydrated && (prepareFreshStack(root, JSCompiler_inline_result).flags |= 256);
                JSCompiler_inline_result = renderRootSync(root, JSCompiler_inline_result, false);
                if (JSCompiler_inline_result !== 2 && JSCompiler_inline_result !== 6) {
                  if (workInProgressRootDidAttachPingListener && !wasRootDehydrated) {
                    root.errorRecoveryDisabledLanes |= renderWasConcurrent;
                    workInProgressRootInterleavedUpdatedLanes |= renderWasConcurrent;
                    exitStatus = 4;
                    break a;
                  }
                  renderWasConcurrent = workInProgressRootRecoverableErrors;
                  workInProgressRootRecoverableErrors = exitStatus;
                  renderWasConcurrent !== null && (workInProgressRootRecoverableErrors === null ? workInProgressRootRecoverableErrors = renderWasConcurrent : workInProgressRootRecoverableErrors.push.apply(workInProgressRootRecoverableErrors, renderWasConcurrent));
                }
                exitStatus = JSCompiler_inline_result;
              }
              renderWasConcurrent = false;
              if (exitStatus !== 2)
                continue;
            }
          }
          if (exitStatus === 1) {
            prepareFreshStack(root$jscomp$0, 0);
            markRootSuspended(root$jscomp$0, lanes, 0, true);
            break;
          }
          a: {
            shouldTimeSlice = root$jscomp$0;
            renderWasConcurrent = exitStatus;
            switch (renderWasConcurrent) {
              case 0:
              case 1:
                throw Error(formatProdErrorMessage(345));
              case 4:
                if ((lanes & 4194048) !== lanes && (lanes & 62914560) !== lanes)
                  break;
              case 6:
                markRootSuspended(shouldTimeSlice, lanes, workInProgressDeferredLane, !workInProgressRootDidSkipSuspendedSiblings);
                break a;
              case 2:
                workInProgressRootRecoverableErrors = null;
                break;
              case 3:
              case 5:
                break;
              default:
                throw Error(formatProdErrorMessage(329));
            }
            if ((lanes & 62914560) === lanes && (exitStatus = globalMostRecentFallbackTime + 300 - now(), 10 < exitStatus)) {
              markRootSuspended(shouldTimeSlice, lanes, workInProgressDeferredLane, !workInProgressRootDidSkipSuspendedSiblings);
              if (getNextLanes(shouldTimeSlice, 0, true) !== 0)
                break a;
              pendingEffectsLanes = lanes;
              shouldTimeSlice.timeoutHandle = scheduleTimeout(completeRootWhenReady.bind(null, shouldTimeSlice, forceSync, workInProgressRootRecoverableErrors, workInProgressTransitions, workInProgressRootDidIncludeRecursiveRenderUpdate, lanes, workInProgressDeferredLane, workInProgressRootInterleavedUpdatedLanes, workInProgressSuspendedRetryLanes, workInProgressRootDidSkipSuspendedSiblings, renderWasConcurrent, "Throttled", -0, 0), exitStatus);
              break a;
            }
            completeRootWhenReady(shouldTimeSlice, forceSync, workInProgressRootRecoverableErrors, workInProgressTransitions, workInProgressRootDidIncludeRecursiveRenderUpdate, lanes, workInProgressDeferredLane, workInProgressRootInterleavedUpdatedLanes, workInProgressSuspendedRetryLanes, workInProgressRootDidSkipSuspendedSiblings, renderWasConcurrent, null, -0, 0);
          }
        }
        break;
      } while (1);
      ensureRootIsScheduled(root$jscomp$0);
    }
    function completeRootWhenReady(root, finishedWork, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, lanes, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedCommitReason, completedRenderStartTime, completedRenderEndTime) {
      root.timeoutHandle = noTimeout;
      var subtreeFlags = finishedWork.subtreeFlags, isViewTransitionEligible = (lanes & 335544064) === lanes;
      suspendedCommitReason = null;
      if (isViewTransitionEligible || subtreeFlags & 8192 || (subtreeFlags & 16785408) === 16785408) {
        if (suspendedCommitReason = startSuspendingCommit(), appearingViewTransitions = null, accumulateSuspenseyCommitOnFiber(finishedWork, lanes, suspendedCommitReason), isViewTransitionEligible && suspendOnActiveViewTransition(suspendedCommitReason, root.containerInfo), subtreeFlags = (lanes & 62914560) === lanes ? globalMostRecentFallbackTime - now() : (lanes & 4194048) === lanes ? globalMostRecentTransitionTime - now() : 0, subtreeFlags = waitForCommitToBeReady(suspendedCommitReason, subtreeFlags), subtreeFlags !== null) {
          pendingEffectsLanes = lanes;
          root.cancelPendingCommit = subtreeFlags(completeRoot.bind(null, root, finishedWork, lanes, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedCommitReason, null, completedRenderStartTime, completedRenderEndTime));
          markRootSuspended(root, lanes, spawnedLane, !didSkipSuspendedSiblings);
          return;
        }
      }
      completeRoot(root, finishedWork, lanes, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedCommitReason);
    }
    function isRenderConsistentWithExternalStores(finishedWork) {
      for (var node = finishedWork;; ) {
        var tag = node.tag;
        if ((tag === 0 || tag === 11 || tag === 15) && node.flags & 16384 && (tag = node.updateQueue, tag !== null && (tag = tag.stores, tag !== null)))
          for (var i = 0;i < tag.length; i++) {
            var check = tag[i], getSnapshot = check.getSnapshot;
            check = check.value;
            try {
              if (!objectIs(getSnapshot(), check))
                return false;
            } catch (error) {
              return false;
            }
          }
        tag = node.child;
        if (node.subtreeFlags & 16384 && tag !== null)
          tag.return = node, node = tag;
        else {
          if (node === finishedWork)
            break;
          for (;node.sibling === null; ) {
            if (node.return === null || node.return === finishedWork)
              return true;
            node = node.return;
          }
          node.sibling.return = node.return;
          node = node.sibling;
        }
      }
      return true;
    }
    function markRootSuspended(root, suspendedLanes, spawnedLane, didAttemptEntireTree) {
      suspendedLanes = getEntangledLanes(root, suspendedLanes);
      suspendedLanes &= ~workInProgressRootPingedLanes;
      suspendedLanes &= ~workInProgressRootInterleavedUpdatedLanes;
      root.suspendedLanes |= suspendedLanes;
      root.pingedLanes &= ~suspendedLanes;
      didAttemptEntireTree && (root.warmLanes |= suspendedLanes);
      didAttemptEntireTree = root.expirationTimes;
      for (var lanes = suspendedLanes;0 < lanes; ) {
        var index$4 = 31 - clz32(lanes), lane = 1 << index$4;
        didAttemptEntireTree[index$4] = -1;
        lanes &= ~lane;
      }
      spawnedLane !== 0 && markSpawnedDeferredLane(root, spawnedLane, suspendedLanes);
    }
    function flushSyncWork() {
      return (executionContext & 6) === 0 ? (flushSyncWorkAcrossRoots_impl(0, false), false) : true;
    }
    function resetWorkInProgressStack() {
      if (workInProgress !== null) {
        if (workInProgressSuspendedReason === 0)
          var interruptedWork = workInProgress.return;
        else
          interruptedWork = workInProgress, lastContextDependency = currentlyRenderingFiber$1 = null, resetHooksOnUnwind(interruptedWork), thenableState$1 = null, thenableIndexCounter$1 = 0, interruptedWork = workInProgress;
        for (;interruptedWork !== null; )
          unwindInterruptedWork(interruptedWork.alternate, interruptedWork), interruptedWork = interruptedWork.return;
        workInProgress = null;
      }
    }
    function prepareFreshStack(root, lanes) {
      var timeoutHandle = root.timeoutHandle;
      timeoutHandle !== noTimeout && (root.timeoutHandle = noTimeout, cancelTimeout(timeoutHandle));
      timeoutHandle = root.cancelPendingCommit;
      timeoutHandle !== null && (root.cancelPendingCommit = null, timeoutHandle());
      pendingEffectsLanes = 0;
      resetWorkInProgressStack();
      workInProgressRoot = root;
      workInProgress = timeoutHandle = createWorkInProgress(root.current, null);
      workInProgressRootRenderLanes = lanes;
      workInProgressSuspendedReason = 0;
      workInProgressThrownValue = null;
      workInProgressRootDidSkipSuspendedSiblings = false;
      workInProgressRootIsPrerendering = checkIfRootIsPrerendering(root, lanes);
      workInProgressRootDidAttachPingListener = false;
      workInProgressSuspendedRetryLanes = workInProgressDeferredLane = workInProgressRootPingedLanes = workInProgressRootInterleavedUpdatedLanes = workInProgressRootSkippedLanes = workInProgressRootExitStatus = 0;
      workInProgressRootRecoverableErrors = workInProgressRootConcurrentErrors = null;
      workInProgressRootDidIncludeRecursiveRenderUpdate = false;
      entangledRenderLanes = getEntangledLanes(root, lanes);
      finishQueueingConcurrentUpdates();
      return timeoutHandle;
    }
    function handleThrow(root, thrownValue) {
      currentlyRenderingFiber = null;
      ReactSharedInternals.H = ContextOnlyDispatcher;
      thrownValue === SuspenseException || thrownValue === SuspenseActionException ? (thrownValue = getSuspendedThenable(), workInProgressSuspendedReason = 3) : thrownValue === SuspenseyCommitException ? (thrownValue = getSuspendedThenable(), workInProgressSuspendedReason = 4) : workInProgressSuspendedReason = thrownValue === SelectiveHydrationException ? 8 : thrownValue !== null && typeof thrownValue === "object" && typeof thrownValue.then === "function" ? 6 : 1;
      workInProgressThrownValue = thrownValue;
      workInProgress === null && (workInProgressRootExitStatus = 1, logUncaughtError(root, createCapturedValueAtFiber(thrownValue, root.current)));
    }
    function shouldRemainOnPreviousScreen() {
      var handler = suspenseHandlerStackCursor.current;
      return handler === null ? true : (workInProgressRootRenderLanes & 4194048) === workInProgressRootRenderLanes ? shellBoundary === null ? true : false : (workInProgressRootRenderLanes & 62914560) === workInProgressRootRenderLanes || (workInProgressRootRenderLanes & 536870912) !== 0 ? handler === shellBoundary : false;
    }
    function pushDispatcher() {
      var prevDispatcher = ReactSharedInternals.H;
      ReactSharedInternals.H = ContextOnlyDispatcher;
      return prevDispatcher === null ? ContextOnlyDispatcher : prevDispatcher;
    }
    function pushAsyncDispatcher() {
      var prevAsyncDispatcher = ReactSharedInternals.A;
      ReactSharedInternals.A = DefaultAsyncDispatcher;
      return prevAsyncDispatcher;
    }
    function renderDidSuspendDelayIfPossible() {
      workInProgressRootExitStatus = 4;
      workInProgressRootDidSkipSuspendedSiblings || (workInProgressRootRenderLanes & 4194048) !== workInProgressRootRenderLanes && suspenseHandlerStackCursor.current !== null || (workInProgressRootIsPrerendering = true);
      (workInProgressRootSkippedLanes & 134217727) === 0 && (workInProgressRootInterleavedUpdatedLanes & 134217727) === 0 || workInProgressRoot === null || markRootSuspended(workInProgressRoot, workInProgressRootRenderLanes, workInProgressDeferredLane, false);
    }
    function renderRootSync(root, lanes, shouldYieldForPrerendering) {
      var prevExecutionContext = executionContext;
      executionContext |= 2;
      var prevDispatcher = pushDispatcher(), prevAsyncDispatcher = pushAsyncDispatcher();
      if (workInProgressRoot !== root || workInProgressRootRenderLanes !== lanes)
        workInProgressTransitions = null, prepareFreshStack(root, lanes);
      lanes = false;
      var exitStatus = workInProgressRootExitStatus;
      a:
        do
          try {
            if (workInProgressSuspendedReason !== 0 && workInProgress !== null) {
              var unitOfWork = workInProgress, thrownValue = workInProgressThrownValue;
              switch (workInProgressSuspendedReason) {
                case 8:
                  resetWorkInProgressStack();
                  exitStatus = 6;
                  break a;
                case 3:
                case 2:
                case 9:
                case 6:
                  suspenseHandlerStackCursor.current === null && (lanes = true);
                  var reason = workInProgressSuspendedReason;
                  workInProgressSuspendedReason = 0;
                  workInProgressThrownValue = null;
                  throwAndUnwindWorkLoop(root, unitOfWork, thrownValue, reason);
                  if (shouldYieldForPrerendering && workInProgressRootIsPrerendering) {
                    exitStatus = 0;
                    break a;
                  }
                  break;
                default:
                  reason = workInProgressSuspendedReason, workInProgressSuspendedReason = 0, workInProgressThrownValue = null, throwAndUnwindWorkLoop(root, unitOfWork, thrownValue, reason);
              }
            }
            workLoopSync();
            exitStatus = workInProgressRootExitStatus;
            break;
          } catch (thrownValue$169) {
            handleThrow(root, thrownValue$169);
          }
        while (1);
      lanes && root.shellSuspendCounter++;
      lastContextDependency = currentlyRenderingFiber$1 = null;
      executionContext = prevExecutionContext;
      ReactSharedInternals.H = prevDispatcher;
      ReactSharedInternals.A = prevAsyncDispatcher;
      workInProgress === null && (workInProgressRoot = null, workInProgressRootRenderLanes = 0, finishQueueingConcurrentUpdates());
      return exitStatus;
    }
    function workLoopSync() {
      for (;workInProgress !== null; )
        performUnitOfWork(workInProgress);
    }
    function renderRootConcurrent(root, lanes) {
      var prevExecutionContext = executionContext;
      executionContext |= 2;
      var prevDispatcher = pushDispatcher(), prevAsyncDispatcher = pushAsyncDispatcher();
      workInProgressRoot !== root || workInProgressRootRenderLanes !== lanes ? (workInProgressTransitions = null, workInProgressRootRenderTargetTime = now() + 500, prepareFreshStack(root, lanes)) : workInProgressRootIsPrerendering = checkIfRootIsPrerendering(root, lanes);
      a:
        do
          try {
            if (workInProgressSuspendedReason !== 0 && workInProgress !== null) {
              lanes = workInProgress;
              var thrownValue = workInProgressThrownValue;
              b:
                switch (workInProgressSuspendedReason) {
                  case 1:
                    workInProgressSuspendedReason = 0;
                    workInProgressThrownValue = null;
                    throwAndUnwindWorkLoop(root, lanes, thrownValue, 1);
                    break;
                  case 2:
                  case 9:
                    if (isThenableResolved(thrownValue)) {
                      workInProgressSuspendedReason = 0;
                      workInProgressThrownValue = null;
                      replaySuspendedUnitOfWork(lanes);
                      break;
                    }
                    lanes = function() {
                      workInProgressSuspendedReason !== 2 && workInProgressSuspendedReason !== 9 || workInProgressRoot !== root || (workInProgressSuspendedReason = 7);
                      ensureRootIsScheduled(root);
                    };
                    thrownValue.then(lanes, lanes);
                    break a;
                  case 3:
                    workInProgressSuspendedReason = 7;
                    break a;
                  case 4:
                    workInProgressSuspendedReason = 5;
                    break a;
                  case 7:
                    isThenableResolved(thrownValue) ? (workInProgressSuspendedReason = 0, workInProgressThrownValue = null, replaySuspendedUnitOfWork(lanes)) : (workInProgressSuspendedReason = 0, workInProgressThrownValue = null, throwAndUnwindWorkLoop(root, lanes, thrownValue, 7));
                    break;
                  case 5:
                    var resource = null;
                    switch (workInProgress.tag) {
                      case 26:
                        resource = workInProgress.memoizedState;
                      case 5:
                      case 27:
                        var hostFiber = workInProgress, { type, pendingProps: props } = hostFiber;
                        if (resource ? preloadResource(resource) : preloadInstance(hostFiber.stateNode, type, props)) {
                          workInProgressSuspendedReason = 0;
                          workInProgressThrownValue = null;
                          var sibling = hostFiber.sibling;
                          if (sibling !== null)
                            workInProgress = sibling;
                          else {
                            var returnFiber = hostFiber.return;
                            returnFiber !== null ? (workInProgress = returnFiber, completeUnitOfWork(returnFiber)) : workInProgress = null;
                          }
                          break b;
                        }
                    }
                    workInProgressSuspendedReason = 0;
                    workInProgressThrownValue = null;
                    throwAndUnwindWorkLoop(root, lanes, thrownValue, 5);
                    break;
                  case 6:
                    workInProgressSuspendedReason = 0;
                    workInProgressThrownValue = null;
                    throwAndUnwindWorkLoop(root, lanes, thrownValue, 6);
                    break;
                  case 8:
                    resetWorkInProgressStack();
                    workInProgressRootExitStatus = 6;
                    break a;
                  default:
                    throw Error(formatProdErrorMessage(462));
                }
            }
            workLoopConcurrentByScheduler();
            break;
          } catch (thrownValue$171) {
            handleThrow(root, thrownValue$171);
          }
        while (1);
      lastContextDependency = currentlyRenderingFiber$1 = null;
      ReactSharedInternals.H = prevDispatcher;
      ReactSharedInternals.A = prevAsyncDispatcher;
      executionContext = prevExecutionContext;
      if (workInProgress !== null)
        return 0;
      workInProgressRoot = null;
      workInProgressRootRenderLanes = 0;
      finishQueueingConcurrentUpdates();
      return workInProgressRootExitStatus;
    }
    function workLoopConcurrentByScheduler() {
      for (;workInProgress !== null && !shouldYield(); )
        performUnitOfWork(workInProgress);
    }
    function performUnitOfWork(unitOfWork) {
      var next = beginWork(unitOfWork.alternate, unitOfWork, entangledRenderLanes);
      unitOfWork.memoizedProps = unitOfWork.pendingProps;
      next === null ? completeUnitOfWork(unitOfWork) : workInProgress = next;
    }
    function replaySuspendedUnitOfWork(unitOfWork) {
      var next = unitOfWork;
      var current = next.alternate;
      switch (next.tag) {
        case 15:
        case 0:
          next = replayFunctionComponent(current, next, next.pendingProps, next.type, undefined, workInProgressRootRenderLanes);
          break;
        case 11:
          next = replayFunctionComponent(current, next, next.pendingProps, next.type.render, next.ref, workInProgressRootRenderLanes);
          break;
        case 5:
          resetHooksOnUnwind(next);
          var fiber = next;
          supportsHydration && fiber === hydrationParentFiber && (isHydrating ? (popToNextHostParent(fiber), fiber.tag === 5 && fiber.stateNode != null && (nextHydratableInstance = fiber.stateNode)) : (popToNextHostParent(fiber), isHydrating = true));
        default:
          unwindInterruptedWork(current, next), next = workInProgress = resetWorkInProgress(next, entangledRenderLanes), next = beginWork(current, next, entangledRenderLanes);
      }
      unitOfWork.memoizedProps = unitOfWork.pendingProps;
      next === null ? completeUnitOfWork(unitOfWork) : workInProgress = next;
    }
    function throwAndUnwindWorkLoop(root, unitOfWork, thrownValue, suspendedReason) {
      lastContextDependency = currentlyRenderingFiber$1 = null;
      resetHooksOnUnwind(unitOfWork);
      thenableState$1 = null;
      thenableIndexCounter$1 = 0;
      var returnFiber = unitOfWork.return;
      try {
        if (throwException(root, returnFiber, unitOfWork, thrownValue, workInProgressRootRenderLanes)) {
          workInProgressRootExitStatus = 1;
          logUncaughtError(root, createCapturedValueAtFiber(thrownValue, root.current));
          workInProgress = null;
          return;
        }
      } catch (error) {
        if (returnFiber !== null)
          throw workInProgress = returnFiber, error;
        workInProgressRootExitStatus = 1;
        logUncaughtError(root, createCapturedValueAtFiber(thrownValue, root.current));
        workInProgress = null;
        return;
      }
      if (unitOfWork.flags & 32768) {
        if (isHydrating || suspendedReason === 1)
          root = true;
        else if (workInProgressRootIsPrerendering || (workInProgressRootRenderLanes & 536870912) !== 0)
          root = false;
        else if (workInProgressRootDidSkipSuspendedSiblings = root = true, suspendedReason === 2 || suspendedReason === 9 || suspendedReason === 3 || suspendedReason === 6)
          suspendedReason = suspenseHandlerStackCursor.current, suspendedReason !== null && suspendedReason.tag === 13 && (suspendedReason.flags |= 16384);
        unwindUnitOfWork(unitOfWork, root);
      } else
        completeUnitOfWork(unitOfWork);
    }
    function completeUnitOfWork(unitOfWork) {
      var completedWork = unitOfWork;
      do {
        if ((completedWork.flags & 32768) !== 0) {
          unwindUnitOfWork(completedWork, workInProgressRootDidSkipSuspendedSiblings);
          return;
        }
        unitOfWork = completedWork.return;
        var next = completeWork(completedWork.alternate, completedWork, entangledRenderLanes);
        if (next !== null) {
          workInProgress = next;
          return;
        }
        completedWork = completedWork.sibling;
        if (completedWork !== null) {
          workInProgress = completedWork;
          return;
        }
        workInProgress = completedWork = unitOfWork;
      } while (completedWork !== null);
      workInProgressRootExitStatus === 0 && (workInProgressRootExitStatus = 5);
    }
    function unwindUnitOfWork(unitOfWork, skipSiblings) {
      do {
        var next = unwindWork(unitOfWork.alternate, unitOfWork);
        if (next !== null) {
          next.flags &= 32767;
          workInProgress = next;
          return;
        }
        next = unitOfWork.return;
        next !== null && (next.flags |= 32768, next.subtreeFlags = 0, next.deletions = null);
        if (!skipSiblings && (unitOfWork = unitOfWork.sibling, unitOfWork !== null)) {
          workInProgress = unitOfWork;
          return;
        }
        workInProgress = unitOfWork = next;
      } while (unitOfWork !== null);
      workInProgressRootExitStatus = 6;
      workInProgress = null;
    }
    function completeRoot(root, finishedWork, lanes, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedState) {
      root.cancelPendingCommit = null;
      do
        flushPendingEffects();
      while (pendingEffectsStatus !== 0);
      if ((executionContext & 6) !== 0)
        throw Error(formatProdErrorMessage(327));
      if (finishedWork !== null) {
        if (finishedWork === root.current)
          throw Error(formatProdErrorMessage(177));
        root === workInProgressRoot && (workInProgress = workInProgressRoot = null, workInProgressRootRenderLanes = 0);
        pendingFinishedWork = finishedWork;
        pendingEffectsRoot = root;
        pendingEffectsLanes = lanes;
        pendingPassiveTransitions = transitions;
        pendingRecoverableErrors = recoverableErrors;
        commitRoot(root, finishedWork, lanes, spawnedLane, updatedLanes, suspendedRetryLanes, suspendedState);
      }
    }
    function commitRoot(root, finishedWork, lanes, spawnedLane, updatedLanes, suspendedRetryLanes, suspendedState) {
      var remainingLanes = finishedWork.lanes | finishedWork.childLanes;
      pendingEffectsRemainingLanes = remainingLanes;
      remainingLanes |= concurrentlyUpdatedLanes;
      markRootFinished(root, lanes, remainingLanes, spawnedLane, updatedLanes, suspendedRetryLanes);
      pendingViewTransitionEvents = null;
      (lanes & 335544064) === lanes ? (pendingTransitionTypes = claimQueuedTransitionTypes(root), spawnedLane = 10262) : (pendingTransitionTypes = null, spawnedLane = 10256);
      (finishedWork.subtreeFlags & spawnedLane) !== 0 || (finishedWork.flags & spawnedLane) !== 0 ? (root.callbackNode = null, root.callbackPriority = 0, scheduleCallback(NormalPriority$1, function() {
        flushPassiveEffects();
        return null;
      })) : (root.callbackNode = null, root.callbackPriority = 0);
      shouldStartViewTransition = false;
      spawnedLane = (finishedWork.flags & 13878) !== 0;
      if ((finishedWork.subtreeFlags & 13878) !== 0 || spawnedLane) {
        spawnedLane = ReactSharedInternals.T;
        ReactSharedInternals.T = null;
        updatedLanes = getCurrentUpdatePriority();
        setCurrentUpdatePriority(2);
        suspendedRetryLanes = executionContext;
        executionContext |= 4;
        try {
          commitBeforeMutationEffects(root, finishedWork, lanes);
        } finally {
          executionContext = suspendedRetryLanes, setCurrentUpdatePriority(updatedLanes), ReactSharedInternals.T = spawnedLane;
        }
      }
      pendingEffectsStatus = 1;
      shouldStartViewTransition ? pendingViewTransition = startViewTransition(suspendedState, root.containerInfo, pendingTransitionTypes, flushMutationEffects, flushLayoutEffects, flushAfterMutationEffects, flushSpawnedWork, flushPassiveEffects, reportViewTransitionError, null, null) : (flushMutationEffects(), flushLayoutEffects(), flushSpawnedWork());
    }
    function reportViewTransitionError(error) {
      if (pendingEffectsStatus !== 0) {
        var onRecoverableError = pendingEffectsRoot.onRecoverableError;
        onRecoverableError(error, { componentStack: null });
      }
    }
    function flushAfterMutationEffects() {
      pendingEffectsStatus === 3 && (pendingEffectsStatus = 0, commitAfterMutationEffectsOnFiber(pendingFinishedWork, pendingEffectsRoot), pendingEffectsStatus = 4);
    }
    function flushMutationEffects() {
      if (pendingEffectsStatus === 1) {
        pendingEffectsStatus = 0;
        var root = pendingEffectsRoot, finishedWork = pendingFinishedWork, lanes = pendingEffectsLanes, rootMutationHasEffect = (finishedWork.flags & 13878) !== 0;
        if ((finishedWork.subtreeFlags & 13878) !== 0 || rootMutationHasEffect) {
          rootMutationHasEffect = ReactSharedInternals.T;
          ReactSharedInternals.T = null;
          var previousPriority = getCurrentUpdatePriority();
          setCurrentUpdatePriority(2);
          var prevExecutionContext = executionContext;
          executionContext |= 4;
          try {
            inUpdateViewTransition = rootViewTransitionAffected = false, commitMutationEffectsOnFiber(finishedWork, root, lanes), resetAfterCommit(root.containerInfo);
          } finally {
            executionContext = prevExecutionContext, setCurrentUpdatePriority(previousPriority), ReactSharedInternals.T = rootMutationHasEffect;
          }
        }
        root.current = finishedWork;
        pendingEffectsStatus = 2;
      }
    }
    function flushLayoutEffects() {
      if (pendingEffectsStatus === 2) {
        pendingEffectsStatus = 0;
        var root = pendingEffectsRoot, finishedWork = pendingFinishedWork, rootHasLayoutEffect = (finishedWork.flags & 8772) !== 0;
        if ((finishedWork.subtreeFlags & 8772) !== 0 || rootHasLayoutEffect) {
          rootHasLayoutEffect = ReactSharedInternals.T;
          ReactSharedInternals.T = null;
          var previousPriority = getCurrentUpdatePriority();
          setCurrentUpdatePriority(2);
          var prevExecutionContext = executionContext;
          executionContext |= 4;
          try {
            commitLayoutEffectOnFiber(root, finishedWork.alternate, finishedWork);
          } finally {
            executionContext = prevExecutionContext, setCurrentUpdatePriority(previousPriority), ReactSharedInternals.T = rootHasLayoutEffect;
          }
        }
        pendingEffectsStatus = 3;
      }
    }
    function flushSpawnedWork() {
      if (pendingEffectsStatus === 4 || pendingEffectsStatus === 3) {
        pendingEffectsStatus = 0;
        var committedViewTransition = pendingViewTransition;
        pendingViewTransition = null;
        requestPaint();
        var root = pendingEffectsRoot, finishedWork = pendingFinishedWork, lanes = pendingEffectsLanes, recoverableErrors = pendingRecoverableErrors, passiveSubtreeMask = (lanes & 335544064) === lanes ? 10262 : 10256;
        (finishedWork.subtreeFlags & passiveSubtreeMask) !== 0 || (finishedWork.flags & passiveSubtreeMask) !== 0 ? pendingEffectsStatus = 5 : (pendingEffectsStatus = 0, pendingFinishedWork = pendingEffectsRoot = null, releaseRootPooledCache(root, root.pendingLanes));
        passiveSubtreeMask = root.pendingLanes;
        passiveSubtreeMask === 0 && (legacyErrorBoundariesThatAlreadyFailed = null);
        lanesToEventPriority(lanes);
        finishedWork = finishedWork.stateNode;
        if (injectedHook && typeof injectedHook.onCommitFiberRoot === "function")
          try {
            injectedHook.onCommitFiberRoot(rendererID, finishedWork, undefined, (finishedWork.current.flags & 128) === 128);
          } catch (err) {}
        if (recoverableErrors !== null) {
          finishedWork = ReactSharedInternals.T;
          passiveSubtreeMask = getCurrentUpdatePriority();
          setCurrentUpdatePriority(2);
          ReactSharedInternals.T = null;
          try {
            for (var onRecoverableError = root.onRecoverableError, i = 0;i < recoverableErrors.length; i++) {
              var recoverableError = recoverableErrors[i];
              onRecoverableError(recoverableError.value, {
                componentStack: recoverableError.stack
              });
            }
          } finally {
            ReactSharedInternals.T = finishedWork, setCurrentUpdatePriority(passiveSubtreeMask);
          }
        }
        recoverableErrors = pendingViewTransitionEvents;
        onRecoverableError = pendingTransitionTypes;
        pendingTransitionTypes = null;
        if (recoverableErrors !== null && (pendingViewTransitionEvents = null, onRecoverableError === null && (onRecoverableError = []), committedViewTransition !== null))
          for (recoverableError = 0;recoverableError < recoverableErrors.length; recoverableError++)
            finishedWork = (0, recoverableErrors[recoverableError])(onRecoverableError), finishedWork !== undefined && addViewTransitionFinishedListener(committedViewTransition, finishedWork);
        (pendingEffectsLanes & 3) !== 0 && flushPendingEffects();
        ensureRootIsScheduled(root);
        passiveSubtreeMask = root.pendingLanes;
        (lanes & 261930) !== 0 && (passiveSubtreeMask & 42) !== 0 ? root === rootWithNestedUpdates ? nestedUpdateCount++ : (nestedUpdateCount = 0, rootWithNestedUpdates = root) : (nestedUpdateCount = 0, rootWithNestedUpdates = null);
        supportsHydration && flushHydrationEvents();
        flushSyncWorkAcrossRoots_impl(0, false);
      }
    }
    function releaseRootPooledCache(root, remainingLanes) {
      (root.pooledCacheLanes &= remainingLanes) === 0 && (remainingLanes = root.pooledCache, remainingLanes != null && (root.pooledCache = null, releaseCache(remainingLanes)));
    }
    function flushPendingEffects() {
      pendingViewTransition !== null && (stopViewTransition(pendingViewTransition), pendingViewTransition = null);
      flushMutationEffects();
      flushLayoutEffects();
      flushSpawnedWork();
      return flushPassiveEffects();
    }
    function flushPassiveEffects() {
      if (pendingEffectsStatus !== 5)
        return false;
      var root = pendingEffectsRoot, remainingLanes = pendingEffectsRemainingLanes;
      pendingEffectsRemainingLanes = 0;
      var renderPriority = lanesToEventPriority(pendingEffectsLanes), priority = 32 > renderPriority ? 32 : renderPriority;
      renderPriority = ReactSharedInternals.T;
      var previousPriority = getCurrentUpdatePriority();
      try {
        setCurrentUpdatePriority(priority);
        ReactSharedInternals.T = null;
        priority = pendingPassiveTransitions;
        pendingPassiveTransitions = null;
        var root$jscomp$0 = pendingEffectsRoot, lanes = pendingEffectsLanes;
        pendingEffectsStatus = 0;
        pendingFinishedWork = pendingEffectsRoot = null;
        pendingEffectsLanes = 0;
        if ((executionContext & 6) !== 0)
          throw Error(formatProdErrorMessage(331));
        var prevExecutionContext = executionContext;
        executionContext |= 4;
        commitPassiveUnmountOnFiber(root$jscomp$0.current);
        commitPassiveMountOnFiber(root$jscomp$0, root$jscomp$0.current, lanes, priority);
        executionContext = prevExecutionContext;
        flushSyncWorkAcrossRoots_impl(0, false);
        if (injectedHook && typeof injectedHook.onPostCommitFiberRoot === "function")
          try {
            injectedHook.onPostCommitFiberRoot(rendererID, root$jscomp$0);
          } catch (err) {}
        return true;
      } finally {
        setCurrentUpdatePriority(previousPriority), ReactSharedInternals.T = renderPriority, releaseRootPooledCache(root, remainingLanes);
      }
    }
    function captureCommitPhaseErrorOnRoot(rootFiber, sourceFiber, error) {
      sourceFiber = createCapturedValueAtFiber(error, sourceFiber);
      sourceFiber = createRootErrorUpdate(rootFiber.stateNode, sourceFiber, 2);
      rootFiber = enqueueUpdate(rootFiber, sourceFiber, 2);
      rootFiber !== null && (markRootUpdated$1(rootFiber, 2), ensureRootIsScheduled(rootFiber));
    }
    function captureCommitPhaseError(sourceFiber, nearestMountedAncestor, error) {
      if (sourceFiber.tag === 3)
        captureCommitPhaseErrorOnRoot(sourceFiber, sourceFiber, error);
      else
        for (;nearestMountedAncestor !== null; ) {
          if (nearestMountedAncestor.tag === 3) {
            captureCommitPhaseErrorOnRoot(nearestMountedAncestor, sourceFiber, error);
            break;
          } else if (nearestMountedAncestor.tag === 1) {
            var instance = nearestMountedAncestor.stateNode;
            if (typeof nearestMountedAncestor.type.getDerivedStateFromError === "function" || typeof instance.componentDidCatch === "function" && (legacyErrorBoundariesThatAlreadyFailed === null || !legacyErrorBoundariesThatAlreadyFailed.has(instance))) {
              sourceFiber = createCapturedValueAtFiber(error, sourceFiber);
              error = createClassErrorUpdate(2);
              instance = enqueueUpdate(nearestMountedAncestor, error, 2);
              instance !== null && (initializeClassErrorUpdate(error, instance, nearestMountedAncestor, sourceFiber), markRootUpdated$1(instance, 2), ensureRootIsScheduled(instance));
              break;
            }
          }
          nearestMountedAncestor = nearestMountedAncestor.return;
        }
    }
    function attachPingListener(root, wakeable, lanes) {
      var pingCache = root.pingCache;
      if (pingCache === null) {
        pingCache = root.pingCache = new PossiblyWeakMap;
        var threadIDs = new Set;
        pingCache.set(wakeable, threadIDs);
      } else
        threadIDs = pingCache.get(wakeable), threadIDs === undefined && (threadIDs = new Set, pingCache.set(wakeable, threadIDs));
      threadIDs.has(lanes) || (workInProgressRootDidAttachPingListener = true, threadIDs.add(lanes), root = pingSuspendedRoot.bind(null, root, wakeable, lanes), wakeable.then(root, root));
    }
    function pingSuspendedRoot(root, wakeable, pingedLanes) {
      var pingCache = root.pingCache;
      pingCache !== null && pingCache.delete(wakeable);
      root.pingedLanes |= root.suspendedLanes & pingedLanes;
      root.warmLanes &= ~pingedLanes;
      workInProgressRoot === root && (workInProgressRootRenderLanes & pingedLanes) === pingedLanes && (workInProgressRootExitStatus === 4 || workInProgressRootExitStatus === 3 && (workInProgressRootRenderLanes & 62914560) === workInProgressRootRenderLanes && 300 > now() - globalMostRecentFallbackTime ? (executionContext & 2) === 0 ? prepareFreshStack(root, 0) : workInProgressRootPingedLanes |= pingedLanes : workInProgressRootPingedLanes |= pingedLanes, workInProgressSuspendedRetryLanes === workInProgressRootRenderLanes && (workInProgressSuspendedRetryLanes = 0));
      ensureRootIsScheduled(root);
    }
    function retryTimedOutBoundary(boundaryFiber, retryLane) {
      retryLane === 0 && (retryLane = claimNextRetryLane());
      boundaryFiber = enqueueConcurrentRenderForLane(boundaryFiber, retryLane);
      boundaryFiber !== null && (markRootUpdated$1(boundaryFiber, retryLane), ensureRootIsScheduled(boundaryFiber));
    }
    function retryDehydratedSuspenseBoundary(boundaryFiber) {
      var suspenseState = boundaryFiber.memoizedState, retryLane = 0;
      suspenseState !== null && (retryLane = suspenseState.retryLane);
      retryTimedOutBoundary(boundaryFiber, retryLane);
    }
    function resolveRetryWakeable(boundaryFiber, wakeable) {
      var retryLane = 0;
      switch (boundaryFiber.tag) {
        case 31:
        case 13:
          var retryCache = boundaryFiber.stateNode;
          var suspenseState = boundaryFiber.memoizedState;
          suspenseState !== null && (retryLane = suspenseState.retryLane);
          break;
        case 19:
          retryCache = boundaryFiber.stateNode;
          break;
        case 22:
          retryCache = boundaryFiber.stateNode._retryCache;
          break;
        default:
          throw Error(formatProdErrorMessage(314));
      }
      retryCache !== null && retryCache.delete(wakeable);
      retryTimedOutBoundary(boundaryFiber, retryLane);
    }
    function scheduleCallback(priorityLevel, callback) {
      return scheduleCallback$3(priorityLevel, callback);
    }
    function FiberNode(tag, pendingProps, key, mode) {
      this.tag = tag;
      this.key = key;
      this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
      this.index = 0;
      this.refCleanup = this.ref = null;
      this.pendingProps = pendingProps;
      this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
      this.mode = mode;
      this.subtreeFlags = this.flags = 0;
      this.deletions = null;
      this.childLanes = this.lanes = 0;
      this.alternate = null;
    }
    function shouldConstruct(Component) {
      Component = Component.prototype;
      return !(!Component || !Component.isReactComponent);
    }
    function createWorkInProgress(current, pendingProps) {
      var workInProgress = current.alternate;
      workInProgress === null ? (workInProgress = createFiber(current.tag, pendingProps, current.key, current.mode), workInProgress.elementType = current.elementType, workInProgress.type = current.type, workInProgress.stateNode = current.stateNode, workInProgress.alternate = current, current.alternate = workInProgress) : (workInProgress.pendingProps = pendingProps, workInProgress.type = current.type, workInProgress.flags = 0, workInProgress.subtreeFlags = 0, workInProgress.deletions = null);
      workInProgress.flags = current.flags & 1206910976;
      workInProgress.childLanes = current.childLanes;
      workInProgress.lanes = current.lanes;
      workInProgress.child = current.child;
      workInProgress.memoizedProps = current.memoizedProps;
      workInProgress.memoizedState = current.memoizedState;
      workInProgress.updateQueue = current.updateQueue;
      pendingProps = current.dependencies;
      workInProgress.dependencies = pendingProps === null ? null : {
        lanes: pendingProps.lanes,
        firstContext: pendingProps.firstContext
      };
      workInProgress.sibling = current.sibling;
      workInProgress.index = current.index;
      workInProgress.ref = current.ref;
      workInProgress.refCleanup = current.refCleanup;
      return workInProgress;
    }
    function resetWorkInProgress(workInProgress, renderLanes) {
      workInProgress.flags &= 1206910978;
      var current = workInProgress.alternate;
      current === null ? (workInProgress.childLanes = 0, workInProgress.lanes = renderLanes, workInProgress.child = null, workInProgress.subtreeFlags = 0, workInProgress.memoizedProps = null, workInProgress.memoizedState = null, workInProgress.updateQueue = null, workInProgress.dependencies = null, workInProgress.stateNode = null) : (workInProgress.childLanes = current.childLanes, workInProgress.lanes = current.lanes, workInProgress.child = current.child, workInProgress.subtreeFlags = 0, workInProgress.deletions = null, workInProgress.memoizedProps = current.memoizedProps, workInProgress.memoizedState = current.memoizedState, workInProgress.updateQueue = current.updateQueue, workInProgress.type = current.type, renderLanes = current.dependencies, workInProgress.dependencies = renderLanes === null ? null : {
        lanes: renderLanes.lanes,
        firstContext: renderLanes.firstContext
      });
      return workInProgress;
    }
    function createFiberFromTypeAndProps(type, key, pendingProps, owner, mode, lanes) {
      var fiberTag = 0;
      owner = type;
      if (typeof owner === "function")
        shouldConstruct(owner) && (fiberTag = 1);
      else if (typeof owner === "string")
        fiberTag = supportsResources && supportsSingletons ? isHostHoistableType(type, pendingProps, contextStackCursor.current) ? 26 : isHostSingletonType(type) ? 27 : 5 : supportsResources ? isHostHoistableType(type, pendingProps, contextStackCursor.current) ? 26 : 5 : supportsSingletons ? isHostSingletonType(type) ? 27 : 5 : 5;
      else
        a:
          switch (owner) {
            case REACT_ACTIVITY_TYPE:
              return type = createFiber(31, pendingProps, key, mode), type.elementType = REACT_ACTIVITY_TYPE, type.lanes = lanes, type;
            case REACT_FRAGMENT_TYPE:
              return createFiberFromFragment(pendingProps.children, mode, lanes, key);
            case REACT_STRICT_MODE_TYPE:
              fiberTag = 8;
              mode |= 24;
              break;
            case REACT_PROFILER_TYPE:
              return type = createFiber(12, pendingProps, key, mode | 2), type.elementType = REACT_PROFILER_TYPE, type.lanes = lanes, type;
            case REACT_SUSPENSE_TYPE:
              return type = createFiber(13, pendingProps, key, mode), type.elementType = REACT_SUSPENSE_TYPE, type.lanes = lanes, type;
            case REACT_SUSPENSE_LIST_TYPE:
              return type = createFiber(19, pendingProps, key, mode), type.elementType = REACT_SUSPENSE_LIST_TYPE, type.lanes = lanes, type;
            case REACT_LEGACY_HIDDEN_TYPE:
            case REACT_VIEW_TRANSITION_TYPE:
              return type = mode | 32, type = createFiber(30, pendingProps, key, type), type.elementType = REACT_VIEW_TRANSITION_TYPE, type.lanes = lanes, type.stateNode = {
                autoName: null,
                paired: null,
                clones: null,
                ref: null
              }, type;
            default:
              if (typeof owner === "object" && owner !== null)
                switch (owner.$$typeof) {
                  case REACT_CONTEXT_TYPE:
                    fiberTag = 10;
                    break a;
                  case REACT_CONSUMER_TYPE:
                    fiberTag = 9;
                    break a;
                  case REACT_FORWARD_REF_TYPE:
                    fiberTag = 11;
                    break a;
                  case REACT_MEMO_TYPE:
                    fiberTag = 14;
                    break a;
                  case REACT_LAZY_TYPE:
                    fiberTag = 16;
                    owner = null;
                    break a;
                }
              fiberTag = 29;
              pendingProps = Error(formatProdErrorMessage(130, type === null ? "null" : typeof type, ""));
              owner = null;
          }
      key = createFiber(fiberTag, pendingProps, key, mode);
      key.elementType = type;
      key.type = owner;
      key.lanes = lanes;
      return key;
    }
    function createFiberFromFragment(elements, mode, lanes, key) {
      elements = createFiber(7, elements, key, mode);
      elements.lanes = lanes;
      return elements;
    }
    function createFiberFromText(content, mode, lanes) {
      content = createFiber(6, content, null, mode);
      content.lanes = lanes;
      return content;
    }
    function createFiberFromDehydratedFragment(dehydratedNode) {
      var fiber = createFiber(18, null, null, 0);
      fiber.stateNode = dehydratedNode;
      return fiber;
    }
    function createFiberFromPortal(portal, mode, lanes) {
      mode = createFiber(4, portal.children !== null ? portal.children : [], portal.key, mode);
      mode.lanes = lanes;
      mode.stateNode = {
        containerInfo: portal.containerInfo,
        pendingChildren: null,
        implementation: portal.implementation
      };
      return mode;
    }
    function FiberRootNode(containerInfo, tag, hydrate, identifierPrefix, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator, formState) {
      this.tag = 1;
      this.containerInfo = containerInfo;
      this.pingCache = this.current = this.pendingChildren = null;
      this.timeoutHandle = noTimeout;
      this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null;
      this.callbackPriority = 0;
      this.expirationTimes = createLaneMap(-1);
      this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
      this.entanglements = createLaneMap(0);
      this.hiddenUpdates = createLaneMap(null);
      this.identifierPrefix = identifierPrefix;
      this.onUncaughtError = onUncaughtError;
      this.onCaughtError = onCaughtError;
      this.onRecoverableError = onRecoverableError;
      this.pooledCache = null;
      this.pooledCacheLanes = 0;
      this.formState = formState;
      this.transitionTypes = null;
      this.incompleteTransitions = new Map;
    }
    function createFiberRoot(containerInfo, tag, hydrate, initialChildren, hydrationCallbacks, isStrictMode, identifierPrefix, formState, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator) {
      containerInfo = new FiberRootNode(containerInfo, tag, hydrate, identifierPrefix, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator, formState);
      tag = 1;
      isStrictMode === true && (tag |= 24);
      isStrictMode = createFiber(3, null, null, tag);
      containerInfo.current = isStrictMode;
      isStrictMode.stateNode = containerInfo;
      tag = createCache();
      tag.refCount++;
      containerInfo.pooledCache = tag;
      tag.refCount++;
      isStrictMode.memoizedState = {
        element: initialChildren,
        isDehydrated: hydrate,
        cache: tag
      };
      initializeUpdateQueue(isStrictMode);
      return containerInfo;
    }
    function getContextForSubtree(parentComponent) {
      if (!parentComponent)
        return emptyContextObject;
      parentComponent = emptyContextObject;
      return parentComponent;
    }
    function findHostInstance(component) {
      var fiber = component._reactInternals;
      if (fiber === undefined) {
        if (typeof component.render === "function")
          throw Error(formatProdErrorMessage(188));
        component = Object.keys(component).join(",");
        throw Error(formatProdErrorMessage(268, component));
      }
      component = findCurrentFiberUsingSlowPath(fiber);
      component = component !== null ? findCurrentHostFiberImpl(component) : null;
      return component === null ? null : getPublicInstance(component.stateNode);
    }
    function updateContainerImpl(rootFiber, lane, element, container, parentComponent, callback) {
      parentComponent = getContextForSubtree(parentComponent);
      container.context === null ? container.context = parentComponent : container.pendingContext = parentComponent;
      container = createUpdate(lane);
      container.payload = { element };
      callback = callback === undefined ? null : callback;
      callback !== null && (container.callback = callback);
      element = enqueueUpdate(rootFiber, container, lane);
      element !== null && (scheduleUpdateOnFiber(element, rootFiber, lane), entangleTransitions(element, rootFiber, lane));
    }
    function markRetryLaneImpl(fiber, retryLane) {
      fiber = fiber.memoizedState;
      if (fiber !== null && fiber.dehydrated !== null) {
        var a = fiber.retryLane;
        fiber.retryLane = a !== 0 && a < retryLane ? a : retryLane;
      }
    }
    function markRetryLaneIfNotHydrated(fiber, retryLane) {
      markRetryLaneImpl(fiber, retryLane);
      (fiber = fiber.alternate) && markRetryLaneImpl(fiber, retryLane);
    }
    var exports2 = {};
    var assign = Object.assign, REACT_LEGACY_ELEMENT_TYPE = Symbol.for("react.element"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy");
    Symbol.for("react.scope");
    var REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_LEGACY_HIDDEN_TYPE = Symbol.for("react.legacy_hidden");
    Symbol.for("react.tracing_marker");
    var REACT_MEMO_CACHE_SENTINEL = Symbol.for("react.memo_cache_sentinel"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_RECOVERABLE_TYPE = Symbol.for("react.recoverable"), MAYBE_ITERATOR_SYMBOL = Symbol.iterator, REACT_OPTIMISTIC_KEY = Symbol.for("react.optimistic_key"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), isArrayImpl = Array.isArray, ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, { rendererVersion, rendererPackageName, extraDevToolsConfig, getPublicInstance, getRootHostContext, getChildHostContext, prepareForCommit, resetAfterCommit, createInstance } = $$$config;
    $$$config.cloneMutableInstance;
    var { appendInitialChild, finalizeInitialChildren, shouldSetTextContent, createTextInstance } = $$$config;
    $$$config.cloneMutableTextInstance;
    var { scheduleTimeout, cancelTimeout, noTimeout, isPrimaryRenderer } = $$$config;
    $$$config.warnsIfNotActing;
    var { supportsMutation, supportsPersistence, supportsHydration, getInstanceFromNode } = $$$config;
    $$$config.beforeActiveInstanceBlur;
    var preparePortalMount = $$$config.preparePortalMount;
    $$$config.prepareScopeUpdate;
    $$$config.getInstanceFromScope;
    var { setCurrentUpdatePriority, getCurrentUpdatePriority, resolveUpdatePriority } = $$$config;
    $$$config.trackSchedulerEvent;
    $$$config.resolveEventType;
    $$$config.resolveEventTimeStamp;
    var { shouldAttemptEagerTransition, detachDeletedInstance } = $$$config;
    $$$config.requestPostPaintCallback;
    var { maySuspendCommit, maySuspendCommitOnUpdate, maySuspendCommitInSyncRender, preloadInstance, startSuspendingCommit, suspendInstance, suspendOnActiveViewTransition, waitForCommitToBeReady } = $$$config;
    $$$config.getSuspendedCommitReason;
    var { NotPendingTransition, HostTransitionContext, resetFormInstance } = $$$config;
    $$$config.bindToConsole;
    var { supportsMicrotasks, scheduleMicrotask, supportsTestSelectors, findFiberRoot, getBoundingRect, getTextContent, isHiddenSubtree, matchAccessibilityRole, setFocusIfFocusable, setupIntersectionObserver, appendChild, appendChildToContainer, commitTextUpdate, commitMount, commitUpdate, insertBefore, insertInContainerBefore, removeChild, removeChildFromContainer, resetTextContent, hideInstance, hideTextInstance, unhideInstance, unhideTextInstance, applyViewTransitionName, restoreViewTransitionName, cancelViewTransitionName, cancelRootViewTransitionName, restoreRootViewTransitionName } = $$$config;
    $$$config.cloneRootViewTransitionContainer;
    $$$config.removeRootViewTransitionClone;
    var { measureInstance, measureClonedInstance, wasInstanceInViewport, hasInstanceChanged, hasInstanceAffectedParent, startViewTransition } = $$$config;
    $$$config.startGestureTransition;
    var { stopViewTransition, addViewTransitionFinishedListener } = $$$config;
    $$$config.getCurrentGestureOffset;
    var { createViewTransitionInstance, clearContainer, createFragmentInstance, updateFragmentInstanceFiber, commitNewChildToFragmentInstance, deleteChildFromFragmentInstance, cloneInstance, createContainerChildSet, appendChildToContainerChildSet, finalizeContainerChildren, replaceContainerChildren, cloneHiddenInstance, cloneHiddenTextInstance, isSuspenseInstancePending, isSuspenseInstanceFallback, getSuspenseInstanceFallbackErrorDetails, registerSuspenseInstanceRetry, canHydrateFormStateMarker, isFormStateMarkerMatching, getNextHydratableSibling, getNextHydratableSiblingAfterSingleton, getFirstHydratableChild, getFirstHydratableChildWithinContainer, getFirstHydratableChildWithinActivityInstance, getFirstHydratableChildWithinSuspenseInstance, getFirstHydratableChildWithinSingleton, canHydrateInstance, canHydrateTextInstance, canHydrateActivityInstance, canHydrateSuspenseInstance, hydrateInstance, hydrateTextInstance, hydrateActivityInstance, hydrateSuspenseInstance, getNextHydratableInstanceAfterActivityInstance, getNextHydratableInstanceAfterSuspenseInstance, commitHydratedInstance, commitHydratedContainer, commitHydratedActivityInstance, commitHydratedSuspenseInstance, finalizeHydratedChildren, flushHydrationEvents } = $$$config;
    $$$config.clearActivityBoundary;
    var clearSuspenseBoundary = $$$config.clearSuspenseBoundary;
    $$$config.clearActivityBoundaryFromContainer;
    var { clearSuspenseBoundaryFromContainer, hideDehydratedBoundary, unhideDehydratedBoundary, shouldDeleteUnhydratedTailInstances } = $$$config;
    $$$config.diffHydratedPropsForDevWarnings;
    $$$config.diffHydratedTextForDevWarnings;
    $$$config.describeHydratableInstanceForDevWarnings;
    var { validateHydratableInstance, validateHydratableTextInstance, supportsResources, isHostHoistableType, getHoistableRoot, getResource, acquireResource, releaseResource, hydrateHoistable, mountHoistable, unmountHoistable, createHoistableInstance, prepareToCommitHoistables, mayResourceSuspendCommit, preloadResource, suspendResource, supportsSingletons, resolveSingletonInstance, acquireSingletonInstance, releaseSingletonInstance, isHostSingletonType, isSingletonScope } = $$$config, valueStack = [], index$jscomp$0 = -1, emptyContextObject = {}, clz32 = Math.clz32 ? Math.clz32 : clz32Fallback, { log: log$1, LN2 } = Math, nextTransitionUpdateLane = 256, nextTransitionDeferredLane = 262144, nextRetryLane = 4194304, scheduleCallback$3 = Scheduler.unstable_scheduleCallback, cancelCallback$1 = Scheduler.unstable_cancelCallback, shouldYield = Scheduler.unstable_shouldYield, requestPaint = Scheduler.unstable_requestPaint, now = Scheduler.unstable_now, ImmediatePriority = Scheduler.unstable_ImmediatePriority, UserBlockingPriority = Scheduler.unstable_UserBlockingPriority, NormalPriority$1 = Scheduler.unstable_NormalPriority, IdlePriority = Scheduler.unstable_IdlePriority, log2 = Scheduler.log, unstable_setDisableYieldValue2 = Scheduler.unstable_setDisableYieldValue, rendererID = null, injectedHook = null, globalClientIdCounter$1 = 0, objectIs = typeof Object.is === "function" ? Object.is : is, reportGlobalError = typeof reportError === "function" ? reportError : function(error) {
      if (typeof window === "object" && typeof window.ErrorEvent === "function") {
        var event = new window.ErrorEvent("error", {
          bubbles: true,
          cancelable: true,
          message: typeof error === "object" && error !== null && typeof error.message === "string" ? String(error.message) : String(error),
          error
        });
        if (!window.dispatchEvent(event))
          return;
      } else if (typeof process === "object" && typeof process.emit === "function") {
        process.emit("uncaughtException", error);
        return;
      }
      console.error(error);
    }, hasOwnProperty = Object.prototype.hasOwnProperty, prefix, suffix, reentry = false, CapturedStacks = new WeakMap, forkStack = [], forkStackIndex = 0, treeForkProvider = null, treeForkCount = 0, idStack = [], idStackIndex = 0, treeContextProvider = null, treeContextId = 1, treeContextOverflow = "", contextStackCursor = createCursor(null), contextFiberStackCursor = createCursor(null), rootInstanceStackCursor = createCursor(null), hostTransitionProviderCursor = createCursor(null), hydrationParentFiber = null, nextHydratableInstance = null, isHydrating = false, hydrationErrors = null, rootOrSingletonContext = false, HydrationMismatchException = Error(formatProdErrorMessage(519)), valueCursor = createCursor(null), currentlyRenderingFiber$1 = null, lastContextDependency = null, AbortControllerLocal = typeof AbortController !== "undefined" ? AbortController : function() {
      var listeners = [], signal = this.signal = {
        aborted: false,
        addEventListener: function(type, listener) {
          listeners.push(listener);
        }
      };
      this.abort = function() {
        signal.aborted = true;
        listeners.forEach(function(listener) {
          return listener();
        });
      };
    }, scheduleCallback$2 = Scheduler.unstable_scheduleCallback, NormalPriority = Scheduler.unstable_NormalPriority, CacheContext = {
      $$typeof: REACT_CONTEXT_TYPE,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0
    }, entangledTransitionTypes = null, firstScheduledRoot = null, lastScheduledRoot = null, didScheduleMicrotask = false, mightHavePendingSyncWork = false, isFlushingWork = false, currentEventTransitionLane = 0, currentEntangledListeners = null, currentEntangledPendingCount = 0, currentEntangledLane = 0, currentEntangledActionThenable = null, prevOnStartTransitionFinish = ReactSharedInternals.S;
    ReactSharedInternals.S = function(transition, returnValue) {
      globalMostRecentTransitionTime = now();
      typeof returnValue === "object" && returnValue !== null && typeof returnValue.then === "function" && entangleAsyncAction(transition, returnValue);
      if (entangledTransitionTypes !== null)
        for (var root = firstScheduledRoot;root !== null; )
          queueTransitionTypes(root, entangledTransitionTypes), root = root.next;
      root = transition.types;
      if (root !== null) {
        for (var root$19 = firstScheduledRoot;root$19 !== null; )
          queueTransitionTypes(root$19, root), root$19 = root$19.next;
        if (currentEntangledLane !== 0) {
          root$19 = entangledTransitionTypes;
          root$19 === null && (root$19 = entangledTransitionTypes = []);
          for (var i = 0;i < root.length; i++) {
            var transitionType = root[i];
            root$19.indexOf(transitionType) === -1 && root$19.push(transitionType);
          }
        }
      }
      prevOnStartTransitionFinish !== null && prevOnStartTransitionFinish(transition, returnValue);
    };
    var resumedCache = createCursor(null), SuspenseException = Error(formatProdErrorMessage(460)), SuspenseyCommitException = Error(formatProdErrorMessage(474)), SuspenseActionException = Error(formatProdErrorMessage(542)), noopSuspenseyCommitThenable = { then: function() {} }, suspendedThenable = null, thenableState$1 = null, thenableIndexCounter$1 = 0, reconcileChildFibers = createChildReconciler(true), mountChildFibers = createChildReconciler(false), concurrentQueues = [], concurrentQueuesIndex = 0, concurrentlyUpdatedLanes = 0, hasForceUpdate = false, didReadFromEntangledAsyncAction = false, currentTreeHiddenStackCursor = createCursor(null), prevEntangledRenderLanesCursor = createCursor(0), suspenseHandlerStackCursor = createCursor(null), shellBoundary = null, suspenseStackCursor = createCursor(0), renderLanes = 0, currentlyRenderingFiber = null, currentHook = null, workInProgressHook = null, didScheduleRenderPhaseUpdate = false, didScheduleRenderPhaseUpdateDuringThisPass = false, shouldDoubleInvokeUserFnsInHooksDEV = false, localIdCounter = 0, thenableIndexCounter = 0, thenableState = null, globalClientIdCounter = 0, ContextOnlyDispatcher = {
      readContext,
      use,
      useCallback: throwInvalidHookError,
      useContext: throwInvalidHookError,
      useEffect: throwInvalidHookError,
      useImperativeHandle: throwInvalidHookError,
      useLayoutEffect: throwInvalidHookError,
      useInsertionEffect: throwInvalidHookError,
      useMemo: throwInvalidHookError,
      useReducer: throwInvalidHookError,
      useRef: throwInvalidHookError,
      useState: throwInvalidHookError,
      useDebugValue: throwInvalidHookError,
      useDeferredValue: throwInvalidHookError,
      useTransition: throwInvalidHookError,
      useSyncExternalStore: throwInvalidHookError,
      useId: throwInvalidHookError,
      useHostTransitionStatus: throwInvalidHookError,
      useFormState: throwInvalidHookError,
      useActionState: throwInvalidHookError,
      useOptimistic: throwInvalidHookError,
      useMemoCache: throwInvalidHookError,
      useCacheRefresh: throwInvalidHookError,
      useEffectEvent: throwInvalidHookError
    }, HooksDispatcherOnMount = {
      readContext,
      use,
      useCallback: function(callback, deps) {
        mountWorkInProgressHook().memoizedState = [
          callback,
          deps === undefined ? null : deps
        ];
        return callback;
      },
      useContext: readContext,
      useEffect: mountEffect,
      useImperativeHandle: function(ref, create, deps) {
        deps = deps !== null && deps !== undefined ? deps.concat([ref]) : null;
        mountEffectImpl(4194308, 4, imperativeHandleEffect.bind(null, create, ref), deps);
      },
      useLayoutEffect: function(create, deps) {
        return mountEffectImpl(4194308, 4, create, deps);
      },
      useInsertionEffect: function(create, deps) {
        mountEffectImpl(4, 2, create, deps);
      },
      useMemo: function(nextCreate, deps) {
        var hook = mountWorkInProgressHook();
        deps = deps === undefined ? null : deps;
        var nextValue = nextCreate();
        if (shouldDoubleInvokeUserFnsInHooksDEV) {
          setIsStrictModeForDevtools(true);
          try {
            nextCreate();
          } finally {
            setIsStrictModeForDevtools(false);
          }
        }
        hook.memoizedState = [nextValue, deps];
        return nextValue;
      },
      useReducer: function(reducer, initialArg, init) {
        var hook = mountWorkInProgressHook();
        if (init !== undefined) {
          var initialState = init(initialArg);
          if (shouldDoubleInvokeUserFnsInHooksDEV) {
            setIsStrictModeForDevtools(true);
            try {
              init(initialArg);
            } finally {
              setIsStrictModeForDevtools(false);
            }
          }
        } else
          initialState = initialArg;
        hook.memoizedState = hook.baseState = initialState;
        reducer = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: reducer,
          lastRenderedState: initialState
        };
        hook.queue = reducer;
        reducer = reducer.dispatch = dispatchReducerAction.bind(null, currentlyRenderingFiber, reducer);
        return [hook.memoizedState, reducer];
      },
      useRef: function(initialValue) {
        var hook = mountWorkInProgressHook();
        initialValue = { current: initialValue };
        return hook.memoizedState = initialValue;
      },
      useState: function(initialState) {
        initialState = mountStateImpl(initialState);
        var queue = initialState.queue, dispatch = dispatchSetState.bind(null, currentlyRenderingFiber, queue);
        queue.dispatch = dispatch;
        return [initialState.memoizedState, dispatch];
      },
      useDebugValue: mountDebugValue,
      useDeferredValue: function(value, initialValue) {
        var hook = mountWorkInProgressHook();
        return mountDeferredValueImpl(hook, value, initialValue);
      },
      useTransition: function() {
        var stateHook = mountStateImpl(false);
        stateHook = startTransition.bind(null, currentlyRenderingFiber, stateHook.queue, true, false);
        mountWorkInProgressHook().memoizedState = stateHook;
        return [false, stateHook];
      },
      useSyncExternalStore: function(subscribe, getSnapshot, getServerSnapshot) {
        var fiber = currentlyRenderingFiber, hook = mountWorkInProgressHook();
        if (isHydrating) {
          if (getServerSnapshot === undefined)
            throw Error(formatProdErrorMessage(407));
          getServerSnapshot = getServerSnapshot();
        } else {
          getServerSnapshot = getSnapshot();
          if (workInProgressRoot === null)
            throw Error(formatProdErrorMessage(349));
          (workInProgressRootRenderLanes & 127) !== 0 || pushStoreConsistencyCheck(fiber, getSnapshot, getServerSnapshot);
        }
        hook.memoizedState = getServerSnapshot;
        var inst = { value: getServerSnapshot, getSnapshot };
        hook.queue = inst;
        mountEffect(subscribeToStore.bind(null, fiber, inst, subscribe), [
          subscribe
        ]);
        fiber.flags |= 2048;
        pushSimpleEffect(9, { destroy: undefined }, updateStoreInstance.bind(null, fiber, inst, getServerSnapshot, getSnapshot), null);
        return getServerSnapshot;
      },
      useId: function() {
        var hook = mountWorkInProgressHook(), identifierPrefix = workInProgressRoot.identifierPrefix;
        if (isHydrating) {
          var JSCompiler_inline_result = treeContextOverflow;
          var idWithLeadingBit = treeContextId;
          JSCompiler_inline_result = (idWithLeadingBit & ~(1 << 32 - clz32(idWithLeadingBit) - 1)).toString(32) + JSCompiler_inline_result;
          identifierPrefix = "_" + identifierPrefix + "R_" + JSCompiler_inline_result;
          JSCompiler_inline_result = localIdCounter++;
          0 < JSCompiler_inline_result && (identifierPrefix += "H" + JSCompiler_inline_result.toString(32));
          identifierPrefix += "_";
        } else
          JSCompiler_inline_result = globalClientIdCounter++, identifierPrefix = "_" + identifierPrefix + "r_" + JSCompiler_inline_result.toString(32) + "_";
        return hook.memoizedState = identifierPrefix;
      },
      useHostTransitionStatus,
      useFormState: mountActionState,
      useActionState: mountActionState,
      useOptimistic: function(passthrough) {
        var hook = mountWorkInProgressHook();
        hook.memoizedState = hook.baseState = passthrough;
        var queue = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: null,
          lastRenderedState: null
        };
        hook.queue = queue;
        hook = dispatchOptimisticSetState.bind(null, currentlyRenderingFiber, true, queue);
        queue.dispatch = hook;
        return [passthrough, hook];
      },
      useMemoCache,
      useCacheRefresh: function() {
        return mountWorkInProgressHook().memoizedState = refreshCache.bind(null, currentlyRenderingFiber);
      },
      useEffectEvent: function(callback) {
        var hook = mountWorkInProgressHook(), ref = { impl: callback };
        hook.memoizedState = ref;
        return function() {
          if ((executionContext & 2) !== 0)
            throw Error(formatProdErrorMessage(440));
          return ref.impl.apply(undefined, arguments);
        };
      }
    }, HooksDispatcherOnUpdate = {
      readContext,
      use,
      useCallback: updateCallback,
      useContext: readContext,
      useEffect: updateEffect,
      useImperativeHandle: updateImperativeHandle,
      useInsertionEffect: updateInsertionEffect,
      useLayoutEffect: updateLayoutEffect,
      useMemo: updateMemo,
      useReducer: updateReducer,
      useRef: updateRef,
      useState: function() {
        return updateReducer(basicStateReducer);
      },
      useDebugValue: mountDebugValue,
      useDeferredValue: function(value, initialValue) {
        var hook = updateWorkInProgressHook();
        return updateDeferredValueImpl(hook, currentHook.memoizedState, value, initialValue);
      },
      useTransition: function() {
        var booleanOrThenable = updateReducer(basicStateReducer)[0], start = updateWorkInProgressHook().memoizedState;
        return [
          typeof booleanOrThenable === "boolean" ? booleanOrThenable : useThenable(booleanOrThenable),
          start
        ];
      },
      useSyncExternalStore: updateSyncExternalStore,
      useId: updateId,
      useHostTransitionStatus,
      useFormState: updateActionState,
      useActionState: updateActionState,
      useOptimistic: function(passthrough, reducer) {
        var hook = updateWorkInProgressHook();
        return updateOptimisticImpl(hook, currentHook, passthrough, reducer);
      },
      useMemoCache,
      useCacheRefresh: updateRefresh,
      useEffectEvent: updateEvent
    }, HooksDispatcherOnRerender = {
      readContext,
      use,
      useCallback: updateCallback,
      useContext: readContext,
      useEffect: updateEffect,
      useImperativeHandle: updateImperativeHandle,
      useInsertionEffect: updateInsertionEffect,
      useLayoutEffect: updateLayoutEffect,
      useMemo: updateMemo,
      useReducer: rerenderReducer,
      useRef: updateRef,
      useState: function() {
        return rerenderReducer(basicStateReducer);
      },
      useDebugValue: mountDebugValue,
      useDeferredValue: function(value, initialValue) {
        var hook = updateWorkInProgressHook();
        return currentHook === null ? mountDeferredValueImpl(hook, value, initialValue) : updateDeferredValueImpl(hook, currentHook.memoizedState, value, initialValue);
      },
      useTransition: function() {
        var booleanOrThenable = rerenderReducer(basicStateReducer)[0], start = updateWorkInProgressHook().memoizedState;
        return [
          typeof booleanOrThenable === "boolean" ? booleanOrThenable : useThenable(booleanOrThenable),
          start
        ];
      },
      useSyncExternalStore: updateSyncExternalStore,
      useId: updateId,
      useHostTransitionStatus,
      useFormState: rerenderActionState,
      useActionState: rerenderActionState,
      useOptimistic: function(passthrough, reducer) {
        var hook = updateWorkInProgressHook();
        if (currentHook !== null)
          return updateOptimisticImpl(hook, currentHook, passthrough, reducer);
        hook.baseState = passthrough;
        return [passthrough, hook.queue.dispatch];
      },
      useMemoCache,
      useCacheRefresh: updateRefresh,
      useEffectEvent: updateEvent
    }, classComponentUpdater = {
      enqueueSetState: function(inst, payload, callback) {
        inst = inst._reactInternals;
        var lane = requestUpdateLane(), update = createUpdate(lane);
        update.payload = payload;
        callback !== undefined && callback !== null && (update.callback = callback);
        payload = enqueueUpdate(inst, update, lane);
        payload !== null && (scheduleUpdateOnFiber(payload, inst, lane), entangleTransitions(payload, inst, lane));
      },
      enqueueReplaceState: function(inst, payload, callback) {
        inst = inst._reactInternals;
        var lane = requestUpdateLane(), update = createUpdate(lane);
        update.tag = 1;
        update.payload = payload;
        callback !== undefined && callback !== null && (update.callback = callback);
        payload = enqueueUpdate(inst, update, lane);
        payload !== null && (scheduleUpdateOnFiber(payload, inst, lane), entangleTransitions(payload, inst, lane));
      },
      enqueueForceUpdate: function(inst, callback) {
        inst = inst._reactInternals;
        var lane = requestUpdateLane(), update = createUpdate(lane);
        update.tag = 2;
        callback !== undefined && callback !== null && (update.callback = callback);
        callback = enqueueUpdate(inst, update, lane);
        callback !== null && (scheduleUpdateOnFiber(callback, inst, lane), entangleTransitions(callback, inst, lane));
      }
    }, SelectiveHydrationException = Error(formatProdErrorMessage(461)), didReceiveUpdate = false, SUSPENDED_MARKER = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0,
      hydrationErrors: null
    }, viewTransitionMutationContext = false, shouldStartViewTransition = false, appearingViewTransitions = null, viewTransitionCancelableChildren = null, viewTransitionHostInstanceIdx = 0, offscreenSubtreeIsHidden = false, offscreenSubtreeWasHidden = false, offscreenDirectParentIsHidden = false, needsFormReset = false, PossiblyWeakSet = typeof WeakSet === "function" ? WeakSet : Set, nextEffect = null, viewTransitionContextChanged = false, inUpdateViewTransition = false, rootViewTransitionAffected = false, rootViewTransitionNameCanceled = false, hostParent = null, hostParentIsContainer = false, currentHoistableRoot = null, suspenseyCommitFlag = 8192, DefaultAsyncDispatcher = {
      getCacheForType: function(resourceType) {
        var cache = readContext(CacheContext), cacheForType = cache.data.get(resourceType);
        cacheForType === undefined && (cacheForType = resourceType(), cache.data.set(resourceType, cacheForType));
        return cacheForType;
      },
      cacheSignal: function() {
        return readContext(CacheContext).controller.signal;
      }
    }, COMPONENT_TYPE = 0, HAS_PSEUDO_CLASS_TYPE = 1, ROLE_TYPE = 2, TEST_NAME_TYPE = 3, TEXT_TYPE = 4;
    if (typeof Symbol === "function" && Symbol.for) {
      var symbolFor = Symbol.for;
      COMPONENT_TYPE = symbolFor("selector.component");
      HAS_PSEUDO_CLASS_TYPE = symbolFor("selector.has_pseudo_class");
      ROLE_TYPE = symbolFor("selector.role");
      TEST_NAME_TYPE = symbolFor("selector.test_id");
      TEXT_TYPE = symbolFor("selector.text");
    }
    var PossiblyWeakMap = typeof WeakMap === "function" ? WeakMap : Map, executionContext = 0, workInProgressRoot = null, workInProgress = null, workInProgressRootRenderLanes = 0, workInProgressSuspendedReason = 0, workInProgressThrownValue = null, workInProgressRootDidSkipSuspendedSiblings = false, workInProgressRootIsPrerendering = false, workInProgressRootDidAttachPingListener = false, entangledRenderLanes = 0, workInProgressRootExitStatus = 0, workInProgressRootSkippedLanes = 0, workInProgressRootInterleavedUpdatedLanes = 0, workInProgressRootPingedLanes = 0, workInProgressDeferredLane = 0, workInProgressSuspendedRetryLanes = 0, workInProgressRootConcurrentErrors = null, workInProgressRootRecoverableErrors = null, workInProgressRootDidIncludeRecursiveRenderUpdate = false, globalMostRecentFallbackTime = 0, globalMostRecentTransitionTime = 0, workInProgressRootRenderTargetTime = Infinity, workInProgressTransitions = null, legacyErrorBoundariesThatAlreadyFailed = null, pendingEffectsStatus = 0, pendingEffectsRoot = null, pendingFinishedWork = null, pendingEffectsLanes = 0, pendingEffectsRemainingLanes = 0, pendingPassiveTransitions = null, pendingRecoverableErrors = null, pendingViewTransition = null, pendingViewTransitionEvents = null, pendingTransitionTypes = null, nestedUpdateCount = 0, rootWithNestedUpdates = null;
    exports2.attemptContinuousHydration = function(fiber) {
      if (fiber.tag === 13 || fiber.tag === 31) {
        var root = enqueueConcurrentRenderForLane(fiber, 67108864);
        root !== null && scheduleUpdateOnFiber(root, fiber, 67108864);
        markRetryLaneIfNotHydrated(fiber, 67108864);
      }
    };
    exports2.attemptHydrationAtCurrentPriority = function(fiber) {
      if (fiber.tag === 13 || fiber.tag === 31) {
        var lane = requestUpdateLane();
        lane = getBumpedLaneForHydrationByLane(lane);
        var root = enqueueConcurrentRenderForLane(fiber, lane);
        root !== null && scheduleUpdateOnFiber(root, fiber, lane);
        markRetryLaneIfNotHydrated(fiber, lane);
      }
    };
    exports2.attemptSynchronousHydration = function(fiber) {
      switch (fiber.tag) {
        case 3:
          fiber = fiber.stateNode;
          if (fiber.current.memoizedState.isDehydrated) {
            var lanes = getHighestPriorityLanes(fiber.pendingLanes);
            if (lanes !== 0) {
              fiber.pendingLanes |= 2;
              for (fiber.entangledLanes |= 2;lanes; ) {
                var lane = 1 << 31 - clz32(lanes);
                fiber.entanglements[1] |= lane;
                lanes &= ~lane;
              }
              ensureRootIsScheduled(fiber);
              (executionContext & 6) === 0 && (workInProgressRootRenderTargetTime = now() + 500, flushSyncWorkAcrossRoots_impl(0, false));
            }
          }
          break;
        case 31:
        case 13:
          lanes = enqueueConcurrentRenderForLane(fiber, 2), lanes !== null && scheduleUpdateOnFiber(lanes, fiber, 2), flushSyncWork(), markRetryLaneIfNotHydrated(fiber, 2);
      }
    };
    exports2.batchedUpdates = function(fn, a) {
      return fn(a);
    };
    exports2.createComponentSelector = function(component) {
      return { $$typeof: COMPONENT_TYPE, value: component };
    };
    exports2.createContainer = function(containerInfo, tag, hydrationCallbacks, isStrictMode, concurrentUpdatesByDefaultOverride, identifierPrefix, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator) {
      return createFiberRoot(containerInfo, tag, false, null, hydrationCallbacks, isStrictMode, identifierPrefix, null, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator);
    };
    exports2.createHasPseudoClassSelector = function(selectors) {
      return { $$typeof: HAS_PSEUDO_CLASS_TYPE, value: selectors };
    };
    exports2.createHydrationContainer = function(initialChildren, callback, containerInfo, tag, hydrationCallbacks, isStrictMode, concurrentUpdatesByDefaultOverride, identifierPrefix, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator, transitionCallbacks, formState) {
      initialChildren = createFiberRoot(containerInfo, tag, true, initialChildren, hydrationCallbacks, isStrictMode, identifierPrefix, formState, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator);
      initialChildren.context = getContextForSubtree(null);
      containerInfo = initialChildren.current;
      tag = requestUpdateLane();
      tag = getBumpedLaneForHydrationByLane(tag);
      hydrationCallbacks = createUpdate(tag);
      hydrationCallbacks.callback = callback !== undefined && callback !== null ? callback : null;
      enqueueUpdate(containerInfo, hydrationCallbacks, tag);
      callback = tag;
      initialChildren.current.lanes = callback;
      markRootUpdated$1(initialChildren, callback);
      ensureRootIsScheduled(initialChildren);
      return initialChildren;
    };
    exports2.createPortal = function(children, containerInfo, implementation) {
      var key = 3 < arguments.length && arguments[3] !== undefined ? arguments[3] : null;
      return {
        $$typeof: REACT_PORTAL_TYPE,
        key: key == null ? null : key === REACT_OPTIMISTIC_KEY ? REACT_OPTIMISTIC_KEY : "" + key,
        children,
        containerInfo,
        implementation
      };
    };
    exports2.createRoleSelector = function(role) {
      return { $$typeof: ROLE_TYPE, value: role };
    };
    exports2.createTestNameSelector = function(id) {
      return { $$typeof: TEST_NAME_TYPE, value: id };
    };
    exports2.createTextSelector = function(text) {
      return { $$typeof: TEXT_TYPE, value: text };
    };
    exports2.defaultOnCaughtError = function(error) {
      console.error(error);
    };
    exports2.defaultOnRecoverableError = function(error) {
      reportGlobalError(error);
    };
    exports2.defaultOnUncaughtError = function(error) {
      reportGlobalError(error);
    };
    exports2.deferredUpdates = function(fn) {
      var prevTransition = ReactSharedInternals.T, previousPriority = getCurrentUpdatePriority();
      try {
        return setCurrentUpdatePriority(32), ReactSharedInternals.T = null, fn();
      } finally {
        setCurrentUpdatePriority(previousPriority), ReactSharedInternals.T = prevTransition;
      }
    };
    exports2.discreteUpdates = function(fn, a, b, c, d) {
      var prevTransition = ReactSharedInternals.T, previousPriority = getCurrentUpdatePriority();
      try {
        return setCurrentUpdatePriority(2), ReactSharedInternals.T = null, fn(a, b, c, d);
      } finally {
        setCurrentUpdatePriority(previousPriority), ReactSharedInternals.T = prevTransition, executionContext === 0 && (workInProgressRootRenderTargetTime = now() + 500);
      }
    };
    exports2.findAllNodes = findAllNodes;
    exports2.findBoundingRects = function(hostRoot, selectors) {
      if (!supportsTestSelectors)
        throw Error(formatProdErrorMessage(363));
      selectors = findAllNodes(hostRoot, selectors);
      hostRoot = [];
      for (var i = 0;i < selectors.length; i++)
        hostRoot.push(getBoundingRect(selectors[i]));
      for (selectors = hostRoot.length - 1;0 < selectors; selectors--) {
        i = hostRoot[selectors];
        for (var targetLeft = i.x, targetRight = targetLeft + i.width, targetTop = i.y, targetBottom = targetTop + i.height, j = selectors - 1;0 <= j; j--)
          if (selectors !== j) {
            var otherRect = hostRoot[j], otherLeft = otherRect.x, otherRight = otherLeft + otherRect.width, otherTop = otherRect.y, otherBottom = otherTop + otherRect.height;
            if (targetLeft >= otherLeft && targetTop >= otherTop && targetRight <= otherRight && targetBottom <= otherBottom) {
              hostRoot.splice(selectors, 1);
              break;
            } else if (!(targetLeft !== otherLeft || i.width !== otherRect.width || otherBottom < targetTop || otherTop > targetBottom)) {
              otherTop > targetTop && (otherRect.height += otherTop - targetTop, otherRect.y = targetTop);
              otherBottom < targetBottom && (otherRect.height = targetBottom - otherTop);
              hostRoot.splice(selectors, 1);
              break;
            } else if (!(targetTop !== otherTop || i.height !== otherRect.height || otherRight < targetLeft || otherLeft > targetRight)) {
              otherLeft > targetLeft && (otherRect.width += otherLeft - targetLeft, otherRect.x = targetLeft);
              otherRight < targetRight && (otherRect.width = targetRight - otherLeft);
              hostRoot.splice(selectors, 1);
              break;
            }
          }
      }
      return hostRoot;
    };
    exports2.findHostInstance = findHostInstance;
    exports2.findHostInstanceWithNoPortals = function(fiber) {
      fiber = findCurrentFiberUsingSlowPath(fiber);
      fiber = fiber !== null ? findCurrentHostFiberWithNoPortalsImpl(fiber) : null;
      return fiber === null ? null : getPublicInstance(fiber.stateNode);
    };
    exports2.findHostInstanceWithWarning = function(component) {
      return findHostInstance(component);
    };
    exports2.flushPassiveEffects = flushPendingEffects;
    exports2.flushSyncFromReconciler = function(fn) {
      var prevExecutionContext = executionContext;
      executionContext |= 1;
      var prevTransition = ReactSharedInternals.T, previousPriority = getCurrentUpdatePriority();
      try {
        if (setCurrentUpdatePriority(2), ReactSharedInternals.T = null, fn)
          return fn();
      } finally {
        setCurrentUpdatePriority(previousPriority), ReactSharedInternals.T = prevTransition, executionContext = prevExecutionContext, (executionContext & 6) === 0 && flushSyncWorkAcrossRoots_impl(0, false);
      }
    };
    exports2.flushSyncWork = flushSyncWork;
    exports2.focusWithin = function(hostRoot, selectors) {
      if (!supportsTestSelectors)
        throw Error(formatProdErrorMessage(363));
      hostRoot = findFiberRootForHostRoot(hostRoot);
      selectors = findPaths(hostRoot, selectors);
      selectors = Array.from(selectors);
      for (hostRoot = 0;hostRoot < selectors.length; ) {
        var fiber = selectors[hostRoot++], tag = fiber.tag;
        if (!isHiddenSubtree(fiber)) {
          if ((tag === 5 || tag === 26 || tag === 27) && setFocusIfFocusable(fiber.stateNode))
            return true;
          for (fiber = fiber.child;fiber !== null; )
            selectors.push(fiber), fiber = fiber.sibling;
        }
      }
      return false;
    };
    exports2.getFindAllNodesFailureDescription = function(hostRoot, selectors) {
      if (!supportsTestSelectors)
        throw Error(formatProdErrorMessage(363));
      var maxSelectorIndex = 0, matchedNames = [];
      hostRoot = [findFiberRootForHostRoot(hostRoot), 0];
      for (var index = 0;index < hostRoot.length; ) {
        var fiber = hostRoot[index++], tag = fiber.tag, selectorIndex = hostRoot[index++], selector = selectors[selectorIndex];
        if (tag !== 5 && tag !== 26 && tag !== 27 || !isHiddenSubtree(fiber)) {
          if (matchSelector(fiber, selector) && (matchedNames.push(selectorToString(selector)), selectorIndex++, selectorIndex > maxSelectorIndex && (maxSelectorIndex = selectorIndex)), selectorIndex < selectors.length)
            for (fiber = fiber.child;fiber !== null; )
              hostRoot.push(fiber, selectorIndex), fiber = fiber.sibling;
        }
      }
      if (maxSelectorIndex < selectors.length) {
        for (hostRoot = [];maxSelectorIndex < selectors.length; maxSelectorIndex++)
          hostRoot.push(selectorToString(selectors[maxSelectorIndex]));
        return `findAllNodes was able to match part of the selector:
  ` + (matchedNames.join(" > ") + `

No matching component was found for:
  `) + hostRoot.join(" > ");
      }
      return null;
    };
    exports2.getPublicRootInstance = function(container) {
      container = container.current;
      if (!container.child)
        return null;
      switch (container.child.tag) {
        case 27:
        case 5:
          return getPublicInstance(container.child.stateNode);
        default:
          return container.child.stateNode;
      }
    };
    exports2.injectIntoDevTools = function() {
      var internals = {
        bundleType: 0,
        version: rendererVersion,
        rendererPackageName,
        currentDispatcherRef: ReactSharedInternals,
        reconcilerVersion: "19.3.0"
      };
      extraDevToolsConfig !== null && (internals.rendererConfig = extraDevToolsConfig);
      if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined")
        internals = false;
      else {
        var hook = __REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (hook.isDisabled || !hook.supportsFiber)
          internals = true;
        else {
          try {
            rendererID = hook.inject(internals), injectedHook = hook;
          } catch (err) {}
          internals = hook.checkDCE ? true : false;
        }
      }
      return internals;
    };
    exports2.isAlreadyRendering = function() {
      return (executionContext & 6) !== 0;
    };
    exports2.observeVisibleRects = function(hostRoot, selectors, callback, options) {
      if (!supportsTestSelectors)
        throw Error(formatProdErrorMessage(363));
      hostRoot = findAllNodes(hostRoot, selectors);
      var disconnect = setupIntersectionObserver(hostRoot, callback, options).disconnect;
      return {
        disconnect: function() {
          disconnect();
        }
      };
    };
    exports2.shouldError = function() {
      return null;
    };
    exports2.shouldSuspend = function() {
      return false;
    };
    exports2.startHostTransition = function(formFiber, pendingState, action, formData) {
      if (formFiber.tag !== 5)
        throw Error(formatProdErrorMessage(476));
      var queue = ensureFormComponentIsStateful(formFiber).queue;
      startTransition(formFiber, queue, pendingState, NotPendingTransition, action === null ? noop : function() {
        var stateHook = ensureFormComponentIsStateful(formFiber);
        stateHook.next === null && (stateHook = formFiber.alternate.memoizedState);
        dispatchSetStateInternal(formFiber, stateHook.next.queue, {}, requestUpdateLane());
        return action(formData);
      });
    };
    exports2.updateContainer = function(element, container, parentComponent, callback) {
      var current = container.current, lane = requestUpdateLane();
      updateContainerImpl(current, lane, element, container, parentComponent, callback);
      return lane;
    };
    exports2.updateContainerSync = function(element, container, parentComponent, callback) {
      updateContainerImpl(container.current, 2, element, container, parentComponent, callback);
      return 2;
    };
    return exports2;
  };
  module.exports.default = module.exports;
  Object.defineProperty(module.exports, "__esModule", { value: true });
});

// ../projects/react-typescript/node_modules/react-reconciler/index.js
var require_react_reconciler = __commonJS(function(exports, module) {
  if (true) {
    module.exports = require_react_reconciler_production();
  }
});

// ../projects/react-typescript/node_modules/react/cjs/react-jsx-runtime.production.js
var exports_react_jsx_runtime_production = {};
__exportCjs(exports_react_jsx_runtime_production, {
  Fragment: () => $Fragment2,
  jsx: () => $jsx,
  jsxs: () => $jsxs
}, {
  Fragment: (value3) => $Fragment2 = value3,
  jsx: (value3) => $jsx = value3,
  jsxs: (value3) => $jsxs = value3
});
function jsxProd(type, config, maybeKey) {
  var key = null;
  maybeKey !== undefined && (key = "" + maybeKey);
  config.key !== undefined && (key = "" + config.key);
  if ("key" in config) {
    maybeKey = {};
    for (var propName in config)
      propName !== "key" && (maybeKey[propName] = config[propName]);
  } else
    maybeKey = config;
  config = maybeKey.ref;
  return {
    $$typeof: REACT_ELEMENT_TYPE2,
    type,
    key,
    ref: config !== undefined ? config : null,
    props: maybeKey
  };
}
var REACT_ELEMENT_TYPE2, REACT_FRAGMENT_TYPE2, $Fragment2, $jsx, $jsxs;
var init_react_jsx_runtime_production = __esm(() => {
  REACT_ELEMENT_TYPE2 = Symbol.for("react.transitional.element");
  REACT_FRAGMENT_TYPE2 = Symbol.for("react.fragment");
  $Fragment2 = REACT_FRAGMENT_TYPE2;
  $jsx = jsxProd;
  $jsxs = jsxProd;
});

// ../projects/react-typescript/node_modules/react/jsx-runtime.js
var require_jsx_runtime = __commonJS(function(exports, module) {
  init_react_jsx_runtime_production();
  if (true) {
    module.exports = exports_react_jsx_runtime_production;
  }
});

// ../projects/react-typescript/node_modules/@bun-native/protocol/src/framing.ts
var MAX_FRAME_BYTES = 65536;

class ProtocolError extends Error {
  name = "ProtocolError";
}
function encodeFrame(value) {
  let json;
  try {
    json = JSON.stringify(value);
  } catch (error) {
    throw new ProtocolError("Frame is not a JSON value", { cause: error });
  }
  if (json === undefined)
    throw new ProtocolError("Frame is not a JSON value");
  const encoded = new TextEncoder().encode(`${json}
`);
  if (encoded.byteLength - 1 > MAX_FRAME_BYTES)
    throw new ProtocolError("Frame exceeds byte limit");
  return encoded;
}

class FrameDecoder {
  buffer = new Uint8Array(MAX_FRAME_BYTES);
  utf8 = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
  length = 0;
  state = "open";
  push(chunk) {
    if (this.state !== "open")
      throw new ProtocolError(this.state === "failed" ? "Decoder is closed after a protocol error" : "Decoder is closed after end of stream");
    const frames = [];
    let start = 0;
    try {
      while (start < chunk.length) {
        const newline = chunk.indexOf(10, start);
        const end = newline === -1 ? chunk.length : newline;
        const size = end - start;
        if (this.length + size > MAX_FRAME_BYTES)
          throw new ProtocolError("Frame exceeds byte limit");
        this.buffer.set(chunk.subarray(start, end), this.length);
        this.length += size;
        if (newline === -1)
          break;
        if (this.length === 0)
          throw new ProtocolError("Empty frame");
        const json = this.utf8.decode(this.buffer.subarray(0, this.length));
        frames.push(JSON.parse(json));
        this.length = 0;
        start = newline + 1;
      }
    } catch (error) {
      this.state = "failed";
      if (error instanceof ProtocolError)
        throw error;
      throw new ProtocolError("Invalid UTF-8 or JSON in native frame", { cause: error });
    }
    return frames;
  }
  finish() {
    if (this.state === "failed")
      throw new ProtocolError("Decoder is closed after a protocol error");
    if (this.length !== 0) {
      this.state = "failed";
      throw new ProtocolError("Native stream ended inside a frame");
    }
    this.state = "finished";
  }
}
// ../projects/react-typescript/node_modules/@bun-native/protocol/src/values.ts
var MAX_TEXT_BYTES = 16384;
var MAX_TITLE_BYTES = 256;
var encoder = new TextEncoder;
function object(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new ProtocolError("Message must be an object");
  return value;
}
function keys(value, allowed) {
  for (const key of Object.keys(value))
    if (!allowed.includes(key))
      throw new ProtocolError("Unknown message property: " + key);
}
function number(value, field, min, max) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max)
    throw new ProtocolError(field + " must be finite and between " + min + " and " + max);
  return value;
}
function integer(value, field, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const result = number(value, field, min, max);
  if (!Number.isSafeInteger(result))
    throw new ProtocolError(field + " must be a safe integer");
  return result;
}
function id(value) {
  return integer(value, "Identifier", 1);
}
function string(value, field, limit = MAX_TEXT_BYTES) {
  if (typeof value !== "string" || encoder.encode(value).byteLength > limit)
    throw new ProtocolError(field + " must be a string within " + limit + " UTF-8 bytes");
  if (!value.isWellFormed())
    throw new ProtocolError(field + " contains an unpaired surrogate");
  if (value.includes("\x00"))
    throw new ProtocolError(field + " contains a NUL character");
  return value;
}

// ../projects/react-typescript/node_modules/@bun-native/protocol/src/elements.ts
function choice(value, name, values) {
  for (const candidate of values)
    if (candidate === value)
      return candidate;
  throw new ProtocolError(name + " must be one of " + values.join(", "));
}
function requireLeafStyle(style) {
  if (style.overflow !== undefined && style.overflow !== "visible" && style.overflow !== "hidden")
    throw new ProtocolError("Scrolling is supported only on box elements");
}
function parseStyle(value) {
  const data = object(value);
  keys(data, [
    "direction",
    "gap",
    "padding",
    "width",
    "height",
    "min_width",
    "max_width",
    "min_height",
    "max_height",
    "flex_grow",
    "flex_shrink",
    "align_items",
    "justify_content",
    "overflow",
    "background",
    "color",
    "font_size"
  ]);
  const style = {};
  for (const key of ["gap", "padding"])
    if (key in data)
      style[key] = number(data[key], key, 0, 4096);
  for (const key of ["width", "height"])
    if (key in data)
      style[key] = data[key] === "fill" ? "fill" : number(data[key], key, 0, 16384);
  for (const key of ["min_width", "max_width", "min_height", "max_height"])
    if (key in data)
      style[key] = number(data[key], key, 0, 16384);
  for (const [minimum, maximum] of [
    [style.min_width, style.max_width],
    [style.min_height, style.max_height]
  ])
    if (minimum !== undefined && maximum !== undefined && minimum > maximum)
      throw new ProtocolError("Minimum size must not exceed maximum size");
  for (const key of ["background", "color"])
    if (key in data)
      style[key] = integer(data[key], key, 0, 16777215);
  if ("direction" in data)
    style.direction = choice(data["direction"], "direction", ["row", "column"]);
  for (const key of ["flex_grow", "flex_shrink"])
    if (key in data)
      style[key] = number(data[key], key, 0, 1000);
  if ("align_items" in data)
    style.align_items = choice(data["align_items"], "align_items", [
      "start",
      "center",
      "end",
      "stretch"
    ]);
  if ("justify_content" in data)
    style.justify_content = choice(data["justify_content"], "justify_content", [
      "start",
      "center",
      "end",
      "space_between",
      "space_around",
      "space_evenly"
    ]);
  if ("overflow" in data)
    style.overflow = choice(data["overflow"], "overflow", [
      "visible",
      "hidden",
      "scroll_x",
      "scroll_y",
      "scroll"
    ]);
  if ("font_size" in data)
    style.font_size = number(data["font_size"], "font_size", 1, 512);
  return style;
}
function parseElement(value) {
  const element = object(value);
  const style = "style" in element ? parseStyle(element["style"]) : {};
  switch (element["kind"]) {
    case "box":
      keys(element, ["kind", "style"]);
      return { kind: "box", style };
    case "text":
      keys(element, ["kind", "text", "style"]);
      requireLeafStyle(style);
      return { kind: "text", text: string(element["text"], "text"), style };
    case "button": {
      keys(element, ["kind", "text", "disabled", "style"]);
      requireLeafStyle(style);
      if ("disabled" in element && typeof element["disabled"] !== "boolean")
        throw new ProtocolError("disabled must be a boolean");
      return {
        kind: "button",
        text: string(element["text"], "text"),
        disabled: element["disabled"] === true,
        style
      };
    }
    case "input":
      keys(element, ["kind", "value", "placeholder", "style"]);
      requireLeafStyle(style);
      return {
        kind: "input",
        value: string(element["value"], "value"),
        placeholder: "placeholder" in element ? string(element["placeholder"], "placeholder") : "",
        style
      };
    default:
      throw new ProtocolError("Unknown native element kind");
  }
}
// ../projects/react-typescript/node_modules/@bun-native/protocol/src/services.ts
var MAX_CLIPBOARD_BYTES = 8192;
var MAX_SERVICE_REQUESTS = 8;
function parseClipboardText(value) {
  const data = object(value);
  if (data["kind"] === "empty") {
    keys(data, ["kind"]);
    return { kind: "empty" };
  }
  keys(data, ["kind", "text"]);
  if (data["kind"] !== "text")
    throw new ProtocolError("Unknown clipboard text result");
  return { kind: "text", text: string(data["text"], "clipboard text", MAX_CLIPBOARD_BYTES) };
}
function parseServicePolicy(value) {
  const data = object(value);
  keys(data, ["window_display", "clipboard_read", "clipboard_write"]);
  const grant = (key) => {
    if (typeof data[key] !== "boolean")
      throw new ProtocolError("Native service policy must explicitly grant or deny each operation");
    return data[key];
  };
  return {
    window_display: grant("window_display"),
    clipboard_read: grant("clipboard_read"),
    clipboard_write: grant("clipboard_write")
  };
}
function parseDisplaySnapshot(value) {
  const data = object(value);
  keys(data, ["bounds", "scale_factor"]);
  const bounds = object(data["bounds"]);
  keys(bounds, ["x", "y", "width", "height"]);
  return {
    bounds: {
      x: number(bounds["x"], "display x", -1048576, 1048576),
      y: number(bounds["y"], "display y", -1048576, 1048576),
      width: number(bounds["width"], "display width", Number.MIN_VALUE, 1048576),
      height: number(bounds["height"], "display height", Number.MIN_VALUE, 1048576)
    },
    scale_factor: number(data["scale_factor"], "display scale factor", 0.125, 16)
  };
}
// ../projects/react-typescript/node_modules/@bun-native/protocol/src/messages.ts
var PROTOCOL_VERSION = 6;
var MAX_OPERATIONS = 256;
var MAX_NODES_PER_WINDOW = 4096;
var MAX_WINDOWS = 16;
var MAX_DEPTH = 64;
var MAX_TEXT_BYTES_PER_WINDOW = 4194304;
var DEFAULT_LIMITS = Object.freeze({
  max_frame_bytes: MAX_FRAME_BYTES,
  max_operations: MAX_OPERATIONS,
  max_nodes_per_window: MAX_NODES_PER_WINDOW,
  max_windows: MAX_WINDOWS,
  max_depth: MAX_DEPTH,
  max_text_bytes: MAX_TEXT_BYTES,
  max_text_bytes_per_window: MAX_TEXT_BYTES_PER_WINDOW,
  max_clipboard_bytes: MAX_CLIPBOARD_BYTES,
  max_service_requests: MAX_SERVICE_REQUESTS
});
var ERROR_CODES = [
  "invalid_command",
  "version_mismatch",
  "invalid_state",
  "invalid_handle",
  "stale_revision",
  "limit_exceeded",
  "native_failure",
  "permission_denied",
  "service_unavailable",
  "cancelled",
  "operation_timed_out",
  "payload_too_large"
];
var REQUIRED_CAPABILITIES = Object.freeze([
  "tree",
  "input_revisions",
  "layout_v1",
  "interactions_v1",
  "window_display_v1"
]);
var CAPABILITIES = [...REQUIRED_CAPABILITIES, "clipboard_text_v1"];
function version(value) {
  if (value !== PROTOCOL_VERSION)
    throw new ProtocolError("Native protocol version mismatch");
  return PROTOCOL_VERSION;
}
function operation(value) {
  const data = object(value);
  switch (data["type"]) {
    case "create":
      keys(data, ["type", "node_id", "element"]);
      return {
        type: "create",
        node_id: id(data["node_id"]),
        element: parseElement(data["element"])
      };
    case "set": {
      keys(data, ["type", "node_id", "element", "expected_input_revision"]);
      const node_id = id(data["node_id"]);
      const element = parseElement(data["element"]);
      if (element.kind === "input")
        return {
          type: "set",
          node_id,
          element,
          expected_input_revision: integer(data["expected_input_revision"], "input revision")
        };
      if ("expected_input_revision" in data)
        throw new ProtocolError("Only input elements accept an input revision");
      return { type: "set", node_id, element };
    }
    case "insert":
      keys(data, ["type", "parent_id", "child_id", "index"]);
      return {
        type: "insert",
        parent_id: id(data["parent_id"]),
        child_id: id(data["child_id"]),
        index: integer(data["index"], "index", 0, MAX_NODES_PER_WINDOW)
      };
    case "delete":
      keys(data, ["type", "node_id"]);
      return { type: "delete", node_id: id(data["node_id"]) };
    default:
      throw new ProtocolError("Unknown native operation");
  }
}
function parseCommand(value) {
  const message = object(value);
  const request = id(message["id"]);
  switch (message["type"]) {
    case "hello":
      keys(message, ["id", "type", "protocol"]);
      return { id: request, type: "hello", protocol: version(message["protocol"]) };
    case "open": {
      keys(message, ["id", "type", "window_id", "root_id", "title", "width", "height"]);
      const title = string(message["title"], "title", MAX_TITLE_BYTES);
      if (!title || /\p{Cc}/u.test(title))
        throw new ProtocolError("Window title must be nonempty and contain no control characters");
      return {
        id: request,
        type: "open",
        window_id: id(message["window_id"]),
        root_id: id(message["root_id"]),
        title,
        width: number(message["width"], "width", 64, 16384),
        height: number(message["height"], "height", 64, 16384)
      };
    }
    case "batch": {
      keys(message, ["id", "type", "window_id", "base_revision", "operations"]);
      const operations = message["operations"];
      if (!Array.isArray(operations) || operations.length < 1 || operations.length > MAX_OPERATIONS)
        throw new ProtocolError("Batch must contain between 1 and " + MAX_OPERATIONS + " operations");
      return {
        id: request,
        type: "batch",
        window_id: id(message["window_id"]),
        base_revision: integer(message["base_revision"], "tree revision"),
        operations: operations.map(operation)
      };
    }
    case "close":
    case "display_snapshot":
    case "clipboard_read":
      keys(message, ["id", "type", "window_id"]);
      return { id: request, type: message["type"], window_id: id(message["window_id"]) };
    case "clipboard_write":
      keys(message, ["id", "type", "window_id", "text"]);
      return {
        id: request,
        type: "clipboard_write",
        window_id: id(message["window_id"]),
        text: string(message["text"], "clipboard text", MAX_CLIPBOARD_BYTES)
      };
    case "shutdown":
      keys(message, ["id", "type"]);
      return { id: request, type: "shutdown" };
    default:
      throw new ProtocolError("Unknown native command");
  }
}
function limits(value) {
  const data = object(value);
  keys(data, Object.keys(DEFAULT_LIMITS));
  const parse = (key) => integer(data[key], key, 1, DEFAULT_LIMITS[key]);
  return {
    max_frame_bytes: parse("max_frame_bytes"),
    max_operations: parse("max_operations"),
    max_nodes_per_window: parse("max_nodes_per_window"),
    max_windows: parse("max_windows"),
    max_depth: parse("max_depth"),
    max_text_bytes: parse("max_text_bytes"),
    max_text_bytes_per_window: parse("max_text_bytes_per_window"),
    max_clipboard_bytes: parse("max_clipboard_bytes"),
    max_service_requests: parse("max_service_requests")
  };
}
var ROUTE_KEYS = ["type", "sequence", "window_id", "node_id", "tree_revision", "path"];
function route(message) {
  const node_id = id(message["node_id"]);
  const value = message["path"];
  if (!Array.isArray(value) || !value.length || value.length > MAX_DEPTH + 1)
    throw new ProtocolError("Native event path must contain between 1 and 65 node identities");
  const path = value.map(id);
  if (new Set(path).size !== path.length || path.at(-1) !== node_id)
    throw new ProtocolError("Native event path must be unique and end at its target");
  return {
    sequence: id(message["sequence"]),
    window_id: id(message["window_id"]),
    node_id,
    tree_revision: integer(message["tree_revision"], "tree revision"),
    path
  };
}
function modifiers(value) {
  const data = object(value);
  keys(data, ["control", "alt", "shift", "platform", "function"]);
  const modifier = (name) => {
    if (typeof data[name] !== "boolean")
      throw new ProtocolError("Invalid native key modifier");
    return data[name];
  };
  return {
    control: modifier("control"),
    alt: modifier("alt"),
    shift: modifier("shift"),
    platform: modifier("platform"),
    function: modifier("function")
  };
}
function parseEvent(value) {
  const message = object(value);
  switch (message["type"]) {
    case "ready": {
      keys(message, ["type", "protocol", "capabilities", "limits", "service_policy"]);
      const capabilities = message["capabilities"];
      if (!Array.isArray(capabilities) || capabilities.length > CAPABILITIES.length)
        throw new ProtocolError("Invalid native capabilities");
      const parsed = [];
      for (const value of capabilities) {
        const capability = CAPABILITIES.find((candidate) => candidate === value);
        if (!capability || parsed.includes(capability))
          throw new ProtocolError("Unknown or duplicate native capability");
        parsed.push(capability);
      }
      return {
        type: "ready",
        protocol: version(message["protocol"]),
        capabilities: parsed,
        limits: limits(message["limits"]),
        service_policy: parseServicePolicy(message["service_policy"])
      };
    }
    case "ack":
      keys(message, ["type", "id"]);
      return { type: "ack", id: id(message["id"]) };
    case "opened":
      keys(message, ["type", "id", "window_id", "root_id", "tree_revision"]);
      return {
        type: "opened",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        root_id: id(message["root_id"]),
        tree_revision: integer(message["tree_revision"], "tree revision")
      };
    case "applied":
      keys(message, ["type", "id", "window_id", "tree_revision"]);
      return {
        type: "applied",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        tree_revision: integer(message["tree_revision"], "tree revision")
      };
    case "display_snapshot":
      keys(message, ["type", "id", "window_id", "snapshot"]);
      return {
        type: "display_snapshot",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        snapshot: parseDisplaySnapshot(message["snapshot"])
      };
    case "clipboard_text":
      keys(message, ["type", "id", "window_id", "result"]);
      return {
        type: "clipboard_text",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        result: parseClipboardText(message["result"])
      };
    case "clipboard_written":
      keys(message, ["type", "id", "window_id"]);
      return {
        type: "clipboard_written",
        id: id(message["id"]),
        window_id: id(message["window_id"])
      };
    case "click":
    case "focus":
    case "blur":
      keys(message, ROUTE_KEYS);
      return {
        type: message["type"],
        ...route(message)
      };
    case "key_down":
    case "key_up": {
      keys(message, [...ROUTE_KEYS, "key", "key_char", "modifiers"]);
      const key = string(message["key"], "key", 256);
      if (!key)
        throw new ProtocolError("Native key must be nonempty");
      return {
        type: message["type"],
        ...route(message),
        key,
        ..."key_char" in message ? { key_char: string(message["key_char"], "key_char", 256) } : {},
        modifiers: modifiers(message["modifiers"])
      };
    }
    case "pointer_down":
    case "pointer_up": {
      keys(message, [...ROUTE_KEYS, "button", "x", "y", "modifiers"]);
      const button = ["left", "right", "middle", "back", "forward"].find((button) => button === message["button"]);
      if (!button)
        throw new ProtocolError("Unknown native pointer button");
      return {
        type: message["type"],
        ...route(message),
        button,
        x: number(message["x"], "pointer x", -1048576, 1048576),
        y: number(message["y"], "pointer y", -1048576, 1048576),
        modifiers: modifiers(message["modifiers"])
      };
    }
    case "closed":
      keys(message, ["type", "sequence", "window_id"]);
      return {
        type: "closed",
        sequence: id(message["sequence"]),
        window_id: id(message["window_id"])
      };
    case "input":
      keys(message, [...ROUTE_KEYS, "value", "input_revision"]);
      return {
        type: "input",
        ...route(message),
        value: string(message["value"], "value"),
        input_revision: integer(message["input_revision"], "input revision")
      };
    case "error": {
      keys(message, ["type", "id", "code", "message"]);
      const code = ERROR_CODES.find((code) => code === message["code"]);
      if (!code)
        throw new ProtocolError("Invalid native error code");
      return {
        type: "error",
        code,
        message: string(message["message"], "message"),
        ..."id" in message ? { id: id(message["id"]) } : {}
      };
    }
    default:
      throw new ProtocolError("Unknown native event");
  }
}
// ../projects/react-typescript/node_modules/@bun-native/runtime/src/index.ts
import { isAbsolute as isAbsolute2 } from "path";

// ../projects/react-typescript/node_modules/@bun-native/runtime/src/startup-trace.ts
import { appendFileSync } from "fs";
import { isAbsolute } from "path";
var MAX_RECORDS = 256;

class StartupTrace {
  path;
  nonce;
  started = process.hrtime.bigint();
  records = 0;
  unavailable = false;
  constructor(path, nonce) {
    this.path = path;
    this.nonce = nonce;
  }
  static fromEnvironment() {
    if (process.env["BUN_NATIVE_STARTUP_TRACE"] !== "1")
      return;
    const path = process.env["BUN_NATIVE_EVIDENCE_LOG"];
    const nonce = process.env["BUN_NATIVE_EVIDENCE_NONCE"];
    if (!path || !isAbsolute(path) || !nonce || Buffer.byteLength(nonce) > 128 || [...nonce].some((character) => {
      const code = character.charCodeAt(0);
      return code < 32 || code >= 127 && code <= 159;
    }))
      throw new Error("Native startup tracing requires an absolute evidence path and valid nonce");
    return new StartupTrace(path, nonce);
  }
  request(phase, command, hostPid) {
    this.write(phase, {
      host_pid: hostPid,
      request_id: command.id,
      command: command.type,
      ..."window_id" in command ? { window_id: command.window_id } : {}
    });
  }
  response(event, hostPid) {
    if (!("id" in event))
      return;
    this.write("response_received", {
      host_pid: hostPid,
      request_id: event.id,
      response: event.type
    });
  }
  failure(error, stderr, hostPid) {
    this.write("transport_failed", { host_pid: hostPid, error: error.message.slice(-1024), stderr_tail: stderr }, true);
  }
  finished(exitCode, stderr, hostPid) {
    this.write("transport_finished", { host_pid: hostPid, exit_code: exitCode, stderr_tail: stderr }, true);
  }
  write(phase, fields, terminal = false) {
    if (this.unavailable || !terminal && this.records >= MAX_RECORDS)
      return;
    if (!terminal && this.records === MAX_RECORDS - 1) {
      phase = "record_limit";
      fields = { host_pid: fields["host_pid"], maximum_records: MAX_RECORDS };
    }
    const record = {
      nonce: this.nonce,
      stage: "startup-diagnostic",
      source: "transport",
      pid: process.pid,
      clock: "process_monotonic_relative",
      elapsed_ns: String(process.hrtime.bigint() - this.started),
      index: ++this.records,
      phase,
      ...fields
    };
    try {
      appendFileSync(this.path, JSON.stringify(record) + `
`, { mode: 384 });
    } catch {
      this.unavailable = true;
      console.error("Bun Native startup trace unavailable; evidence file could not be appended");
    }
  }
}

// ../projects/react-typescript/node_modules/@bun-native/runtime/src/index.ts
class NativeCommandError extends Error {
  code;
  requestId;
  name = "NativeCommandError";
  constructor(code, requestId, message) {
    super("Native " + code + ": " + message);
    this.code = code;
    this.requestId = requestId;
  }
}
function launchPolicy(value = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new TypeError("Native permissions must be an object");
  if (Object.keys(value).some((key) => !["windowDisplay", "clipboardRead", "clipboardWrite"].includes(key)))
    throw new TypeError("Unknown native service permission");
  const grant = (key) => {
    const permission = Object.hasOwn(value, key) ? value[key] : "deny";
    if (permission !== "allow" && permission !== "deny")
      throw new TypeError(key + " permission must be allow or deny");
    return permission === "allow";
  };
  return Object.freeze({
    window_display: grant("windowDisplay"),
    clipboard_read: grant("clipboardRead"),
    clipboard_write: grant("clipboardWrite")
  });
}
var MAX_PENDING_COMMANDS = 128;
var MAX_QUEUED_EVENTS = 128;

class NativeHost {
  requestedPolicy;
  exited;
  process;
  stdout;
  stderr;
  timeout;
  pending = new Map;
  events = [];
  finished;
  waiting;
  failure;
  phase = "starting";
  ready = false;
  negotiatedLimits;
  negotiatedServicePolicy;
  negotiatedCapabilities;
  sequence = 0;
  nextId = 1;
  writeTail = Promise.resolve();
  stderrTail = "";
  iteratorTaken = false;
  startupTrace = StartupTrace.fromEnvironment();
  constructor(options, requestedPolicy) {
    this.requestedPolicy = requestedPolicy;
    this.timeout = options.requestTimeoutMs ?? 5000;
    this.process = Bun.spawn({
      cmd: [
        options.executable,
        ...options.args ?? [],
        ...requestedPolicy.window_display ? ["--bun-native-allow-window-display"] : [],
        ...requestedPolicy.clipboard_read ? ["--bun-native-allow-clipboard-read"] : [],
        ...requestedPolicy.clipboard_write ? ["--bun-native-allow-clipboard-write"] : []
      ],
      stdin: "pipe",
      stdout: "pipe",
      stderr: "pipe"
    });
    this.stdout = this.process.stdout.getReader();
    this.stderr = this.process.stderr.getReader();
    this.exited = this.process.exited;
    this.finished = this.watch();
  }
  static async launch(options) {
    if (!isAbsolute2(options.executable))
      throw new Error("Native host path must be absolute");
    const timeout = options.requestTimeoutMs ?? 5000;
    if (!Number.isSafeInteger(timeout) || timeout < 1 || timeout > 60000)
      throw new Error("requestTimeoutMs must be an integer between 1 and 60000");
    const policy = launchPolicy(options.permissions);
    if (options.args?.some((argument) => typeof argument !== "string" || argument.startsWith("--bun-native-")))
      throw new TypeError("Native service arguments are reserved for the explicit permissions option");
    const host = new NativeHost(options, policy);
    try {
      await host.request({ type: "hello", protocol: PROTOCOL_VERSION });
      if (!host.ready)
        throw new ProtocolError("Host acknowledged hello before protocol readiness");
      host.phase = "running";
      return host;
    } catch (error) {
      host.fail(error);
      await host.finished;
      throw host.failure;
    }
  }
  get limits() {
    if (!this.negotiatedLimits)
      throw new ProtocolError("Native limits are not negotiated");
    return this.negotiatedLimits;
  }
  get servicePolicy() {
    if (!this.negotiatedServicePolicy)
      throw new ProtocolError("Native service policy is not negotiated");
    return this.negotiatedServicePolicy;
  }
  get capabilities() {
    if (!this.negotiatedCapabilities)
      throw new ProtocolError("Native capabilities are not negotiated");
    return this.negotiatedCapabilities;
  }
  send(command) {
    if (this.phase !== "running")
      return Promise.reject(this.closedError());
    return this.request(command);
  }
  async shutdown() {
    if (this.phase === "closed" || this.phase === "stopping") {
      await this.finished;
      if (this.failure)
        throw this.failure;
      return;
    }
    this.phase = "stopping";
    try {
      await this.request({ type: "shutdown" });
      this.process.stdin.end();
      const deadline = setTimeout(() => this.fail(new Error("Native host did not exit")), this.timeout);
      try {
        await this.finished;
      } finally {
        clearTimeout(deadline);
      }
      if (this.failure)
        throw this.failure;
    } catch (error) {
      this.fail(error);
      await this.finished;
      throw this.failure;
    }
  }
  [Symbol.asyncIterator]() {
    if (this.iteratorTaken)
      throw new Error("Native events have exactly one consumer");
    this.iteratorTaken = true;
    return {
      next: () => {
        if (this.failure)
          return Promise.reject(this.failure);
        const event = this.events.shift();
        if (event)
          return Promise.resolve({ done: false, value: event });
        if (this.phase === "closed")
          return Promise.resolve({ done: true, value: undefined });
        if (this.waiting)
          return Promise.reject(new Error("Concurrent event reads are not supported"));
        return new Promise((resolve, reject) => {
          this.waiting = { resolve, reject };
        });
      },
      return: async () => {
        await this.shutdown();
        return { done: true, value: undefined };
      }
    };
  }
  request(input) {
    if (this.phase === "closed")
      return Promise.reject(this.closedError());
    if (this.pending.size >= MAX_PENDING_COMMANDS)
      return Promise.reject(new Error("Native command limit exceeded"));
    let command;
    let frame;
    try {
      command = parseCommand({ ...input, id: this.nextId++ });
      frame = encodeFrame(command);
      if (this.negotiatedLimits) {
        if (frame.byteLength - 1 > this.negotiatedLimits.max_frame_bytes)
          throw new ProtocolError("Command exceeds the negotiated frame limit");
        if (command.type === "batch" && command.operations.length > this.negotiatedLimits.max_operations)
          throw new ProtocolError("Command exceeds the negotiated batch limit");
        if (command.type === "clipboard_write" && Buffer.byteLength(command.text, "utf8") > this.negotiatedLimits.max_clipboard_bytes)
          throw new ProtocolError("Clipboard write exceeds the negotiated text limit");
      }
    } catch (error) {
      return Promise.reject(error);
    }
    const result = new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.fail(new Error(`Native ${command.type} request ${command.id} timed out`)), this.timeout);
      this.pending.set(command.id, {
        command,
        resolve,
        reject,
        timer
      });
    });
    this.startupTrace?.request("request_queued", command, this.process.pid);
    this.writeTail = this.writeTail.then(async () => {
      if (this.phase === "closed")
        return;
      this.startupTrace?.request("stdin_write_enter", command, this.process.pid);
      this.process.stdin.write(frame);
      this.startupTrace?.request("stdin_write_returned", command, this.process.pid);
      this.startupTrace?.request("stdin_flush_enter", command, this.process.pid);
      await this.process.stdin.flush();
      this.startupTrace?.request("stdin_flushed", command, this.process.pid);
    }).catch((error) => this.fail(error));
    return result;
  }
  async readStdout() {
    const decoder = new FrameDecoder;
    try {
      for (;; ) {
        const { done, value } = await this.stdout.read();
        if (done)
          break;
        for (const raw of decoder.push(value))
          this.receive(parseEvent(raw));
      }
      decoder.finish();
      if (this.phase !== "stopping" && this.phase !== "closed")
        throw new ProtocolError("Native output closed before shutdown");
    } finally {
      this.stdout.releaseLock();
    }
  }
  async readStderr() {
    const decoder = new TextDecoder;
    try {
      for (;; ) {
        const { done, value } = await this.stderr.read();
        if (done)
          break;
        this.stderrTail = (this.stderrTail + decoder.decode(value, { stream: true })).slice(-4096);
      }
      this.stderrTail = (this.stderrTail + decoder.decode()).slice(-4096);
    } finally {
      this.stderr.releaseLock();
    }
  }
  cancelOutput() {
    this.stdout.cancel().catch(() => {});
    this.stderr.cancel().catch(() => {});
  }
  async watch() {
    const streams = [this.readStdout(), this.readStderr()];
    let drainDeadline;
    const exit = this.exited.then((code) => {
      drainDeadline = setTimeout(() => this.fail(new Error("Native output remained open after host exit")), this.timeout);
      return code;
    });
    try {
      const [code] = await Promise.all([exit, ...streams]);
      if (code !== 0 || this.phase !== "stopping" || this.pending.size)
        throw new Error(`Native host exited unexpectedly (${code}). ${this.stderrTail}`);
      this.phase = "closed";
      this.waiting?.resolve({ done: true, value: undefined });
      this.waiting = undefined;
    } catch (error) {
      this.fail(error);
      await this.exited;
    } finally {
      clearTimeout(drainDeadline);
      this.cancelOutput();
      await Promise.allSettled(streams);
      this.startupTrace?.finished(this.process.exitCode, this.stderrTail, this.process.pid);
    }
  }
  receive(event) {
    if (this.phase === "closed")
      return;
    this.startupTrace?.response(event, this.process.pid);
    if (event.type === "clipboard_text" && event.result.kind === "text" && this.negotiatedLimits && Buffer.byteLength(event.result.text, "utf8") > this.negotiatedLimits.max_clipboard_bytes)
      throw new ProtocolError("Clipboard response exceeds the negotiated text limit");
    if (event.type === "ready") {
      if (this.ready || this.phase !== "starting")
        throw new ProtocolError("Unexpected ready event");
      if (REQUIRED_CAPABILITIES.some((capability) => !event.capabilities.includes(capability)))
        throw new ProtocolError("Native host lacks required protocol capabilities: " + REQUIRED_CAPABILITIES.join(", "));
      this.negotiatedLimits = Object.freeze(event.limits);
      if (Object.keys(this.requestedPolicy).some((key) => event.service_policy[key] !== this.requestedPolicy[key]))
        throw new ProtocolError("Native service policy does not match the explicit launch permissions");
      this.negotiatedServicePolicy = Object.freeze(event.service_policy);
      this.negotiatedCapabilities = Object.freeze(event.capabilities);
      this.ready = true;
      return;
    }
    if (event.type === "ack" || event.type === "opened" || event.type === "applied" || event.type === "display_snapshot" || event.type === "clipboard_text" || event.type === "clipboard_written" || event.type === "error") {
      if (event.type === "error" && event.id === undefined)
        throw new ProtocolError(`Native ${event.code}: ${event.message}`);
      const requestId = event.id;
      const request = requestId === undefined ? undefined : this.pending.get(requestId);
      if (!request || requestId === undefined)
        throw new ProtocolError("Unknown native response id");
      clearTimeout(request.timer);
      this.pending.delete(requestId);
      if (event.type === "error")
        request.reject(new NativeCommandError(event.code, requestId, event.message));
      else if (!this.matchesResponse(request.command, event)) {
        const error = new ProtocolError("Native response does not match its request, owner or revision");
        request.reject(error);
        throw error;
      } else
        request.resolve(event);
      return;
    }
    if (!this.ready)
      throw new ProtocolError("Native input arrived before protocol readiness");
    if (event.sequence !== this.sequence + 1)
      throw new ProtocolError("Native event sequence is out of order");
    this.sequence = event.sequence;
    if (this.waiting) {
      this.waiting.resolve({ done: false, value: event });
      this.waiting = undefined;
    } else {
      if (this.events.length >= MAX_QUEUED_EVENTS)
        throw new ProtocolError("Native event limit exceeded");
      this.events.push(event);
    }
  }
  matchesResponse(command, response) {
    switch (command.type) {
      case "display_snapshot":
        return response.type === "display_snapshot" && response.window_id === command.window_id;
      case "clipboard_read":
        return response.type === "clipboard_text" && response.window_id === command.window_id;
      case "clipboard_write":
        return response.type === "clipboard_written" && response.window_id === command.window_id;
      case "open":
        return response.type === "opened" && response.window_id === command.window_id && response.root_id === command.root_id && response.tree_revision === 0;
      case "batch":
        return response.type === "applied" && response.window_id === command.window_id && response.tree_revision === command.base_revision + 1;
      case "hello":
      case "close":
      case "shutdown":
        return response.type === "ack";
    }
  }
  closedError() {
    return this.failure ?? new Error("Native host is not running");
  }
  fail(cause) {
    if (this.failure)
      return;
    this.failure = cause instanceof Error ? cause : new Error(String(cause));
    this.startupTrace?.failure(this.failure, this.stderrTail, this.process.pid);
    this.phase = "closed";
    for (const request of this.pending.values()) {
      clearTimeout(request.timer);
      request.reject(this.failure);
    }
    this.pending.clear();
    this.events.length = 0;
    this.waiting?.reject(this.failure);
    this.waiting = undefined;
    this.cancelOutput();
    this.process.kill("SIGKILL");
  }
}

// ../projects/react-typescript/node_modules/@bun-native/core/src/types.ts
class NativeStateError extends Error {
  code;
  name = "NativeStateError";
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

class UnsupportedFeatureError extends Error {
  feature;
  name = "UnsupportedFeatureError";
  constructor(feature) {
    super("Unsupported native feature: " + feature);
    this.feature = feature;
  }
}

// ../projects/react-typescript/node_modules/@bun-native/core/src/events.ts
var eventTypes = [
  "click",
  "input",
  "key_down",
  "key_up",
  "pointer_down",
  "pointer_up",
  "focus",
  "blur"
];
function invocation(listener) {
  return (event) => listener(event);
}
function revoke(binding) {
  binding.invoke = undefined;
  binding.subscription.remove = undefined;
  binding.controller.abort();
}
function unsubscribe(subscription) {
  return () => subscription.remove?.();
}
function payload(event, node, path) {
  const common = {
    node,
    path: Object.freeze([...path]),
    sequence: event.sequence,
    treeRevision: event.tree_revision
  };
  switch (event.type) {
    case "click":
      return { ...common, type: event.type, node };
    case "input":
      return {
        ...common,
        type: event.type,
        node,
        value: event.value,
        revision: event.input_revision
      };
    case "key_down":
    case "key_up":
      return {
        ...common,
        type: event.type,
        key: event.key,
        ...event.key_char === undefined ? {} : { keyChar: event.key_char },
        modifiers: Object.freeze({ ...event.modifiers })
      };
    case "pointer_down":
    case "pointer_up":
      return {
        ...common,
        type: event.type,
        button: event.button,
        x: event.x,
        y: event.y,
        modifiers: Object.freeze({ ...event.modifiers })
      };
    case "focus":
    case "blur":
      return { ...common, type: event.type };
  }
}
function prunePlan(plan) {
  plan.deliveries = plan.deliveries.filter(({ binding }) => !binding.controller.signal.aborted);
  return !plan.cancellation.signal.aborted && plan.deliveries.length !== 0;
}

class EventBindings {
  changed;
  nodes = new Map;
  plans = new Set;
  constructor(changed) {
    this.changed = changed;
  }
  get size() {
    let size = 0;
    for (const bindings of this.nodes.values())
      size += bindings.size;
    return size;
  }
  register(id, node, type, listener, options = {}) {
    if (!eventTypes.includes(type) || typeof listener !== "function" || options === null || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((key) => key !== "capture") || "capture" in options && typeof options.capture !== "boolean")
      throw new NativeStateError("invalid_state", "Invalid native listener type, function or options");
    const key = `${type}:${options.capture ? "capture" : "bubble"}`;
    const bindings = this.nodes.get(id) ?? new Map;
    this.nodes.set(id, bindings);
    const previous = bindings.get(key);
    const subscription = { remove: undefined };
    const binding = {
      node,
      controller: new AbortController,
      invoke: invocation(listener),
      subscription
    };
    subscription.remove = () => {
      if (this.nodes.get(id)?.get(key) !== binding)
        return;
      bindings.delete(key);
      if (!bindings.size)
        this.nodes.delete(id);
      revoke(binding);
      this.changed();
    };
    bindings.set(key, binding);
    if (previous)
      revoke(previous);
    this.changed();
    return unsubscribe(subscription);
  }
  retain(ids) {
    for (const [id, bindings] of this.nodes) {
      if (ids.has(id))
        continue;
      this.nodes.delete(id);
      for (const binding of bindings.values())
        revoke(binding);
    }
    for (const plan of this.plans)
      if (!ids.has(plan.targetId))
        plan.cancellation.abort();
    this.changed();
  }
  clear() {
    const removed = [...this.nodes.values()];
    this.nodes.clear();
    for (const bindings of removed)
      for (const binding of bindings.values())
        revoke(binding);
    for (const plan of this.plans)
      plan.cancellation.abort();
    this.plans.clear();
    this.changed();
  }
  release(plan) {
    this.plans.delete(plan);
    plan.deliveries.length = 0;
  }
  prepare(event, path) {
    const deliveries = [];
    const append = (index, capture) => {
      const binding = this.nodes.get(event.path[index])?.get(`${event.type}:${capture ? "capture" : "bubble"}`);
      if (binding)
        deliveries.push({
          binding,
          phase: index === path.length - 1 ? "target" : capture ? "capture" : "bubble"
        });
    };
    for (let index = 0;index < path.length; index++)
      append(index, true);
    for (let index = path.length - 1;index >= 0; index--)
      append(index, false);
    if (!deliveries.length)
      return;
    const plan = {
      targetId: event.node_id,
      cancellation: new AbortController,
      data: payload(event, path.at(-1), path),
      deliveries
    };
    this.plans.add(plan);
    return plan;
  }
}
async function dispatchPlan(plan, targetIsLive) {
  let stopped = false;
  let immediate = false;
  let previous;
  let previousPhase;
  try {
    for (const { binding, phase } of plan.deliveries) {
      if (!targetIsLive() || plan.cancellation.signal.aborted || immediate || stopped && (binding.node !== previous || phase !== "target" || previousPhase !== "target"))
        break;
      if (binding.controller.signal.aborted)
        continue;
      previous = binding.node;
      previousPhase = phase;
      const signal = binding.controller.signal;
      let executing = true;
      const stop = (all) => {
        if (!executing || signal.aborted)
          return;
        stopped = true;
        immediate ||= all;
      };
      const event = Object.freeze({
        ...plan.data,
        currentTarget: binding.node,
        phase,
        signal,
        get propagationStopped() {
          return stopped;
        },
        stopPropagation: () => stop(false),
        stopImmediatePropagation: () => stop(true)
      });
      let cancel;
      const cancelled = new Promise((resolve) => {
        cancel = resolve;
      });
      signal.addEventListener("abort", cancel, { once: true });
      plan.cancellation.signal.addEventListener("abort", cancel, { once: true });
      try {
        await Promise.race([binding.invoke?.(event), cancelled]);
      } finally {
        executing = false;
        signal.removeEventListener("abort", cancel);
        plan.cancellation.signal.removeEventListener("abort", cancel);
      }
    }
  } finally {
    plan.deliveries.length = 0;
  }
}

// ../projects/react-typescript/node_modules/@bun-native/core/src/services.ts
class NativeServiceError extends Error {
  service;
  code;
  name = "NativeServiceError";
  constructor(service, code, message) {
    super(message);
    this.service = service;
    this.code = code;
  }
}
var unavailable = Object.freeze({
  availability: "unavailable",
  reason: "not_implemented"
});
function serviceCapabilities(policy, capabilities) {
  return Object.freeze({
    windowDisplay: Object.freeze({
      availability: "available",
      permission: policy.window_display ? "allow" : "deny",
      scope: "owned_window"
    }),
    clipboardText: capabilities.includes("clipboard_text_v1") ? Object.freeze({
      availability: "available",
      read: policy.clipboard_read ? "allow" : "deny",
      write: policy.clipboard_write ? "allow" : "deny",
      scope: "owned_window",
      backend: "x11"
    }) : Object.freeze({ availability: "unavailable", reason: "unsupported_platform" }),
    globalShortcuts: unavailable,
    systemMenus: unavailable,
    dialogs: unavailable,
    notifications: unavailable,
    dragDrop: unavailable,
    filesystemGrants: unavailable,
    ptyProcess: unavailable
  });
}
function serviceSignal(options) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("Native service options must be an object");
  if (Object.keys(options).some((key) => key !== "signal"))
    throw new TypeError("Unknown native service option");
  const signal = Object.hasOwn(options, "signal") ? options.signal : undefined;
  if (signal !== undefined && !(signal instanceof AbortSignal))
    throw new TypeError("Native service signal must be an AbortSignal");
  return signal;
}
function checkServiceCancellation(signal, service) {
  if (signal?.aborted)
    throw new NativeServiceError(service, "cancelled", "Native service read was cancelled; no result is delivered");
}

// ../projects/react-typescript/node_modules/@bun-native/core/src/tree.ts
var identities = new WeakMap;
var encoder2 = new TextEncoder;
var elementKinds = ["box", "text", "button", "input"];
function normalize(element) {
  if (element !== null && typeof element === "object" && typeof element.kind === "string" && !elementKinds.includes(element.kind))
    throw new UnsupportedFeatureError("element:" + element.kind);
  return parseElement(element);
}
function makeNode(id, element) {
  const handle = Object.freeze({ kind: element.kind });
  identities.set(handle, id);
  return {
    id,
    handle,
    element: normalize(element),
    parent: undefined,
    children: [],
    inputRevision: 0
  };
}
function own(nodes, handle) {
  const id = identities.get(handle);
  const node = id === undefined ? undefined : nodes.get(id);
  if (!node || node.handle !== handle)
    throw new NativeStateError("invalid_handle", "Node is forged, disposed or belongs to another window");
  return node;
}

class Transaction {
  rootId;
  allocateId;
  limits;
  nodes;
  operations = [];
  active = true;
  constructor(current, rootId, allocateId, limits) {
    this.rootId = rootId;
    this.allocateId = allocateId;
    this.limits = limits;
    this.nodes = new Map([...current].map(([id, node]) => [id, { ...node, children: [...node.children] }]));
  }
  check() {
    if (!this.active)
      throw new NativeStateError("invalid_state", "Batch callback has already returned");
    if (this.operations.length >= this.limits.max_operations)
      throw new NativeStateError("limit_exceeded", "Batch operation limit exceeded");
  }
  finish() {
    this.active = false;
  }
  create(element) {
    this.check();
    if (this.nodes.size >= this.limits.max_nodes_per_window)
      throw new NativeStateError("limit_exceeded", "Window node limit exceeded");
    const normalized = normalize(element);
    const node = makeNode(this.allocateId(), normalized);
    this.nodes.set(node.id, node);
    this.operations.push({ type: "create", node_id: node.id, element: node.element });
    return node.handle;
  }
  set(handle, value, expectedInputRevision) {
    this.check();
    const node = own(this.nodes, handle);
    const element = normalize(value);
    if (element.kind !== node.element.kind)
      throw new NativeStateError("invalid_state", "Element kind cannot change; create a replacement node");
    if (element.kind === "input") {
      if (!Number.isSafeInteger(expectedInputRevision) || expectedInputRevision !== node.inputRevision)
        throw new NativeStateError("stale_revision", "Input update requires its current observed revision");
      if (node.inputRevision === Number.MAX_SAFE_INTEGER)
        throw new NativeStateError("limit_exceeded", "Input revision exhausted");
      this.operations.push({
        type: "set",
        node_id: node.id,
        element,
        expected_input_revision: node.inputRevision
      });
      node.inputRevision += 1;
    } else {
      if (expectedInputRevision !== undefined)
        throw new NativeStateError("invalid_state", "Only an input accepts an edit revision");
      this.operations.push({ type: "set", node_id: node.id, element });
    }
    node.element = element;
  }
  insert(parentHandle, childHandle, index) {
    this.check();
    const parent = own(this.nodes, parentHandle);
    const child = own(this.nodes, childHandle);
    if (parent.element.kind !== "box" || child.id === this.rootId)
      throw new NativeStateError("invalid_state", "Only boxes accept children and the root cannot move");
    let ancestor = parent;
    while (ancestor) {
      if (ancestor.id === child.id)
        throw new NativeStateError("invalid_state", "Native tree cannot contain a cycle");
      ancestor = ancestor.parent === undefined ? undefined : this.nodes.get(ancestor.parent);
    }
    const length = parent.children.length - (child.parent === parent.id ? 1 : 0);
    if (!Number.isSafeInteger(index) || index < 0 || index > length)
      throw new NativeStateError("invalid_state", "Child insertion index is out of range");
    if (child.parent !== undefined) {
      const previous = this.nodes.get(child.parent);
      previous.children.splice(previous.children.indexOf(child.id), 1);
    }
    parent.children.splice(index, 0, child.id);
    child.parent = parent.id;
    this.operations.push({ type: "insert", parent_id: parent.id, child_id: child.id, index });
  }
  append(parentHandle, childHandle) {
    const parent = own(this.nodes, parentHandle);
    const child = own(this.nodes, childHandle);
    this.insert(parentHandle, childHandle, parent.children.length - (child.parent === parent.id ? 1 : 0));
  }
  remove(handle) {
    this.check();
    const node = own(this.nodes, handle);
    if (node.id === this.rootId)
      throw new NativeStateError("invalid_state", "Close the window to dispose its root");
    if (node.parent !== undefined) {
      const parent = this.nodes.get(node.parent);
      parent.children.splice(parent.children.indexOf(node.id), 1);
    }
    const pending = [node.id];
    for (const id of pending) {
      const child = this.nodes.get(id);
      pending.push(...child.children);
      this.nodes.delete(id);
    }
    this.operations.push({ type: "delete", node_id: node.id });
  }
  validate() {
    let seen = 0;
    let bytes = 0;
    const pending = [{ id: this.rootId, depth: 0 }];
    for (const { id, depth } of pending) {
      if (depth > this.limits.max_depth)
        throw new NativeStateError("limit_exceeded", "Native tree depth limit exceeded");
      const node = this.nodes.get(id);
      seen += 1;
      const element = node.element;
      const texts = element.kind === "input" ? [element.value, element.placeholder ?? ""] : element.kind === "box" ? [] : [element.text];
      for (const text of texts) {
        const size = encoder2.encode(text).byteLength;
        if (size > this.limits.max_text_bytes)
          throw new NativeStateError("limit_exceeded", "Native text limit exceeded");
        bytes += size;
      }
      if (bytes > this.limits.max_text_bytes_per_window)
        throw new NativeStateError("limit_exceeded", "Window text memory limit exceeded");
      pending.push(...node.children.map((child) => ({ id: child, depth: depth + 1 })));
    }
    if (seen !== this.nodes.size)
      throw new NativeStateError("invalid_state", "Every created node must be attached before commit");
  }
}

// ../projects/react-typescript/node_modules/@bun-native/core/src/application.ts
var MAX_QUEUED_TRANSACTIONS = 128;
var MAX_QUEUED_CALLBACKS = 128;

class Application {
  host;
  closed;
  limits;
  capabilities;
  serviceCapabilities;
  windows = new Map;
  tail = Promise.resolve();
  queued = 0;
  services = new Set;
  callbacks = [];
  dispatching;
  activeCallbacks = 0;
  nextWindow = 1;
  nextNode = 1;
  stopping;
  failure;
  phase = "running";
  constructor(host) {
    this.host = host;
    this.limits = host.limits;
    this.capabilities = host.capabilities;
    this.serviceCapabilities = serviceCapabilities(host.servicePolicy, host.capabilities);
    this.closed = this.consume();
    this.closed.catch(() => {});
  }
  get diagnostics() {
    let nodes = 0;
    let callbacks = 0;
    for (const window2 of this.windows.values()) {
      nodes += window2.nodes.size;
      callbacks += window2.listeners.size;
    }
    return Object.freeze({
      windows: this.windows.size,
      nodes,
      callbacks,
      queuedTransactions: this.queued,
      queuedCallbacks: this.callbacks.length,
      activeCallbacks: this.activeCallbacks,
      serviceRequests: this.services.size
    });
  }
  allocateNode() {
    if (!Number.isSafeInteger(this.nextNode))
      throw new NativeStateError("limit_exceeded", "Native node identity space exhausted");
    return this.nextNode++;
  }
  cancelCallbacks(windowId) {
    const window2 = this.windows.get(windowId);
    this.callbacks = this.callbacks.filter((callback) => {
      if (callback.windowId !== windowId)
        return true;
      if (window2?.isTargetLive(callback.nodeId) && prunePlan(callback.plan))
        return true;
      window2?.listeners.release(callback.plan);
      return false;
    });
  }
  queueCallback(callback) {
    if (this.phase !== "running")
      return;
    if (this.callbacks.length >= MAX_QUEUED_CALLBACKS)
      throw new ProtocolError("Application callback queue limit exceeded");
    this.callbacks.push(callback);
    this.startDispatch();
  }
  startDispatch() {
    if (!this.callbacks.length)
      return;
    if (this.dispatching)
      return;
    this.dispatching = this.dispatchCallbacks().catch(async (cause) => {
      this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
      await this.shutdown().catch(() => {});
    }).finally(() => {
      this.dispatching = undefined;
      this.startDispatch();
    });
  }
  async dispatchCallbacks() {
    while (this.callbacks.length) {
      const callback = this.callbacks.shift();
      const window2 = this.windows.get(callback.windowId);
      if (!window2)
        continue;
      this.activeCallbacks = 1;
      try {
        await window2.dispatch(callback.nodeId, callback.plan);
      } finally {
        this.activeCallbacks = 0;
      }
    }
  }
  enqueue(operation, closingWindow = false) {
    if (this.phase !== "running")
      return Promise.reject(this.failure ?? new NativeStateError("invalid_state", "Application is shutting down"));
    if (!closingWindow && this.queued >= MAX_QUEUED_TRANSACTIONS)
      return Promise.reject(new NativeStateError("limit_exceeded", "Application transaction queue is full"));
    this.queued += 1;
    const result = this.tail.then(() => {
      if (this.phase !== "running")
        throw this.failure ?? new NativeStateError("invalid_state", "Transaction cancelled during shutdown");
      return operation();
    }).finally(() => {
      this.queued -= 1;
    });
    this.tail = result.then(() => {}, () => {});
    return result;
  }
  openWindow(options) {
    const requested = { ...options };
    return this.enqueue(async () => {
      if (this.windows.size >= this.limits.max_windows)
        throw new NativeStateError("limit_exceeded", "Application window limit exceeded");
      if (!Number.isSafeInteger(this.nextWindow))
        throw new NativeStateError("limit_exceeded", "Native window identity space exhausted");
      const window2 = new Window(this, this.nextWindow++, this.allocateNode());
      this.windows.set(window2.id, window2);
      try {
        await this.host.send({
          type: "open",
          window_id: window2.id,
          root_id: window2.rootId,
          title: requested.title,
          width: requested.width ?? 560,
          height: requested.height ?? 380
        });
        window2.assertActive();
        return window2;
      } catch (error) {
        window2.revoke();
        throw error;
      }
    });
  }
  service(operation) {
    if (this.phase !== "running")
      return Promise.reject(new NativeStateError("invalid_state", "Application is shutting down"));
    if (this.services.size >= this.limits.max_service_requests)
      return Promise.reject(new NativeStateError("limit_exceeded", "Native service request limit exceeded"));
    const result = Promise.resolve().then(() => {
      if (this.phase !== "running")
        throw new NativeStateError("invalid_state", "Service request cancelled during shutdown");
      return operation();
    });
    const settled = result.then(() => {}, () => {}).finally(() => this.services.delete(settled));
    this.services.add(settled);
    return result;
  }
  async shutdown() {
    if (!this.stopping) {
      this.phase = "stopping";
      for (const window2 of this.windows.values())
        window2.revoke();
      this.stopping = (async () => {
        await this.tail;
        await this.host.shutdown();
        await Promise.all(this.services);
      })();
    }
    await this.stopping;
    if (this.failure)
      throw this.failure;
  }
  async consume() {
    try {
      for await (const event of this.host) {
        const window2 = this.windows.get(event.window_id);
        if (!window2) {
          if (event.window_id >= this.nextWindow)
            throw new ProtocolError("Native event names an unallocated window");
          continue;
        }
        window2.receive(event, this.nextNode);
      }
    } catch (cause) {
      this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
      this.phase = "stopping";
      await this.host.shutdown().catch(() => {});
    } finally {
      for (const window2 of this.windows.values())
        window2.revoke();
      await this.dispatching;
      await Promise.all(this.services);
      this.phase = "closed";
    }
    if (this.failure)
      throw this.failure;
  }
}

class Window {
  application;
  id;
  rootId;
  root;
  closed;
  listeners;
  nodes = new Map;
  revision = 0;
  active = true;
  resolveClosed;
  closing;
  constructor(application, id, rootId) {
    this.application = application;
    this.id = id;
    this.rootId = rootId;
    const node = makeNode(rootId, { kind: "box" });
    this.root = node.handle;
    this.nodes.set(rootId, node);
    this.listeners = new EventBindings(() => this.application.cancelCallbacks(this.id));
    this.closed = new Promise((resolve) => {
      this.resolveClosed = resolve;
    });
  }
  assertActive() {
    if (!this.active)
      throw new NativeStateError("invalid_handle", "Window is closed");
  }
  batch(update) {
    return this.application.enqueue(async () => {
      this.assertActive();
      const transaction = new Transaction(this.nodes, this.rootId, () => this.application.allocateNode(), this.application.limits);
      let value;
      try {
        value = update(transaction);
        if (value !== null && (typeof value === "object" || typeof value === "function") && typeof value.then === "function") {
          Promise.resolve(value).catch(() => {});
          throw new NativeStateError("invalid_state", "Batch callbacks must be synchronous");
        }
        transaction.validate();
      } finally {
        transaction.finish();
      }
      if (!transaction.operations.length)
        return value;
      const reply = await this.application.host.send({
        type: "batch",
        window_id: this.id,
        base_revision: this.revision,
        operations: transaction.operations
      });
      this.assertActive();
      for (const [id, candidate] of transaction.nodes) {
        const current = this.nodes.get(id);
        if (current && current.inputRevision > candidate.inputRevision && current.element.kind === "input" && candidate.element.kind === "input") {
          candidate.inputRevision = current.inputRevision;
          candidate.element = { ...candidate.element, value: current.element.value };
        }
      }
      this.nodes = transaction.nodes;
      this.revision = reply.tree_revision;
      this.listeners.retain(this.nodes);
      return value;
    });
  }
  on(handle, type, listener, options) {
    this.assertActive();
    const node = own(this.nodes, handle);
    return this.listeners.register(node.id, node.handle, type, listener, options);
  }
  onClick(handle, listener) {
    this.assertActive();
    const node = own(this.nodes, handle);
    if (node.element.kind !== "button")
      throw new NativeStateError("invalid_state", "Click listeners require a button and a function");
    return this.listeners.register(node.id, node.handle, "click", listener);
  }
  onInput(handle, listener) {
    this.assertActive();
    const node = own(this.nodes, handle);
    if (node.element.kind !== "input")
      throw new NativeStateError("invalid_state", "Input listeners require an input and a function");
    return this.listeners.register(node.id, node.handle, "input", listener);
  }
  input(handle) {
    this.assertActive();
    const node = own(this.nodes, handle);
    if (node.element.kind !== "input")
      throw new NativeStateError("invalid_state", "Only an input has an edit state");
    return Object.freeze({ value: node.element.value, revision: node.inputRevision });
  }
  async displaySnapshot(options = {}) {
    const signal = serviceSignal(options);
    this.assertActive();
    checkServiceCancellation(signal, "window_display");
    return this.application.enqueue(async () => {
      this.assertActive();
      checkServiceCancellation(signal, "window_display");
      try {
        const response = await this.application.host.send({
          type: "display_snapshot",
          window_id: this.id
        });
        this.assertActive();
        checkServiceCancellation(signal, "window_display");
        return Object.freeze({
          bounds: Object.freeze({ ...response.snapshot.bounds }),
          scaleFactor: response.snapshot.scale_factor
        });
      } catch (error) {
        if (error instanceof ProtocolError)
          throw error;
        this.assertActive();
        checkServiceCancellation(signal, "window_display");
        if (error instanceof NativeCommandError && (error.code === "permission_denied" || error.code === "service_unavailable"))
          throw new NativeServiceError("window_display", error.code, error.message);
        throw error;
      }
    });
  }
  async readClipboardText(options = {}) {
    const signal = serviceSignal(options);
    return this.clipboard("clipboard_read", signal, async () => {
      const response = await this.application.host.send({
        type: "clipboard_read",
        window_id: this.id
      });
      return Object.freeze(response.result);
    });
  }
  writeClipboardText(text) {
    return this.clipboard("clipboard_write", undefined, async () => {
      await this.application.host.send({ type: "clipboard_write", window_id: this.id, text });
    });
  }
  async clipboard(service, signal, operation) {
    this.assertActive();
    checkServiceCancellation(signal, service);
    return this.application.service(async () => {
      this.assertActive();
      checkServiceCancellation(signal, service);
      try {
        const result = await operation();
        this.assertActive();
        checkServiceCancellation(signal, service);
        return result;
      } catch (error) {
        if (error instanceof ProtocolError)
          throw error;
        this.assertActive();
        checkServiceCancellation(signal, service);
        if (error instanceof NativeCommandError && [
          "permission_denied",
          "service_unavailable",
          "cancelled",
          "native_failure",
          "operation_timed_out",
          "payload_too_large",
          "limit_exceeded"
        ].includes(error.code))
          throw new NativeServiceError(service, error.code, error.message);
        throw error;
      }
    });
  }
  async close() {
    if (!this.active) {
      await this.closing;
      return;
    }
    this.active = false;
    this.listeners.clear();
    this.nodes.clear();
    this.closing = this.application.enqueue(async () => {
      try {
        await this.application.host.send({ type: "close", window_id: this.id });
      } catch (error) {
        if (!(error instanceof NativeCommandError && error.code === "invalid_handle")) {
          this.application.shutdown().catch(() => {});
          throw error;
        }
      }
      this.revoke();
    }, true);
    await this.closing;
  }
  revoke() {
    this.active = false;
    this.listeners.clear();
    this.nodes.clear();
    this.application.windows.delete(this.id);
    this.resolveClosed();
  }
  isTargetLive(id) {
    return this.active && this.nodes.has(id);
  }
  receive(event, nextNode) {
    if (event.type === "closed") {
      this.revoke();
      return;
    }
    if (!this.active)
      return;
    if (event.tree_revision > this.revision)
      throw new ProtocolError("Native event tree revision is ahead of its acknowledgement");
    if (event.path[0] !== this.rootId)
      throw new ProtocolError("Native event path starts outside its window root");
    const ownedPath = [];
    for (const id of event.path) {
      if (id >= nextNode)
        throw new ProtocolError("Native event names a node outside its owner");
      const node = this.nodes.get(id);
      if (node)
        ownedPath.push(node);
      else
        for (const window2 of this.application.windows.values())
          if (window2 !== this && window2.nodes.has(id))
            throw new ProtocolError("Native event names a node outside its owner");
    }
    if (ownedPath.length !== event.path.length)
      return;
    if (event.tree_revision === this.revision && ownedPath.some((node, index) => index > 0 && node.parent !== event.path[index - 1]))
      throw new ProtocolError("Native event path does not match its committed tree revision");
    const node = ownedPath.at(-1);
    if (event.type === "input") {
      if (node.element.kind !== "input" || event.input_revision <= node.inputRevision)
        throw new ProtocolError("Native input kind or edit revision is invalid");
      node.inputRevision = event.input_revision;
      node.element = { ...node.element, value: event.value };
    } else if (event.type === "click") {
      if (node.element.kind !== "button")
        throw new ProtocolError("Native click targeted a non-button node");
      if (node.element.disabled)
        return;
    }
    const plan = this.listeners.prepare(event, ownedPath.map((item) => item.handle));
    if (plan)
      this.application.queueCallback({ windowId: this.id, nodeId: node.id, plan });
  }
  async dispatch(nodeId, plan) {
    try {
      await dispatchPlan(plan, () => this.isTargetLive(nodeId));
    } finally {
      this.listeners.release(plan);
    }
  }
}
async function createApplication(options) {
  return new Application(await NativeHost.launch(options));
}
// ../projects/react-typescript/node_modules/@bun-native/renderer/src/input-intent.ts
var observations = new WeakMap;
function observeInput(event) {
  observations.set(event, {
    value: event.value,
    revision: event.revision,
    observedNode: event.node
  });
}
function captureInput(value) {
  if (value === undefined || typeof value === "string")
    return value;
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new TypeError("Native input value must be an initial string or { value, revision } intent");
  const observed = observations.get(value);
  if (observed)
    return Object.freeze({ ...observed });
  if (Object.keys(value).some((field) => field !== "value" && field !== "revision"))
    throw new TypeError("Explicit input intents accept only value and revision");
  const data = value;
  const text = data.value;
  const revision = data.revision;
  if (typeof text !== "string")
    throw new TypeError("Input intent value must be a string");
  if (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0)
    throw new NativeStateError("stale_revision", "Input intent requires a nonnegative safe revision");
  return Object.freeze({ value: text, revision, observedNode: undefined });
}

// ../projects/react-typescript/node_modules/@bun-native/renderer/src/event-properties.ts
function binding(type, capture = false) {
  return Object.freeze({ type, capture });
}
var eventProperties = Object.freeze({
  onClick: binding("click"),
  onClickCapture: binding("click", true),
  onInput: binding("input"),
  onInputCapture: binding("input", true),
  onKeyDown: binding("key_down"),
  onKeyDownCapture: binding("key_down", true),
  onKeyUp: binding("key_up"),
  onKeyUpCapture: binding("key_up", true),
  onPointerDown: binding("pointer_down"),
  onPointerDownCapture: binding("pointer_down", true),
  onPointerUp: binding("pointer_up"),
  onPointerUpCapture: binding("pointer_up", true),
  onFocus: binding("focus"),
  onFocusCapture: binding("focus", true),
  onBlur: binding("blur"),
  onBlurCapture: binding("blur", true)
});
function isEventProperty(name) {
  return Object.hasOwn(eventProperties, name);
}
var emptyListeners = Object.freeze({});
function listeners(properties) {
  let result;
  for (const name of Object.keys(properties)) {
    if (!isEventProperty(name))
      continue;
    const listener = properties[name];
    if (listener)
      (result ??= {})[name] = listener;
  }
  return result ? Object.freeze(result) : emptyListeners;
}

// ../projects/react-typescript/node_modules/@bun-native/renderer/src/nodes.ts
var nodes = new WeakSet;

class Node {
  kind;
  children = [];
  properties = {};
  parent;
  owner;
  scope;
  data = "";
  constructor(kind) {
    this.kind = kind;
    nodes.add(this);
  }
}
function createElement(tag) {
  if (tag !== "box" && tag !== "text" && tag !== "button" && tag !== "input")
    throw new UnsupportedFeatureError("native-element:" + tag);
  return new Node(tag);
}
function createTextNode(value) {
  const node = new Node("text-node");
  node.data = String(value);
  return node;
}
function visit(node, fn) {
  fn(node);
  for (const child of node.children)
    visit(child, fn);
}
function insertNode(parent, node, anchor) {
  if (parent.kind === "input" || parent.kind === "text-node")
    throw new NativeStateError("invalid_state", "This native element cannot have children");
  if (parent.kind !== "box" && node.kind !== "text-node")
    throw new NativeStateError("invalid_state", "Text and button children must be text");
  if (anchor && anchor.parent !== parent)
    throw new NativeStateError("invalid_handle", "Insertion anchor belongs to another parent");
  if (anchor === node)
    return;
  for (let ancestor = parent;ancestor; ancestor = ancestor.parent)
    if (ancestor === node)
      throw new NativeStateError("invalid_state", "Native tree cycle");
  const owner = parent.owner;
  if (owner)
    visit(node, (child) => {
      if (child.scope && child.scope !== owner.token)
        throw new NativeStateError("invalid_handle", "Renderer nodes cannot move between render roots");
    });
  const previousOwner = node.owner;
  if (previousOwner && previousOwner !== owner)
    previousOwner.detached(node);
  if (node.parent)
    node.parent.children.splice(node.parent.children.indexOf(node), 1);
  node.parent = parent;
  parent.children.splice(anchor ? parent.children.indexOf(anchor) : parent.children.length, 0, node);
  visit(node, (child) => {
    child.owner = owner;
    if (owner)
      child.scope = owner.token;
  });
  previousOwner?.changed();
  owner?.changed();
}
function removeNode(parent, node) {
  if (node.parent !== parent)
    throw new NativeStateError("invalid_handle", "Removal target belongs to another parent");
  const owner = parent.owner;
  owner?.detached(node);
  parent.children.splice(parent.children.indexOf(node), 1);
  node.parent = undefined;
  visit(node, (child) => {
    child.owner = undefined;
  });
  owner?.changed();
}
function replaceText(node, value) {
  if (node.kind !== "text-node")
    throw new NativeStateError("invalid_state", "Text replacement requires a text node");
  if (node.data === value)
    return;
  node.data = value;
  node.owner?.changed();
}
function setProperty(node, name, value) {
  const props = node.properties;
  if (isEventProperty(name)) {
    if (node.kind === "text-node")
      throw new TypeError("Text literals cannot own native event handlers");
    if (value === undefined)
      delete props[name];
    else if (typeof value === "function")
      props[name] = value;
    else
      throw new TypeError(`Native ${name} must be a function`);
    node.owner?.changed();
    return;
  }
  switch (name) {
    case "style":
      if (value === undefined)
        delete props.style;
      else if (value && typeof value === "object" && !Array.isArray(value))
        props.style = { ...value };
      else
        throw new TypeError("Native style must be an object");
      break;
    case "text":
      if (node.kind !== "text" && node.kind !== "button")
        throw new TypeError("Only text and button elements accept text");
      if (value === undefined)
        delete props.text;
      else if (typeof value === "string")
        props.text = value;
      else
        throw new TypeError("Native text must be a string");
      break;
    case "value": {
      if (node.kind !== "input")
        throw new TypeError("Only inputs accept value");
      const captured = captureInput(value);
      if (captured === undefined)
        delete props.value;
      else
        props.value = captured;
      break;
    }
    case "placeholder":
      if (node.kind !== "input")
        throw new TypeError("Only inputs accept placeholder");
      if (value === undefined)
        delete props.placeholder;
      else if (typeof value === "string")
        props.placeholder = value;
      else
        throw new TypeError("Native input placeholder must be a string");
      break;
    case "disabled":
      if (node.kind !== "button")
        throw new TypeError("Only buttons accept disabled");
      if (value === undefined)
        delete props.disabled;
      else if (typeof value === "boolean")
        props.disabled = value;
      else
        throw new TypeError("Native disabled must be boolean");
      break;
    default:
      throw new UnsupportedFeatureError("native-property:" + name);
  }
  node.owner?.changed();
}
function leafStyle(style) {
  const { overflow, ...rest } = style;
  if (overflow !== undefined && overflow !== "visible" && overflow !== "hidden")
    throw new TypeError("Only native boxes support scrolling");
  return { ...rest, ...overflow === undefined ? {} : { overflow } };
}
function snapshot(root) {
  const result = new Map;
  const capture = (node, parent) => {
    const props = node.properties;
    const style = props.style && node.kind !== "box" ? { style: leafStyle(props.style) } : {};
    let element;
    if (node.kind === "box")
      element = { kind: "box", ...props.style ? { style: { ...props.style } } : {} };
    else if (node.kind === "input")
      element = {
        kind: "input",
        value: typeof props.value === "string" ? props.value : props.value?.value ?? "",
        ...props.placeholder === undefined ? {} : { placeholder: props.placeholder },
        ...style
      };
    else {
      if (props.text !== undefined && node.children.length)
        throw new TypeError("Choose text properties or text children, not both");
      const text = node.kind === "text-node" ? node.data : props.text ?? node.children.map((child) => child.data).join("");
      element = node.kind === "button" ? {
        kind: "button",
        text,
        ...props.disabled === undefined ? {} : { disabled: props.disabled },
        ...style
      } : { kind: "text", text, ...style };
    }
    const children = node.kind === "box" ? [...node.children] : [];
    result.set(node, {
      element,
      children,
      parent,
      events: listeners(props),
      initialValue: typeof props.value === "string" ? props.value : undefined,
      inputIntent: typeof props.value === "object" ? props.value : undefined
    });
    for (const child of children)
      capture(child, node);
  };
  capture(root);
  return result;
}

// ../projects/react-typescript/node_modules/@bun-native/renderer/src/order.ts
function stableChildren(current, desired) {
  const positions = new Map(current.map((node, index) => [node, index]));
  const tails = [];
  const preceding = new Map;
  for (const node of desired) {
    const position = positions.get(node);
    if (position === undefined)
      continue;
    let start = 0;
    let end = tails.length;
    while (start < end) {
      const middle = start + end >>> 1;
      if (tails[middle].position < position)
        start = middle + 1;
      else
        end = middle;
    }
    preceding.set(node, tails[start - 1]?.node);
    tails[start] = { node, position };
  }
  const stable = new Set;
  let node = tails.at(-1)?.node;
  while (node !== undefined) {
    stable.add(node);
    node = preceding.get(node);
  }
  return stable;
}

// ../projects/react-typescript/node_modules/@bun-native/renderer/src/native-tree.ts
function key(element) {
  return JSON.stringify(element);
}
function updateInput(window2, batch, old, state) {
  if (old.element.kind !== "input")
    throw new NativeStateError("invalid_handle", "Input kind changed");
  if (state.initialValue !== undefined && state.initialValue !== old.initialValue)
    throw new UnsupportedFeatureError("input-value-requires-revision");
  const intent = state.inputIntent;
  if (intent && intent !== old.inputIntent) {
    if (intent.observedNode) {
      if (intent.observedNode !== old.handle)
        throw new NativeStateError("invalid_handle", "Native input observation belongs to another node");
    } else {
      batch.set(old.handle, state.element, intent.revision);
      return true;
    }
  }
  const appearance = (element) => JSON.stringify({ placeholder: element.placeholder ?? "", style: element.style ?? {} });
  if (appearance(old.element) === appearance(state.element))
    return false;
  const current = window2.input(old.handle);
  batch.set(old.handle, { ...state.element, value: current.value }, current.revision);
  return true;
}
async function commitNativeTree(window2, root, previous, desired) {
  const counts = { create: 0, set: 0, insert: 0, remove: 0 };
  const next = await window2.batch((batch) => {
    const handles = new Map([...previous].map(([node, state]) => [node, state.handle]));
    const parents = new Map([...previous].map(([node, state]) => [node, state.parent]));
    const children = new Map([...previous].map(([node, state]) => [node, [...state.children]]));
    const attach = (parent, child, index) => {
      const oldParent = parents.get(child);
      const oldChildren = oldParent && children.get(oldParent);
      if (oldChildren)
        oldChildren.splice(oldChildren.indexOf(child), 1);
      const siblings = children.get(parent);
      siblings.splice(index, 0, child);
      parents.set(child, parent);
      batch.insert(handles.get(parent), handles.get(child), index);
      counts.insert += 1;
    };
    const rescue = (node) => {
      const descendants = children.get(node)?.slice() ?? [];
      for (const child of descendants) {
        if (desired.has(child))
          attach(root, child, children.get(root).length);
        else
          rescue(child);
      }
    };
    for (const [node, state] of previous) {
      if (desired.has(node) || state.parent && !desired.has(state.parent))
        continue;
      rescue(node);
      batch.remove(state.handle);
      counts.remove += 1;
      const siblings = state.parent && children.get(state.parent);
      if (siblings)
        siblings.splice(siblings.indexOf(node), 1);
    }
    for (const [node, state] of desired) {
      const old = previous.get(node);
      if (!old) {
        if (state.inputIntent?.observedNode)
          throw new NativeStateError("invalid_handle", "Native input observation belongs to another node");
        if (state.inputIntent && state.inputIntent.revision !== 0)
          throw new NativeStateError("stale_revision", "New input value intent requires revision zero");
        const handle = batch.create(state.element);
        handles.set(node, handle);
        children.set(node, []);
        counts.create += 1;
        if (node === root) {
          batch.append(window2.root, handle);
          counts.insert += 1;
        }
      } else if (state.element.kind === "input") {
        if (updateInput(window2, batch, old, { ...state, element: state.element }))
          counts.set += 1;
      } else if (key(old.element) !== key(state.element)) {
        batch.set(old.handle, state.element);
        counts.set += 1;
      }
    }
    for (const [parent, state] of desired) {
      const siblings = children.get(parent);
      if (siblings.length === state.children.length && siblings.every((child, index) => child === state.children[index]))
        continue;
      const stable = stableChildren(siblings, state.children);
      let anchor;
      for (let index = state.children.length - 1;index >= 0; index -= 1) {
        const child = state.children[index];
        if (!stable.has(child)) {
          const before = anchor === undefined ? siblings.length : siblings.indexOf(anchor);
          const old = parents.get(child) === parent ? siblings.indexOf(child) : -1;
          attach(parent, child, before - (old >= 0 && old < before ? 1 : 0));
        }
        anchor = child;
      }
    }
    return new Map([...desired].map(([node, state]) => [node, { ...state, handle: handles.get(node) }]));
  });
  return { nodes: next, counts };
}

// ../projects/react-typescript/node_modules/@bun-native/renderer/src/window-lifetime.ts
var lifetimes = new WeakMap;
function consume(registration) {
  const listener = registration.listener;
  registration.listener = undefined;
  return listener;
}
function lifetimeFor(window2) {
  let lifetime = lifetimes.get(window2);
  if (!lifetime) {
    const created = { ended: false, listeners: new Set };
    lifetime = created;
    lifetimes.set(window2, created);
    window2.closed.then(() => {
      created.ended = true;
      const listeners = [...created.listeners].map(consume);
      created.listeners.clear();
      for (const notify of listeners)
        notify?.();
    });
  }
  return lifetime;
}
function watchWindow(window2, listener) {
  const lifetime = lifetimeFor(window2);
  if (lifetime.ended)
    throw new NativeStateError("invalid_handle", "Window is already closed");
  const registration = { listener };
  lifetime.listeners.add(registration);
  return () => {
    lifetime.listeners.delete(registration);
    registration.listener = undefined;
  };
}

// ../projects/react-typescript/node_modules/@bun-native/renderer/src/root.ts
class Root {
  window;
  token = {};
  root = new Node("box");
  ready;
  closed;
  resolveClosed;
  rejectClosed;
  disposeFramework;
  unwatch;
  committed = new Map;
  registrations = new Map;
  operation;
  version = 0;
  acknowledged = -1;
  phase = "active";
  windowEnded = false;
  failure;
  commits = 0;
  mutations = { create: 0, set: 0, insert: 0, remove: 0 };
  constructor(window2, initialize, style) {
    this.window = window2;
    setProperty(this.root, "style", style);
    this.closed = new Promise((resolve, reject) => {
      this.resolveClosed = resolve;
      this.rejectClosed = reject;
    });
    this.closed.catch(() => {});
    this.root.owner = this;
    this.root.scope = this.token;
    this.unwatch = watchWindow(window2, () => {
      this.windowEnded = true;
      this.stop();
      this.finish();
    });
    try {
      initialize({
        container: this.root,
        onCleanup: (cleanup) => {
          if (this.disposeFramework)
            throw new NativeStateError("invalid_state", "Framework cleanup is already registered");
          this.disposeFramework = cleanup;
        },
        fail: (cause) => this.fail(cause)
      });
    } catch (cause) {
      this.failure = cause instanceof Error ? cause : new Error(String(cause));
      this.stop();
    }
    this.start();
    this.ready = this.flush().then(() => {
      if (this.commits === 0)
        throw new NativeStateError("invalid_handle", "Render root closed before initial native acknowledgement");
    });
    this.ready.catch(() => {});
  }
  get diagnostics() {
    let listeners = 0;
    for (const registrations of this.registrations.values())
      listeners += registrations.size;
    return Object.freeze({
      nodes: this.committed.size,
      listeners,
      pending: this.operation !== undefined,
      commits: this.commits,
      mutations: Object.freeze({ ...this.mutations })
    });
  }
  changed() {
    if (this.phase !== "active")
      return;
    this.version += 1;
    this.start();
  }
  detached(node) {
    visit(node, (child) => this.revoke(child));
  }
  revoke(node, property) {
    const registrations = this.registrations.get(node);
    if (!registrations)
      return;
    if (property) {
      const registration = registrations.get(property);
      registrations.delete(property);
      if (!registrations.size)
        this.registrations.delete(node);
      registration?.unsubscribe();
    } else {
      this.registrations.delete(node);
      for (const registration of registrations.values())
        registration.unsubscribe();
      registrations.clear();
    }
  }
  input(node) {
    const state = this.committed.get(node);
    if (this.phase !== "active" || !state || state.handle.kind !== "input")
      throw new NativeStateError("invalid_handle", "Input is unmounted or has no committed native handle");
    return this.window.input(state.handle);
  }
  start() {
    if (this.operation || this.phase === "closed")
      return;
    this.operation = Promise.resolve().then(async () => {
      while (this.phase === "active" && this.acknowledged !== this.version) {
        const version = this.version;
        await this.commit(snapshot(this.root));
        this.acknowledged = version;
      }
      if (this.phase === "disposing")
        await this.cleanup();
    }).catch(async (cause) => {
      if (!this.windowEnded) {
        this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
        this.stop();
        try {
          await this.cleanup();
        } catch (cleanupError) {
          this.failure = new AggregateError([this.failure, cleanupError], "Native renderer cleanup failed");
          this.finish();
        }
      }
    }).finally(() => {
      this.operation = undefined;
      if (this.phase === "disposing" || this.phase === "active" && this.acknowledged !== this.version)
        this.start();
    });
  }
  async flush() {
    while (this.operation)
      await this.operation;
    if (this.failure)
      throw this.failure;
  }
  async dispose() {
    this.stop();
    this.start();
    await this.flush();
    await this.closed;
  }
  fail(cause) {
    if (this.phase !== "active")
      return;
    this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
    this.stop();
    this.start();
  }
  stop() {
    if (this.phase === "closed")
      return;
    this.phase = "disposing";
    const dispose = this.disposeFramework;
    this.disposeFramework = undefined;
    try {
      dispose?.();
    } catch (cause) {
      this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
    }
    for (const node of this.registrations.keys())
      this.revoke(node);
    visit(this.root, (node) => {
      node.owner = undefined;
      for (const name of Object.keys(node.properties))
        if (isEventProperty(name))
          delete node.properties[name];
    });
  }
  finish() {
    if (this.phase === "closed")
      return;
    this.phase = "closed";
    this.unwatch?.();
    this.unwatch = undefined;
    this.committed.clear();
    this.root.children.length = 0;
    if (this.failure)
      this.rejectClosed(this.failure);
    else
      this.resolveClosed();
  }
  async cleanup() {
    const root = this.committed.get(this.root);
    if (root && !this.windowEnded) {
      await this.window.batch((batch) => batch.remove(root.handle));
      this.mutations.remove += 1;
      this.commits += 1;
    }
    this.finish();
  }
  async commit(desired) {
    const previous = this.committed;
    const { nodes: next, counts } = await commitNativeTree(this.window, this.root, previous, desired);
    if (this.windowEnded)
      return;
    this.committed = next;
    if (Object.values(counts).some((count) => count > 0))
      this.commits += 1;
    for (const field of ["create", "set", "insert", "remove"])
      this.mutations[field] += counts[field];
    if (this.phase !== "active")
      return;
    for (const node of this.registrations.keys())
      if (!next.has(node) || node.owner !== this)
        this.revoke(node);
    for (const [node, state] of next) {
      if (node.owner !== this)
        continue;
      for (const [name, registration] of this.registrations.get(node) ?? [])
        if (state.events[name] !== registration.listener)
          this.revoke(node, name);
      for (const [name, listener] of Object.entries(state.events)) {
        if (!isEventProperty(name) || !listener || this.registrations.get(node)?.has(name))
          continue;
        const binding = eventProperties[name];
        const unsubscribe = this.window.on(state.handle, binding.type, async (event) => {
          if (node.owner !== this || node.properties[name] !== listener)
            return;
          if (event.type === "input")
            observeInput(event);
          await listener(event);
          await this.flush();
        }, { capture: binding.capture });
        let registrations = this.registrations.get(node);
        if (!registrations) {
          registrations = new Map;
          this.registrations.set(node, registrations);
        }
        registrations.set(name, { listener, unsubscribe });
      }
    }
  }
}
function createRenderRoot(window2, initialize, options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("Native render options must be an object");
  for (const name of Object.keys(options))
    if (name !== "style")
      throw new TypeError("Unknown native render option: " + name);
  return new Root(window2, initialize, options.style);
}
// ../projects/react-typescript/node_modules/@bun-native/react/src/mount.ts
var import_constants2 = __toESM(require_constants(), 1);

// ../projects/react-typescript/node_modules/@bun-native/react/src/reconciler.ts
var import_react = __toESM(require_react(), 1);
var import_react_reconciler = __toESM(require_react_reconciler(), 1);
var import_constants = __toESM(require_constants(), 1);
var context = Object.freeze({});
var updatePriority = import_constants.NoEventPriority;
var activeEvent;
var bindings = new WeakMap;
function unsupported(feature) {
  throw new UnsupportedFeatureError("react-" + feature);
}
var noOp = () => {};
var noInstance = () => null;
var returnFalse = () => false;
var hostContext = () => context;
function createBinding(listener) {
  const binding = { listener, dispatch };
  function dispatch(event) {
    const current = binding.listener;
    if (!current)
      return;
    const previous = activeEvent;
    activeEvent = { type: event.type, observedAt: performance.now() };
    try {
      return reconciler.discreteUpdates(current, event, undefined, undefined, undefined);
    } finally {
      activeEvent = previous;
      reconciler.flushSyncWork();
    }
  }
  return binding;
}
function updateEvent(node, name, value) {
  const registered = bindings.get(node);
  const existing = registered?.get(name);
  if (value === undefined) {
    if (existing)
      existing.listener = undefined;
    registered?.delete(name);
    setProperty(node, name, undefined);
    return;
  }
  if (typeof value !== "function")
    throw new TypeError("Native event listeners must be functions");
  const listener = value;
  if (existing) {
    existing.listener = listener;
    return;
  }
  const binding = createBinding(listener);
  setProperty(node, name, binding.dispatch);
  const next = registered ?? new Map;
  next.set(name, binding);
  bindings.set(node, next);
}
function updateProperties(node, previous, next) {
  for (const name of new Set([...Object.keys(previous), ...Object.keys(next)])) {
    if (name === "children" || name === "ref" || name === "key")
      continue;
    const value = next[name];
    if (Object.hasOwn(previous, name) && Object.is(previous[name], value))
      continue;
    if (isEventProperty(name))
      updateEvent(node, name, value);
    else
      setProperty(node, name, value);
  }
}
var host = {
  supportsMutation: true,
  supportsPersistence: false,
  supportsHydration: false,
  supportsResources: false,
  supportsSingletons: false,
  supportsTestSelectors: false,
  isPrimaryRenderer: true,
  rendererVersion: "0.0.0",
  rendererPackageName: "@bun-native/react",
  extraDevToolsConfig: null,
  bindToConsole(method, args) {
    const log = method === "warn" ? console.warn : method === "error" ? console.error : console.log;
    return log.bind(console, ...args);
  },
  createInstance(type, props) {
    const node = createElement(type);
    updateProperties(node, {}, props);
    return node;
  },
  createTextInstance: createTextNode,
  appendInitialChild: insertNode,
  finalizeInitialChildren: returnFalse,
  shouldSetTextContent: returnFalse,
  getRootHostContext: hostContext,
  getChildHostContext: hostContext,
  getPublicInstance: (node) => node,
  prepareForCommit: noInstance,
  resetAfterCommit: noOp,
  preparePortalMount: unsupported.bind(null, "portals"),
  scheduleTimeout: setTimeout,
  cancelTimeout: clearTimeout,
  noTimeout: null,
  supportsMicrotasks: true,
  scheduleMicrotask: queueMicrotask,
  getInstanceFromNode: noInstance,
  beforeActiveInstanceBlur: noOp,
  afterActiveInstanceBlur: noOp,
  prepareScopeUpdate: unsupported.bind(null, "scope"),
  getInstanceFromScope: noInstance,
  detachDeletedInstance(node) {
    for (const binding of bindings.get(node)?.values() ?? [])
      binding.listener = undefined;
    bindings.delete(node);
    node.children.length = 0;
    node.parent = undefined;
    for (const name of Object.keys(node.properties)) {
      if (isEventProperty(name))
        delete node.properties[name];
    }
  },
  appendChild: insertNode,
  appendChildToContainer: insertNode,
  insertBefore: insertNode,
  insertInContainerBefore: insertNode,
  removeChild: removeNode,
  removeChildFromContainer: removeNode,
  commitTextUpdate: (node, _previous, next) => replaceText(node, next),
  commitUpdate: (node, _type, previous, next) => updateProperties(node, previous, next),
  hideInstance: unsupported.bind(null, "hidden-subtrees"),
  hideTextInstance: unsupported.bind(null, "hidden-subtrees"),
  unhideInstance: unsupported.bind(null, "hidden-subtrees"),
  unhideTextInstance: unsupported.bind(null, "hidden-subtrees"),
  clearContainer(container) {
    while (container.children.length)
      removeNode(container, container.children[0]);
  },
  NotPendingTransition: null,
  HostTransitionContext: import_react.createContext(null),
  setCurrentUpdatePriority(priority) {
    updatePriority = priority;
  },
  getCurrentUpdatePriority: () => updatePriority,
  resolveUpdatePriority: () => updatePriority || import_constants.DefaultEventPriority,
  resetFormInstance: unsupported.bind(null, "forms"),
  requestPostPaintCallback: unsupported.bind(null, "presentation-timing"),
  shouldAttemptEagerTransition: returnFalse,
  trackSchedulerEvent: noOp,
  resolveEventType: () => activeEvent?.type ?? null,
  resolveEventTimeStamp: () => activeEvent?.observedAt ?? -1,
  maySuspendCommit: returnFalse,
  maySuspendCommitOnUpdate: returnFalse,
  maySuspendCommitInSyncRender: returnFalse,
  preloadInstance: () => true,
  startSuspendingCommit: noInstance,
  suspendInstance: unsupported.bind(null, "suspended-host-commit"),
  suspendOnActiveViewTransition: noOp,
  createViewTransitionInstance: unsupported.bind(null, "view-transitions"),
  applyViewTransitionName: unsupported.bind(null, "view-transitions"),
  startViewTransition: unsupported.bind(null, "view-transitions"),
  waitForCommitToBeReady: noInstance,
  getSuspendedCommitReason: noInstance
};
var reconciler = import_react_reconciler.default(host);

// ../projects/react-typescript/node_modules/@bun-native/react/src/commit-barrier.ts
function settle(bindings, failed, cause) {
  const release = bindings.release;
  const resolve = bindings.resolve;
  const reject = bindings.reject;
  bindings.release = undefined;
  bindings.resolve = undefined;
  bindings.reject = undefined;
  release?.();
  if (failed)
    reject?.(cause);
  else
    resolve?.();
}
function createCommitBarrier(bindings) {
  return {
    complete() {
      settle(bindings, false);
    },
    reject(cause) {
      settle(bindings, true, cause);
    }
  };
}

// ../projects/react-typescript/node_modules/@bun-native/react/src/mount.ts
class Root2 {
  ready;
  closed;
  native;
  fiber;
  element;
  phase = "active";
  failure;
  disposal;
  barriers = new Set;
  constructor(children, window2, onRecoverableError, style) {
    this.element = children;
    this.native = createRenderRoot(window2, ({ container, onCleanup, fail }) => {
      const terminate = (error) => {
        this.failure ??= error instanceof Error ? error : new Error(String(error));
        queueMicrotask(() => fail(this.failure));
      };
      this.fiber = reconciler.createContainer(container, import_constants2.ConcurrentRoot, null, false, null, "", terminate, () => {}, (error, info) => {
        try {
          onRecoverableError(error, Object.freeze({ ...info }));
        } catch (reporterError) {
          terminate(reporterError);
        }
      }, () => {}, null);
      onCleanup(() => {
        this.phase = "disposing";
        reconciler.updateContainerSync(null, this.fiber, null);
        reconciler.flushSyncWork();
        reconciler.flushPassiveEffects();
        if (this.failure)
          throw this.failure;
      });
      reconciler.updateContainerSync(children, this.fiber, null);
      reconciler.flushSyncWork();
      if (this.failure !== undefined)
        throw this.failure;
      reconciler.flushPassiveEffects();
    }, style === undefined ? {} : { style });
    this.ready = this.native.ready.then(() => {
      if (this.phase !== "active")
        throw new NativeStateError("invalid_handle", "React root closed before initial native acknowledgement");
    });
    this.ready.catch(() => {});
    this.closed = this.native.closed;
    this.closed.then(() => this.finish(), (error) => {
      this.failure = error;
      this.finish();
    });
  }
  get diagnostics() {
    return this.native.diagnostics;
  }
  finish() {
    this.phase = "closed";
    const error = this.failure ?? new NativeStateError("invalid_state", "React root is closed");
    for (const barrier of this.barriers)
      barrier.reject(error);
    this.barriers.clear();
    this.element = null;
    this.fiber = null;
  }
  assertActive() {
    if (this.failure !== undefined)
      throw this.failure;
    if (this.phase !== "active")
      throw new NativeStateError("invalid_state", "React root is closed");
  }
  async render(children) {
    this.assertActive();
    this.element = children;
    reconciler.updateContainerSync(children, this.fiber, null);
    reconciler.flushSyncWork();
    await this.flush();
  }
  async flush() {
    this.assertActive();
    reconciler.flushPassiveEffects();
    await new Promise((resolve, reject) => {
      if (this.barriers.size >= 128) {
        reject(new NativeStateError("limit_exceeded", "React commit barrier queue is full"));
        return;
      }
      const barrier = createCommitBarrier({
        release: () => this.barriers.delete(barrier),
        resolve,
        reject
      });
      this.barriers.add(barrier);
      try {
        reconciler.updateContainer(this.element, this.fiber, null, barrier.complete);
      } catch (cause) {
        barrier.reject(cause);
      }
    });
    await this.native.flush();
    this.assertActive();
    reconciler.flushPassiveEffects();
    await this.native.flush();
  }
  dispose() {
    if (!this.disposal) {
      this.phase = "disposing";
      this.disposal = reconciler.isAlreadyRendering() ? Promise.resolve().then(() => this.native.dispose()) : this.native.dispose();
    }
    return this.disposal;
  }
}
function render(children, window2, options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("React render options must be an object");
  for (const name of Object.keys(options))
    if (name !== "onRecoverableError" && name !== "style")
      throw new TypeError("Unknown React render option: " + name);
  const reporter = options.onRecoverableError;
  if (reporter !== undefined && typeof reporter !== "function")
    throw new TypeError("onRecoverableError must be a function");
  return new Root2(children, window2, reporter ?? console.error, options.style);
}
// ../projects/react-typescript/main.tsx
var import_react3 = __toESM(require_react(), 1);

// ../projects/react-typescript/node_modules/@bun-native/react/src/jsx-runtime.ts
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);

// ../projects/react-typescript/main.tsx
var executable = process.env["BUN_NATIVE_HOST"];
if (!executable)
  throw new Error("Run the dev command with --host pointing to a prebuilt native host");
var application = await createApplication({ executable });
var view;
var stopped = Promise.withResolvers();
var stop = () => stopped.resolve();
function stopFromParent(message) {
  if (message && typeof message === "object" && "type" in message && message.type === "bun-native:stop")
    stop();
}
process.once("SIGINT", stop);
process.once("SIGTERM", stop);
process.on("message", stopFromParent);
function App() {
  const [clicks, setClicks] = import_react3.useState(0);
  return /* @__PURE__ */ import_jsx_runtime.jsxs("box", {
    style: { direction: "column", gap: 12, padding: 24 },
    children: [
      /* @__PURE__ */ import_jsx_runtime.jsx("text", {
        text: "Bun Native React",
        style: { font_size: 28 }
      }),
      /* @__PURE__ */ import_jsx_runtime.jsx("text", {
        text: "Clicks: " + clicks
      }),
      /* @__PURE__ */ import_jsx_runtime.jsx("button", {
        text: "Increment",
        style: { width: 160, height: 44 },
        onClick: () => {
          setClicks((value) => value + 1);
        }
      })
    ]
  });
}
try {
  const window2 = await application.openWindow({
    title: "Bun Native React",
    width: 640,
    height: 480
  });
  view = render(/* @__PURE__ */ import_jsx_runtime.jsx(App, {}), window2);
  await view.ready;
  process.send?.({ type: "bun-native:ready" });
  await Promise.race([window2.closed, view.closed, stopped.promise]);
} finally {
  process.off("SIGINT", stop);
  process.off("SIGTERM", stop);
  process.off("message", stopFromParent);
  try {
    await view?.dispose();
  } finally {
    await application.shutdown();
    await application.closed;
    process.send?.({
      type: "bun-native:stopped",
      application: application.diagnostics,
      nodes: view?.diagnostics.nodes ?? 0
    });
    if (process.connected)
      process.disconnect?.();
  }
}

//# debugId=71DB38FC5DCB183564756E2164756E21
