/** @jsxImportSource @bun-native/react */
import { createApplication } from '@bun-native/core'
import { render } from '@bun-native/react'
import { useState } from 'react'

const executable = process.env['BUN_NATIVE_HOST']
if (!executable)
  throw new Error('Run the dev command with --host pointing to a prebuilt native host')
const application = await createApplication({ executable })
/** @type {ReturnType<typeof render> | undefined} */
let view
const stopped = Promise.withResolvers()
const stop = () => stopped.resolve(undefined)
/** @param {unknown} message */
function stopFromParent(message) {
  if (
    message &&
    typeof message === 'object' &&
    'type' in message &&
    message.type === 'bun-native:stop'
  )
    stop()
}
process.once('SIGINT', stop)
process.once('SIGTERM', stop)
process.on('message', stopFromParent)

function App() {
  const [clicks, setClicks] = useState(0)
  return (
    <box style={{ direction: 'column', gap: 12, padding: 24 }}>
      <text text="Bun Native React" style={{ font_size: 28 }} />
      <text text={'Clicks: ' + clicks} />
      <button
        text="Increment"
        style={{ width: 160, height: 44 }}
        onClick={() => {
          setClicks((value) => value + 1)
        }}
      />
    </box>
  )
}

try {
  const window = await application.openWindow({
    title: 'Bun Native React',
    width: 640,
    height: 480,
  })
  view = render(<App />, window)
  await view.ready
  process.send?.({ type: 'bun-native:ready' })
  await Promise.race([window.closed, view.closed, stopped.promise])
} finally {
  process.off('SIGINT', stop)
  process.off('SIGTERM', stop)
  process.off('message', stopFromParent)
  try {
    await view?.dispose()
  } finally {
    await application.shutdown()
    await application.closed
    process.send?.({
      type: 'bun-native:stopped',
      application: application.diagnostics,
      nodes: view?.diagnostics.nodes ?? 0,
    })
    if (process.connected) process.disconnect?.()
  }
}
