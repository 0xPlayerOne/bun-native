import { createApplication } from '@bun-native/core'
import { render, type JSX } from '@bun-native/solid'
import { createSignal } from 'solid-js'

const executable = process.env['BUN_NATIVE_HOST']
if (!executable)
  throw new Error('Run the dev command with --host pointing to a prebuilt native host')
const application = await createApplication({ executable })
let view: ReturnType<typeof render> | undefined
const stopped = Promise.withResolvers<void>()
const stop = () => stopped.resolve()
function stopFromParent(message: unknown) {
  if (
    message &&
    typeof message === 'object' &&
    'type' in message &&
    message.type === 'bun-native:stop'
  )
    stop()
}
process.once('SIGINT', stop)
process.once('SIGTERM', stop)
process.on('message', stopFromParent)

function App(): JSX.Element {
  const [clicks, setClicks] = createSignal(0)
  return (
    <box style={{ direction: 'column', gap: 12, padding: 24 }}>
      <text text="Bun Native Solid" style={{ font_size: 28 }} />
      <text text={'Clicks: ' + clicks()} />
      <button
        text="Increment"
        style={{ width: 160, height: 44 }}
        onClick={() => {
          setClicks((value) => value + 1)
        }}
      />
    </box>
  )
}

try {
  const window = await application.openWindow({
    title: 'Bun Native Solid',
    width: 640,
    height: 480,
  })
  view = render(App, window)
  await view.ready
  process.send?.({ type: 'bun-native:ready' })
  await Promise.race([window.closed, view.closed, stopped.promise])
} finally {
  process.off('SIGINT', stop)
  process.off('SIGTERM', stop)
  process.off('message', stopFromParent)
  try {
    await view?.dispose()
  } finally {
    await application.shutdown()
    await application.closed
    process.send?.({
      type: 'bun-native:stopped',
      application: application.diagnostics,
      nodes: view?.diagnostics.nodes ?? 0,
    })
    if (process.connected) process.disconnect?.()
  }
}
