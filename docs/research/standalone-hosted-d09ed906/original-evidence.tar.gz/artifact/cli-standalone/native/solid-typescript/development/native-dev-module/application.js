// @bun
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/solid-js/dist/solid.js
var sharedConfig = {
  context: undefined,
  registry: undefined,
  effects: undefined,
  done: false,
  getContextId() {
    return getContextId(this.context.count);
  },
  getNextContextId() {
    return getContextId(this.context.count++);
  }
};
function getContextId(count) {
  const num = String(count), len = num.length - 1;
  return sharedConfig.context.id + (len ? String.fromCharCode(96 + len) : "") + num;
}
function setHydrateContext(context) {
  sharedConfig.context = context;
}
function nextHydrateContext() {
  return {
    ...sharedConfig.context,
    id: sharedConfig.getNextContextId(),
    count: 0
  };
}
var IS_DEV = false;
var equalFn = (a, b) => a === b;
var $PROXY = Symbol("solid-proxy");
var SUPPORTS_PROXY = typeof Proxy === "function";
var $TRACK = Symbol("solid-track");
var $DEVCOMP = Symbol("solid-dev-component");
var signalOptions = {
  equals: equalFn
};
var ERROR = null;
var runEffects = runQueue;
var STALE = 1;
var PENDING = 2;
var UNOWNED = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var Owner = null;
var Transition = null;
var Scheduler = null;
var ExternalSourceConfig = null;
var Listener = null;
var Updates = null;
var Effects = null;
var ExecCount = 0;
function createRoot(fn, detachedOwner) {
  const listener = Listener, owner = Owner, unowned = fn.length === 0, current = detachedOwner === undefined ? owner : detachedOwner, root = unowned ? UNOWNED : {
    owned: null,
    cleanups: null,
    context: current ? current.context : null,
    owner: current
  }, updateFn = unowned ? fn : () => fn(createDisposer(root));
  Owner = root;
  Listener = null;
  try {
    return runUpdates(updateFn, true);
  } finally {
    Listener = listener;
    Owner = owner;
  }
}
function createDisposer(root) {
  return () => untrack(() => cleanNode(root));
}
function createSignal(value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const s = {
    value,
    observers: null,
    observerSlots: null,
    comparator: options.equals || undefined
  };
  const setter = (value) => {
    if (typeof value === "function") {
      if (Transition && Transition.running && Transition.sources.has(s))
        value = value(s.tValue);
      else
        value = value(s.value);
    }
    return writeSignal(s, value);
  };
  return [readSignal.bind(s), setter];
}
function createRenderEffect(fn, value, options) {
  const c = createComputation(fn, value, false, STALE);
  if (Scheduler && Transition && Transition.running)
    Updates.push(c);
  else
    updateComputation(c);
}
function createMemo(fn, value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const c = createComputation(fn, value, true, 0);
  c.observers = null;
  c.observerSlots = null;
  c.comparator = options.equals || undefined;
  if (Scheduler && Transition && Transition.running) {
    c.tState = STALE;
    Updates.push(c);
  } else
    updateComputation(c);
  return readSignal.bind(c);
}
function untrack(fn) {
  if (!ExternalSourceConfig && Listener === null)
    return fn();
  const listener = Listener;
  Listener = null;
  try {
    if (ExternalSourceConfig)
      return ExternalSourceConfig.untrack(fn);
    return fn();
  } finally {
    Listener = listener;
  }
}
function onCleanup(fn) {
  if (Owner === null)
    ;
  else if (Owner.cleanups === null)
    Owner.cleanups = [fn];
  else
    Owner.cleanups.push(fn);
  return fn;
}
function startTransition(fn) {
  if (Transition && Transition.running) {
    fn();
    return Transition.done;
  }
  const l = Listener;
  const o = Owner;
  return Promise.resolve().then(() => {
    Listener = l;
    Owner = o;
    let t;
    if (Scheduler || SuspenseContext) {
      t = Transition || (Transition = {
        sources: new Set,
        effects: [],
        promises: new Set,
        disposed: new Set,
        queue: new Set,
        running: true
      });
      t.done || (t.done = new Promise((res) => t.resolve = res));
      t.running = true;
    }
    runUpdates(fn, false);
    Listener = Owner = null;
    return t ? t.done : undefined;
  });
}
var [transPending, setTransPending] = /* @__PURE__ */ createSignal(false);
var SuspenseContext;
function readSignal() {
  const runningTransition = Transition && Transition.running;
  if (this.sources && (runningTransition ? this.tState : this.state)) {
    if ((runningTransition ? this.tState : this.state) === STALE)
      updateComputation(this);
    else {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(this), false);
      Updates = updates;
    }
  }
  if (Listener) {
    const observers = this.observers;
    if (!observers || observers[observers.length - 1] !== Listener) {
      const sSlot = observers ? observers.length : 0;
      if (!Listener.sources) {
        Listener.sources = [this];
        Listener.sourceSlots = [sSlot];
      } else {
        Listener.sources.push(this);
        Listener.sourceSlots.push(sSlot);
      }
      if (!observers) {
        this.observers = [Listener];
        this.observerSlots = [Listener.sources.length - 1];
      } else {
        observers.push(Listener);
        this.observerSlots.push(Listener.sources.length - 1);
      }
    }
  }
  if (runningTransition && Transition.sources.has(this))
    return this.tValue;
  return this.value;
}
function writeSignal(node, value, isComp) {
  let current = Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value;
  if (!node.comparator || !node.comparator(current, value)) {
    if (Transition) {
      const TransitionRunning = Transition.running;
      if (TransitionRunning || !isComp && Transition.sources.has(node)) {
        Transition.sources.add(node);
        node.tValue = value;
      }
      if (!TransitionRunning)
        node.value = value;
    } else
      node.value = value;
    if (node.observers && node.observers.length) {
      runUpdates(() => {
        for (let i = 0;i < node.observers.length; i += 1) {
          const o = node.observers[i];
          const TransitionRunning = Transition && Transition.running;
          if (TransitionRunning && Transition.disposed.has(o))
            continue;
          if (TransitionRunning ? !o.tState : !o.state) {
            if (o.pure)
              Updates.push(o);
            else
              Effects.push(o);
            if (o.observers)
              markDownstream(o);
          }
          if (!TransitionRunning)
            o.state = STALE;
          else
            o.tState = STALE;
        }
        if (Updates.length > 1e6) {
          Updates = [];
          if (IS_DEV)
            ;
          throw new Error;
        }
      }, false);
    }
  }
  return value;
}
function updateComputation(node) {
  if (!node.fn)
    return;
  cleanNode(node);
  const time = ExecCount;
  runComputation(node, Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value, time);
  if (Transition && !Transition.running && Transition.sources.has(node)) {
    queueMicrotask(() => {
      runUpdates(() => {
        Transition && (Transition.running = true);
        Listener = Owner = node;
        runComputation(node, node.tValue, time);
        Listener = Owner = null;
      }, false);
    });
  }
}
function runComputation(node, value, time) {
  let nextValue;
  const owner = Owner, listener = Listener;
  Listener = Owner = node;
  try {
    nextValue = node.fn(value);
  } catch (err) {
    if (node.pure) {
      if (Transition && Transition.running) {
        node.tState = STALE;
        node.tOwned && node.tOwned.forEach(cleanNode);
        node.tOwned = undefined;
      } else {
        node.state = STALE;
        node.owned && node.owned.forEach(cleanNode);
        node.owned = null;
      }
    }
    node.updatedAt = time + 1;
    return handleError(err);
  } finally {
    Listener = listener;
    Owner = owner;
  }
  if (!node.updatedAt || node.updatedAt <= time) {
    if (node.updatedAt != null && "observers" in node) {
      writeSignal(node, nextValue, true);
    } else if (Transition && Transition.running && node.pure) {
      if (!Transition.sources.has(node))
        node.value = nextValue;
      Transition.sources.add(node);
      node.tValue = nextValue;
    } else
      node.value = nextValue;
    node.updatedAt = time;
  }
}
function createComputation(fn, init, pure, state = STALE, options) {
  const c = {
    fn,
    state,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: init,
    owner: Owner,
    context: Owner ? Owner.context : null,
    pure
  };
  if (Transition && Transition.running) {
    c.state = 0;
    c.tState = state;
  }
  if (Owner === null)
    ;
  else if (Owner !== UNOWNED) {
    if (Transition && Transition.running && Owner.pure) {
      if (!Owner.tOwned)
        Owner.tOwned = [c];
      else
        Owner.tOwned.push(c);
    } else {
      if (!Owner.owned)
        Owner.owned = [c];
      else
        Owner.owned.push(c);
    }
  }
  if (ExternalSourceConfig && c.fn) {
    const sourceFn = c.fn;
    const [track, trigger] = createSignal(undefined, {
      equals: false
    });
    const ordinary = ExternalSourceConfig.factory(sourceFn, trigger);
    onCleanup(() => ordinary.dispose());
    let inTransition;
    let trackedOrdinary = false;
    const triggerInTransition = () => startTransition(trigger).then(() => {
      if (inTransition) {
        inTransition.dispose();
        inTransition = undefined;
        if (!trackedOrdinary)
          trigger();
      }
    });
    c.fn = (x) => {
      track();
      if (Transition && Transition.running) {
        if (!inTransition)
          inTransition = ExternalSourceConfig.factory(sourceFn, triggerInTransition);
        return inTransition.track(x);
      }
      trackedOrdinary = true;
      return ordinary.track(x);
    };
  }
  return c;
}
function runTop(node) {
  const runningTransition = Transition && Transition.running;
  if ((runningTransition ? node.tState : node.state) === 0)
    return;
  if ((runningTransition ? node.tState : node.state) === PENDING)
    return lookUpstream(node);
  if (node.suspense && untrack(node.suspense.inFallback))
    return node.suspense.effects.push(node);
  const ancestors = [node];
  while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
    if (runningTransition && Transition.disposed.has(node))
      return;
    if (runningTransition ? node.tState : node.state)
      ancestors.push(node);
  }
  for (let i = ancestors.length - 1;i >= 0; i--) {
    node = ancestors[i];
    if (runningTransition) {
      let top = node, prev = ancestors[i + 1];
      while ((top = top.owner) && top !== prev) {
        if (Transition.disposed.has(top))
          return;
      }
    }
    if ((runningTransition ? node.tState : node.state) === STALE) {
      updateComputation(node);
    } else if ((runningTransition ? node.tState : node.state) === PENDING) {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(node, ancestors[0]), false);
      Updates = updates;
    }
  }
}
function runUpdates(fn, init) {
  if (Updates)
    return fn();
  let wait = false;
  if (!init)
    Updates = [];
  if (Effects)
    wait = true;
  else
    Effects = [];
  ExecCount++;
  try {
    const res = fn();
    completeUpdates(wait);
    return res;
  } catch (err) {
    if (!wait)
      Effects = null;
    Updates = null;
    handleError(err);
  }
}
function completeUpdates(wait) {
  if (Updates) {
    if (Scheduler && Transition && Transition.running)
      scheduleQueue(Updates);
    else
      runQueue(Updates);
    Updates = null;
  }
  if (wait)
    return;
  let res;
  if (Transition) {
    if (!Transition.promises.size && !Transition.queue.size) {
      const sources = Transition.sources;
      const disposed = Transition.disposed;
      Effects.push.apply(Effects, Transition.effects);
      res = Transition.resolve;
      for (const e of Effects) {
        "tState" in e && (e.state = e.tState);
        delete e.tState;
      }
      Transition = null;
      runUpdates(() => {
        for (const d of disposed)
          cleanNode(d);
        for (const v of sources) {
          v.value = v.tValue;
          if (v.owned) {
            for (let i = 0, len = v.owned.length;i < len; i++)
              cleanNode(v.owned[i]);
          }
          if (v.tOwned)
            v.owned = v.tOwned;
          delete v.tValue;
          delete v.tOwned;
          v.tState = 0;
        }
        setTransPending(false);
      }, false);
    } else if (Transition.running) {
      Transition.running = false;
      Transition.effects.push.apply(Transition.effects, Effects);
      Effects = null;
      setTransPending(true);
      return;
    }
  }
  const e = Effects;
  Effects = null;
  if (e.length)
    runUpdates(() => runEffects(e), false);
  if (res)
    res();
}
function runQueue(queue) {
  for (let i = 0;i < queue.length; i++)
    runTop(queue[i]);
}
function scheduleQueue(queue) {
  for (let i = 0;i < queue.length; i++) {
    const item = queue[i];
    const tasks = Transition.queue;
    if (!tasks.has(item)) {
      tasks.add(item);
      Scheduler(() => {
        tasks.delete(item);
        runUpdates(() => {
          Transition.running = true;
          runTop(item);
        }, false);
        Transition && (Transition.running = false);
      });
    }
  }
}
function lookUpstream(node, ignore) {
  const runningTransition = Transition && Transition.running;
  if (runningTransition)
    node.tState = 0;
  else
    node.state = 0;
  for (let i = 0;i < node.sources.length; i += 1) {
    const source = node.sources[i];
    if (source.sources) {
      const state = runningTransition ? source.tState : source.state;
      if (state === STALE) {
        if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount))
          runTop(source);
      } else if (state === PENDING)
        lookUpstream(source, ignore);
    }
  }
}
function markDownstream(node) {
  const runningTransition = Transition && Transition.running;
  for (let i = 0;i < node.observers.length; i += 1) {
    const o = node.observers[i];
    if (runningTransition ? !o.tState : !o.state) {
      if (runningTransition)
        o.tState = PENDING;
      else
        o.state = PENDING;
      if (o.pure)
        Updates.push(o);
      else
        Effects.push(o);
      o.observers && markDownstream(o);
    }
  }
}
function cleanNode(node) {
  let i;
  if (node.sources) {
    while (node.sources.length) {
      const source = node.sources.pop(), index = node.sourceSlots.pop(), obs = source.observers;
      if (obs && obs.length) {
        const n = obs.pop(), s = source.observerSlots.pop();
        if (index < obs.length) {
          n.sourceSlots[s] = index;
          obs[index] = n;
          source.observerSlots[index] = s;
        }
      }
    }
  }
  if (node.tOwned) {
    for (i = node.tOwned.length - 1;i >= 0; i--)
      cleanNode(node.tOwned[i]);
    delete node.tOwned;
  }
  if (Transition && Transition.running && node.pure) {
    reset(node, true);
  } else if (node.owned) {
    for (i = node.owned.length - 1;i >= 0; i--)
      cleanNode(node.owned[i]);
    node.owned = null;
  }
  if (node.cleanups) {
    for (i = node.cleanups.length - 1;i >= 0; i--)
      node.cleanups[i]();
    node.cleanups = null;
  }
  if (Transition && Transition.running)
    node.tState = 0;
  else
    node.state = 0;
}
function reset(node, top) {
  if (!top) {
    node.tState = 0;
    Transition.disposed.add(node);
  }
  if (node.owned) {
    for (let i = 0;i < node.owned.length; i++)
      reset(node.owned[i]);
  }
}
function castError(err) {
  if (err instanceof Error)
    return err;
  return new Error(typeof err === "string" ? err : "Unknown error", {
    cause: err
  });
}
function runErrors(err, fns, owner) {
  try {
    for (const f of fns)
      f(err);
  } catch (e) {
    handleError(e, owner && owner.owner || null);
  }
}
function handleError(err, owner = Owner) {
  const fns = ERROR && owner && owner.context && owner.context[ERROR];
  const error = castError(err);
  if (!fns)
    throw error;
  if (Effects)
    Effects.push({
      fn() {
        runErrors(error, fns, owner);
      },
      state: STALE
    });
  else
    runErrors(error, fns, owner);
}
var FALLBACK = Symbol("fallback");
var hydrationEnabled = false;
function createComponent(Comp, props) {
  if (hydrationEnabled) {
    if (sharedConfig.context) {
      const c = sharedConfig.context;
      setHydrateContext(nextHydrateContext());
      const r = untrack(() => Comp(props || {}));
      setHydrateContext(c);
      return r;
    }
  }
  return untrack(() => Comp(props || {}));
}
function trueFn() {
  return true;
}
var propTraps = {
  get(_, property, receiver) {
    if (property === $PROXY)
      return receiver;
    return _.get(property);
  },
  has(_, property) {
    if (property === $PROXY)
      return true;
    return _.has(property);
  },
  set: trueFn,
  deleteProperty: trueFn,
  getOwnPropertyDescriptor(_, property) {
    return {
      configurable: true,
      enumerable: true,
      get() {
        return _.get(property);
      },
      set: trueFn,
      deleteProperty: trueFn
    };
  },
  ownKeys(_) {
    return _.keys();
  }
};
function resolveSource(s) {
  return !(s = typeof s === "function" ? s() : s) ? {} : s;
}
function resolveSources() {
  for (let i = 0, length = this.length;i < length; ++i) {
    const v = this[i]();
    if (v !== undefined)
      return v;
  }
}
function mergeProps(...sources) {
  let proxy = false;
  for (let i = 0;i < sources.length; i++) {
    const s = sources[i];
    proxy = proxy || !!s && $PROXY in s;
    sources[i] = typeof s === "function" ? (proxy = true, createMemo(s)) : s;
  }
  if (SUPPORTS_PROXY && proxy) {
    return new Proxy({
      get(property) {
        for (let i = sources.length - 1;i >= 0; i--) {
          const v = resolveSource(sources[i])[property];
          if (v !== undefined)
            return v;
        }
      },
      has(property) {
        for (let i = sources.length - 1;i >= 0; i--) {
          if (property in resolveSource(sources[i]))
            return true;
        }
        return false;
      },
      keys() {
        const keys = [];
        for (let i = 0;i < sources.length; i++)
          keys.push(...Object.keys(resolveSource(sources[i])));
        return [...new Set(keys)];
      }
    }, propTraps);
  }
  const sourcesMap = {};
  const defined = Object.create(null);
  for (let i = sources.length - 1;i >= 0; i--) {
    const source = sources[i];
    if (!source)
      continue;
    const sourceKeys = Object.getOwnPropertyNames(source);
    for (let i = sourceKeys.length - 1;i >= 0; i--) {
      const key = sourceKeys[i];
      if (key === "__proto__" || key === "constructor")
        continue;
      const desc = Object.getOwnPropertyDescriptor(source, key);
      if (!defined[key]) {
        defined[key] = desc.get ? {
          enumerable: true,
          configurable: true,
          get: resolveSources.bind(sourcesMap[key] = [desc.get.bind(source)])
        } : desc.value !== undefined ? desc : undefined;
      } else {
        const sources = sourcesMap[key];
        if (sources) {
          if (desc.get)
            sources.push(desc.get.bind(source));
          else if (desc.value !== undefined)
            sources.push(() => desc.value);
        }
      }
    }
  }
  const target = {};
  const definedKeys = Object.keys(defined);
  for (let i = definedKeys.length - 1;i >= 0; i--) {
    const key = definedKeys[i], desc = defined[key];
    if (desc && desc.get)
      Object.defineProperty(target, key, desc);
    else
      target[key] = desc ? desc.value : undefined;
  }
  return target;
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/solid-js/universal/dist/universal.js
var memo = (fn) => createMemo(() => fn());
function createRenderer$1({
  createElement,
  createTextNode,
  isTextNode,
  replaceText,
  insertNode,
  removeNode,
  setProperty,
  getParentNode,
  getFirstChild,
  getNextSibling
}) {
  function insert(parent, accessor, marker, initial) {
    if (marker !== undefined && !initial)
      initial = [];
    if (typeof accessor !== "function")
      return insertExpression(parent, accessor, initial, marker);
    createRenderEffect((current) => insertExpression(parent, accessor(), current, marker), initial);
  }
  function insertExpression(parent, value, current, marker, unwrapArray) {
    while (typeof current === "function")
      current = current();
    if (value === current)
      return current;
    const t = typeof value, multi = marker !== undefined;
    if (t === "string" || t === "number") {
      if (t === "number")
        value = value.toString();
      if (multi) {
        let node = current[0];
        if (node && isTextNode(node)) {
          replaceText(node, value);
        } else
          node = createTextNode(value);
        current = cleanChildren(parent, current, marker, node);
      } else {
        if (current !== "" && typeof current === "string") {
          replaceText(getFirstChild(parent), current = value);
        } else {
          cleanChildren(parent, current, marker, createTextNode(value));
          current = value;
        }
      }
    } else if (value == null || t === "boolean") {
      current = cleanChildren(parent, current, marker);
    } else if (t === "function") {
      createRenderEffect(() => {
        let v = value();
        while (typeof v === "function")
          v = v();
        current = insertExpression(parent, v, current, marker);
      });
      return () => current;
    } else if (Array.isArray(value)) {
      const array = [];
      if (normalizeIncomingArray(array, value, unwrapArray)) {
        createRenderEffect(() => current = insertExpression(parent, array, current, marker, true));
        return () => current;
      }
      if (array.length === 0) {
        const replacement = cleanChildren(parent, current, marker);
        if (multi)
          return current = replacement;
      } else {
        if (Array.isArray(current)) {
          if (current.length === 0) {
            appendNodes(parent, array, marker);
          } else
            reconcileArrays(parent, current, array);
        } else if (current == null || !getFirstChild(parent)) {
          appendNodes(parent, array);
        } else {
          reconcileArrays(parent, multi && current || [getFirstChild(parent)], array);
        }
      }
      current = array;
    } else {
      if (Array.isArray(current)) {
        if (multi)
          return current = cleanChildren(parent, current, marker, value);
        cleanChildren(parent, current, null, value);
      } else if (current == null || !getFirstChild(parent)) {
        insertNode(parent, value);
      } else
        replaceNode(parent, value, getFirstChild(parent));
      current = value;
    }
    return current;
  }
  function normalizeIncomingArray(normalized, array, unwrap) {
    let dynamic = false;
    for (let i = 0, len = array.length;i < len; i++) {
      let item = array[i], t;
      if (item == null || item === true || item === false)
        ;
      else if (Array.isArray(item)) {
        dynamic = normalizeIncomingArray(normalized, item) || dynamic;
      } else if ((t = typeof item) === "string" || t === "number") {
        normalized.push(createTextNode(item));
      } else if (t === "function") {
        if (unwrap) {
          while (typeof item === "function")
            item = item();
          dynamic = normalizeIncomingArray(normalized, Array.isArray(item) ? item : [item]) || dynamic;
        } else {
          normalized.push(item);
          dynamic = true;
        }
      } else
        normalized.push(item);
    }
    return dynamic;
  }
  function reconcileArrays(parentNode, a, b) {
    let bLength = b.length, aEnd = a.length, bEnd = bLength, aStart = 0, bStart = 0, after = getNextSibling(a[aEnd - 1]), map = null;
    while (aStart < aEnd || bStart < bEnd) {
      if (a[aStart] === b[bStart]) {
        aStart++;
        bStart++;
        continue;
      }
      while (a[aEnd - 1] === b[bEnd - 1]) {
        aEnd--;
        bEnd--;
      }
      if (aEnd === aStart) {
        const node = bEnd < bLength ? bStart ? getNextSibling(b[bStart - 1]) : b[bEnd - bStart] : after;
        while (bStart < bEnd)
          insertNode(parentNode, b[bStart++], node);
      } else if (bEnd === bStart) {
        while (aStart < aEnd) {
          if (!map || !map.has(a[aStart]))
            removeNode(parentNode, a[aStart]);
          aStart++;
        }
      } else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
        const node = getNextSibling(a[--aEnd]);
        insertNode(parentNode, b[bStart++], getNextSibling(a[aStart++]));
        insertNode(parentNode, b[--bEnd], node);
        a[aEnd] = b[bEnd];
      } else {
        if (!map) {
          map = new Map;
          let i = bStart;
          while (i < bEnd)
            map.set(b[i], i++);
        }
        const index = map.get(a[aStart]);
        if (index != null) {
          if (bStart < index && index < bEnd) {
            let i = aStart, sequence = 1, t;
            while (++i < aEnd && i < bEnd) {
              if ((t = map.get(a[i])) == null || t !== index + sequence)
                break;
              sequence++;
            }
            if (sequence > index - bStart) {
              const node = a[aStart];
              while (bStart < index)
                insertNode(parentNode, b[bStart++], node);
            } else
              replaceNode(parentNode, b[bStart++], a[aStart++]);
          } else
            aStart++;
        } else
          removeNode(parentNode, a[aStart++]);
      }
    }
  }
  function cleanChildren(parent, current, marker, replacement) {
    if (marker === undefined) {
      let removed;
      while (removed = getFirstChild(parent))
        removeNode(parent, removed);
      replacement && insertNode(parent, replacement);
      return "";
    }
    const node = replacement || createTextNode("");
    if (current.length) {
      let inserted = false;
      for (let i = current.length - 1;i >= 0; i--) {
        const el = current[i];
        if (node !== el) {
          const isParent = getParentNode(el) === parent;
          if (!inserted && !i)
            isParent ? replaceNode(parent, node, el) : insertNode(parent, node, marker);
          else
            isParent && removeNode(parent, el);
        } else
          inserted = true;
      }
    } else
      insertNode(parent, node, marker);
    return [node];
  }
  function appendNodes(parent, array, marker) {
    for (let i = 0, len = array.length;i < len; i++)
      insertNode(parent, array[i], marker);
  }
  function replaceNode(parent, newNode, oldNode) {
    insertNode(parent, newNode, oldNode);
    removeNode(parent, oldNode);
  }
  function spreadExpression(node, props, prevProps = {}, skipChildren) {
    props || (props = {});
    if (!skipChildren) {
      createRenderEffect(() => prevProps.children = insertExpression(node, props.children, prevProps.children));
    }
    createRenderEffect(() => props.ref && props.ref(node));
    createRenderEffect(() => {
      const propNames = new Set;
      for (const prop in props)
        propNames.add(prop);
      for (const prop in prevProps) {
        if (prop === "children" || prop === "ref" || propNames.has(prop))
          continue;
        setProperty(node, prop, undefined, prevProps[prop]);
        delete prevProps[prop];
      }
      for (const prop of propNames) {
        if (prop === "children" || prop === "ref")
          continue;
        const value = props[prop];
        if (value === prevProps[prop])
          continue;
        setProperty(node, prop, value, prevProps[prop]);
        prevProps[prop] = value;
      }
    });
    return prevProps;
  }
  return {
    render(code, element) {
      let disposer;
      createRoot((dispose) => {
        disposer = dispose;
        insert(element, code());
      });
      return disposer;
    },
    insert,
    spread(node, accessor, skipChildren) {
      if (typeof accessor === "function") {
        createRenderEffect((current) => spreadExpression(node, accessor(), current, skipChildren));
      } else
        spreadExpression(node, accessor, undefined, skipChildren);
    },
    createElement,
    createTextNode,
    insertNode,
    setProp(node, name, value, prev) {
      setProperty(node, name, value, prev);
      return value;
    },
    mergeProps,
    effect: createRenderEffect,
    memo,
    createComponent,
    use(fn, element, arg) {
      return untrack(() => fn(element, arg));
    }
  };
}
function createRenderer(options) {
  const renderer = createRenderer$1(options);
  renderer.mergeProps = mergeProps;
  return renderer;
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/protocol/src/framing.ts
var MAX_FRAME_BYTES = 65536;

class ProtocolError extends Error {
  name = "ProtocolError";
}
function encodeFrame(value) {
  let json;
  try {
    json = JSON.stringify(value);
  } catch (error) {
    throw new ProtocolError("Frame is not a JSON value", { cause: error });
  }
  if (json === undefined)
    throw new ProtocolError("Frame is not a JSON value");
  const encoded = new TextEncoder().encode(`${json}
`);
  if (encoded.byteLength - 1 > MAX_FRAME_BYTES)
    throw new ProtocolError("Frame exceeds byte limit");
  return encoded;
}

class FrameDecoder {
  buffer = new Uint8Array(MAX_FRAME_BYTES);
  utf8 = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
  length = 0;
  state = "open";
  push(chunk) {
    if (this.state !== "open")
      throw new ProtocolError(this.state === "failed" ? "Decoder is closed after a protocol error" : "Decoder is closed after end of stream");
    const frames = [];
    let start = 0;
    try {
      while (start < chunk.length) {
        const newline = chunk.indexOf(10, start);
        const end = newline === -1 ? chunk.length : newline;
        const size = end - start;
        if (this.length + size > MAX_FRAME_BYTES)
          throw new ProtocolError("Frame exceeds byte limit");
        this.buffer.set(chunk.subarray(start, end), this.length);
        this.length += size;
        if (newline === -1)
          break;
        if (this.length === 0)
          throw new ProtocolError("Empty frame");
        const json = this.utf8.decode(this.buffer.subarray(0, this.length));
        frames.push(JSON.parse(json));
        this.length = 0;
        start = newline + 1;
      }
    } catch (error) {
      this.state = "failed";
      if (error instanceof ProtocolError)
        throw error;
      throw new ProtocolError("Invalid UTF-8 or JSON in native frame", { cause: error });
    }
    return frames;
  }
  finish() {
    if (this.state === "failed")
      throw new ProtocolError("Decoder is closed after a protocol error");
    if (this.length !== 0) {
      this.state = "failed";
      throw new ProtocolError("Native stream ended inside a frame");
    }
    this.state = "finished";
  }
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/protocol/src/values.ts
var MAX_TEXT_BYTES = 16384;
var MAX_TITLE_BYTES = 256;
var encoder = new TextEncoder;
function object(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new ProtocolError("Message must be an object");
  return value;
}
function keys(value, allowed) {
  for (const key of Object.keys(value))
    if (!allowed.includes(key))
      throw new ProtocolError("Unknown message property: " + key);
}
function number(value, field, min, max) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max)
    throw new ProtocolError(field + " must be finite and between " + min + " and " + max);
  return value;
}
function integer(value, field, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const result = number(value, field, min, max);
  if (!Number.isSafeInteger(result))
    throw new ProtocolError(field + " must be a safe integer");
  return result;
}
function id(value) {
  return integer(value, "Identifier", 1);
}
function string(value, field, limit = MAX_TEXT_BYTES) {
  if (typeof value !== "string" || encoder.encode(value).byteLength > limit)
    throw new ProtocolError(field + " must be a string within " + limit + " UTF-8 bytes");
  if (!value.isWellFormed())
    throw new ProtocolError(field + " contains an unpaired surrogate");
  if (value.includes("\x00"))
    throw new ProtocolError(field + " contains a NUL character");
  return value;
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/protocol/src/elements.ts
function choice(value, name, values) {
  for (const candidate of values)
    if (candidate === value)
      return candidate;
  throw new ProtocolError(name + " must be one of " + values.join(", "));
}
function requireLeafStyle(style) {
  if (style.overflow !== undefined && style.overflow !== "visible" && style.overflow !== "hidden")
    throw new ProtocolError("Scrolling is supported only on box elements");
}
function parseStyle(value) {
  const data = object(value);
  keys(data, [
    "direction",
    "gap",
    "padding",
    "width",
    "height",
    "min_width",
    "max_width",
    "min_height",
    "max_height",
    "flex_grow",
    "flex_shrink",
    "align_items",
    "justify_content",
    "overflow",
    "background",
    "color",
    "font_size"
  ]);
  const style = {};
  for (const key of ["gap", "padding"])
    if (key in data)
      style[key] = number(data[key], key, 0, 4096);
  for (const key of ["width", "height"])
    if (key in data)
      style[key] = data[key] === "fill" ? "fill" : number(data[key], key, 0, 16384);
  for (const key of ["min_width", "max_width", "min_height", "max_height"])
    if (key in data)
      style[key] = number(data[key], key, 0, 16384);
  for (const [minimum, maximum] of [
    [style.min_width, style.max_width],
    [style.min_height, style.max_height]
  ])
    if (minimum !== undefined && maximum !== undefined && minimum > maximum)
      throw new ProtocolError("Minimum size must not exceed maximum size");
  for (const key of ["background", "color"])
    if (key in data)
      style[key] = integer(data[key], key, 0, 16777215);
  if ("direction" in data)
    style.direction = choice(data["direction"], "direction", ["row", "column"]);
  for (const key of ["flex_grow", "flex_shrink"])
    if (key in data)
      style[key] = number(data[key], key, 0, 1000);
  if ("align_items" in data)
    style.align_items = choice(data["align_items"], "align_items", [
      "start",
      "center",
      "end",
      "stretch"
    ]);
  if ("justify_content" in data)
    style.justify_content = choice(data["justify_content"], "justify_content", [
      "start",
      "center",
      "end",
      "space_between",
      "space_around",
      "space_evenly"
    ]);
  if ("overflow" in data)
    style.overflow = choice(data["overflow"], "overflow", [
      "visible",
      "hidden",
      "scroll_x",
      "scroll_y",
      "scroll"
    ]);
  if ("font_size" in data)
    style.font_size = number(data["font_size"], "font_size", 1, 512);
  return style;
}
function parseElement(value) {
  const element = object(value);
  const style = "style" in element ? parseStyle(element["style"]) : {};
  switch (element["kind"]) {
    case "box":
      keys(element, ["kind", "style"]);
      return { kind: "box", style };
    case "text":
      keys(element, ["kind", "text", "style"]);
      requireLeafStyle(style);
      return { kind: "text", text: string(element["text"], "text"), style };
    case "button": {
      keys(element, ["kind", "text", "disabled", "style"]);
      requireLeafStyle(style);
      if ("disabled" in element && typeof element["disabled"] !== "boolean")
        throw new ProtocolError("disabled must be a boolean");
      return {
        kind: "button",
        text: string(element["text"], "text"),
        disabled: element["disabled"] === true,
        style
      };
    }
    case "input":
      keys(element, ["kind", "value", "placeholder", "style"]);
      requireLeafStyle(style);
      return {
        kind: "input",
        value: string(element["value"], "value"),
        placeholder: "placeholder" in element ? string(element["placeholder"], "placeholder") : "",
        style
      };
    default:
      throw new ProtocolError("Unknown native element kind");
  }
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/protocol/src/services.ts
var MAX_CLIPBOARD_BYTES = 8192;
var MAX_SERVICE_REQUESTS = 8;
function parseClipboardText(value) {
  const data = object(value);
  if (data["kind"] === "empty") {
    keys(data, ["kind"]);
    return { kind: "empty" };
  }
  keys(data, ["kind", "text"]);
  if (data["kind"] !== "text")
    throw new ProtocolError("Unknown clipboard text result");
  return { kind: "text", text: string(data["text"], "clipboard text", MAX_CLIPBOARD_BYTES) };
}
function parseServicePolicy(value) {
  const data = object(value);
  keys(data, ["window_display", "clipboard_read", "clipboard_write"]);
  const grant = (key) => {
    if (typeof data[key] !== "boolean")
      throw new ProtocolError("Native service policy must explicitly grant or deny each operation");
    return data[key];
  };
  return {
    window_display: grant("window_display"),
    clipboard_read: grant("clipboard_read"),
    clipboard_write: grant("clipboard_write")
  };
}
function parseDisplaySnapshot(value) {
  const data = object(value);
  keys(data, ["bounds", "scale_factor"]);
  const bounds = object(data["bounds"]);
  keys(bounds, ["x", "y", "width", "height"]);
  return {
    bounds: {
      x: number(bounds["x"], "display x", -1048576, 1048576),
      y: number(bounds["y"], "display y", -1048576, 1048576),
      width: number(bounds["width"], "display width", Number.MIN_VALUE, 1048576),
      height: number(bounds["height"], "display height", Number.MIN_VALUE, 1048576)
    },
    scale_factor: number(data["scale_factor"], "display scale factor", 0.125, 16)
  };
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/protocol/src/messages.ts
var PROTOCOL_VERSION = 6;
var MAX_OPERATIONS = 256;
var MAX_NODES_PER_WINDOW = 4096;
var MAX_WINDOWS = 16;
var MAX_DEPTH = 64;
var MAX_TEXT_BYTES_PER_WINDOW = 4194304;
var DEFAULT_LIMITS = Object.freeze({
  max_frame_bytes: MAX_FRAME_BYTES,
  max_operations: MAX_OPERATIONS,
  max_nodes_per_window: MAX_NODES_PER_WINDOW,
  max_windows: MAX_WINDOWS,
  max_depth: MAX_DEPTH,
  max_text_bytes: MAX_TEXT_BYTES,
  max_text_bytes_per_window: MAX_TEXT_BYTES_PER_WINDOW,
  max_clipboard_bytes: MAX_CLIPBOARD_BYTES,
  max_service_requests: MAX_SERVICE_REQUESTS
});
var ERROR_CODES = [
  "invalid_command",
  "version_mismatch",
  "invalid_state",
  "invalid_handle",
  "stale_revision",
  "limit_exceeded",
  "native_failure",
  "permission_denied",
  "service_unavailable",
  "cancelled",
  "operation_timed_out",
  "payload_too_large"
];
var REQUIRED_CAPABILITIES = Object.freeze([
  "tree",
  "input_revisions",
  "layout_v1",
  "interactions_v1",
  "window_display_v1"
]);
var CAPABILITIES = [...REQUIRED_CAPABILITIES, "clipboard_text_v1"];
function version(value) {
  if (value !== PROTOCOL_VERSION)
    throw new ProtocolError("Native protocol version mismatch");
  return PROTOCOL_VERSION;
}
function operation(value) {
  const data = object(value);
  switch (data["type"]) {
    case "create":
      keys(data, ["type", "node_id", "element"]);
      return {
        type: "create",
        node_id: id(data["node_id"]),
        element: parseElement(data["element"])
      };
    case "set": {
      keys(data, ["type", "node_id", "element", "expected_input_revision"]);
      const node_id = id(data["node_id"]);
      const element = parseElement(data["element"]);
      if (element.kind === "input")
        return {
          type: "set",
          node_id,
          element,
          expected_input_revision: integer(data["expected_input_revision"], "input revision")
        };
      if ("expected_input_revision" in data)
        throw new ProtocolError("Only input elements accept an input revision");
      return { type: "set", node_id, element };
    }
    case "insert":
      keys(data, ["type", "parent_id", "child_id", "index"]);
      return {
        type: "insert",
        parent_id: id(data["parent_id"]),
        child_id: id(data["child_id"]),
        index: integer(data["index"], "index", 0, MAX_NODES_PER_WINDOW)
      };
    case "delete":
      keys(data, ["type", "node_id"]);
      return { type: "delete", node_id: id(data["node_id"]) };
    default:
      throw new ProtocolError("Unknown native operation");
  }
}
function parseCommand(value) {
  const message = object(value);
  const request = id(message["id"]);
  switch (message["type"]) {
    case "hello":
      keys(message, ["id", "type", "protocol"]);
      return { id: request, type: "hello", protocol: version(message["protocol"]) };
    case "open": {
      keys(message, ["id", "type", "window_id", "root_id", "title", "width", "height"]);
      const title = string(message["title"], "title", MAX_TITLE_BYTES);
      if (!title || /\p{Cc}/u.test(title))
        throw new ProtocolError("Window title must be nonempty and contain no control characters");
      return {
        id: request,
        type: "open",
        window_id: id(message["window_id"]),
        root_id: id(message["root_id"]),
        title,
        width: number(message["width"], "width", 64, 16384),
        height: number(message["height"], "height", 64, 16384)
      };
    }
    case "batch": {
      keys(message, ["id", "type", "window_id", "base_revision", "operations"]);
      const operations = message["operations"];
      if (!Array.isArray(operations) || operations.length < 1 || operations.length > MAX_OPERATIONS)
        throw new ProtocolError("Batch must contain between 1 and " + MAX_OPERATIONS + " operations");
      return {
        id: request,
        type: "batch",
        window_id: id(message["window_id"]),
        base_revision: integer(message["base_revision"], "tree revision"),
        operations: operations.map(operation)
      };
    }
    case "close":
    case "display_snapshot":
    case "clipboard_read":
      keys(message, ["id", "type", "window_id"]);
      return { id: request, type: message["type"], window_id: id(message["window_id"]) };
    case "clipboard_write":
      keys(message, ["id", "type", "window_id", "text"]);
      return {
        id: request,
        type: "clipboard_write",
        window_id: id(message["window_id"]),
        text: string(message["text"], "clipboard text", MAX_CLIPBOARD_BYTES)
      };
    case "shutdown":
      keys(message, ["id", "type"]);
      return { id: request, type: "shutdown" };
    default:
      throw new ProtocolError("Unknown native command");
  }
}
function limits(value) {
  const data = object(value);
  keys(data, Object.keys(DEFAULT_LIMITS));
  const parse = (key) => integer(data[key], key, 1, DEFAULT_LIMITS[key]);
  return {
    max_frame_bytes: parse("max_frame_bytes"),
    max_operations: parse("max_operations"),
    max_nodes_per_window: parse("max_nodes_per_window"),
    max_windows: parse("max_windows"),
    max_depth: parse("max_depth"),
    max_text_bytes: parse("max_text_bytes"),
    max_text_bytes_per_window: parse("max_text_bytes_per_window"),
    max_clipboard_bytes: parse("max_clipboard_bytes"),
    max_service_requests: parse("max_service_requests")
  };
}
var ROUTE_KEYS = ["type", "sequence", "window_id", "node_id", "tree_revision", "path"];
function route(message) {
  const node_id = id(message["node_id"]);
  const value = message["path"];
  if (!Array.isArray(value) || !value.length || value.length > MAX_DEPTH + 1)
    throw new ProtocolError("Native event path must contain between 1 and 65 node identities");
  const path = value.map(id);
  if (new Set(path).size !== path.length || path.at(-1) !== node_id)
    throw new ProtocolError("Native event path must be unique and end at its target");
  return {
    sequence: id(message["sequence"]),
    window_id: id(message["window_id"]),
    node_id,
    tree_revision: integer(message["tree_revision"], "tree revision"),
    path
  };
}
function modifiers(value) {
  const data = object(value);
  keys(data, ["control", "alt", "shift", "platform", "function"]);
  const modifier = (name) => {
    if (typeof data[name] !== "boolean")
      throw new ProtocolError("Invalid native key modifier");
    return data[name];
  };
  return {
    control: modifier("control"),
    alt: modifier("alt"),
    shift: modifier("shift"),
    platform: modifier("platform"),
    function: modifier("function")
  };
}
function parseEvent(value) {
  const message = object(value);
  switch (message["type"]) {
    case "ready": {
      keys(message, ["type", "protocol", "capabilities", "limits", "service_policy"]);
      const capabilities = message["capabilities"];
      if (!Array.isArray(capabilities) || capabilities.length > CAPABILITIES.length)
        throw new ProtocolError("Invalid native capabilities");
      const parsed = [];
      for (const value of capabilities) {
        const capability = CAPABILITIES.find((candidate) => candidate === value);
        if (!capability || parsed.includes(capability))
          throw new ProtocolError("Unknown or duplicate native capability");
        parsed.push(capability);
      }
      return {
        type: "ready",
        protocol: version(message["protocol"]),
        capabilities: parsed,
        limits: limits(message["limits"]),
        service_policy: parseServicePolicy(message["service_policy"])
      };
    }
    case "ack":
      keys(message, ["type", "id"]);
      return { type: "ack", id: id(message["id"]) };
    case "opened":
      keys(message, ["type", "id", "window_id", "root_id", "tree_revision"]);
      return {
        type: "opened",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        root_id: id(message["root_id"]),
        tree_revision: integer(message["tree_revision"], "tree revision")
      };
    case "applied":
      keys(message, ["type", "id", "window_id", "tree_revision"]);
      return {
        type: "applied",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        tree_revision: integer(message["tree_revision"], "tree revision")
      };
    case "display_snapshot":
      keys(message, ["type", "id", "window_id", "snapshot"]);
      return {
        type: "display_snapshot",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        snapshot: parseDisplaySnapshot(message["snapshot"])
      };
    case "clipboard_text":
      keys(message, ["type", "id", "window_id", "result"]);
      return {
        type: "clipboard_text",
        id: id(message["id"]),
        window_id: id(message["window_id"]),
        result: parseClipboardText(message["result"])
      };
    case "clipboard_written":
      keys(message, ["type", "id", "window_id"]);
      return {
        type: "clipboard_written",
        id: id(message["id"]),
        window_id: id(message["window_id"])
      };
    case "click":
    case "focus":
    case "blur":
      keys(message, ROUTE_KEYS);
      return {
        type: message["type"],
        ...route(message)
      };
    case "key_down":
    case "key_up": {
      keys(message, [...ROUTE_KEYS, "key", "key_char", "modifiers"]);
      const key = string(message["key"], "key", 256);
      if (!key)
        throw new ProtocolError("Native key must be nonempty");
      return {
        type: message["type"],
        ...route(message),
        key,
        ..."key_char" in message ? { key_char: string(message["key_char"], "key_char", 256) } : {},
        modifiers: modifiers(message["modifiers"])
      };
    }
    case "pointer_down":
    case "pointer_up": {
      keys(message, [...ROUTE_KEYS, "button", "x", "y", "modifiers"]);
      const button = ["left", "right", "middle", "back", "forward"].find((button) => button === message["button"]);
      if (!button)
        throw new ProtocolError("Unknown native pointer button");
      return {
        type: message["type"],
        ...route(message),
        button,
        x: number(message["x"], "pointer x", -1048576, 1048576),
        y: number(message["y"], "pointer y", -1048576, 1048576),
        modifiers: modifiers(message["modifiers"])
      };
    }
    case "closed":
      keys(message, ["type", "sequence", "window_id"]);
      return {
        type: "closed",
        sequence: id(message["sequence"]),
        window_id: id(message["window_id"])
      };
    case "input":
      keys(message, [...ROUTE_KEYS, "value", "input_revision"]);
      return {
        type: "input",
        ...route(message),
        value: string(message["value"], "value"),
        input_revision: integer(message["input_revision"], "input revision")
      };
    case "error": {
      keys(message, ["type", "id", "code", "message"]);
      const code = ERROR_CODES.find((code) => code === message["code"]);
      if (!code)
        throw new ProtocolError("Invalid native error code");
      return {
        type: "error",
        code,
        message: string(message["message"], "message"),
        ..."id" in message ? { id: id(message["id"]) } : {}
      };
    }
    default:
      throw new ProtocolError("Unknown native event");
  }
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/runtime/src/index.ts
import { isAbsolute as isAbsolute2 } from "path";

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/runtime/src/startup-trace.ts
import { appendFileSync } from "fs";
import { isAbsolute } from "path";
var MAX_RECORDS = 256;

class StartupTrace {
  path;
  nonce;
  started = process.hrtime.bigint();
  records = 0;
  unavailable = false;
  constructor(path, nonce) {
    this.path = path;
    this.nonce = nonce;
  }
  static fromEnvironment() {
    if (process.env["BUN_NATIVE_STARTUP_TRACE"] !== "1")
      return;
    const path = process.env["BUN_NATIVE_EVIDENCE_LOG"];
    const nonce = process.env["BUN_NATIVE_EVIDENCE_NONCE"];
    if (!path || !isAbsolute(path) || !nonce || Buffer.byteLength(nonce) > 128 || [...nonce].some((character) => {
      const code = character.charCodeAt(0);
      return code < 32 || code >= 127 && code <= 159;
    }))
      throw new Error("Native startup tracing requires an absolute evidence path and valid nonce");
    return new StartupTrace(path, nonce);
  }
  request(phase, command, hostPid) {
    this.write(phase, {
      host_pid: hostPid,
      request_id: command.id,
      command: command.type,
      ..."window_id" in command ? { window_id: command.window_id } : {}
    });
  }
  response(event, hostPid) {
    if (!("id" in event))
      return;
    this.write("response_received", {
      host_pid: hostPid,
      request_id: event.id,
      response: event.type
    });
  }
  failure(error, stderr, hostPid) {
    this.write("transport_failed", { host_pid: hostPid, error: error.message.slice(-1024), stderr_tail: stderr }, true);
  }
  finished(exitCode, stderr, hostPid) {
    this.write("transport_finished", { host_pid: hostPid, exit_code: exitCode, stderr_tail: stderr }, true);
  }
  write(phase, fields, terminal = false) {
    if (this.unavailable || !terminal && this.records >= MAX_RECORDS)
      return;
    if (!terminal && this.records === MAX_RECORDS - 1) {
      phase = "record_limit";
      fields = { host_pid: fields["host_pid"], maximum_records: MAX_RECORDS };
    }
    const record = {
      nonce: this.nonce,
      stage: "startup-diagnostic",
      source: "transport",
      pid: process.pid,
      clock: "process_monotonic_relative",
      elapsed_ns: String(process.hrtime.bigint() - this.started),
      index: ++this.records,
      phase,
      ...fields
    };
    try {
      appendFileSync(this.path, JSON.stringify(record) + `
`, { mode: 384 });
    } catch {
      this.unavailable = true;
      console.error("Bun Native startup trace unavailable; evidence file could not be appended");
    }
  }
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/runtime/src/index.ts
class NativeCommandError extends Error {
  code;
  requestId;
  name = "NativeCommandError";
  constructor(code, requestId, message) {
    super("Native " + code + ": " + message);
    this.code = code;
    this.requestId = requestId;
  }
}
function launchPolicy(value = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new TypeError("Native permissions must be an object");
  if (Object.keys(value).some((key) => !["windowDisplay", "clipboardRead", "clipboardWrite"].includes(key)))
    throw new TypeError("Unknown native service permission");
  const grant = (key) => {
    const permission = Object.hasOwn(value, key) ? value[key] : "deny";
    if (permission !== "allow" && permission !== "deny")
      throw new TypeError(key + " permission must be allow or deny");
    return permission === "allow";
  };
  return Object.freeze({
    window_display: grant("windowDisplay"),
    clipboard_read: grant("clipboardRead"),
    clipboard_write: grant("clipboardWrite")
  });
}
var MAX_PENDING_COMMANDS = 128;
var MAX_QUEUED_EVENTS = 128;

class NativeHost {
  requestedPolicy;
  exited;
  process;
  stdout;
  stderr;
  timeout;
  pending = new Map;
  events = [];
  finished;
  waiting;
  failure;
  phase = "starting";
  ready = false;
  negotiatedLimits;
  negotiatedServicePolicy;
  negotiatedCapabilities;
  sequence = 0;
  nextId = 1;
  writeTail = Promise.resolve();
  stderrTail = "";
  iteratorTaken = false;
  startupTrace = StartupTrace.fromEnvironment();
  constructor(options, requestedPolicy) {
    this.requestedPolicy = requestedPolicy;
    this.timeout = options.requestTimeoutMs ?? 5000;
    this.process = Bun.spawn({
      cmd: [
        options.executable,
        ...options.args ?? [],
        ...requestedPolicy.window_display ? ["--bun-native-allow-window-display"] : [],
        ...requestedPolicy.clipboard_read ? ["--bun-native-allow-clipboard-read"] : [],
        ...requestedPolicy.clipboard_write ? ["--bun-native-allow-clipboard-write"] : []
      ],
      stdin: "pipe",
      stdout: "pipe",
      stderr: "pipe"
    });
    this.stdout = this.process.stdout.getReader();
    this.stderr = this.process.stderr.getReader();
    this.exited = this.process.exited;
    this.finished = this.watch();
  }
  static async launch(options) {
    if (!isAbsolute2(options.executable))
      throw new Error("Native host path must be absolute");
    const timeout = options.requestTimeoutMs ?? 5000;
    if (!Number.isSafeInteger(timeout) || timeout < 1 || timeout > 60000)
      throw new Error("requestTimeoutMs must be an integer between 1 and 60000");
    const policy = launchPolicy(options.permissions);
    if (options.args?.some((argument) => typeof argument !== "string" || argument.startsWith("--bun-native-")))
      throw new TypeError("Native service arguments are reserved for the explicit permissions option");
    const host = new NativeHost(options, policy);
    try {
      await host.request({ type: "hello", protocol: PROTOCOL_VERSION });
      if (!host.ready)
        throw new ProtocolError("Host acknowledged hello before protocol readiness");
      host.phase = "running";
      return host;
    } catch (error) {
      host.fail(error);
      await host.finished;
      throw host.failure;
    }
  }
  get limits() {
    if (!this.negotiatedLimits)
      throw new ProtocolError("Native limits are not negotiated");
    return this.negotiatedLimits;
  }
  get servicePolicy() {
    if (!this.negotiatedServicePolicy)
      throw new ProtocolError("Native service policy is not negotiated");
    return this.negotiatedServicePolicy;
  }
  get capabilities() {
    if (!this.negotiatedCapabilities)
      throw new ProtocolError("Native capabilities are not negotiated");
    return this.negotiatedCapabilities;
  }
  send(command) {
    if (this.phase !== "running")
      return Promise.reject(this.closedError());
    return this.request(command);
  }
  async shutdown() {
    if (this.phase === "closed" || this.phase === "stopping") {
      await this.finished;
      if (this.failure)
        throw this.failure;
      return;
    }
    this.phase = "stopping";
    try {
      await this.request({ type: "shutdown" });
      this.process.stdin.end();
      const deadline = setTimeout(() => this.fail(new Error("Native host did not exit")), this.timeout);
      try {
        await this.finished;
      } finally {
        clearTimeout(deadline);
      }
      if (this.failure)
        throw this.failure;
    } catch (error) {
      this.fail(error);
      await this.finished;
      throw this.failure;
    }
  }
  [Symbol.asyncIterator]() {
    if (this.iteratorTaken)
      throw new Error("Native events have exactly one consumer");
    this.iteratorTaken = true;
    return {
      next: () => {
        if (this.failure)
          return Promise.reject(this.failure);
        const event = this.events.shift();
        if (event)
          return Promise.resolve({ done: false, value: event });
        if (this.phase === "closed")
          return Promise.resolve({ done: true, value: undefined });
        if (this.waiting)
          return Promise.reject(new Error("Concurrent event reads are not supported"));
        return new Promise((resolve, reject) => {
          this.waiting = { resolve, reject };
        });
      },
      return: async () => {
        await this.shutdown();
        return { done: true, value: undefined };
      }
    };
  }
  request(input) {
    if (this.phase === "closed")
      return Promise.reject(this.closedError());
    if (this.pending.size >= MAX_PENDING_COMMANDS)
      return Promise.reject(new Error("Native command limit exceeded"));
    let command;
    let frame;
    try {
      command = parseCommand({ ...input, id: this.nextId++ });
      frame = encodeFrame(command);
      if (this.negotiatedLimits) {
        if (frame.byteLength - 1 > this.negotiatedLimits.max_frame_bytes)
          throw new ProtocolError("Command exceeds the negotiated frame limit");
        if (command.type === "batch" && command.operations.length > this.negotiatedLimits.max_operations)
          throw new ProtocolError("Command exceeds the negotiated batch limit");
        if (command.type === "clipboard_write" && Buffer.byteLength(command.text, "utf8") > this.negotiatedLimits.max_clipboard_bytes)
          throw new ProtocolError("Clipboard write exceeds the negotiated text limit");
      }
    } catch (error) {
      return Promise.reject(error);
    }
    const result = new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.fail(new Error(`Native ${command.type} request ${command.id} timed out`)), this.timeout);
      this.pending.set(command.id, {
        command,
        resolve,
        reject,
        timer
      });
    });
    this.startupTrace?.request("request_queued", command, this.process.pid);
    this.writeTail = this.writeTail.then(async () => {
      if (this.phase === "closed")
        return;
      this.startupTrace?.request("stdin_write_enter", command, this.process.pid);
      this.process.stdin.write(frame);
      this.startupTrace?.request("stdin_write_returned", command, this.process.pid);
      this.startupTrace?.request("stdin_flush_enter", command, this.process.pid);
      await this.process.stdin.flush();
      this.startupTrace?.request("stdin_flushed", command, this.process.pid);
    }).catch((error) => this.fail(error));
    return result;
  }
  async readStdout() {
    const decoder = new FrameDecoder;
    try {
      for (;; ) {
        const { done, value } = await this.stdout.read();
        if (done)
          break;
        for (const raw of decoder.push(value))
          this.receive(parseEvent(raw));
      }
      decoder.finish();
      if (this.phase !== "stopping" && this.phase !== "closed")
        throw new ProtocolError("Native output closed before shutdown");
    } finally {
      this.stdout.releaseLock();
    }
  }
  async readStderr() {
    const decoder = new TextDecoder;
    try {
      for (;; ) {
        const { done, value } = await this.stderr.read();
        if (done)
          break;
        this.stderrTail = (this.stderrTail + decoder.decode(value, { stream: true })).slice(-4096);
      }
      this.stderrTail = (this.stderrTail + decoder.decode()).slice(-4096);
    } finally {
      this.stderr.releaseLock();
    }
  }
  cancelOutput() {
    this.stdout.cancel().catch(() => {});
    this.stderr.cancel().catch(() => {});
  }
  async watch() {
    const streams = [this.readStdout(), this.readStderr()];
    let drainDeadline;
    const exit = this.exited.then((code) => {
      drainDeadline = setTimeout(() => this.fail(new Error("Native output remained open after host exit")), this.timeout);
      return code;
    });
    try {
      const [code] = await Promise.all([exit, ...streams]);
      if (code !== 0 || this.phase !== "stopping" || this.pending.size)
        throw new Error(`Native host exited unexpectedly (${code}). ${this.stderrTail}`);
      this.phase = "closed";
      this.waiting?.resolve({ done: true, value: undefined });
      this.waiting = undefined;
    } catch (error) {
      this.fail(error);
      await this.exited;
    } finally {
      clearTimeout(drainDeadline);
      this.cancelOutput();
      await Promise.allSettled(streams);
      this.startupTrace?.finished(this.process.exitCode, this.stderrTail, this.process.pid);
    }
  }
  receive(event) {
    if (this.phase === "closed")
      return;
    this.startupTrace?.response(event, this.process.pid);
    if (event.type === "clipboard_text" && event.result.kind === "text" && this.negotiatedLimits && Buffer.byteLength(event.result.text, "utf8") > this.negotiatedLimits.max_clipboard_bytes)
      throw new ProtocolError("Clipboard response exceeds the negotiated text limit");
    if (event.type === "ready") {
      if (this.ready || this.phase !== "starting")
        throw new ProtocolError("Unexpected ready event");
      if (REQUIRED_CAPABILITIES.some((capability) => !event.capabilities.includes(capability)))
        throw new ProtocolError("Native host lacks required protocol capabilities: " + REQUIRED_CAPABILITIES.join(", "));
      this.negotiatedLimits = Object.freeze(event.limits);
      if (Object.keys(this.requestedPolicy).some((key) => event.service_policy[key] !== this.requestedPolicy[key]))
        throw new ProtocolError("Native service policy does not match the explicit launch permissions");
      this.negotiatedServicePolicy = Object.freeze(event.service_policy);
      this.negotiatedCapabilities = Object.freeze(event.capabilities);
      this.ready = true;
      return;
    }
    if (event.type === "ack" || event.type === "opened" || event.type === "applied" || event.type === "display_snapshot" || event.type === "clipboard_text" || event.type === "clipboard_written" || event.type === "error") {
      if (event.type === "error" && event.id === undefined)
        throw new ProtocolError(`Native ${event.code}: ${event.message}`);
      const requestId = event.id;
      const request = requestId === undefined ? undefined : this.pending.get(requestId);
      if (!request || requestId === undefined)
        throw new ProtocolError("Unknown native response id");
      clearTimeout(request.timer);
      this.pending.delete(requestId);
      if (event.type === "error")
        request.reject(new NativeCommandError(event.code, requestId, event.message));
      else if (!this.matchesResponse(request.command, event)) {
        const error = new ProtocolError("Native response does not match its request, owner or revision");
        request.reject(error);
        throw error;
      } else
        request.resolve(event);
      return;
    }
    if (!this.ready)
      throw new ProtocolError("Native input arrived before protocol readiness");
    if (event.sequence !== this.sequence + 1)
      throw new ProtocolError("Native event sequence is out of order");
    this.sequence = event.sequence;
    if (this.waiting) {
      this.waiting.resolve({ done: false, value: event });
      this.waiting = undefined;
    } else {
      if (this.events.length >= MAX_QUEUED_EVENTS)
        throw new ProtocolError("Native event limit exceeded");
      this.events.push(event);
    }
  }
  matchesResponse(command, response) {
    switch (command.type) {
      case "display_snapshot":
        return response.type === "display_snapshot" && response.window_id === command.window_id;
      case "clipboard_read":
        return response.type === "clipboard_text" && response.window_id === command.window_id;
      case "clipboard_write":
        return response.type === "clipboard_written" && response.window_id === command.window_id;
      case "open":
        return response.type === "opened" && response.window_id === command.window_id && response.root_id === command.root_id && response.tree_revision === 0;
      case "batch":
        return response.type === "applied" && response.window_id === command.window_id && response.tree_revision === command.base_revision + 1;
      case "hello":
      case "close":
      case "shutdown":
        return response.type === "ack";
    }
  }
  closedError() {
    return this.failure ?? new Error("Native host is not running");
  }
  fail(cause) {
    if (this.failure)
      return;
    this.failure = cause instanceof Error ? cause : new Error(String(cause));
    this.startupTrace?.failure(this.failure, this.stderrTail, this.process.pid);
    this.phase = "closed";
    for (const request of this.pending.values()) {
      clearTimeout(request.timer);
      request.reject(this.failure);
    }
    this.pending.clear();
    this.events.length = 0;
    this.waiting?.reject(this.failure);
    this.waiting = undefined;
    this.cancelOutput();
    this.process.kill("SIGKILL");
  }
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/core/src/types.ts
class NativeStateError extends Error {
  code;
  name = "NativeStateError";
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

class UnsupportedFeatureError extends Error {
  feature;
  name = "UnsupportedFeatureError";
  constructor(feature) {
    super("Unsupported native feature: " + feature);
    this.feature = feature;
  }
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/core/src/events.ts
var eventTypes = [
  "click",
  "input",
  "key_down",
  "key_up",
  "pointer_down",
  "pointer_up",
  "focus",
  "blur"
];
function invocation(listener) {
  return (event) => listener(event);
}
function revoke(binding) {
  binding.invoke = undefined;
  binding.subscription.remove = undefined;
  binding.controller.abort();
}
function unsubscribe(subscription) {
  return () => subscription.remove?.();
}
function payload(event, node, path) {
  const common = {
    node,
    path: Object.freeze([...path]),
    sequence: event.sequence,
    treeRevision: event.tree_revision
  };
  switch (event.type) {
    case "click":
      return { ...common, type: event.type, node };
    case "input":
      return {
        ...common,
        type: event.type,
        node,
        value: event.value,
        revision: event.input_revision
      };
    case "key_down":
    case "key_up":
      return {
        ...common,
        type: event.type,
        key: event.key,
        ...event.key_char === undefined ? {} : { keyChar: event.key_char },
        modifiers: Object.freeze({ ...event.modifiers })
      };
    case "pointer_down":
    case "pointer_up":
      return {
        ...common,
        type: event.type,
        button: event.button,
        x: event.x,
        y: event.y,
        modifiers: Object.freeze({ ...event.modifiers })
      };
    case "focus":
    case "blur":
      return { ...common, type: event.type };
  }
}
function prunePlan(plan) {
  plan.deliveries = plan.deliveries.filter(({ binding }) => !binding.controller.signal.aborted);
  return !plan.cancellation.signal.aborted && plan.deliveries.length !== 0;
}

class EventBindings {
  changed;
  nodes = new Map;
  plans = new Set;
  constructor(changed) {
    this.changed = changed;
  }
  get size() {
    let size = 0;
    for (const bindings of this.nodes.values())
      size += bindings.size;
    return size;
  }
  register(id, node, type, listener, options = {}) {
    if (!eventTypes.includes(type) || typeof listener !== "function" || options === null || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((key) => key !== "capture") || "capture" in options && typeof options.capture !== "boolean")
      throw new NativeStateError("invalid_state", "Invalid native listener type, function or options");
    const key = `${type}:${options.capture ? "capture" : "bubble"}`;
    const bindings = this.nodes.get(id) ?? new Map;
    this.nodes.set(id, bindings);
    const previous = bindings.get(key);
    const subscription = { remove: undefined };
    const binding = {
      node,
      controller: new AbortController,
      invoke: invocation(listener),
      subscription
    };
    subscription.remove = () => {
      if (this.nodes.get(id)?.get(key) !== binding)
        return;
      bindings.delete(key);
      if (!bindings.size)
        this.nodes.delete(id);
      revoke(binding);
      this.changed();
    };
    bindings.set(key, binding);
    if (previous)
      revoke(previous);
    this.changed();
    return unsubscribe(subscription);
  }
  retain(ids) {
    for (const [id, bindings] of this.nodes) {
      if (ids.has(id))
        continue;
      this.nodes.delete(id);
      for (const binding of bindings.values())
        revoke(binding);
    }
    for (const plan of this.plans)
      if (!ids.has(plan.targetId))
        plan.cancellation.abort();
    this.changed();
  }
  clear() {
    const removed = [...this.nodes.values()];
    this.nodes.clear();
    for (const bindings of removed)
      for (const binding of bindings.values())
        revoke(binding);
    for (const plan of this.plans)
      plan.cancellation.abort();
    this.plans.clear();
    this.changed();
  }
  release(plan) {
    this.plans.delete(plan);
    plan.deliveries.length = 0;
  }
  prepare(event, path) {
    const deliveries = [];
    const append = (index, capture) => {
      const binding = this.nodes.get(event.path[index])?.get(`${event.type}:${capture ? "capture" : "bubble"}`);
      if (binding)
        deliveries.push({
          binding,
          phase: index === path.length - 1 ? "target" : capture ? "capture" : "bubble"
        });
    };
    for (let index = 0;index < path.length; index++)
      append(index, true);
    for (let index = path.length - 1;index >= 0; index--)
      append(index, false);
    if (!deliveries.length)
      return;
    const plan = {
      targetId: event.node_id,
      cancellation: new AbortController,
      data: payload(event, path.at(-1), path),
      deliveries
    };
    this.plans.add(plan);
    return plan;
  }
}
async function dispatchPlan(plan, targetIsLive) {
  let stopped = false;
  let immediate = false;
  let previous;
  let previousPhase;
  try {
    for (const { binding, phase } of plan.deliveries) {
      if (!targetIsLive() || plan.cancellation.signal.aborted || immediate || stopped && (binding.node !== previous || phase !== "target" || previousPhase !== "target"))
        break;
      if (binding.controller.signal.aborted)
        continue;
      previous = binding.node;
      previousPhase = phase;
      const signal = binding.controller.signal;
      let executing = true;
      const stop = (all) => {
        if (!executing || signal.aborted)
          return;
        stopped = true;
        immediate ||= all;
      };
      const event = Object.freeze({
        ...plan.data,
        currentTarget: binding.node,
        phase,
        signal,
        get propagationStopped() {
          return stopped;
        },
        stopPropagation: () => stop(false),
        stopImmediatePropagation: () => stop(true)
      });
      let cancel;
      const cancelled = new Promise((resolve) => {
        cancel = resolve;
      });
      signal.addEventListener("abort", cancel, { once: true });
      plan.cancellation.signal.addEventListener("abort", cancel, { once: true });
      try {
        await Promise.race([binding.invoke?.(event), cancelled]);
      } finally {
        executing = false;
        signal.removeEventListener("abort", cancel);
        plan.cancellation.signal.removeEventListener("abort", cancel);
      }
    }
  } finally {
    plan.deliveries.length = 0;
  }
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/core/src/services.ts
class NativeServiceError extends Error {
  service;
  code;
  name = "NativeServiceError";
  constructor(service, code, message) {
    super(message);
    this.service = service;
    this.code = code;
  }
}
var unavailable = Object.freeze({
  availability: "unavailable",
  reason: "not_implemented"
});
function serviceCapabilities(policy, capabilities) {
  return Object.freeze({
    windowDisplay: Object.freeze({
      availability: "available",
      permission: policy.window_display ? "allow" : "deny",
      scope: "owned_window"
    }),
    clipboardText: capabilities.includes("clipboard_text_v1") ? Object.freeze({
      availability: "available",
      read: policy.clipboard_read ? "allow" : "deny",
      write: policy.clipboard_write ? "allow" : "deny",
      scope: "owned_window",
      backend: "x11"
    }) : Object.freeze({ availability: "unavailable", reason: "unsupported_platform" }),
    globalShortcuts: unavailable,
    systemMenus: unavailable,
    dialogs: unavailable,
    notifications: unavailable,
    dragDrop: unavailable,
    filesystemGrants: unavailable,
    ptyProcess: unavailable
  });
}
function serviceSignal(options) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("Native service options must be an object");
  if (Object.keys(options).some((key) => key !== "signal"))
    throw new TypeError("Unknown native service option");
  const signal = Object.hasOwn(options, "signal") ? options.signal : undefined;
  if (signal !== undefined && !(signal instanceof AbortSignal))
    throw new TypeError("Native service signal must be an AbortSignal");
  return signal;
}
function checkServiceCancellation(signal, service) {
  if (signal?.aborted)
    throw new NativeServiceError(service, "cancelled", "Native service read was cancelled; no result is delivered");
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/core/src/tree.ts
var identities = new WeakMap;
var encoder2 = new TextEncoder;
var elementKinds = ["box", "text", "button", "input"];
function normalize(element) {
  if (element !== null && typeof element === "object" && typeof element.kind === "string" && !elementKinds.includes(element.kind))
    throw new UnsupportedFeatureError("element:" + element.kind);
  return parseElement(element);
}
function makeNode(id, element) {
  const handle = Object.freeze({ kind: element.kind });
  identities.set(handle, id);
  return {
    id,
    handle,
    element: normalize(element),
    parent: undefined,
    children: [],
    inputRevision: 0
  };
}
function own(nodes, handle) {
  const id = identities.get(handle);
  const node = id === undefined ? undefined : nodes.get(id);
  if (!node || node.handle !== handle)
    throw new NativeStateError("invalid_handle", "Node is forged, disposed or belongs to another window");
  return node;
}

class Transaction {
  rootId;
  allocateId;
  limits;
  nodes;
  operations = [];
  active = true;
  constructor(current, rootId, allocateId, limits) {
    this.rootId = rootId;
    this.allocateId = allocateId;
    this.limits = limits;
    this.nodes = new Map([...current].map(([id, node]) => [id, { ...node, children: [...node.children] }]));
  }
  check() {
    if (!this.active)
      throw new NativeStateError("invalid_state", "Batch callback has already returned");
    if (this.operations.length >= this.limits.max_operations)
      throw new NativeStateError("limit_exceeded", "Batch operation limit exceeded");
  }
  finish() {
    this.active = false;
  }
  create(element) {
    this.check();
    if (this.nodes.size >= this.limits.max_nodes_per_window)
      throw new NativeStateError("limit_exceeded", "Window node limit exceeded");
    const normalized = normalize(element);
    const node = makeNode(this.allocateId(), normalized);
    this.nodes.set(node.id, node);
    this.operations.push({ type: "create", node_id: node.id, element: node.element });
    return node.handle;
  }
  set(handle, value, expectedInputRevision) {
    this.check();
    const node = own(this.nodes, handle);
    const element = normalize(value);
    if (element.kind !== node.element.kind)
      throw new NativeStateError("invalid_state", "Element kind cannot change; create a replacement node");
    if (element.kind === "input") {
      if (!Number.isSafeInteger(expectedInputRevision) || expectedInputRevision !== node.inputRevision)
        throw new NativeStateError("stale_revision", "Input update requires its current observed revision");
      if (node.inputRevision === Number.MAX_SAFE_INTEGER)
        throw new NativeStateError("limit_exceeded", "Input revision exhausted");
      this.operations.push({
        type: "set",
        node_id: node.id,
        element,
        expected_input_revision: node.inputRevision
      });
      node.inputRevision += 1;
    } else {
      if (expectedInputRevision !== undefined)
        throw new NativeStateError("invalid_state", "Only an input accepts an edit revision");
      this.operations.push({ type: "set", node_id: node.id, element });
    }
    node.element = element;
  }
  insert(parentHandle, childHandle, index) {
    this.check();
    const parent = own(this.nodes, parentHandle);
    const child = own(this.nodes, childHandle);
    if (parent.element.kind !== "box" || child.id === this.rootId)
      throw new NativeStateError("invalid_state", "Only boxes accept children and the root cannot move");
    let ancestor = parent;
    while (ancestor) {
      if (ancestor.id === child.id)
        throw new NativeStateError("invalid_state", "Native tree cannot contain a cycle");
      ancestor = ancestor.parent === undefined ? undefined : this.nodes.get(ancestor.parent);
    }
    const length = parent.children.length - (child.parent === parent.id ? 1 : 0);
    if (!Number.isSafeInteger(index) || index < 0 || index > length)
      throw new NativeStateError("invalid_state", "Child insertion index is out of range");
    if (child.parent !== undefined) {
      const previous = this.nodes.get(child.parent);
      previous.children.splice(previous.children.indexOf(child.id), 1);
    }
    parent.children.splice(index, 0, child.id);
    child.parent = parent.id;
    this.operations.push({ type: "insert", parent_id: parent.id, child_id: child.id, index });
  }
  append(parentHandle, childHandle) {
    const parent = own(this.nodes, parentHandle);
    const child = own(this.nodes, childHandle);
    this.insert(parentHandle, childHandle, parent.children.length - (child.parent === parent.id ? 1 : 0));
  }
  remove(handle) {
    this.check();
    const node = own(this.nodes, handle);
    if (node.id === this.rootId)
      throw new NativeStateError("invalid_state", "Close the window to dispose its root");
    if (node.parent !== undefined) {
      const parent = this.nodes.get(node.parent);
      parent.children.splice(parent.children.indexOf(node.id), 1);
    }
    const pending = [node.id];
    for (const id of pending) {
      const child = this.nodes.get(id);
      pending.push(...child.children);
      this.nodes.delete(id);
    }
    this.operations.push({ type: "delete", node_id: node.id });
  }
  validate() {
    let seen = 0;
    let bytes = 0;
    const pending = [{ id: this.rootId, depth: 0 }];
    for (const { id, depth } of pending) {
      if (depth > this.limits.max_depth)
        throw new NativeStateError("limit_exceeded", "Native tree depth limit exceeded");
      const node = this.nodes.get(id);
      seen += 1;
      const element = node.element;
      const texts = element.kind === "input" ? [element.value, element.placeholder ?? ""] : element.kind === "box" ? [] : [element.text];
      for (const text of texts) {
        const size = encoder2.encode(text).byteLength;
        if (size > this.limits.max_text_bytes)
          throw new NativeStateError("limit_exceeded", "Native text limit exceeded");
        bytes += size;
      }
      if (bytes > this.limits.max_text_bytes_per_window)
        throw new NativeStateError("limit_exceeded", "Window text memory limit exceeded");
      pending.push(...node.children.map((child) => ({ id: child, depth: depth + 1 })));
    }
    if (seen !== this.nodes.size)
      throw new NativeStateError("invalid_state", "Every created node must be attached before commit");
  }
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/core/src/application.ts
var MAX_QUEUED_TRANSACTIONS = 128;
var MAX_QUEUED_CALLBACKS = 128;

class Application {
  host;
  closed;
  limits;
  capabilities;
  serviceCapabilities;
  windows = new Map;
  tail = Promise.resolve();
  queued = 0;
  services = new Set;
  callbacks = [];
  dispatching;
  activeCallbacks = 0;
  nextWindow = 1;
  nextNode = 1;
  stopping;
  failure;
  phase = "running";
  constructor(host) {
    this.host = host;
    this.limits = host.limits;
    this.capabilities = host.capabilities;
    this.serviceCapabilities = serviceCapabilities(host.servicePolicy, host.capabilities);
    this.closed = this.consume();
    this.closed.catch(() => {});
  }
  get diagnostics() {
    let nodes = 0;
    let callbacks = 0;
    for (const window of this.windows.values()) {
      nodes += window.nodes.size;
      callbacks += window.listeners.size;
    }
    return Object.freeze({
      windows: this.windows.size,
      nodes,
      callbacks,
      queuedTransactions: this.queued,
      queuedCallbacks: this.callbacks.length,
      activeCallbacks: this.activeCallbacks,
      serviceRequests: this.services.size
    });
  }
  allocateNode() {
    if (!Number.isSafeInteger(this.nextNode))
      throw new NativeStateError("limit_exceeded", "Native node identity space exhausted");
    return this.nextNode++;
  }
  cancelCallbacks(windowId) {
    const window = this.windows.get(windowId);
    this.callbacks = this.callbacks.filter((callback) => {
      if (callback.windowId !== windowId)
        return true;
      if (window?.isTargetLive(callback.nodeId) && prunePlan(callback.plan))
        return true;
      window?.listeners.release(callback.plan);
      return false;
    });
  }
  queueCallback(callback) {
    if (this.phase !== "running")
      return;
    if (this.callbacks.length >= MAX_QUEUED_CALLBACKS)
      throw new ProtocolError("Application callback queue limit exceeded");
    this.callbacks.push(callback);
    this.startDispatch();
  }
  startDispatch() {
    if (!this.callbacks.length)
      return;
    if (this.dispatching)
      return;
    this.dispatching = this.dispatchCallbacks().catch(async (cause) => {
      this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
      await this.shutdown().catch(() => {});
    }).finally(() => {
      this.dispatching = undefined;
      this.startDispatch();
    });
  }
  async dispatchCallbacks() {
    while (this.callbacks.length) {
      const callback = this.callbacks.shift();
      const window = this.windows.get(callback.windowId);
      if (!window)
        continue;
      this.activeCallbacks = 1;
      try {
        await window.dispatch(callback.nodeId, callback.plan);
      } finally {
        this.activeCallbacks = 0;
      }
    }
  }
  enqueue(operation, closingWindow = false) {
    if (this.phase !== "running")
      return Promise.reject(this.failure ?? new NativeStateError("invalid_state", "Application is shutting down"));
    if (!closingWindow && this.queued >= MAX_QUEUED_TRANSACTIONS)
      return Promise.reject(new NativeStateError("limit_exceeded", "Application transaction queue is full"));
    this.queued += 1;
    const result = this.tail.then(() => {
      if (this.phase !== "running")
        throw this.failure ?? new NativeStateError("invalid_state", "Transaction cancelled during shutdown");
      return operation();
    }).finally(() => {
      this.queued -= 1;
    });
    this.tail = result.then(() => {}, () => {});
    return result;
  }
  openWindow(options) {
    const requested = { ...options };
    return this.enqueue(async () => {
      if (this.windows.size >= this.limits.max_windows)
        throw new NativeStateError("limit_exceeded", "Application window limit exceeded");
      if (!Number.isSafeInteger(this.nextWindow))
        throw new NativeStateError("limit_exceeded", "Native window identity space exhausted");
      const window = new Window(this, this.nextWindow++, this.allocateNode());
      this.windows.set(window.id, window);
      try {
        await this.host.send({
          type: "open",
          window_id: window.id,
          root_id: window.rootId,
          title: requested.title,
          width: requested.width ?? 560,
          height: requested.height ?? 380
        });
        window.assertActive();
        return window;
      } catch (error) {
        window.revoke();
        throw error;
      }
    });
  }
  service(operation) {
    if (this.phase !== "running")
      return Promise.reject(new NativeStateError("invalid_state", "Application is shutting down"));
    if (this.services.size >= this.limits.max_service_requests)
      return Promise.reject(new NativeStateError("limit_exceeded", "Native service request limit exceeded"));
    const result = Promise.resolve().then(() => {
      if (this.phase !== "running")
        throw new NativeStateError("invalid_state", "Service request cancelled during shutdown");
      return operation();
    });
    const settled = result.then(() => {}, () => {}).finally(() => this.services.delete(settled));
    this.services.add(settled);
    return result;
  }
  async shutdown() {
    if (!this.stopping) {
      this.phase = "stopping";
      for (const window of this.windows.values())
        window.revoke();
      this.stopping = (async () => {
        await this.tail;
        await this.host.shutdown();
        await Promise.all(this.services);
      })();
    }
    await this.stopping;
    if (this.failure)
      throw this.failure;
  }
  async consume() {
    try {
      for await (const event of this.host) {
        const window = this.windows.get(event.window_id);
        if (!window) {
          if (event.window_id >= this.nextWindow)
            throw new ProtocolError("Native event names an unallocated window");
          continue;
        }
        window.receive(event, this.nextNode);
      }
    } catch (cause) {
      this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
      this.phase = "stopping";
      await this.host.shutdown().catch(() => {});
    } finally {
      for (const window of this.windows.values())
        window.revoke();
      await this.dispatching;
      await Promise.all(this.services);
      this.phase = "closed";
    }
    if (this.failure)
      throw this.failure;
  }
}

class Window {
  application;
  id;
  rootId;
  root;
  closed;
  listeners;
  nodes = new Map;
  revision = 0;
  active = true;
  resolveClosed;
  closing;
  constructor(application, id, rootId) {
    this.application = application;
    this.id = id;
    this.rootId = rootId;
    const node = makeNode(rootId, { kind: "box" });
    this.root = node.handle;
    this.nodes.set(rootId, node);
    this.listeners = new EventBindings(() => this.application.cancelCallbacks(this.id));
    this.closed = new Promise((resolve) => {
      this.resolveClosed = resolve;
    });
  }
  assertActive() {
    if (!this.active)
      throw new NativeStateError("invalid_handle", "Window is closed");
  }
  batch(update) {
    return this.application.enqueue(async () => {
      this.assertActive();
      const transaction = new Transaction(this.nodes, this.rootId, () => this.application.allocateNode(), this.application.limits);
      let value;
      try {
        value = update(transaction);
        if (value !== null && (typeof value === "object" || typeof value === "function") && typeof value.then === "function") {
          Promise.resolve(value).catch(() => {});
          throw new NativeStateError("invalid_state", "Batch callbacks must be synchronous");
        }
        transaction.validate();
      } finally {
        transaction.finish();
      }
      if (!transaction.operations.length)
        return value;
      const reply = await this.application.host.send({
        type: "batch",
        window_id: this.id,
        base_revision: this.revision,
        operations: transaction.operations
      });
      this.assertActive();
      for (const [id, candidate] of transaction.nodes) {
        const current = this.nodes.get(id);
        if (current && current.inputRevision > candidate.inputRevision && current.element.kind === "input" && candidate.element.kind === "input") {
          candidate.inputRevision = current.inputRevision;
          candidate.element = { ...candidate.element, value: current.element.value };
        }
      }
      this.nodes = transaction.nodes;
      this.revision = reply.tree_revision;
      this.listeners.retain(this.nodes);
      return value;
    });
  }
  on(handle, type, listener, options) {
    this.assertActive();
    const node = own(this.nodes, handle);
    return this.listeners.register(node.id, node.handle, type, listener, options);
  }
  onClick(handle, listener) {
    this.assertActive();
    const node = own(this.nodes, handle);
    if (node.element.kind !== "button")
      throw new NativeStateError("invalid_state", "Click listeners require a button and a function");
    return this.listeners.register(node.id, node.handle, "click", listener);
  }
  onInput(handle, listener) {
    this.assertActive();
    const node = own(this.nodes, handle);
    if (node.element.kind !== "input")
      throw new NativeStateError("invalid_state", "Input listeners require an input and a function");
    return this.listeners.register(node.id, node.handle, "input", listener);
  }
  input(handle) {
    this.assertActive();
    const node = own(this.nodes, handle);
    if (node.element.kind !== "input")
      throw new NativeStateError("invalid_state", "Only an input has an edit state");
    return Object.freeze({ value: node.element.value, revision: node.inputRevision });
  }
  async displaySnapshot(options = {}) {
    const signal = serviceSignal(options);
    this.assertActive();
    checkServiceCancellation(signal, "window_display");
    return this.application.enqueue(async () => {
      this.assertActive();
      checkServiceCancellation(signal, "window_display");
      try {
        const response = await this.application.host.send({
          type: "display_snapshot",
          window_id: this.id
        });
        this.assertActive();
        checkServiceCancellation(signal, "window_display");
        return Object.freeze({
          bounds: Object.freeze({ ...response.snapshot.bounds }),
          scaleFactor: response.snapshot.scale_factor
        });
      } catch (error) {
        if (error instanceof ProtocolError)
          throw error;
        this.assertActive();
        checkServiceCancellation(signal, "window_display");
        if (error instanceof NativeCommandError && (error.code === "permission_denied" || error.code === "service_unavailable"))
          throw new NativeServiceError("window_display", error.code, error.message);
        throw error;
      }
    });
  }
  async readClipboardText(options = {}) {
    const signal = serviceSignal(options);
    return this.clipboard("clipboard_read", signal, async () => {
      const response = await this.application.host.send({
        type: "clipboard_read",
        window_id: this.id
      });
      return Object.freeze(response.result);
    });
  }
  writeClipboardText(text) {
    return this.clipboard("clipboard_write", undefined, async () => {
      await this.application.host.send({ type: "clipboard_write", window_id: this.id, text });
    });
  }
  async clipboard(service, signal, operation) {
    this.assertActive();
    checkServiceCancellation(signal, service);
    return this.application.service(async () => {
      this.assertActive();
      checkServiceCancellation(signal, service);
      try {
        const result = await operation();
        this.assertActive();
        checkServiceCancellation(signal, service);
        return result;
      } catch (error) {
        if (error instanceof ProtocolError)
          throw error;
        this.assertActive();
        checkServiceCancellation(signal, service);
        if (error instanceof NativeCommandError && [
          "permission_denied",
          "service_unavailable",
          "cancelled",
          "native_failure",
          "operation_timed_out",
          "payload_too_large",
          "limit_exceeded"
        ].includes(error.code))
          throw new NativeServiceError(service, error.code, error.message);
        throw error;
      }
    });
  }
  async close() {
    if (!this.active) {
      await this.closing;
      return;
    }
    this.active = false;
    this.listeners.clear();
    this.nodes.clear();
    this.closing = this.application.enqueue(async () => {
      try {
        await this.application.host.send({ type: "close", window_id: this.id });
      } catch (error) {
        if (!(error instanceof NativeCommandError && error.code === "invalid_handle")) {
          this.application.shutdown().catch(() => {});
          throw error;
        }
      }
      this.revoke();
    }, true);
    await this.closing;
  }
  revoke() {
    this.active = false;
    this.listeners.clear();
    this.nodes.clear();
    this.application.windows.delete(this.id);
    this.resolveClosed();
  }
  isTargetLive(id) {
    return this.active && this.nodes.has(id);
  }
  receive(event, nextNode) {
    if (event.type === "closed") {
      this.revoke();
      return;
    }
    if (!this.active)
      return;
    if (event.tree_revision > this.revision)
      throw new ProtocolError("Native event tree revision is ahead of its acknowledgement");
    if (event.path[0] !== this.rootId)
      throw new ProtocolError("Native event path starts outside its window root");
    const ownedPath = [];
    for (const id of event.path) {
      if (id >= nextNode)
        throw new ProtocolError("Native event names a node outside its owner");
      const node = this.nodes.get(id);
      if (node)
        ownedPath.push(node);
      else
        for (const window of this.application.windows.values())
          if (window !== this && window.nodes.has(id))
            throw new ProtocolError("Native event names a node outside its owner");
    }
    if (ownedPath.length !== event.path.length)
      return;
    if (event.tree_revision === this.revision && ownedPath.some((node, index) => index > 0 && node.parent !== event.path[index - 1]))
      throw new ProtocolError("Native event path does not match its committed tree revision");
    const node = ownedPath.at(-1);
    if (event.type === "input") {
      if (node.element.kind !== "input" || event.input_revision <= node.inputRevision)
        throw new ProtocolError("Native input kind or edit revision is invalid");
      node.inputRevision = event.input_revision;
      node.element = { ...node.element, value: event.value };
    } else if (event.type === "click") {
      if (node.element.kind !== "button")
        throw new ProtocolError("Native click targeted a non-button node");
      if (node.element.disabled)
        return;
    }
    const plan = this.listeners.prepare(event, ownedPath.map((item) => item.handle));
    if (plan)
      this.application.queueCallback({ windowId: this.id, nodeId: node.id, plan });
  }
  async dispatch(nodeId, plan) {
    try {
      await dispatchPlan(plan, () => this.isTargetLive(nodeId));
    } finally {
      this.listeners.release(plan);
    }
  }
}
async function createApplication(options) {
  return new Application(await NativeHost.launch(options));
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/input-intent.ts
var observations = new WeakMap;
function observeInput(event) {
  observations.set(event, {
    value: event.value,
    revision: event.revision,
    observedNode: event.node
  });
}
function captureInput(value) {
  if (value === undefined || typeof value === "string")
    return value;
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new TypeError("Native input value must be an initial string or { value, revision } intent");
  const observed = observations.get(value);
  if (observed)
    return Object.freeze({ ...observed });
  if (Object.keys(value).some((field) => field !== "value" && field !== "revision"))
    throw new TypeError("Explicit input intents accept only value and revision");
  const data = value;
  const text = data.value;
  const revision = data.revision;
  if (typeof text !== "string")
    throw new TypeError("Input intent value must be a string");
  if (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0)
    throw new NativeStateError("stale_revision", "Input intent requires a nonnegative safe revision");
  return Object.freeze({ value: text, revision, observedNode: undefined });
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/event-properties.ts
function binding(type, capture = false) {
  return Object.freeze({ type, capture });
}
var eventProperties = Object.freeze({
  onClick: binding("click"),
  onClickCapture: binding("click", true),
  onInput: binding("input"),
  onInputCapture: binding("input", true),
  onKeyDown: binding("key_down"),
  onKeyDownCapture: binding("key_down", true),
  onKeyUp: binding("key_up"),
  onKeyUpCapture: binding("key_up", true),
  onPointerDown: binding("pointer_down"),
  onPointerDownCapture: binding("pointer_down", true),
  onPointerUp: binding("pointer_up"),
  onPointerUpCapture: binding("pointer_up", true),
  onFocus: binding("focus"),
  onFocusCapture: binding("focus", true),
  onBlur: binding("blur"),
  onBlurCapture: binding("blur", true)
});
function isEventProperty(name) {
  return Object.hasOwn(eventProperties, name);
}
var emptyListeners = Object.freeze({});
function listeners(properties) {
  let result;
  for (const name of Object.keys(properties)) {
    if (!isEventProperty(name))
      continue;
    const listener = properties[name];
    if (listener)
      (result ??= {})[name] = listener;
  }
  return result ? Object.freeze(result) : emptyListeners;
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/nodes.ts
var nodes = new WeakSet;

class Node {
  kind;
  children = [];
  properties = {};
  parent;
  owner;
  scope;
  data = "";
  constructor(kind) {
    this.kind = kind;
    nodes.add(this);
  }
}
function asNode(value) {
  if (!value || typeof value !== "object" || !nodes.has(value))
    throw new NativeStateError("invalid_handle", "Expected an owned staged native node");
  return value;
}
function createElement(tag) {
  if (tag !== "box" && tag !== "text" && tag !== "button" && tag !== "input")
    throw new UnsupportedFeatureError("native-element:" + tag);
  return new Node(tag);
}
function createTextNode(value) {
  const node = new Node("text-node");
  node.data = String(value);
  return node;
}
function visit(node, fn) {
  fn(node);
  for (const child of node.children)
    visit(child, fn);
}
function insertNode(parent, node, anchor) {
  if (parent.kind === "input" || parent.kind === "text-node")
    throw new NativeStateError("invalid_state", "This native element cannot have children");
  if (parent.kind !== "box" && node.kind !== "text-node")
    throw new NativeStateError("invalid_state", "Text and button children must be text");
  if (anchor && anchor.parent !== parent)
    throw new NativeStateError("invalid_handle", "Insertion anchor belongs to another parent");
  if (anchor === node)
    return;
  for (let ancestor = parent;ancestor; ancestor = ancestor.parent)
    if (ancestor === node)
      throw new NativeStateError("invalid_state", "Native tree cycle");
  const owner = parent.owner;
  if (owner)
    visit(node, (child) => {
      if (child.scope && child.scope !== owner.token)
        throw new NativeStateError("invalid_handle", "Renderer nodes cannot move between render roots");
    });
  const previousOwner = node.owner;
  if (previousOwner && previousOwner !== owner)
    previousOwner.detached(node);
  if (node.parent)
    node.parent.children.splice(node.parent.children.indexOf(node), 1);
  node.parent = parent;
  parent.children.splice(anchor ? parent.children.indexOf(anchor) : parent.children.length, 0, node);
  visit(node, (child) => {
    child.owner = owner;
    if (owner)
      child.scope = owner.token;
  });
  previousOwner?.changed();
  owner?.changed();
}
function removeNode(parent, node) {
  if (node.parent !== parent)
    throw new NativeStateError("invalid_handle", "Removal target belongs to another parent");
  const owner = parent.owner;
  owner?.detached(node);
  parent.children.splice(parent.children.indexOf(node), 1);
  node.parent = undefined;
  visit(node, (child) => {
    child.owner = undefined;
  });
  owner?.changed();
}
function replaceText(node, value) {
  if (node.kind !== "text-node")
    throw new NativeStateError("invalid_state", "Text replacement requires a text node");
  if (node.data === value)
    return;
  node.data = value;
  node.owner?.changed();
}
function setProperty(node, name, value) {
  const props = node.properties;
  if (isEventProperty(name)) {
    if (node.kind === "text-node")
      throw new TypeError("Text literals cannot own native event handlers");
    if (value === undefined)
      delete props[name];
    else if (typeof value === "function")
      props[name] = value;
    else
      throw new TypeError(`Native ${name} must be a function`);
    node.owner?.changed();
    return;
  }
  switch (name) {
    case "style":
      if (value === undefined)
        delete props.style;
      else if (value && typeof value === "object" && !Array.isArray(value))
        props.style = { ...value };
      else
        throw new TypeError("Native style must be an object");
      break;
    case "text":
      if (node.kind !== "text" && node.kind !== "button")
        throw new TypeError("Only text and button elements accept text");
      if (value === undefined)
        delete props.text;
      else if (typeof value === "string")
        props.text = value;
      else
        throw new TypeError("Native text must be a string");
      break;
    case "value": {
      if (node.kind !== "input")
        throw new TypeError("Only inputs accept value");
      const captured = captureInput(value);
      if (captured === undefined)
        delete props.value;
      else
        props.value = captured;
      break;
    }
    case "placeholder":
      if (node.kind !== "input")
        throw new TypeError("Only inputs accept placeholder");
      if (value === undefined)
        delete props.placeholder;
      else if (typeof value === "string")
        props.placeholder = value;
      else
        throw new TypeError("Native input placeholder must be a string");
      break;
    case "disabled":
      if (node.kind !== "button")
        throw new TypeError("Only buttons accept disabled");
      if (value === undefined)
        delete props.disabled;
      else if (typeof value === "boolean")
        props.disabled = value;
      else
        throw new TypeError("Native disabled must be boolean");
      break;
    default:
      throw new UnsupportedFeatureError("native-property:" + name);
  }
  node.owner?.changed();
}
function leafStyle(style) {
  const { overflow, ...rest } = style;
  if (overflow !== undefined && overflow !== "visible" && overflow !== "hidden")
    throw new TypeError("Only native boxes support scrolling");
  return { ...rest, ...overflow === undefined ? {} : { overflow } };
}
function snapshot(root) {
  const result = new Map;
  const capture = (node, parent) => {
    const props = node.properties;
    const style = props.style && node.kind !== "box" ? { style: leafStyle(props.style) } : {};
    let element;
    if (node.kind === "box")
      element = { kind: "box", ...props.style ? { style: { ...props.style } } : {} };
    else if (node.kind === "input")
      element = {
        kind: "input",
        value: typeof props.value === "string" ? props.value : props.value?.value ?? "",
        ...props.placeholder === undefined ? {} : { placeholder: props.placeholder },
        ...style
      };
    else {
      if (props.text !== undefined && node.children.length)
        throw new TypeError("Choose text properties or text children, not both");
      const text = node.kind === "text-node" ? node.data : props.text ?? node.children.map((child) => child.data).join("");
      element = node.kind === "button" ? {
        kind: "button",
        text,
        ...props.disabled === undefined ? {} : { disabled: props.disabled },
        ...style
      } : { kind: "text", text, ...style };
    }
    const children = node.kind === "box" ? [...node.children] : [];
    result.set(node, {
      element,
      children,
      parent,
      events: listeners(props),
      initialValue: typeof props.value === "string" ? props.value : undefined,
      inputIntent: typeof props.value === "object" ? props.value : undefined
    });
    for (const child of children)
      capture(child, node);
  };
  capture(root);
  return result;
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/order.ts
function stableChildren(current, desired) {
  const positions = new Map(current.map((node, index) => [node, index]));
  const tails = [];
  const preceding = new Map;
  for (const node of desired) {
    const position = positions.get(node);
    if (position === undefined)
      continue;
    let start = 0;
    let end = tails.length;
    while (start < end) {
      const middle = start + end >>> 1;
      if (tails[middle].position < position)
        start = middle + 1;
      else
        end = middle;
    }
    preceding.set(node, tails[start - 1]?.node);
    tails[start] = { node, position };
  }
  const stable = new Set;
  let node = tails.at(-1)?.node;
  while (node !== undefined) {
    stable.add(node);
    node = preceding.get(node);
  }
  return stable;
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/native-tree.ts
function key(element) {
  return JSON.stringify(element);
}
function updateInput(window, batch, old, state) {
  if (old.element.kind !== "input")
    throw new NativeStateError("invalid_handle", "Input kind changed");
  if (state.initialValue !== undefined && state.initialValue !== old.initialValue)
    throw new UnsupportedFeatureError("input-value-requires-revision");
  const intent = state.inputIntent;
  if (intent && intent !== old.inputIntent) {
    if (intent.observedNode) {
      if (intent.observedNode !== old.handle)
        throw new NativeStateError("invalid_handle", "Native input observation belongs to another node");
    } else {
      batch.set(old.handle, state.element, intent.revision);
      return true;
    }
  }
  const appearance = (element) => JSON.stringify({ placeholder: element.placeholder ?? "", style: element.style ?? {} });
  if (appearance(old.element) === appearance(state.element))
    return false;
  const current = window.input(old.handle);
  batch.set(old.handle, { ...state.element, value: current.value }, current.revision);
  return true;
}
async function commitNativeTree(window, root, previous, desired) {
  const counts = { create: 0, set: 0, insert: 0, remove: 0 };
  const next = await window.batch((batch) => {
    const handles = new Map([...previous].map(([node, state]) => [node, state.handle]));
    const parents = new Map([...previous].map(([node, state]) => [node, state.parent]));
    const children = new Map([...previous].map(([node, state]) => [node, [...state.children]]));
    const attach = (parent, child, index) => {
      const oldParent = parents.get(child);
      const oldChildren = oldParent && children.get(oldParent);
      if (oldChildren)
        oldChildren.splice(oldChildren.indexOf(child), 1);
      const siblings = children.get(parent);
      siblings.splice(index, 0, child);
      parents.set(child, parent);
      batch.insert(handles.get(parent), handles.get(child), index);
      counts.insert += 1;
    };
    const rescue = (node) => {
      const descendants = children.get(node)?.slice() ?? [];
      for (const child of descendants) {
        if (desired.has(child))
          attach(root, child, children.get(root).length);
        else
          rescue(child);
      }
    };
    for (const [node, state] of previous) {
      if (desired.has(node) || state.parent && !desired.has(state.parent))
        continue;
      rescue(node);
      batch.remove(state.handle);
      counts.remove += 1;
      const siblings = state.parent && children.get(state.parent);
      if (siblings)
        siblings.splice(siblings.indexOf(node), 1);
    }
    for (const [node, state] of desired) {
      const old = previous.get(node);
      if (!old) {
        if (state.inputIntent?.observedNode)
          throw new NativeStateError("invalid_handle", "Native input observation belongs to another node");
        if (state.inputIntent && state.inputIntent.revision !== 0)
          throw new NativeStateError("stale_revision", "New input value intent requires revision zero");
        const handle = batch.create(state.element);
        handles.set(node, handle);
        children.set(node, []);
        counts.create += 1;
        if (node === root) {
          batch.append(window.root, handle);
          counts.insert += 1;
        }
      } else if (state.element.kind === "input") {
        if (updateInput(window, batch, old, { ...state, element: state.element }))
          counts.set += 1;
      } else if (key(old.element) !== key(state.element)) {
        batch.set(old.handle, state.element);
        counts.set += 1;
      }
    }
    for (const [parent, state] of desired) {
      const siblings = children.get(parent);
      if (siblings.length === state.children.length && siblings.every((child, index) => child === state.children[index]))
        continue;
      const stable = stableChildren(siblings, state.children);
      let anchor;
      for (let index = state.children.length - 1;index >= 0; index -= 1) {
        const child = state.children[index];
        if (!stable.has(child)) {
          const before = anchor === undefined ? siblings.length : siblings.indexOf(anchor);
          const old = parents.get(child) === parent ? siblings.indexOf(child) : -1;
          attach(parent, child, before - (old >= 0 && old < before ? 1 : 0));
        }
        anchor = child;
      }
    }
    return new Map([...desired].map(([node, state]) => [node, { ...state, handle: handles.get(node) }]));
  });
  return { nodes: next, counts };
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/window-lifetime.ts
var lifetimes = new WeakMap;
function consume(registration) {
  const listener = registration.listener;
  registration.listener = undefined;
  return listener;
}
function lifetimeFor(window) {
  let lifetime = lifetimes.get(window);
  if (!lifetime) {
    const created = { ended: false, listeners: new Set };
    lifetime = created;
    lifetimes.set(window, created);
    window.closed.then(() => {
      created.ended = true;
      const listeners = [...created.listeners].map(consume);
      created.listeners.clear();
      for (const notify of listeners)
        notify?.();
    });
  }
  return lifetime;
}
function watchWindow(window, listener) {
  const lifetime = lifetimeFor(window);
  if (lifetime.ended)
    throw new NativeStateError("invalid_handle", "Window is already closed");
  const registration = { listener };
  lifetime.listeners.add(registration);
  return () => {
    lifetime.listeners.delete(registration);
    registration.listener = undefined;
  };
}

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/renderer/src/root.ts
class Root {
  window;
  token = {};
  root = new Node("box");
  ready;
  closed;
  resolveClosed;
  rejectClosed;
  disposeFramework;
  unwatch;
  committed = new Map;
  registrations = new Map;
  operation;
  version = 0;
  acknowledged = -1;
  phase = "active";
  windowEnded = false;
  failure;
  commits = 0;
  mutations = { create: 0, set: 0, insert: 0, remove: 0 };
  constructor(window, initialize, style) {
    this.window = window;
    setProperty(this.root, "style", style);
    this.closed = new Promise((resolve, reject) => {
      this.resolveClosed = resolve;
      this.rejectClosed = reject;
    });
    this.closed.catch(() => {});
    this.root.owner = this;
    this.root.scope = this.token;
    this.unwatch = watchWindow(window, () => {
      this.windowEnded = true;
      this.stop();
      this.finish();
    });
    try {
      initialize({
        container: this.root,
        onCleanup: (cleanup) => {
          if (this.disposeFramework)
            throw new NativeStateError("invalid_state", "Framework cleanup is already registered");
          this.disposeFramework = cleanup;
        },
        fail: (cause) => this.fail(cause)
      });
    } catch (cause) {
      this.failure = cause instanceof Error ? cause : new Error(String(cause));
      this.stop();
    }
    this.start();
    this.ready = this.flush().then(() => {
      if (this.commits === 0)
        throw new NativeStateError("invalid_handle", "Render root closed before initial native acknowledgement");
    });
    this.ready.catch(() => {});
  }
  get diagnostics() {
    let listeners = 0;
    for (const registrations of this.registrations.values())
      listeners += registrations.size;
    return Object.freeze({
      nodes: this.committed.size,
      listeners,
      pending: this.operation !== undefined,
      commits: this.commits,
      mutations: Object.freeze({ ...this.mutations })
    });
  }
  changed() {
    if (this.phase !== "active")
      return;
    this.version += 1;
    this.start();
  }
  detached(node) {
    visit(node, (child) => this.revoke(child));
  }
  revoke(node, property) {
    const registrations = this.registrations.get(node);
    if (!registrations)
      return;
    if (property) {
      const registration = registrations.get(property);
      registrations.delete(property);
      if (!registrations.size)
        this.registrations.delete(node);
      registration?.unsubscribe();
    } else {
      this.registrations.delete(node);
      for (const registration of registrations.values())
        registration.unsubscribe();
      registrations.clear();
    }
  }
  input(node) {
    const state = this.committed.get(node);
    if (this.phase !== "active" || !state || state.handle.kind !== "input")
      throw new NativeStateError("invalid_handle", "Input is unmounted or has no committed native handle");
    return this.window.input(state.handle);
  }
  start() {
    if (this.operation || this.phase === "closed")
      return;
    this.operation = Promise.resolve().then(async () => {
      while (this.phase === "active" && this.acknowledged !== this.version) {
        const version = this.version;
        await this.commit(snapshot(this.root));
        this.acknowledged = version;
      }
      if (this.phase === "disposing")
        await this.cleanup();
    }).catch(async (cause) => {
      if (!this.windowEnded) {
        this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
        this.stop();
        try {
          await this.cleanup();
        } catch (cleanupError) {
          this.failure = new AggregateError([this.failure, cleanupError], "Native renderer cleanup failed");
          this.finish();
        }
      }
    }).finally(() => {
      this.operation = undefined;
      if (this.phase === "disposing" || this.phase === "active" && this.acknowledged !== this.version)
        this.start();
    });
  }
  async flush() {
    while (this.operation)
      await this.operation;
    if (this.failure)
      throw this.failure;
  }
  async dispose() {
    this.stop();
    this.start();
    await this.flush();
    await this.closed;
  }
  fail(cause) {
    if (this.phase !== "active")
      return;
    this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
    this.stop();
    this.start();
  }
  stop() {
    if (this.phase === "closed")
      return;
    this.phase = "disposing";
    const dispose = this.disposeFramework;
    this.disposeFramework = undefined;
    try {
      dispose?.();
    } catch (cause) {
      this.failure ??= cause instanceof Error ? cause : new Error(String(cause));
    }
    for (const node of this.registrations.keys())
      this.revoke(node);
    visit(this.root, (node) => {
      node.owner = undefined;
      for (const name of Object.keys(node.properties))
        if (isEventProperty(name))
          delete node.properties[name];
    });
  }
  finish() {
    if (this.phase === "closed")
      return;
    this.phase = "closed";
    this.unwatch?.();
    this.unwatch = undefined;
    this.committed.clear();
    this.root.children.length = 0;
    if (this.failure)
      this.rejectClosed(this.failure);
    else
      this.resolveClosed();
  }
  async cleanup() {
    const root = this.committed.get(this.root);
    if (root && !this.windowEnded) {
      await this.window.batch((batch) => batch.remove(root.handle));
      this.mutations.remove += 1;
      this.commits += 1;
    }
    this.finish();
  }
  async commit(desired) {
    const previous = this.committed;
    const { nodes: next, counts } = await commitNativeTree(this.window, this.root, previous, desired);
    if (this.windowEnded)
      return;
    this.committed = next;
    if (Object.values(counts).some((count) => count > 0))
      this.commits += 1;
    for (const field of ["create", "set", "insert", "remove"])
      this.mutations[field] += counts[field];
    if (this.phase !== "active")
      return;
    for (const node of this.registrations.keys())
      if (!next.has(node) || node.owner !== this)
        this.revoke(node);
    for (const [node, state] of next) {
      if (node.owner !== this)
        continue;
      for (const [name, registration] of this.registrations.get(node) ?? [])
        if (state.events[name] !== registration.listener)
          this.revoke(node, name);
      for (const [name, listener] of Object.entries(state.events)) {
        if (!isEventProperty(name) || !listener || this.registrations.get(node)?.has(name))
          continue;
        const binding = eventProperties[name];
        const unsubscribe = this.window.on(state.handle, binding.type, async (event) => {
          if (node.owner !== this || node.properties[name] !== listener)
            return;
          if (event.type === "input")
            observeInput(event);
          await listener(event);
          await this.flush();
        }, { capture: binding.capture });
        let registrations = this.registrations.get(node);
        if (!registrations) {
          registrations = new Map;
          this.registrations.set(node, registrations);
        }
        registrations.set(name, { listener, unsubscribe });
      }
    }
  }
}
function createRenderRoot(window, initialize, options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("Native render options must be an object");
  for (const name of Object.keys(options))
    if (name !== "style")
      throw new TypeError("Unknown native render option: " + name);
  return new Root(window, initialize, options.style);
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/solid/src/renderer.ts
var renderer = createRenderer({
  createElement,
  createTextNode,
  isTextNode: (node) => asNode(node).kind === "text-node",
  replaceText: (node, value) => replaceText(asNode(node), value),
  setProperty: (node, name, value) => setProperty(asNode(node), name, value),
  insertNode: (parent, node, anchor) => insertNode(asNode(parent), asNode(node), anchor == null ? undefined : asNode(anchor)),
  removeNode: (parent, node) => removeNode(asNode(parent), asNode(node)),
  getParentNode: (node) => asNode(node).parent,
  getFirstChild: (node) => asNode(node).children[0],
  getNextSibling: (value) => {
    const node = asNode(value);
    return node.parent?.children[node.parent.children.indexOf(node) + 1];
  }
});

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/solid/src/mount.ts
function assertReactiveRuntime() {
  let observed = -1;
  createRoot((dispose) => {
    const [value, set] = createSignal(0);
    const derived = createMemo(value);
    set(1);
    observed = derived();
    dispose();
  });
  if (observed !== 1)
    throw new Error("Solid native rendering requires Bun --conditions=browser (reactive Solid exports)");
}
function render(component, window, options = {}) {
  if (typeof component !== "function")
    throw new NativeStateError("invalid_state", "Solid render requires a component function");
  assertReactiveRuntime();
  return createRenderRoot(window, ({ container, onCleanup }) => {
    createRoot((dispose) => {
      onCleanup(dispose);
      renderer.insert(container, component());
    });
  }, options);
}
// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/node_modules/@bun-native/solid/src/index.ts
var {
  effect,
  memo: memo2,
  createComponent: createComponent2,
  createElement: createElement2,
  createTextNode: createTextNode2,
  insertNode: insertNode2,
  insert,
  spread,
  setProp,
  mergeProps: mergeProps2,
  use
} = renderer;

// ../home/runner/work/_temp/native-evidence/cli-standalone/owned/projects/solid-typescript/main.tsx
var executable = process.env["BUN_NATIVE_HOST"];
if (!executable)
  throw new Error("Run the dev command with --host pointing to a prebuilt native host");
var application = await createApplication({
  executable
});
var view;
var stopped = Promise.withResolvers();
var stop = () => stopped.resolve();
function stopFromParent(message) {
  if (message && typeof message === "object" && "type" in message && message.type === "bun-native:stop")
    stop();
}
process.once("SIGINT", stop);
process.once("SIGTERM", stop);
process.on("message", stopFromParent);
function App() {
  const [clicks, setClicks] = createSignal(0);
  return (() => {
    var _el$ = createElement2("box"), _el$2 = createElement2("text"), _el$3 = createElement2("text"), _el$4 = createElement2("button");
    insertNode2(_el$, _el$2);
    insertNode2(_el$, _el$3);
    insertNode2(_el$, _el$4);
    setProp(_el$, "style", {
      direction: "column",
      gap: 12,
      padding: 24
    });
    setProp(_el$2, "text", "Bun Native Solid");
    setProp(_el$2, "style", {
      font_size: 28
    });
    setProp(_el$4, "text", "Increment");
    setProp(_el$4, "style", {
      width: 160,
      height: 44
    });
    setProp(_el$4, "onClick", () => {
      setClicks((value) => value + 1);
    });
    effect((_$p) => setProp(_el$3, "text", "Clicks: " + clicks(), _$p));
    return _el$;
  })();
}
try {
  const window = await application.openWindow({
    title: "Bun Native Solid",
    width: 640,
    height: 480
  });
  view = render(App, window);
  await view.ready;
  process.send?.({
    type: "bun-native:ready"
  });
  await Promise.race([window.closed, view.closed, stopped.promise]);
} finally {
  process.off("SIGINT", stop);
  process.off("SIGTERM", stop);
  process.off("message", stopFromParent);
  try {
    await view?.dispose();
  } finally {
    await application.shutdown();
    await application.closed;
    process.send?.({
      type: "bun-native:stopped",
      application: application.diagnostics,
      nodes: view?.diagnostics.nodes ?? 0
    });
    if (process.connected)
      process.disconnect?.();
  }
}

//# debugId=2D119E5344EB35AD64756E2164756E21
