#!/usr/bin/env python3
"""Collect real X11 input evidence for an explicitly supplied Bun Native app.

Requires xdotool, ImageMagick's import, an X11 display and an EWMH window manager.
The app receives BUN_NATIVE_EVIDENCE_LOG and BUN_NATIVE_EVIDENCE_NONCE. It may
append JSON objects containing that nonce and its actual native events/render
reports. Only records written after input injection can satisfy expectations.
Screenshots are evidence, never automatically asserted to contain expected text.
"""

import argparse
import ctypes
import hashlib
import importlib.util
import json
import math
import os
import platform
import re
import secrets
import shutil
import signal
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path

EVENT_STRESS_COUNT = 1000
EVENT_STRESS_TEXT = "x" * EVENT_STRESS_COUNT
EVENT_STRESS_TITLE = "Bun Native event throughput"
PAINT_OBSERVER_PATH = Path(__file__).with_name("native-paint-observer.py")
PAINT_OBSERVER_SPEC = importlib.util.spec_from_file_location(
    "native_paint_observer", PAINT_OBSERVER_PATH
)
PAINT_OBSERVER = importlib.util.module_from_spec(PAINT_OBSERVER_SPEC)
PAINT_OBSERVER_SPEC.loader.exec_module(PAINT_OBSERVER)
MAX_LOG_BYTES = PAINT_OBSERVER.MAX_LOG_BYTES


class Unsupported(RuntimeError):
    """The environment cannot perform real native input verification."""


def proc_identity_matches():
    try:
        return int(Path("/proc/self/stat").read_text().split(" ", 1)[0]) == os.getpid()
    except (OSError, ValueError):
        return False


def enable_subreaper():
    """Adopt orphaned descendants so cleanup can reap them without relying on PID1."""
    # Process-local Linux API; no privilege or system-wide setting is changed.
    # https://man7.org/linux/man-pages/man2/PR_SET_CHILD_SUBREAPER.2const.html
    try:
        prctl = ctypes.CDLL(None, use_errno=True).prctl
    except (AttributeError, OSError) as error:
        raise Unsupported("Linux child-subreaper support is unavailable") from error
    prctl.argtypes = [ctypes.c_int, *([ctypes.c_ulong] * 4)]
    prctl.restype = ctypes.c_int
    if prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise Unsupported(
            f"Cannot supervise orphaned children: {os.strerror(ctypes.get_errno())}"
        )


def run(command, timeout=3):
    result = subprocess.run(
        command, check=False, capture_output=True, text=True, timeout=timeout
    )
    if result.returncode:
        raise RuntimeError(
            f"{command[0]} exited {result.returncode}: {result.stderr[-2000:]}"
        )
    return result.stdout.strip()


def process_table():
    result = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
            result[int(entry.name)] = {
                "pid": int(entry.name),
                "state": fields[0],
                "parent_pid": int(fields[1]),
                "process_group": int(fields[2]),
                "start_ticks": int(fields[19]),
                "rss_bytes": int(fields[21]) * os.sysconf("SC_PAGE_SIZE"),
            }
        except (OSError, ValueError, IndexError, ProcessLookupError):
            continue
    return result


def owned_processes(root_pid, table):
    owned = {root_pid}
    while True:
        children = {
            pid
            for pid, row in table.items()
            if row["parent_pid"] in owned or row["process_group"] == root_pid
        }
        if children.issubset(owned):
            return [row for pid, row in table.items() if pid in owned]
        owned.update(children)


def close_window_probe(window, expected_owner, started):
    """One read-only X11 observation; neither a close request nor a success gate."""
    observation = {
        "window_id": window,
        "expected_owner": expected_owner,
        "state": "unknown",
        "method": "xdotool getwindowpid plus /proc PID/start-ticks identity",
        "scope": "X11 window presence and owner at observation; not WM close delivery",
        "clock": "driver_monotonic_relative",
    }
    try:
        if (
            not isinstance(window, str)
            or not re.fullmatch(r"[1-9][0-9]{0,9}", window)
            or int(window) >= 2**32
            or not isinstance(expected_owner, dict)
            or any(
                type(expected_owner.get(key)) is not int or expected_owner[key] <= 0
                for key in ["pid", "start_ticks"]
            )
        ):
            raise ValueError(
                "Close probe requires the previously owned window identity"
            )
        result = subprocess.run(
            ["xdotool", "getwindowpid", window],
            check=False,
            capture_output=True,
            text=True,
            timeout=3,
        )
        observation["command_returncode"] = result.returncode
        observation["stderr_tail"] = result.stderr[-2000:]
        if result.returncode:
            # A generic command error is not evidence that the window vanished.
            if "BadWindow (invalid Window parameter)" in result.stderr:
                observation["state"] = "absent"
        elif re.fullmatch(r"[1-9][0-9]{0,9}\s*", result.stdout):
            pid = int(result.stdout)
            identity = process_table().get(pid)
            observation["observed_owner_pid"] = pid
            if pid != expected_owner["pid"]:
                observation["state"] = "present-foreign-owner"
            elif identity and identity["start_ticks"] == expected_owner["start_ticks"]:
                observation["state"] = "present-owned"
            else:
                observation["state"] = "present-unverified-owner"
        else:
            observation["error"] = "Malformed window owner response"
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        observation["error"] = str(error)[-2000:]
    observation["observed_at_ms"] = (time.monotonic() - started) * 1000
    return observation


def close_process_snapshot(observed, started):
    """Observe known identities without extending cleanup ownership after exit."""
    table = process_table()
    matching = []
    missing = []
    reused = []
    for pid, start_ticks in observed.items():
        row = table.get(pid)
        if row is None:
            missing.append(pid)
        elif row["start_ticks"] != start_ticks:
            reused.append(pid)
        else:
            matching.append(row)
    return {
        "scope": "previously observed PID/start-ticks matches only; no owner discovery",
        "clock": "driver_monotonic_relative",
        "observed_at_ms": (time.monotonic() - started) * 1000,
        "processes": matching,
        "missing_pids": missing,
        "reused_pids": reused,
    }


def capture(stream, path, stats):
    with path.open("wb") as output:
        while chunk := stream.read(8192):
            remaining = max(0, MAX_LOG_BYTES - stats["written_bytes"])
            output.write(chunk[:remaining])
            stats["written_bytes"] += min(remaining, len(chunk))
            stats["discarded_bytes"] += max(0, len(chunk) - remaining)


def read_events(path, nonce, offset):
    if not path.exists():
        return []
    if path.stat().st_size > MAX_LOG_BYTES:
        raise RuntimeError("Application event evidence exceeded the 4 MiB limit")
    with path.open("rb") as stream:
        stream.seek(offset)
        data = stream.read(MAX_LOG_BYTES + 1)
    if len(data) > MAX_LOG_BYTES:
        raise RuntimeError("Application event evidence exceeded the 4 MiB limit")
    events = []
    # Ignore an unfinished final record until the next polling pass.
    for line in data.split(b"\n")[:-1]:
        value = json.loads(line)
        if not isinstance(value, dict) or value.get("nonce") != nonce:
            raise RuntimeError(
                "Application evidence has an invalid record or session nonce"
            )
        events.append(value)
    return events


def matches(event, expected):
    return bool(expected) and all(
        PAINT_OBSERVER.same_json(event.get(key), value)
        for key, value in expected.items()
    )


def matches_paint(event, expected):
    return (
        event.get("stage") == "native-paint"
        and event.get("status") != "omitted"
        and matches(event, expected)
    )


def validate_native_pointer_request(click, keys, text, expectations, initial, final):
    """Opt-in evidence for unchanged apps, separate from app callback evidence."""
    if (
        click is None
        or keys
        or text is not None
        or expectations
        or not isinstance(initial, dict)
        or not isinstance(final, dict)
        or not isinstance(initial.get("nodes"), list)
        or not initial["nodes"]
        or not isinstance(final.get("nodes"), list)
        or not final["nodes"]
        or initial["nodes"] == final["nodes"]
        or type(initial.get("window_id")) is not int
        or initial["window_id"] < 1
        or type(final.get("window_id")) is not int
        or initial["window_id"] != final.get("window_id")
        or type(initial.get("tree_revision")) is not int
        or type(final.get("tree_revision")) is not int
        or not 0 < initial["tree_revision"] < final["tree_revision"]
    ):
        raise ValueError(
            "Native pointer evidence requires one click, no app-event expectations "
            "or other input, and different complete initial/final trees for one window"
        )


def native_pointer_click_observed(events, window_id, position):
    """Require down then up in the injected logical pixel after the input offset."""
    if (
        not isinstance(position, list)
        or len(position) != 2
        or any(type(coordinate) is not int for coordinate in position)
    ):
        return False
    down_index = None
    expected = {
        "type": "pointer_trace",
        "stage": "gpui-window-input",
        "window_id": window_id,
        "button": "Left",
        "window_active": True,
        "limit_reached": False,
    }
    for event in events:
        index = event.get("trace_index")
        coordinates = event.get("position")
        if (
            not matches(event, expected)
            or type(index) is not int
            or not 1 <= index < 64
            or not isinstance(coordinates, list)
            or len(coordinates) != 2
            # Pinned GPUI converts XInput16.16 with divisor 65535: the injected
            # 100,130 becomes f32 100.001526,130.001984 at scale 1. Require the
            # same integer pixel, rejecting ambiguous half-pixel boundaries.
            or not all(
                type(value) in (int, float)
                and (type(value) is int or math.isfinite(value))
                and abs(value - target) < 0.5
                for value, target in zip(coordinates, position)
            )
        ):
            continue
        if event.get("event") == "down":
            down_index = index
        elif (
            event.get("event") == "up" and down_index is not None and index > down_index
        ):
            return True
    return False


def validate_input_request(event_stress, title, text, keys, click):
    """The larger workload is explicit and fixed; ordinary smoke limits remain."""
    if event_stress:
        if (
            title != EVENT_STRESS_TITLE
            or text != EVENT_STRESS_TEXT
            or keys
            or click is not None
        ):
            raise ValueError(
                "Event stress requires its fixed title, exactly 1000 lowercase x "
                "characters, and no additional key or click actions"
            )
    elif len(keys) > 16 or (
        text is not None and len(text.replace("{nonce}", "0" * 32)) > 200
    ):
        raise ValueError(
            "Native smoke input is limited to 16 keys and 200 expanded text characters"
        )


def event_stress_observations(events, require_complete=False):
    """Validate every app-observed edit; do not infer individual dispatch latency."""
    edits = [
        event
        for event in events
        if event.get("type") == "input" and event.get("stage") == "bun-application"
    ]
    if len(edits) > EVENT_STRESS_COUNT:
        raise RuntimeError("Event stress produced more than 1000 input callbacks")
    observed = []
    previous_sequence = 0
    for index, event in enumerate(edits, 1):
        if (
            type(event.get("sequence")) is not int
            or not previous_sequence < event["sequence"] <= 9_007_199_254_740_991
            or type(event.get("input_revision")) is not int
            or event["input_revision"] != index
            or event.get("value") != "x" * index
        ):
            raise RuntimeError(
                f"Event stress callback {index} has a missing, repeated, reordered or invalid edit"
            )
        previous_sequence = event["sequence"]
        timestamp = event.get("observed_at_ms")
        if (
            not isinstance(timestamp, (int, float))
            or isinstance(timestamp, bool)
            or not math.isfinite(timestamp)
            or timestamp < 0
            or (observed and timestamp < observed[-1])
        ):
            raise RuntimeError(
                "Event stress callback timestamps must be finite and monotonic"
            )
        observed.append(timestamp)
    complete = len(edits) == EVENT_STRESS_COUNT
    if require_complete and not complete:
        raise RuntimeError("Event stress did not deliver all 1000 input callbacks")
    span_ms = observed[-1] - observed[0] if len(observed) > 1 else None
    if complete and span_ms <= 0:
        raise RuntimeError(
            "Event stress requires a positive callback observation interval"
        )
    return {
        "complete": complete,
        "verified_callbacks": len(edits),
        "first_callback_observed_ms": observed[0] if observed else None,
        "last_callback_observed_ms": observed[-1] if observed else None,
        "callback_observation_span_ms": span_ms,
        "observed_callbacks_per_second": (len(observed) - 1) * 1000 / span_ms
        if span_ms is not None and span_ms > 0
        else None,
        "timing_scope": "Bun callback-entry observations, including the offered input schedule; not per-event dispatch or presentation latency",
    }


def fixture_paint(tree_revision, label, value=""):
    """Independent full-tree expectation shared by native smoke and baseline runs."""
    elements = [
        {
            "kind": "box",
            "style": {
                "direction": "column",
                "gap": 12,
                "padding": 24,
                "background": 0xF4F5F7,
            },
        },
        {"kind": "text", "text": "Bun Native", "style": {"font_size": 28}},
        {"kind": "text", "text": label, "style": {}},
        {
            "kind": "button",
            "text": "Increment",
            "disabled": False,
            "style": {"width": 160, "height": 44},
        },
        {"kind": "text", "text": "Native editable input", "style": {}},
        {
            "kind": "input",
            "value": value,
            "placeholder": "Type here…",
            "style": {"width": "fill", "font_size": 24},
        },
    ]
    nodes = [
        {
            "node_id": index + 1,
            "element": element,
            "children": [2, 3, 4, 5, 6] if index == 0 else [],
        }
        for index, element in enumerate(elements)
    ]
    # The smoke fixture types only ASCII; one native edit per typed character.
    nodes[-1]["input_revision"] = len(value.replace("{nonce}", "0" * 32))
    return {
        "type": "rendered",
        "stage": "native-paint",
        "window_id": 1,
        "tree_revision": tree_revision,
        "nodes": nodes,
    }


def fixture_click(activation):
    return {
        "type": "click",
        "stage": "bun-application",
        "activation": activation,
        "target": "increment",
    }


def javascript_fixture_paint(tree_revision, label, value, input_revision):
    state = fixture_paint(tree_revision, label, value)
    state["nodes"][1]["element"]["text"] = "JavaScript consumer"
    state["nodes"][3]["element"]["text"] = "Update"
    state["nodes"][4]["element"]["text"] = "Native input from JavaScript"
    state["nodes"][5]["input_revision"] = input_revision
    return state


def display_service_fixture_paint(tree_revision, label, framework="core"):
    if framework == "core":
        state = fixture_paint(tree_revision, label)
        state["nodes"][3]["element"]["text"] = "Read display"
        return state
    if framework not in ("solid", "react"):
        raise ValueError("Unknown display-service fixture framework")
    elements = [
        {"kind": "box", "style": {}},
        {"kind": "box", "style": {}},
        {"kind": "box", "style": {"direction": "column", "gap": 12, "padding": 24}},
        {"kind": "text", "text": "Bun Native services", "style": {"font_size": 28}},
        {"kind": "text", "text": label, "style": {}},
        {
            "kind": "button",
            "text": "Read display",
            "disabled": False,
            "style": {"width": 160, "height": 44},
        },
    ]
    children = {1: [2], 2: [3], 3: [4, 5, 6]}
    return {
        "type": "rendered",
        "stage": "native-paint",
        "window_id": 1,
        "tree_revision": tree_revision,
        "nodes": [
            {
                "node_id": identity,
                "element": element,
                "children": children.get(identity, []),
            }
            for identity, element in enumerate(elements, 1)
        ],
    }


def lifecycle_fixture_paint(tree_revision, label):
    state = fixture_paint(tree_revision, label)
    state["nodes"] = state["nodes"][:4]
    state["nodes"][0]["children"] = [2, 3, 4]
    state["nodes"][1]["element"]["text"] = "Public lifecycle"
    state["nodes"][3]["element"]["text"] = "Run 1,000 cycles"
    state["nodes"][3]["element"]["style"]["width"] = 200
    return state


def lifecycle_fixture_event():
    # Focus, pointer and key observations share native global sequence numbers.
    # The launch click is identified by its application target, not position 1.
    return {
        "type": "click",
        "stage": "bun-application",
        "target": "public-lifecycle",
    }


def event_stress_fixture_paint(value):
    state = fixture_paint(1, "Recording 1000 OS-delivered edits", value)
    state["nodes"] = [*state["nodes"][:3], state["nodes"][5]]
    state["nodes"][0]["children"] = [2, 3, 4]
    state["nodes"][1]["element"]["text"] = "Native input throughput"
    state["nodes"][3]["node_id"] = 4
    state["nodes"][3]["element"]["placeholder"] = "1000 lowercase x edits"
    state["nodes"][3]["element"]["style"]["font_size"] = 20
    return state


def interrupted(signum, _frame):
    raise InterruptedError(f"Native input driver received signal {signum}")


def cleanup(app, observed):
    """Signal only this launched session and identity-checked observed descendants."""

    def reap_adopted():
        app.poll()
        table = process_table()
        for pid, started in observed.items():
            row = table.get(pid)
            if (
                pid != app.pid
                and row is not None
                and row["start_ticks"] == started
                and row["parent_pid"] == os.getpid()
                and row["state"] == "Z"
            ):
                try:
                    os.waitpid(pid, os.WNOHANG)
                except ChildProcessError:
                    pass

    forced = False
    for sig, grace in [(signal.SIGTERM, 2), (signal.SIGKILL, 1)]:
        reap_adopted()
        table = process_table()
        alive = [
            row
            for pid, row in table.items()
            if pid in observed
            and row["start_ticks"] == observed[pid]
            and row["state"] != "Z"
        ]
        if not alive:
            break
        forced = True
        if any(row["process_group"] == app.pid for row in alive):
            try:
                os.killpg(app.pid, sig)
            except ProcessLookupError:
                pass
        for row in alive:
            if row["process_group"] != app.pid:
                try:
                    os.kill(row["pid"], sig)
                except ProcessLookupError:
                    pass
        try:
            app.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            pass
        time.sleep(0.1)
    reap_adopted()
    table = process_table()
    remaining = [
        pid
        for pid, started in observed.items()
        if pid in table
        and table[pid]["start_ticks"] == started
        and table[pid]["state"] != "Z"
    ]
    zombies = [
        pid
        for pid, started in observed.items()
        if pid in table
        and table[pid]["start_ticks"] == started
        and table[pid]["state"] == "Z"
    ]
    return {
        "forced_termination": forced,
        "remaining_observed_pids": remaining,
        "unreaped_observed_pids": zombies,
        "application_exit_code": app.poll(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, required=True, help="New evidence directory"
    )
    parser.add_argument(
        "--title", default="Bun Native BN1", help="Exact X11 window title"
    )
    parser.add_argument("--mode", required=True, choices=["development", "aot"])
    parser.add_argument("--timeout", type=float, default=20)
    parser.add_argument(
        "--idle-seconds",
        type=float,
        default=0,
        help="Sample idle process-tree RSS after first paint, before input (0 to 10)",
    )
    parser.add_argument("--key", action="append", default=[])
    parser.add_argument(
        "--text", help="Text to type; {nonce} expands to this run identifier"
    )
    parser.add_argument("--click", nargs=2, type=int, metavar=("X", "Y"))
    parser.add_argument(
        "--event-stress",
        action="store_true",
        help="Run the fixed 1000-edit event-throughput fixture with 1ms requested typing delay",
    )
    parser.add_argument(
        "--expect-event", action="append", default=[], help="JSON object subset"
    )
    parser.add_argument(
        "--expect-native-pointer",
        action="store_true",
        help="Require native down/up capture plus changed complete paint, without an app callback probe",
    )
    parser.add_argument(
        "--require-unforced-cleanup",
        action="store_true",
        help="Fail if process-tree cleanup needs to terminate a remaining owned process",
    )
    parser.add_argument(
        "--expect-render", help="JSON subset with type=rendered; app-reported only"
    )
    parser.add_argument(
        "--expect-initial-render",
        help="Native paint JSON subset required before idle sampling or input",
    )
    parser.add_argument(
        "--expect-software-renderer",
        action="store_true",
        help="Require the native window to report a software GPU adapter",
    )
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command or not (args.key or args.text is not None or args.click):
        parser.error(
            "supply an app command after -- and at least one --key, --text or --click"
        )
    if not 1 <= args.timeout <= 60:
        parser.error("--timeout must be between 1 and 60 seconds")
    if not 0 <= args.idle_seconds <= 10:
        parser.error("--idle-seconds must be between 0 and 10 seconds")
    if any(not re.fullmatch(r"[A-Za-z0-9_+]+", key) for key in args.key):
        parser.error("--key accepts xdotool key names and + modifiers only")
    try:
        validate_input_request(
            args.event_stress, args.title, args.text, args.key, args.click
        )
    except ValueError as error:
        parser.error(str(error))
    args.output.mkdir(parents=True, exist_ok=False)
    nonce = secrets.token_hex(16)
    evidence_path = args.output.resolve() / "app-events.jsonl"
    report = {
        "schema_version": 1,
        "status": "failed",
        "nonce": nonce,
        "command": command,
        "execution_mode": {"declared": args.mode, "aot_verified_by_driver": False},
        "verification_scope": "owned X11 window, OS-injected input, application event/paint reports and close",
        "platform": {
            "os": platform.platform(),
            "architecture": platform.machine(),
            "display": os.environ.get("DISPLAY"),
            "display_protocol": "X11",
            "physical_input_tested": False,
            "vulkan_driver_files": os.environ.get("VK_DRIVER_FILES"),
            "software_gl_requested": os.environ.get("LIBGL_ALWAYS_SOFTWARE"),
        },
        "renderer": {"status": "unavailable"},
        "measurements": {
            "rss_method": "sampled sum of process RSS; shared pages may be counted twice",
            "cold_cache_controlled": False,
            "launch_kind": "fresh application process; OS page cache uncontrolled",
            "observation_poll_interval_ms": 100,
            "polling_scope": "startup/window/RSS and post-command app checks; concurrent paint observation is reported separately",
            "paint_is_presentation_timestamp": False,
            "samples": [],
        },
        "checks": {
            "window": "not-run",
            "os_input": "not-run",
            "app_input_event": "unsupported",
            "native_pointer_input": "not-required",
            "app_initial_render_report": "not-required",
            "app_render_report": "unsupported",
            "native_paint_file_observation": "not-required",
            "pixel_or_text_assertion": "unsupported",
            "os_close": "not-run",
            "renderer": "not-required",
            "event_stress": "failed" if args.event_stress else "not-required",
        },
        "logs": {},
        "tools": {"python": sys.version},
    }
    app = None
    paint_observer = None
    harness_fingerprints = []
    threads = []
    observed = {}
    started = time.monotonic()
    previous_sigterm = signal.signal(signal.SIGTERM, interrupted)

    def sample(phase="interaction"):
        rows = owned_processes(app.pid, process_table())
        for row in rows:
            observed[row["pid"]] = row["start_ticks"]
        if len(rows) > 128:
            raise RuntimeError("Application process tree exceeded 128 processes")
        report["measurements"]["samples"].append(
            {
                "elapsed_ms": (time.monotonic() - started) * 1000,
                "phase": phase,
                "tree_rss_bytes": sum(row["rss_bytes"] for row in rows),
                "processes": rows,
            }
        )
        return {row["pid"] for row in rows}

    def observe_first_paint():
        records = read_events(evidence_path, nonce, 0)
        key = "time_to_first_paint_report_observed_ms"
        if key not in report["measurements"] and any(
            event.get("type") == "rendered" and event.get("stage") == "native-paint"
            for event in records
        ):
            report["measurements"][key] = (time.monotonic() - started) * 1000
        return records

    try:
        pin_file = Path(__file__).resolve().parents[2] / "toolchain.json"
        if pin_file.is_file():
            pin_bytes = pin_file.read_bytes()
            pins = json.loads(pin_bytes)
            report["intended_toolchain"] = {
                "manifest_sha256": hashlib.sha256(pin_bytes).hexdigest(),
                "bun_revision": pins["bun"]["revision"],
                "rust": pins["rust"],
                "gpui": pins["gpui"],
            }
        if sys.platform != "linux" or not os.environ.get("DISPLAY"):
            raise Unsupported(
                "A Linux X11 display is required; no native interaction was attempted"
            )
        if not proc_identity_matches():
            raise Unsupported(
                "Process IDs and /proc belong to different namespaces; ownership and RSS cannot be verified"
            )
        enable_subreaper()
        report["platform"]["child_subreaper"] = True
        missing = [tool for tool in ["xdotool", "import"] if not shutil.which(tool)]
        if missing:
            raise Unsupported(
                f"Missing native input/capture tools: {', '.join(missing)}"
            )
        report["tools"] = {
            "python": sys.version,
            "xdotool": run(["xdotool", "version"]),
            "imagemagick": run(["import", "-version"]),
        }
        try:
            report["source"] = {
                "commit": run(["git", "rev-parse", "HEAD"]),
                "dirty": bool(run(["git", "status", "--porcelain"])),
            }
        except (RuntimeError, subprocess.TimeoutExpired):
            report["source"] = {"status": "unavailable"}
        for path in [Path(__file__), PAINT_OBSERVER_PATH]:
            harness_fingerprints.append(
                {
                    "path": "scripts/quality/" + path.name,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
            )
        report["source"]["harness_files"] = harness_fingerprints
        expectations = [
            json.loads(item.replace("{nonce}", nonce)) for item in args.expect_event
        ]
        render = (
            json.loads(args.expect_render.replace("{nonce}", nonce))
            if args.expect_render
            else None
        )
        initial_render = (
            json.loads(args.expect_initial_render.replace("{nonce}", nonce))
            if args.expect_initial_render
            else None
        )
        if any(
            not isinstance(item, dict) or item.get("type") not in ["input", "click"]
            for item in expectations
        ):
            raise RuntimeError(
                "--expect-event must describe an actual input or click event"
            )
        for name, expected in [
            ("--expect-render", render),
            ("--expect-initial-render", initial_render),
        ]:
            if expected is not None and (
                not isinstance(expected, dict)
                or expected.get("type") != "rendered"
                or expected.get("stage", "native-paint") != "native-paint"
            ):
                raise RuntimeError(
                    f"{name} must describe type=rendered from native-paint, never an acknowledgement"
                )
        if args.expect_native_pointer:
            validate_native_pointer_request(
                args.click, args.key, args.text, expectations, initial_render, render
            )
            report["checks"]["native_pointer_input"] = "failed"
            report["checks"]["app_input_event"] = "not-required"
            report["verification_scope"] = (
                "owned X11 window, OS-injected click, native GPUI pointer capture, "
                "changed complete native paint and close; no application callback probe"
            )
        if args.event_stress and (
            initial_render != event_stress_fixture_paint("")
            or render != event_stress_fixture_paint(EVENT_STRESS_TEXT)
            or expectations
            != [
                {
                    "type": "input",
                    "stage": "bun-application",
                    "input_revision": EVENT_STRESS_COUNT,
                    "value": EVENT_STRESS_TEXT,
                }
            ]
        ):
            raise RuntimeError(
                "Event stress requires its complete fixed initial/final native paints and final input event"
            )
        report["scenario"] = {
            "input_mode": "event-stress" if args.event_stress else "smoke",
            "click": args.click,
            "keys": args.key,
            "text": args.text.replace("{nonce}", nonce)
            if args.text is not None
            else None,
            "expected_events": expectations,
            "native_pointer_required": args.expect_native_pointer,
            "expected_initial_render": initial_render,
            "expected_render": render,
        }
        report["native_host"] = {
            "path": os.environ.get("BUN_NATIVE_HOST"),
            "declared_profile": os.environ.get("BUN_NATIVE_HOST_PROFILE", "unreported"),
        }
        environment = dict(
            os.environ,
            BUN_NATIVE_EVIDENCE_LOG=str(evidence_path),
            BUN_NATIVE_EVIDENCE_NONCE=nonce,
        )
        if args.expect_native_pointer:
            environment["BUN_NATIVE_POINTER_TRACE"] = "1"
        started = time.monotonic()
        deadline = started + args.timeout
        app = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=environment,
            start_new_session=True,
        )
        sample("startup")
        for name, stream in [("stdout", app.stdout), ("stderr", app.stderr)]:
            stats = {"written_bytes": 0, "discarded_bytes": 0}
            report["logs"][name] = stats
            thread = threading.Thread(
                target=capture,
                args=(stream, args.output / f"{name}.log", stats),
                daemon=True,
            )
            thread.start()
            threads.append(thread)
        window = None
        while time.monotonic() < deadline:
            owned = sample("startup")
            observe_first_paint()
            if app.poll() is not None:
                raise RuntimeError(
                    f"Application exited before opening its window: {app.returncode}"
                )
            search = subprocess.run(
                [
                    "xdotool",
                    "search",
                    "--onlyvisible",
                    "--name",
                    f"^{re.escape(args.title)}$",
                ],
                check=False,
                capture_output=True,
                text=True,
                timeout=3,
            )
            for candidate in search.stdout.split()[:16]:
                if time.monotonic() >= deadline:
                    break
                if candidate.isdigit():
                    try:
                        owner = int(run(["xdotool", "getwindowpid", candidate]))
                    except (RuntimeError, ValueError):
                        continue
                    if owner in owned:
                        window = candidate
                        break
            if window:
                break
            time.sleep(0.1)
        if not window:
            raise RuntimeError(
                "Timed out waiting for an application-owned native window"
            )
        report["checks"]["window"] = "passed"
        report["measurements"]["time_to_window_observed_ms"] = (
            time.monotonic() - started
        ) * 1000
        report["window_id"] = window
        # The first traversal can contain only the root, before the app's initial
        # batch. Match the mounted tree before targeting controls or sampling idle.
        if initial_render is not None or render is not None or args.idle_seconds:
            if initial_render is not None:
                report["checks"]["app_initial_render_report"] = "failed"
            while True:
                records = observe_first_paint()
                if "time_to_first_paint_report_observed_ms" in report[
                    "measurements"
                ] and (
                    initial_render is None
                    or any(matches_paint(event, initial_render) for event in records)
                ):
                    if initial_render is not None:
                        report["checks"]["app_initial_render_report"] = "passed"
                        report["measurements"][
                            "time_to_expected_initial_paint_report_observed_ms"
                        ] = (time.monotonic() - started) * 1000
                    break
                sample("startup")
                if app.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError(
                        "The native window did not report the required initial paint"
                    )
                time.sleep(0.1)
        if args.idle_seconds:
            idle_started = time.monotonic()
            idle_end = idle_started + args.idle_seconds
            idle_rss = []
            while True:
                if app.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError(
                        "Application exited or timed out during idle sampling"
                    )
                sample("idle")
                idle_rss.append(report["measurements"]["samples"][-1]["tree_rss_bytes"])
                remaining = idle_end - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(0.1, remaining))
            report["measurements"]["idle"] = {
                "requested_seconds": args.idle_seconds,
                "observed_duration_ms": (time.monotonic() - idle_started) * 1000,
                "sample_count": len(idle_rss),
                "median_tree_rss_bytes": statistics.median(idle_rss),
                "maximum_tree_rss_bytes": max(idle_rss),
            }

        def focus():
            owner = int(run(["xdotool", "getwindowpid", window]))
            if owner not in sample():
                raise RuntimeError(
                    "Window no longer belongs to the launched application"
                )
            run(["xdotool", "windowactivate", "--sync", window])
            if run(["xdotool", "getactivewindow"]) != window:
                raise RuntimeError(
                    "Native window did not gain focus; no input was injected"
                )
            return {"pid": owner, "start_ticks": observed[owner]}

        def screenshot(name):
            path = args.output / name
            run(["import", "-window", window, "-strip", str(path)])
            report.setdefault("screenshots", {})[name] = {
                "bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }

        focus()
        screenshot("before.png")
        offset = evidence_path.stat().st_size if evidence_path.exists() else 0
        if render is not None and isinstance(render.get("nodes"), list):
            report["checks"]["native_paint_file_observation"] = "failed"
            paint_observer = PAINT_OBSERVER.PaintObserver(
                evidence_path,
                nonce,
                {"stage": "native-paint", **render},
                timeout=deadline - time.monotonic(),
            )
            paint_observer.__enter__()
        input_commands_returned_ns = None

        def input_command(command, timeout=3):
            nonlocal input_commands_returned_ns
            if paint_observer is not None and paint_observer.started_ns is None:
                paint_observer.begin()
            output = run(command, timeout=timeout)
            input_commands_returned_ns = time.monotonic_ns()
            return output

        injection_started = time.monotonic()
        report["measurements"]["input_injection_started_ms"] = (
            injection_started - started
        ) * 1000
        if args.click:
            geometry = dict(
                line.split("=", 1)
                for line in run(
                    ["xdotool", "getwindowgeometry", "--shell", window]
                ).splitlines()
            )
            x, y = args.click
            if not (
                0 <= x < int(geometry["WIDTH"]) and 0 <= y < int(geometry["HEIGHT"])
            ):
                raise RuntimeError(
                    "Click coordinates are outside the owned application window"
                )
            run(["xdotool", "mousemove", "--window", window, str(x), str(y)])
            input_command(["xdotool", "click", "1"])
        for key in args.key:
            focus()
            input_command(["xdotool", "key", "--clearmodifiers", key])
        if args.text is not None:
            focus()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise RuntimeError(
                    "Native input deadline expired before text injection"
                )
            text_started = time.monotonic()
            delay_ms = 1 if args.event_stress else 10
            input_command(
                [
                    "xdotool",
                    "type",
                    "--clearmodifiers",
                    "--delay",
                    str(delay_ms),
                    "--",
                    args.text.replace("{nonce}", nonce),
                ],
                timeout=min(10 if args.event_stress else 3, remaining),
            )
            duration_ms = (time.monotonic() - text_started) * 1000
            characters = len(args.text.replace("{nonce}", nonce))
            report["measurements"]["text_injection"] = {
                "characters": characters,
                "requested_delay_ms": delay_ms,
                "command_duration_ms": duration_ms,
                "average_command_duration_per_character_ms": duration_ms / characters
                if characters
                else None,
                "command_characters_per_second": characters * 1000 / duration_ms
                if duration_ms > 0
                else None,
                "timing_scope": "Observed xdotool command interval including subprocess and X server enqueue overhead; individual OS delivery times are not measured",
            }
        report["checks"]["os_input"] = "injected-through-XTest"
        report["measurements"]["input_injection_completed_ms"] = (
            time.monotonic() - started
        ) * 1000
        if paint_observer is not None:
            report["measurements"]["native_paint_file_observation"] = (
                paint_observer.result(input_commands_returned_ns)
            )
            report["checks"]["native_paint_file_observation"] = "passed"
            paint_observer.close()
        events = []
        input_ok = render_ok = False
        while time.monotonic() < deadline:
            sample()
            events = read_events(evidence_path, nonce, offset)
            input_ok = bool(expectations) and all(
                any(matches(event, item) for event in events) for item in expectations
            )
            if args.expect_native_pointer:
                input_ok = native_pointer_click_observed(
                    events, initial_render["window_id"], args.click
                )
            if args.event_stress:
                stress = event_stress_observations(events)
                report["measurements"]["event_stress"] = stress
                input_ok = input_ok and stress["complete"]
            render_ok = render is not None and any(
                matches_paint(event, render) for event in events
            )
            for matched, key in [
                (
                    input_ok,
                    "input_start_to_native_pointer_observed_ms"
                    if args.expect_native_pointer
                    else "input_start_to_matching_app_event_observed_ms",
                ),
                (render_ok, "input_start_to_matching_paint_report_observed_ms"),
            ]:
                if matched and key not in report["measurements"]:
                    report["measurements"][key] = (
                        time.monotonic() - injection_started
                    ) * 1000
            if input_ok and (render is None or render_ok):
                break
            if not expectations and render is None:
                break
            if app.poll() is not None:
                raise RuntimeError(
                    "Application exited before producing requested input evidence"
                )
            time.sleep(0.1)
        report["observed_events"] = events
        renderer = [
            event
            for event in read_events(evidence_path, nonce, 0)
            if event.get("type") == "renderer"
        ]
        if renderer:
            report["renderer"] = {
                "status": "reported-by-native-window",
                "gpu": renderer[-1].get("gpu"),
            }
        if args.expect_software_renderer:
            gpu = report["renderer"].get("gpu")
            software_gpu = (
                isinstance(gpu, dict)
                and gpu.get("is_software_emulated") is True
                and all(
                    isinstance(gpu.get(key), str) and gpu[key]
                    for key in ["device_name", "driver_name", "driver_info"]
                )
            )
            report["checks"]["renderer"] = "passed" if software_gpu else "failed"
        if expectations:
            report["checks"]["app_input_event"] = "passed" if input_ok else "failed"
        if args.expect_native_pointer:
            report["checks"]["native_pointer_input"] = (
                "passed" if input_ok else "failed"
            )
        if render is not None:
            report["checks"]["app_render_report"] = "passed" if render_ok else "failed"
        screenshot("after.png")
        close_owner = focus()
        report["measurements"]["os_close_requested_ms"] = (
            time.monotonic() - started
        ) * 1000
        run(["xdotool", "key", "--clearmodifiers", "alt+F4"])
        report["measurements"]["os_close_command_returned_ms"] = (
            time.monotonic() - started
        ) * 1000
        try:
            app.wait(timeout=5)
            report["measurements"]["application_exit_observed_ms"] = (
                time.monotonic() - started
            ) * 1000
            report["checks"]["os_close"] = "passed" if app.returncode == 0 else "failed"
        except subprocess.TimeoutExpired:
            report["checks"]["os_close"] = "failed"
        # Observe once after the existing close decision, before forced cleanup.
        # Missing diagnostics never change that decision or grant extra grace.
        report["close_diagnostics"] = close_window_probe(window, close_owner, started)
        try:
            report["close_diagnostics"]["process_snapshot"] = close_process_snapshot(
                observed, started
            )
            phases = [
                event
                for event in read_events(evidence_path, nonce, 0)
                if event.get("type") in ["native_window_closed", "lifecycle_phase"]
            ]
            report["close_diagnostics"]["phases"] = phases[:32]
            report["close_diagnostics"]["phases_truncated"] = len(phases) > 32
        except (OSError, ValueError, RuntimeError) as error:
            report["close_diagnostics"]["snapshot_error"] = str(error)[-2000:]
        if args.event_stress:
            # Re-read after process exit so a duplicate or late input cannot hide
            # behind the earlier matching final paint.
            events = read_events(evidence_path, nonce, offset)
            report["observed_events"] = events
            report["measurements"]["event_stress"] = event_stress_observations(
                events, require_complete=True
            )
            report["checks"]["event_stress"] = "passed"
        report["status"] = (
            "failed"
            if "failed" in report["checks"].values()
            else ("passed" if input_ok and render_ok else "partial")
        )
    except Unsupported as error:
        report.update(status="unsupported", error=str(error))
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
        report.update(status="failed", error=str(error))
    finally:
        # Finish bounded child cleanup even if a supervisor repeats termination.
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        if paint_observer is not None:
            try:
                paint_observer.close()
                report["paint_observer_cleanup"] = {
                    "reader_stopped": paint_observer.thread is None
                    or not paint_observer.thread.is_alive(),
                    "open_descriptors": len(paint_observer.descriptors),
                }
            except (OSError, RuntimeError) as error:
                report.update(
                    status="failed",
                    error=f"Native paint reader cleanup failed: {error}",
                )
        if harness_fingerprints:
            try:
                for fingerprint in harness_fingerprints:
                    path = Path(__file__).with_name(Path(fingerprint["path"]).name)
                    if (
                        hashlib.sha256(path.read_bytes()).hexdigest()
                        != fingerprint["sha256"]
                    ):
                        report.update(
                            status="failed",
                            error="Native evidence harness changed during the run",
                        )
            except OSError as error:
                report.update(
                    status="failed",
                    error=f"Cannot verify final native harness identity: {error}",
                )
        if app is not None:
            try:
                report["cleanup"] = cleanup(app, observed)
                if (
                    report["cleanup"]["remaining_observed_pids"]
                    or report["cleanup"]["unreaped_observed_pids"]
                    or (
                        args.require_unforced_cleanup
                        and report["cleanup"]["forced_termination"]
                    )
                ):
                    report.update(
                        status="failed",
                        error="Observed application processes remain or required forced cleanup",
                    )
            except (OSError, RuntimeError, subprocess.TimeoutExpired) as error:
                report.update(
                    status="failed", error=f"Application cleanup failed: {error}"
                )
        for thread in threads:
            thread.join(timeout=1)
        if any(thread.is_alive() for thread in threads):
            report.update(
                status="failed", error="Application log pipes remain open after cleanup"
            )
        elif app is not None:
            app.stdout.close()
            app.stderr.close()
        samples = report["measurements"]["samples"]
        if samples:
            report["measurements"]["sampled_peak_tree_rss_bytes"] = max(
                row["tree_rss_bytes"] for row in samples
            )
        (args.output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "status": report["status"],
                    "evidence": str(args.output / "result.json"),
                }
            )
        )
        signal.signal(signal.SIGTERM, previous_sigterm)
    return (
        0
        if report["status"] == "passed"
        else 2
        if report["status"] in ["partial", "unsupported"]
        else 1
    )


if __name__ == "__main__":
    sys.exit(main())
