#!/usr/bin/env python3
"""Collect existing completed-run bytes only; never execute archived code."""

import argparse
import gzip
import hashlib
import io
import json
import stat
import subprocess
import tarfile
import zipfile
from pathlib import Path, PurePosixPath

RUN = 41929577560
ATTEMPT = 1
HEAD = "d09ed9068b472337337e07accbf0e465f2e8c1d1"
MERGE = "d04361e69fb2b71b51a995287ac5d328f0812633"
TREE = "a906a768ceec7efaf5f47ff9ae41c8fe05876aa4"
PARENTS = ["c4de68deee812cd816316b33f9276786e6eae5c8", HEAD]
MAX_MEMBERS = 10_000
MAX_FILE = 256 * 1024 * 1024
MAX_TOTAL = 2 * 1024 * 1024 * 1024
MAX_ZIP = 512 * 1024 * 1024
MAX_RETAINED = 256 * 1024 * 1024
EXPECTED_JOBS = 12
MISSING = object()
PROTOCOL_ARTIFACTS = {
    13370124944: {
        "name": "protocol-macOS-ARM64",
        "bytes": 1188,
        "sha256": "12fe66199118d3f8284f4809cd47855f46ab7dd0df271a02f43f22527115660e",
    },
    13370468930: {
        "name": "protocol-Windows-X64",
        "bytes": 1195,
        "sha256": "181c6f9c6d1ff1920760d95e0671c3d76334ab5cc00aff729d1c678618298a51",
    },
}
PROTOCOL_MEMBERS = {"bootstrap.txt", "bun-bootstrap.log", "toolchain.txt"}
PORTABLE_LOGS = {
    "job-126922750409.log": {
        "bytes": 140238,
        "sha256": "f8a845aa880d17f74f9a32fb59dccddfb1a1d78657b1117eb37841a00a4db6dc",
    },
    "job-126922750741.log": {
        "bytes": 146032,
        "sha256": "0a930533e2ea3e0614fdcf8fd990de0ddc8cb0cff70e7fef34a5bca6601d67a7",
    },
    "job-126922750937.log": {
        "bytes": 149542,
        "sha256": "4645240968e62e175d7c02ab1df0a83b802c8b0e477d4a22a1bed169679b74fb",
    },
}
TOP_RECORDS = {
    "toolchain.txt",
    "build.log",
    "binary-sha256.txt",
    "binary-size.txt",
    "unsigned-native-host.tar.gz.sha256",
}
SOURCE_PATHS = {
    ".github/workflows/native-linux.yml",
    ".github/workflows/bun-native.yml",
    "docs/standalone-native-plan.md",
    "docs/standalone-packages-plan.md",
    "docs/standalone-projects.md",
    "toolchain.json",
    "rust-toolchain.toml",
    "Cargo.toml",
    "Cargo.lock",
    "bun.lock",
    "package.json",
    "tests/native/cli-standalone.py",
    "tests/native/cli-standalone-owner.ts",
    "tests/native/cli-owned-exec.py",
    "tests/native/cli-module-evidence.ts",
    "tests/native/cli-template-owner.ts",
    "tests/native/cli-templates.py",
    "tests/native/cli-dev-owner.ts",
    "scripts/quality/standalone-packages.py",
    "scripts/quality/standalone-package-evidence.py",
    "scripts/quality/standalone-package-inspect.ts",
    "scripts/quality/native-input-linux.py",
    "scripts/quality/native-watch-processes.py",
    "scripts/quality/native-paint-observer.py",
    "scripts/quality/native-linux-session.sh",
    "scripts/native/build.ts",
    "experiments/aot-gpui/compile.ts",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest_stream(stream, limit=MAX_FILE):
    size, sha = 0, hashlib.sha256()
    while chunk := stream.read(1024 * 1024):
        size += len(chunk)
        require(size <= limit, "Input exceeds its fixed collection bound")
        sha.update(chunk)
    return {"bytes": size, "sha256": sha.hexdigest()}


def digest(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def regular(path):
    require(stat.S_ISREG(path.lstat().st_mode), f"Expected a regular input: {path}")
    return path


def read_json(path):
    return json.loads(
        regular(path).read_bytes(),
        object_pairs_hook=unique_object,
        parse_constant=invalid_constant,
    )


def canonical(name):
    path = PurePosixPath(name)
    require(name and "\\" not in name and "\0" not in name, "Invalid archive name")
    require(
        path.parts
        and not path.is_absolute()
        and path.as_posix() == name
        and ".." not in path.parts,
        f"Noncanonical archive name: {name}",
    )
    require(":" not in path.parts[0], "Drive-qualified archive name")
    return name


def validate_jobs(value):
    require(isinstance(value, dict), "Expected the complete jobs object")
    rows = value.get("jobs")
    require(
        isinstance(rows, list)
        and type(value.get("total_count")) is int
        and value["total_count"] == len(rows) == EXPECTED_JOBS,
        "Complete original twelve-job metadata required",
    )
    identities = set()
    for job in rows:
        require(isinstance(job, dict), "Malformed original job record")
        identity = job.get("id")
        require(
            type(identity) is int and identity > 0 and identity not in identities,
            "Original job IDs must be positive integers and unique",
        )
        identities.add(identity)
        require(
            type(job.get("run_id")) is int
            and job["run_id"] == RUN
            and type(job.get("run_attempt")) is int
            and job["run_attempt"] == ATTEMPT
            and job.get("head_sha") == HEAD
            and job.get("status") == "completed",
            "Every original job must match the completed run/head/attempt",
        )
    return rows


def artifact_record(value, identity, name):
    require(
        isinstance(value, dict) and isinstance(value.get("artifacts"), list),
        "Expected the original artifacts object",
    )
    matches = [
        row
        for row in value["artifacts"]
        if isinstance(row, dict) and row.get("id") == identity
    ]
    require(len(matches) == 1, "Expected one original artifact with the requested ID")
    artifact = matches[0]
    workflow = artifact.get("workflow_run")
    require(
        isinstance(workflow, dict)
        and workflow.get("id") == RUN
        and workflow.get("head_sha") == HEAD
        and artifact.get("expired") is False
        and artifact.get("name") == name,
        "Wrong original artifact run/head/name or expired artifact",
    )
    return artifact


def member_relative(name, directory, prefix):
    if not prefix:
        return name
    if directory and name == prefix.removesuffix("/"):
        return ""
    require(name.startswith(prefix), "ZIP member is outside the declared upload root")
    return name[len(prefix) :]


def verify_archive_members(archive, retained):
    members = archive.getmembers()
    names = [member.name for member in members]
    require(
        len(names) == len(set(names)) and set(names) == set(retained),
        "Retained archive names must be unique and exactly match the retained set",
    )
    for member in members:
        canonical(member.name)
        require(member.isreg(), "Retained archive member is not regular")
        with archive.extractfile(member) as stream:
            require(
                stream.read() == retained[member.name]["data"],
                "Retained member round-trip differs",
            )


def protocol_artifact(path, artifact, expected, add):
    with regular(path).open("rb") as stream:
        data = stream.read(expected["bytes"] + 1)
    identity = digest(data)
    require(
        identity == {key: expected[key] for key in ("bytes", "sha256")}
        and identity["bytes"] == artifact.get("size_in_bytes")
        and "sha256:" + identity["sha256"] == artifact.get("digest"),
        "Original protocol ZIP differs from its fixed identity or API digest",
    )
    identity_number = artifact["id"]
    retained_zip = f"original-artifacts/artifact-{identity_number}.zip"
    add(retained_zip, data, "byte-exact original protocol environment artifact ZIP")
    members = []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        rows = archive.infolist()
        names = [row.filename for row in rows]
        require(
            len(names) == len(set(names)) and set(names) == PROTOCOL_MEMBERS,
            "Original protocol ZIP must contain the exact three environment files",
        )
        for row in rows:
            canonical(row.filename)
            require(
                not row.is_dir()
                and not row.flag_bits & 1
                and stat.S_IFMT(row.external_attr >> 16) in (0, stat.S_IFREG)
                and row.file_size <= MAX_FILE,
                "Nonregular, encrypted or oversized protocol environment member",
            )
            payload = archive.read(row)
            require(len(payload) == row.file_size, "Protocol member size differs")
            retained_path = f"protocol-environments/{identity_number}/{row.filename}"
            add(retained_path, payload, "byte-exact original protocol ZIP member")
            members.append(
                {
                    "path": row.filename,
                    "retained_path": retained_path,
                    **digest(payload),
                }
            )
    return {
        "artifact_id": identity_number,
        "artifact_name": artifact["name"],
        "workflow_run": artifact["workflow_run"],
        **identity,
        "api_digest": artifact["digest"],
        "full_zip_retained": True,
        "retained_path": retained_zip,
        "members": members,
    }


def omitted_executable_claims(result, diagnostics):
    member = "cli-standalone/result.json"
    claims = []

    def object_record(value, pointer):
        if isinstance(value, dict):
            return value
        diagnostics.append(
            {
                "member": member,
                "pointer": pointer,
                "availability": "not recorded"
                if value is MISSING
                else "malformed or partial object",
                "expected_type": "object",
                "observed_type": "absent" if value is MISSING else type(value).__name__,
                "raw_bytes_preserved_when_available": True,
            }
        )
        return None

    root = object_record(result, "")
    if root is None:
        return claims
    for key in ("bun", "host"):
        if key in root:
            object_record(root[key], "/" + key)
            claims.append(
                {"kind": key, "original_claim": root[key], "payload_retained": False}
            )
    cases = object_record(root.get("cases", MISSING), "/cases")
    if cases is None:
        return claims
    for name, value in cases.items():
        pointer = "/cases/" + name.replace("~", "~0").replace("/", "~1")
        case = object_record(value, pointer)
        if case is None:
            continue
        build = object_record(case.get("build", MISSING), pointer + "/build")
        if build is None:
            continue
        manifest = object_record(
            build.get("manifest", MISSING), pointer + "/build/manifest"
        )
        if manifest is None:
            continue
        for key in ("application", "host"):
            if key in manifest:
                object_record(manifest[key], pointer + "/build/manifest/" + key)
                claims.append(
                    {
                        "case": name,
                        "kind": key,
                        "original_claim": manifest[key],
                        "payload_retained": False,
                    }
                )
    return claims


def disposition(name):
    if name in TOP_RECORDS:
        return True, "native-job source/tool/build identity"
    if not name.startswith("cli-standalone/"):
        return False, "outside the installed-consumer collection scope"
    parts = PurePosixPath(name).parts
    if parts[1] == "owned" or parts[1:3] in (
        ("packages", "cli"),
        ("packages", "staging"),
    ):
        return False, "owned cache/consumer or duplicate staging tree"
    if "node_modules" in parts or "cache" in parts:
        return False, "installed dependency or cache payload"
    if parts[-1] in (
        "application",
        "application.exe",
        "bun-native-host",
        "bun-native-host.exe",
    ):
        return False, "large executable; preserve recorded identities separately"
    return True, "original installed-consumer record/source/archive/map/native evidence"


def outcome_fields(value, pointer=""):
    """Index claims without converting an observed claim into qualification."""
    found = []
    if isinstance(value, dict):
        for key, child in value.items():
            location = pointer + "/" + key.replace("~", "~0").replace("/", "~1")
            if key in {
                "status",
                "error",
                "secondary_errors",
                "conclusion",
                "exit_code",
                "forced_termination",
                "owned_directory_removed",
            }:
                found.append({"pointer": location, "reported_value": child})
            if isinstance(child, (dict, list)):
                found.extend(outcome_fields(child, location))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(outcome_fields(child, f"{pointer}/{index}"))
    return found


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError(f"Nonfinite JSON constant: {value}")


def git(repository, *arguments):
    return subprocess.run(
        ["git", "-C", str(repository), *arguments],
        check=True,
        capture_output=True,
        timeout=10,
    ).stdout


def collect(args):
    require(
        not args.output.exists(), "Collection output must be new; no overwrite or retry"
    )
    require(args.output.parent.is_dir(), "Collection parent must already exist")
    metadata = args.metadata.resolve(strict=True)
    run = read_json(metadata / "validation-run.json")
    jobs = read_json(metadata / "validation-jobs.json")
    artifacts = read_json(metadata / "artifacts.json")
    require(
        run["id"] == RUN and run["run_attempt"] == ATTEMPT and run["head_sha"] == HEAD,
        "Wrong run/head/attempt",
    )
    require(
        run["status"] == "completed", "Wait for the original Validation run to complete"
    )
    job_rows = validate_jobs(jobs)
    matching_jobs = [row for row in job_rows if row["id"] == args.job_id]
    require(len(matching_jobs) == 1, "Requested native job is absent from this run")
    job = matching_jobs[0]
    require(
        "GPUI release, native contracts and baselines" in job["name"], "Wrong job scope"
    )
    artifact = artifact_record(artifacts, args.artifact_id, "native-linux-X64")
    protocol_inputs = {}
    for identity_text, path in args.protocol_artifact:
        identity = int(identity_text)
        require(identity not in protocol_inputs, "Duplicate protocol artifact input")
        protocol_inputs[identity] = Path(path)
    require(
        set(protocol_inputs) == set(PROTOCOL_ARTIFACTS),
        "Supply both original protocol environment artifacts by exact ID",
    )
    with regular(args.zip).open("rb") as stream:
        zip_identity = digest_stream(stream, MAX_ZIP)
    require(
        zip_identity["bytes"] == artifact["size_in_bytes"]
        and "sha256:" + zip_identity["sha256"] == artifact["digest"],
        "Original ZIP differs from GitHub's declared bytes/digest",
    )
    require(
        git(args.repository, "show", "-s", "--format=%T", MERGE).decode().strip()
        == TREE,
        "Wrong tested source tree",
    )
    require(
        git(args.repository, "show", "-s", "--format=%P", MERGE).decode().split()
        == PARENTS,
        "Wrong tested merge parents",
    )

    retained, inventory, observations, diagnostics = {}, [], [], []

    def add(name, data, origin):
        canonical(name)
        require(name not in retained, f"Duplicate retained member: {name}")
        require(len(data) <= MAX_FILE, "Retained member exceeds bound")
        require(
            sum(len(item["data"]) for item in retained.values()) + len(data)
            <= MAX_RETAINED,
            "Retained data exceeds the fixed memory/archive bound",
        )
        retained[name] = {"data": data, "origin": origin}

    for file in sorted(metadata.iterdir()):
        require(
            file.is_file() and file.suffix == ".json",
            "Metadata directory must contain only the original JSON records",
        )
        add(
            "metadata/" + file.name,
            regular(file).read_bytes(),
            "original saved GitHub metadata",
        )
    add(
        "logs/native-job.log",
        regular(args.job_log).read_bytes(),
        "original complete decoded native-job log, no newline normalization",
    )
    add(
        "logs/gate.log",
        regular(args.gate_log).read_bytes(),
        "original complete final Gate log",
    )
    for name, identity in PORTABLE_LOGS.items():
        data = regular(args.portable_logs / name).read_bytes()
        require(
            digest(data) == identity, f"Original portable failure log changed: {name}"
        )
        add(
            "logs/" + name,
            data,
            "original completed portable failure log, including original CRLF",
        )
    for file in args.extra_log:
        add(
            "logs/" + file.name,
            regular(file).read_bytes(),
            "additional original completed-job log",
        )
    protocol_artifacts = []
    for identity, expected in PROTOCOL_ARTIFACTS.items():
        protocol_artifacts.append(
            protocol_artifact(
                protocol_inputs[identity],
                artifact_record(artifacts, identity, expected["name"]),
                expected,
                add,
            )
        )

    source = {}
    for row in git(args.repository, "ls-tree", "-rz", "--full-tree", MERGE).split(
        b"\0"
    ):
        if not row:
            continue
        header, path_bytes = row.split(b"\t", 1)
        mode, kind, blob = header.decode().split()
        path = path_bytes.decode()
        canonical(path)
        require(
            kind == "blob" and mode in ("100644", "100755"),
            "Expected regular tracked source",
        )
        data = git(args.repository, "cat-file", "blob", blob)
        source[path] = {"mode": mode, "git_blob": blob, **digest(data)}
        if path in SOURCE_PATHS:
            add("source/" + path, data, "exact tested-merge Git blob")
    require(
        len(source) == 544 and SOURCE_PATHS <= source.keys(),
        "Unexpected tested source inventory",
    )
    expected_files = {
        name: {key: value[key] for key in ("bytes", "sha256")}
        for name, value in source.items()
    }
    decoded = {}
    host_payload = None
    with zipfile.ZipFile(args.zip) as archive:
        rows = archive.infolist()
        require(
            len(rows) <= MAX_MEMBERS and sum(i.file_size for i in rows) <= MAX_TOTAL,
            "ZIP inventory exceeds collection bounds",
        )
        names = set()
        raw_names = {i.filename for i in rows}
        prefix = "" if "toolchain.txt" in raw_names else "native-evidence/"
        require(
            prefix + "toolchain.txt" in raw_names,
            "Unknown artifact root; inspect without flattening",
        )
        for item in rows:
            name = canonical(
                item.filename.removesuffix("/") if item.is_dir() else item.filename
            )
            require(
                name not in names and not item.flag_bits & 1,
                "Duplicate or encrypted ZIP member",
            )
            names.add(name)
            mode = item.external_attr >> 16
            require(
                stat.S_IFMT(mode)
                in ((0, stat.S_IFDIR) if item.is_dir() else (0, stat.S_IFREG)),
                "Nonregular ZIP member",
            )
            relative = member_relative(name, item.is_dir(), prefix)
            if item.is_dir():
                inventory.append(
                    {
                        "path": item.filename,
                        "kind": "directory",
                        "retained": False,
                        "reason": "directory metadata only",
                    }
                )
                continue
            require(item.file_size <= MAX_FILE, "ZIP member exceeds bound")
            with archive.open(item) as stream:
                identity = digest_stream(stream)
            require(identity["bytes"] == item.file_size, "ZIP declared size differs")
            keep, reason = disposition(relative)
            inventory.append(
                {
                    "path": item.filename,
                    "relative_path": relative,
                    "kind": "regular",
                    **identity,
                    "retained": keep,
                    "reason": reason,
                }
            )
            if keep:
                data = archive.read(item)
                add("artifact/" + relative, data, "byte-exact original ZIP member")
                if relative.endswith(".json"):
                    try:
                        value = json.loads(
                            data,
                            object_pairs_hook=unique_object,
                            parse_constant=invalid_constant,
                        )
                        decoded[relative] = value
                        observations.append(
                            {
                                "member": "artifact/" + relative,
                                "reported_fields": outcome_fields(value),
                            }
                        )
                    except (ValueError, UnicodeDecodeError, RecursionError) as error:
                        diagnostics.append(
                            {
                                "member": relative,
                                "parse_error": str(error),
                                "raw_bytes_preserved": True,
                            }
                        )
            if relative == "unsigned-native-host.tar.gz":
                with (
                    archive.open(item) as stream,
                    tarfile.open(fileobj=stream, mode="r|gz") as host_archive,
                ):
                    count = 0
                    for member in host_archive:
                        count += 1
                        require(
                            count == 1
                            and member.name == "bun-native-host"
                            and member.isreg()
                            and member.size <= MAX_FILE,
                            "Unexpected unsigned-host archive inventory",
                        )
                        host_payload = digest_stream(host_archive.extractfile(member))
                        require(
                            host_payload["bytes"] == member.size,
                            "Host member size differs",
                        )
                    require(count == 1, "Empty unsigned-host archive")

    for name in ("cli-standalone/result.json", "cli-standalone/packages/manifest.json"):
        value = decoded.get(name)
        if isinstance(value, dict) and isinstance(value.get("source"), dict):
            claim = value["source"]
            observations.append(
                {
                    "member": "artifact/" + name,
                    "source_claim_matches_tested_merge": claim.get("commit") == MERGE
                    and claim.get("tree") == TREE
                    and claim.get("files") == expected_files,
                }
            )
        else:
            diagnostics.append(
                {
                    "member": name,
                    "availability": "missing or unparseable; no phase completion inferred",
                }
            )
    omitted_claims = omitted_executable_claims(
        decoded.get("cli-standalone/result.json", MISSING), diagnostics
    )
    limits = [
        "Collection preserves raw claims; it does not independently certify any native or AOT acceptance predicate.",
        "The full original native ZIP is not embedded. Every original native member is inventoried and hashed, including omitted members. Both original protocol environment ZIPs and their exact three members are retained and indexed separately.",
        "Caches, installed node_modules, large application/host/Bun binaries and duplicate staging trees are omitted; original recorded hashes remain where available.",
        "The hosted source does not copy dist/compile-aot.stdout.log, dist/compile-aot.stderr.log or launcher.ts before excluding/removing owned consumers. Do not reconstruct those missing bytes or claim they are retained.",
        "An early failure can precede per-case generated-source, installed-lock or build copies. Missing/partial/unparseable evidence remains missing/partial/unparseable.",
        "No existing result is reclassified. First and secondary errors remain in byte-exact raw records and the complete native-job log.",
        "Other native scenarios are omitted from this focused archive; their job-step outcomes remain in original complete metadata/logs.",
    ]
    add(
        "collection/collector.py",
        Path(__file__).read_bytes(),
        "collector source, not executed artifact code",
    )
    add(
        "collection/plan.md",
        Path(__file__).with_name("plan.md").read_bytes(),
        "predeclared collection plan",
    )
    args.output.mkdir()
    target = args.output / "original-evidence.tar.gz"
    with (
        target.open("xb") as output,
        gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as compressed,
        tarfile.open(fileobj=compressed, mode="w|", format=tarfile.USTAR_FORMAT) as tar,
    ):
        for name, entry in sorted(retained.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(entry["data"]), 0o644, 0
            tar.addfile(info, io.BytesIO(entry["data"]))
    with tarfile.open(target, "r:gz") as tar:
        verify_archive_members(tar, retained)
    with target.open("rb") as stream:
        retained_identity = digest_stream(stream, MAX_TOTAL)
    records = {
        "source": {
            "head": HEAD,
            "tested_merge": MERGE,
            "tree": TREE,
            "parents": PARENTS,
            "tracked_files": source,
        },
        "original_zip": {
            "artifact_id": args.artifact_id,
            "artifact_name": artifact["name"],
            **zip_identity,
            "api_digest": artifact["digest"],
            "full_zip_retained": False,
        },
        "original_protocol_artifacts": protocol_artifacts,
        "run": {
            "id": RUN,
            "attempt": ATTEMPT,
            "reported_status": run["status"],
            "reported_conclusion": run["conclusion"],
        },
        "native_job": {
            "id": job["id"],
            "name": job["name"],
            "reported_conclusion": job["conclusion"],
            "steps": job["steps"],
        },
        "complete_job_set_binding": {
            "count": EXPECTED_JOBS,
            "unique_ids": [row["id"] for row in job_rows],
            "run_id": RUN,
            "run_attempt": ATTEMPT,
            "head_sha": HEAD,
            "all_completed": True,
        },
        "archive": {
            "path": target.name,
            **retained_identity,
            "members": len(retained),
            "round_trip_verified": True,
        },
        "actual_host_payload_hash_only": host_payload,
        "observed_claims": observations,
        "missing_or_unparseable": diagnostics,
        "omitted_executable_claims": omitted_claims,
        "scope_limits": limits,
        "independent_native_predicate_audit": "pending; collection alone grants no acceptance",
    }
    for name, value in (
        ("collection-receipt.json", records),
        ("full-zip-inventory.json", inventory),
        (
            "retained-members.json",
            [
                {"path": name, **digest(entry["data"]), "origin": entry["origin"]}
                for name, entry in sorted(retained.items())
            ],
        ),
    ):
        (args.output / name).write_text(json.dumps(value, indent=2) + "\n")
    print(
        json.dumps(
            {
                "collection": str(args.output),
                "archive": retained_identity,
                "members": len(retained),
                "native_acceptance_audit": "pending",
            }
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "zip",
        "metadata",
        "job-log",
        "gate-log",
        "portable-logs",
        "repository",
        "output",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--job-id", type=int, required=True)
    parser.add_argument("--artifact-id", type=int, required=True)
    parser.add_argument(
        "--protocol-artifact",
        nargs=2,
        action="append",
        required=True,
        metavar=("ARTIFACT_ID", "ORIGINAL_ZIP"),
    )
    parser.add_argument("--extra-log", type=Path, action="append", default=[])
    collect(parser.parse_args())


if __name__ == "__main__":
    main()
