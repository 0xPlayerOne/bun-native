# First hosted installed-consumer archive collection plan

**Prepared, not executed. No outcome is recorded by this plan.** The collector
only reads already downloaded, completed-run bytes and local Git objects. It has
no network operation and never imports or executes an archived package,
controller, generated application, compiler, host, test or native workload.

## Fixed source and run

| Identity | Value |
| --- | --- |
| Pull request | #388 |
| Published head | `d09ed9068b472337337e07accbf0e465f2e8c1d1` |
| Actual tested merge | `d04361e69fb2b71b51a995287ac5d328f0812633` |
| Tree | `a906a768ceec7efaf5f47ff9ae41c8fe05876aa4` |
| Merge parents | accepted `c4de68deee812cd816316b33f9276786e6eae5c8`, then the published head |
| Validation | `41929577560`, attempt **1** |
| CodeQL | `41929578336`, attempt **1**; preserve separately if supplied |
| Tracked source | 544 regular Git files |
| Native artifact | `native-linux-X64`; numeric artifact/job IDs are supplied only after completion |

Root coordinates the completed-artifact download and independent audits. No
running artifact is downloaded. Before collecting a durable final archive, obtain
the original completed Validation run, complete attempt-1 jobs and artifact
metadata. Supply the original native job log with its existing bytes/newlines,
and final Gate/CodeQL metadata/logs when available. Do not replace any failed
record with a later observation or run. This collector accepts only the fixed
head, merge/tree, Validation run and attempt above.

## Inputs and output boundary

The metadata directory must contain the original saved REST JSON objects named
`validation-run.json`, `validation-jobs.json` and `artifacts.json`. The jobs object
must include exactly all 12 completed jobs and `total_count`. Every job must have
a unique positive integer ID and match the fixed run ID, attempt and published
head; a mixed-source or mixed-attempt list is rejected even if its selected native
job matches. Additional original `.json` metadata is retained unchanged, including
tested-merge, checks, CodeQL or full Gate-needs records. The native job's numeric ID
and the completed native artifact's numeric ID are required arguments. The ZIP's
size and SHA-256 must match the selected API artifact record before any archive is
written. The native artifact and both protocol environment artifacts must also
match their original API run/head/name records. Metadata is not normalized or
reserialized inside the retained archive.

The two already downloaded original protocol environment ZIPs are separate,
mandatory artifact inputs, with these fixed identities:

| Artifact ID | Original API name | Bytes | SHA-256 |
| --- | --- | --- | --- |
| 13370124944 | `protocol-macOS-ARM64` | 1,188 | `12fe66199118d3f8284f4809cd47855f46ab7dd0df271a02f43f22527115660e` |
| 13370468930 | `protocol-Windows-X64` | 1,195 | `181c6f9c6d1ff1920760d95e0671c3d76334ab5cc00aff729d1c678618298a51` |

Each ZIP must match both its fixed byte identity and the final artifacts API
record. Retain the complete original ZIP and all three regular members
(`bootstrap.txt`, `bun-bootstrap.log`, `toolchain.txt`) unchanged, with their own
byte/hash index. They are not job logs or inputs to `--extra-log`.

The output directory must be new. No existing record is overwritten or deleted.
After the actual artifact arrives, the explicit collector command is:

```sh
python3 collect.py \
  --zip /absolute/original-native-linux.zip \
  --metadata /absolute/completed-original-metadata \
  --job-log /absolute/original-native-job.log \
  --gate-log /absolute/original-final-gate.log \
  --portable-logs /workspace/scratch/2c5e94c456dd/standalone-hosted-d09-audit \
  --protocol-artifact 13370124944 /workspace/scratch/2c5e94c456dd/standalone-hosted-d09-audit/artifact-13370124944.zip \
  --protocol-artifact 13370468930 /workspace/scratch/2c5e94c456dd/standalone-hosted-d09-audit/artifact-13370468930.zip \
  --job-id ACTUAL_COMPLETED_JOB_ID \
  --artifact-id ACTUAL_COMPLETED_ARTIFACT_ID \
  --repository /absolute/existing-bun-native-checkout \
  --output /absolute/new-collection
```

`--extra-log` may be repeated for original final Gate or other relevant completed
job logs. This is a prepared invocation with placeholders, not an executed
command. It is not a workflow dispatch, native retry or acceptance decision.

The collector refuses links, special files, encrypted/duplicate/noncanonical ZIP
members and path traversal. It permits at most 10,000 ZIP entries, a 512 MiB ZIP,
256 MiB per original member, 2 GiB total declared payload and 256 MiB retained
in-memory/archive payload. It reads and hashes
every regular member without extracting it into the repository. The known upload
root is either flat or one `native-evidence/` prefix. When that prefix is selected,
every non-root member must belong to it; mixed flat/nested members are rejected.
Another layout requires inspection rather than automatic arbitrary flattening. These are collection
resource bounds, not changes to any test deadline or native assertion.

## Retained bytes

Retain every available regular file beneath `cli-standalone/` except the explicit
large/temporary exclusions below. This includes:

- The original aggregate `result.json`, including all first and secondary errors,
  terminal or unfinished command records, saved source/Bun/host identities,
  process identities, joins, signal/exit outcomes and final cleanup observations.
- Every producer and consumer stdout/stderr log and command receipt; package-set
  manifest and all seven source package archives. Failed partial production stays
  partial and is retained when uploaded.
- Generated source/configuration, original seed locks and vendor inputs, installed
  locks/import/file receipts, cache inventory, Cargo/Rust sentinel files and any
  recorded invocation log. These do not substitute for omitted cache contents.
- AOT manifests and actual development modules/maps retained by the controller,
  plus ready-time development CLI modules/maps in each native case.
- Every available native case's original IPC/lifecycle/result JSON, raw native
  paint/input JSONL, process/close observations, stdout/stderr, before/after PNGs
  and isolated window-manager/session logs.
- Top-level toolchain, native build log, host hash/size and unsigned-host archive
  checksum records; complete original native job log and supplied metadata.
- The three already completed original portable failure logs
  `job-126922750409.log` (140,238 bytes), `job-126922750741.log` (146,032 bytes)
  and `job-126922750937.log` (149,542 bytes), plus the eventual final Gate log.
  The collector binds each portable log to its separately verified SHA-256;
  the Windows log's original 1,372 CRLF sequences are preserved. These failures
  remain separate from the installed native results and their independent audit.
- Both original protocol environment ZIPs and their six original member files,
  individually indexed as artifacts rather than logs.
- Exact tested-merge controller, receipt, oracle, workflow, build and toolchain
  source snapshots. The full 544-file tracked-source inventory is reconstructed
  from Git, including file mode, blob ID, byte count and SHA-256.

All retained original file bytes are copied unchanged. Archive member names are
portable and provenance is indexed. Gzip/TAR metadata is normalized; the collector
round-trips every retained member and checks unique reconstructed names, exact
name-set equality and exact byte equality. It emits
`original-evidence.tar.gz`, `retained-members.json`, `full-zip-inventory.json` and
`collection-receipt.json`. The last file is an authored collection index, not a
rewritten original result.

## Omitted data and observed gaps

The complete original native ZIP is not embedded in the focused durable archive.
Its ID, size, digest and every original member's size/hash/disposition remain in
the inventory. Other native scenarios' raw data is omitted; their original step
outcomes remain in the complete job metadata/log, with no individual predicate
audit implied.

Owned caches, `node_modules`, duplicate producer staging/unpacked-CLI trees and
large AOT application/host/Bun binaries are omitted. When present in the original
ZIP they are still hashed and inventoried. Recorded executable identities are
copied from original receipts without pretending those omitted bytes can be
reinspected from the archive. If the separate unsigned-host archive is available,
the collector reads its one regular host member and verifies/hashes the actual
payload without retaining or executing the binary.

The measured controller copies `dist/manifest.json` and `dist/development/`, but
does **not** copy `dist/compile-aot.stdout.log`, `dist/compile-aot.stderr.log` or
`dist/launcher.ts` before its owned projects are excluded/removed. Those bytes are
therefore not promised by this archive. The owning CLI command logs and build
manifest remain distinct from the compiler child's full explain output.

An early failure may precede generated-source, installed-lock or build-receipt
copies. The collector records missing or malformed JSON and preserves every
available raw byte. Syntactically valid partial records, including null/list
`cases`, null cases and invalid nested build/manifest objects, receive explicit
shape diagnostics instead of aborting the archive or being treated as success.
It does not fabricate absent files, infer completion because
execution advanced, or require an expected success status in order to preserve a
failure. A source-claim mismatch is surfaced separately from the original record.

## Outcome and independent audit

Collection indexes original reported statuses/errors verbatim with JSON pointers;
it does not declare the native matrix passed. The archive's final README and
audited outcome are written only after the completed artifact and raw records are
inspected. Independently verify actual source/tool/host binding, every executed
case's full 0→1 native paint, fresh pointer pair, OS close, IPC zero counters,
joined unforced ownership and omitted/not-run cases. Preserve earlier unrelated
failures and overall Validation/Gate status separately.

The prior local `cba506b` pass remains the distinct result in closed research
archive #403. Earlier #394/#397/#400 failures remain unchanged. This collection
does not qualify watch, physical GPU, accessibility/IME, additional platforms,
long soak, signing or performance budgets.

## Collector preparation controls

Seven inert data-only controls exercise the actual collector helpers: complete
failed-job retention, mixed identity/duplicate job rejection, malformed nested
JSON handling, mixed upload-root rejection, duplicate/missing TAR round-trip
members, API artifact identity binding, and exact synthetic protocol ZIP/member
retention with invalid-member negatives. They create only temporary synthetic
data and do not call `collect()`, read the original ZIPs, execute artifact code,
or qualify an application. Their log and the source hashes are separate
preparation evidence; the real collection still awaits final read-only review.
