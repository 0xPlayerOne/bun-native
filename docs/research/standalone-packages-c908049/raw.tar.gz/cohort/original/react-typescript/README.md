# react-typescript

This standalone project carries its local Bun Native package archives in `vendor/bun-native`. Commit that directory with this project. Its source snapshot is `c90804933034ccc942467de8eb47379d8ee47e71`; use Bun revision `da867c60bf0bcbf9d6d36994f8ca0efa42075115`. No checkout paths or workspace links are required.

The initial `bun.lock` seeds the exact existing external dependency graph. First run `bun install --offline --ignore-scripts --linker hoisted --backend copyfile` with a populated package cache. An empty offline cache must fail; the local archives do not contain the third-party packages. Preserve the resulting lock, then use `bun install --offline --frozen-lockfile --ignore-scripts --linker hoisted --backend copyfile` for subsequent installs and relocation. The CLI never installs packages implicitly.

- `bun run check` checks TypeScript or checked JavaScript.
- `bun run dev --host /absolute/path/to/bun-native-host` bundles and opens the app once.
- Add `--watch` to remount after source edits with joined teardown. State resets; state-preserving hot reload is not implemented.
- `bun run build --host /absolute/path/to/bun-native-host --host-profile release` creates an unsigned same-platform AOT app in `dist`. The output directory must be empty.

Supply a separately acquired, compatible prebuilt native host. These commands never download it or run Cargo. Keep the template's optional development IPC hooks: they report readiness and join renderer/application/host cleanup. The archives are private experimental source packages, not a signed registry release. Their checksums establish consistency with the supplied manifest; verify that manifest's origin separately.

Solid uses the universal JSX transform with `jsx: preserve`; its `jsx-runtime` export supplies types, not React-style automatic JSX functions. React uses its native JSX runtime. DOM/WebView APIs and browser component libraries are unsupported. See [the source-bound tooling documentation](https://github.com/0xPlayerOne/bun-native/blob/c90804933034ccc942467de8eb47379d8ee47e71/docs/developer-tooling.md) for the native/platform and measurement limits.
