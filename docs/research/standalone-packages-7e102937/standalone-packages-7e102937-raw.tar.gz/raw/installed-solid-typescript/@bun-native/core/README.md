# @bun-native/core

Private experimental Bun Native source package from [7e102937bb7af362db59bddd1ab92b664386cd52](https://github.com/0xPlayerOne/bun-native/tree/7e102937bb7af362db59bddd1ab92b664386cd52). Install through its local package-set manifest and pinned consumer lock. Use Bun revision da867c60bf0bcbf9d6d36994f8ca0efa42075115; supply the compatible native host explicitly. No registry release or platform signing is implied. Original license notice is retained in LICENSE.
